﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>


struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// System.Comparison`1<WindBot.Game.ClientCard>
struct Comparison_1_tCB6C68013648AE60E26CAC7EB38ADFF7FD206D46;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Func`2<WindBot.Game.ClientCard,System.Boolean>>
struct Dictionary_2_t8A1454E151C07322C358242DF1647EBCA3D20773;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Func`3<WindBot.Game.ClientCard,System.Collections.Generic.List`1<WindBot.Game.ClientCard>,System.Boolean>>
struct Dictionary_2_t8C0665560BCD0EB04534B6117705CA76262B784E;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32>
struct Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180;
// System.Func`1<System.Boolean>
struct Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457;
// System.Func`2<WindBot.Game.ClientCard,System.Boolean>
struct Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2;
// System.Collections.Generic.IDictionary`2<System.Int32,System.Int32>
struct IDictionary_2_tD7429CE1A1D78F0C391515DA897DD0EB3091757E;
// System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>
struct IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A;
// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardAttribute>
struct IList_1_t0E3CC48D673DBF61FF11ECE603848D3138E65E52;
// System.Collections.Generic.IList`1<WindBot.Game.AI.CardExecutor>
struct IList_1_t487D3D3DA8AC9A8717F7E664B7F421B510F80F13;
// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardPosition>
struct IList_1_tD6CB88B0A2ECE6556772ECA37C4408E350E6B79A;
// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardRace>
struct IList_1_t85B6BECC8692BD6D60BE29C739EF572B5FCD446F;
// System.Collections.Generic.IList`1<WindBot.Game.AI.CardSelector>
struct IList_1_tAC3B7EAD5BB81FF7519E6AEEFC130F05F5BEC919;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard>
struct IList_1_tD6D9B2CE0D00AAAF921ECAFFCEA43E0942094AA0;
// System.Collections.Generic.IList`1<System.Int32>
struct IList_1_tFB8BE2ED9A601C1259EAB8D73D1B3E96EA321FA1;
// System.Collections.Generic.IList`1<System.Object>
struct IList_1_t6EE90D273EFCF5E7E4C37FAB712E70BB6F1B4BFF;
// System.Collections.Generic.List`1<WindBot.Game.ClientCard>
struct List_1_tFD3517A71322E467BC146AEAF76EC021968D868F;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73;
// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D;
// System.Byte[]
struct ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031;
// System.Char[]
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
// WindBot.Game.ClientCard[]
struct ClientCardU5BU5D_t920986C159D59CAC4045BE02C84E9885D39EAE39;
// WindBot.Game.ClientField[]
struct ClientFieldU5BU5D_t66AC8C298450829D5148BE66B83BE8F7C24AA3DD;
// System.Delegate[]
struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771;
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
// WindBot.Game.AI.AIUtil
struct AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF;
// System.AsyncCallback
struct AsyncCallback_t7FEF460CBDCFB9C5FA2EF776984778B9A4145F4C;
// WindBot.Game.BattlePhase
struct BattlePhase_tB98E96A1E999317CDA55AF9A088CA9821CAF00C2;
// WindBot.Game.AI.CardSelector
struct CardSelector_tD75C4F33C8AF35886287569D762948336D850D13;
// WindBot.Game.ClientCard
struct ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59;
// WindBot.Game.ClientField
struct ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7;
// WindBot.Game.AI.DefaultExecutor
struct DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317;
// System.DelegateData
struct DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E;
// WindBot.Game.AI.Dialogs
struct Dialogs_t8658B7B0342102EC5C4614D8FFD96B8A85F9DC5E;
// WindBot.Game.Duel
struct Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D;
// WindBot.Game.AI.Executor
struct Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083;
// WindBot.Game.GameAI
struct GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963;
// WindBot.Game.GameClient
struct GameClient_t5A33670CD7BB53EF0570C5CE18D21CCA688D12A0;
// System.IAsyncResult
struct IAsyncResult_t7B9B5A0ECB35DCEC31B8A8122C37D687369253B5;
// WindBot.Game.MainPhase
struct MainPhase_tF8EAFFFF36B94E244A2142388709CB36CCBFF1E7;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// YGOSharp.OCGWrapper.NamedCard
struct NamedCard_tEB4CE4D34CA54A76C86A9D7DDB9D5BBC838C5015;
// System.String
struct String_t;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
// WindBot.Game.AI.Decks.ZefraExecutor
struct ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48;
// WindBot.Game.AI.Decks.ZexalWeaponsExecutor
struct ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E;
// WindBot.Game.AI.Decks.ZoodiacExecutor
struct ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA;
// WindBot.Game.AI.Decks.ZefraExecutor/<>c
struct U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87;
// WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0
struct U3CU3Ec__DisplayClass77_0_tE895338B8B0F926B323A6BF3F2F9A7EF5573FF3E;
// WindBot.Game.AI.Decks.ZefraExecutor/Func
struct Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F;
// WindBot.Game.AI.Decks.ZexalWeaponsExecutor/CardId
struct CardId_tDC859E1E9CD22AAF608046410ACC38ABA2A950DA;
// WindBot.Game.AI.Decks.ZoodiacExecutor/CardId
struct CardId_t493C1F60A0CFB6BE32EA7E39991862ACF80A4E3C;
// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0
struct U3CU3Ec__DisplayClass17_0_t3C4D4EE7E6524FB29D68B9043B03E17A15D9BBDD;
// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0
struct U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C;
// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0
struct U3CU3Ec__DisplayClass32_0_t9A72BB44DF8E46921AB9AC829D6D7C0BBBD875A9;
// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0
struct U3CU3Ec__DisplayClass35_0_t92CE76AB7A9281F20FE93D2F38778051384ADC9E;
// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate
struct Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE;

IL2CPP_EXTERN_C RuntimeClass* Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tFD3517A71322E467BC146AEAF76EC021968D868F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____108710702D56B721FE6351364171D9FE220305A52FF09CA45DBB65E1CEB31854_23_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4658A9F91C7899BAA1F32C6D7A573540CF1559A1AF3BD98BB87294BC7252A8F9_89_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4E90313FD2428587A82788026D3458A35F4A9F16ED24BBB4C45C92DF07C5E31F_97_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5593F1AAE0656CCB5BE70A58C6CED4F7CFED42BC8DD0ADE1B33AE7FC14C68591_105_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5B4CF157C2F10921822CD7687881E5DC2824083C35BBF544252DC35C49B896AD_112_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____66E5E7AB424DD096605E51332FF630ADED08E0DE27F408C52F23E62160961EB1_132_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____773C6CE57E1CA4558EE8D2F9F84478B08F5C4AFDA39E2A0E7AE2ABD5DDC234E9_156_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____A907C56D065442866F76567FE30FA552330DC6BBA117DA02C49CBF28C0A5BA47_212_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____B10B006404D9DA431F45BF1F6465B990B1496FFFDA5432E063E134E351C345E1_220_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C39E75F0FDE9B5E6330B103A1120EDA05C092A7C02409AE33215F94481761233_251_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C8185DC090901A187F7582AE1A540C37D260DECB8A5B092C4D8A79B789289F57_258_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____DE5859B5A095EEC3948A5BD9656FF92406D576751581F174EBC6F38C517B1E28_293_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____E9484E9181F8FEDF2C097076D63594DE2E285F7EEBCAE6303F4AAE44490FDFF4_305_FieldInfo_var;
IL2CPP_EXTERN_C RuntimeField* U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____FEA9F4CA8688E2AAC63B626BFBD34208AFCABFBD900A072570214FF1D5E94D9F_342_FieldInfo_var;
IL2CPP_EXTERN_C const RuntimeMethod* Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultBreakthroughSkill_m09BB7FC45F746E9DDDBD3B241A510540A98C7B7B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultDarkHole_mB9930C5974260886FF733F8C03649F5463745299_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultHonestEffect_m9DAA75B44D48D55E94C10E94D21FBC8FD308ED20_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultInterruptedKaijuSlumber_mD6A134DB30D2D34F4E1F54B6489114C11D0D4191_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultMysticalSpaceTyphoon_mA2B4FCE8324CD396BA235FD5DC3333CA92C3DF97_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultNumberS39UtopiaTheLightningEffect_mCE1E815E90A7A6465C667AEA3CC49D863DE3D80D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultNumberS39UtopiaTheLightningSummon_m9E867AFB489F0DF1BA5CED4D37B7800694F78E33_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultRaigeki_mC2CB36381BD51664EAA5460889ACA0C87F8E7B39_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultSolemnStrike_m00FC454C344F9E5BE6E56427AD6C0FC18D6531D9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultSolemnWarning_mA3F68F34432CCA786CA975746DB944073FC80E9C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultSpellSet_mFA02D4DE014BC67FA51265209892217571E194FC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* DefaultExecutor_DefaultTrap_mF6AF4A6CC17A4E3FC40BEB6BB0CC3F00645C3998_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m16C7DC8619DE24DE2760056021DBB52CBB19ACAF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mFD01966772F1C308D34514243361686DB88A421C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_1_m9D9AA859E7842E7C099EB279A2799B3EB03A756C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_2_mDF19FC72939BFC468F6E328844F567C4744D31B7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_GoblindberghEffect_m9ED19382B54E4C7D282E40AEF4F80FDD85DED5C8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_GoblindberghFirst_m8372ECC4F98346513FEB08E4BF1C6231D6F7F04A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_InstantFusion_mEDE9589E1BB7FE9DC6B37E1A2047C3CF3FC3B2A0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_KagetokageEffect_mA8E9E94B0B519E16D20E34F30371A0F59A615153_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_MonsterRepos_m63077AD390EC67DF9BC08EEDCD29C2AFA2910F5D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_Number39Utopia_mE132513090DE325CBDD4FEE725E0552873F35A03_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_Number61Volcasaurus_mCC4DD0DADA3EEADF91DDA02206F4C2788BBE79BC_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_ReinforcementOfTheArmy_m1E095C372509A4D8124D81908DEA172F2F213ADF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_SolarWindJammer_m2342B5EFE3BB8554E7D8C15B48389370B8C711BA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_SummonerMonkEffect_mC0B24686D98130FD7EC3D139A8390E6EFC8AE524_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_XyzChangeTactics_m763EA06DB8884BC07AD75CFD65610CA6597A5510_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_ZwLionArms_mD1CDB1ADCC0ACB04278F406CF8330EC6D1D4136D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_AleisterTheInvokerEffect_mF7CC8E892AEC5AA225341B545945D076944B7E33_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_BroadbullEffect_m58423C9AEF280904C98C1F98A59309DDC0167853_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_BroadbullSummon_m2B7299A2A14FF5F212DAC18B9785D3E075307DA6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_BroadbullXYZSummon_mE970E9CC798A0C5CFF07BDC5A683268BB27BE8CA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_ChakanineEffect_mBF76840856B026046F1C53523EB6744ADE29A124_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_ChakanineSummon_m99FA65841520A8057D3F5A0843A668F1C95365DB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_DaigustoEmeralEffect_m35420E1998490817CF77BB6F5FEE2EC0D9A5CAF3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_DaigustoEmeralSummon_m0E1AB7FB015BD4534E63E320D2021DDEE2D12677_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_DridentEffect_m49B4EDBE2FC4DBBB43031BCD06F764FF124D0141_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_DridentSummon_mE76044F95CF9E22E2F692FC8142A35189AAAA7A6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_FireFormationTenkiEffect_mAA0B505305FDC869DB24CA34A240BF16828AF05C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_InvocationEffect_mC0FF065213093F9AF9858B7032B83EA62C508553_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_MonsterRebornEffect_m2CAF7F71963167C4947B2776333EAB377CC68EEA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_MonsterRepos_mB1E09B2A017BB01CA5C26FFB68B957BB2627B2B4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_PhotonThrasherSummon_m45C0C8DBBCC1A48A118DB318A06B40F2DA3BC6D8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_RatpierEffect_m4A512209CB118E70E4784E51DFDA1C714235B827_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_RatpierMaterialEffect_mA083061D495C295650BF2551FA4B2DD67F6F0335_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_TigermortarEffect_m89C12A32939C22435DC8B937DFB47BBB1E0C7985_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_TigermortarSummon_m265F2BEEFDD7D5C119BF7B516BDE5662400A6BF9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_WhiptailEffect_mB911200A480506535F01029F54B88D405ED49CB6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_ZoodiacBarrageEffect_mE7FC8E95902A2F19ECE91861D5970CE112731FDB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ZoodiacExecutor_ZoodiacComboEffect_mF31C9066BB24F5001AD5A6205826AC35B8B56A96_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;

struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.EmptyArray`1<System.Object>
struct EmptyArray_1_tDF0DD7256B115243AA6BD5558417387A734240EE  : public RuntimeObject
{
};

// System.Collections.Generic.List`1<WindBot.Game.ClientCard>
struct List_1_tFD3517A71322E467BC146AEAF76EC021968D868F  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ClientCardU5BU5D_t920986C159D59CAC4045BE02C84E9885D39EAE39* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.Int32>
struct List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA  : public RuntimeObject
{
};

// WindBot.Game.AI.AIUtil
struct AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF  : public RuntimeObject
{
	// WindBot.Game.Duel WindBot.Game.AI.AIUtil::<Duel>k__BackingField
	Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___U3CDuelU3Ek__BackingField_0;
	// WindBot.Game.ClientField WindBot.Game.AI.AIUtil::<Bot>k__BackingField
	ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* ___U3CBotU3Ek__BackingField_1;
	// WindBot.Game.ClientField WindBot.Game.AI.AIUtil::<Enemy>k__BackingField
	ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* ___U3CEnemyU3Ek__BackingField_2;
};

// WindBot.Game.ClientField
struct ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7  : public RuntimeObject
{
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::<Hand>k__BackingField
	RuntimeObject* ___U3CHandU3Ek__BackingField_0;
	// WindBot.Game.ClientCard[] WindBot.Game.ClientField::<MonsterZone>k__BackingField
	ClientCardU5BU5D_t920986C159D59CAC4045BE02C84E9885D39EAE39* ___U3CMonsterZoneU3Ek__BackingField_1;
	// WindBot.Game.ClientCard[] WindBot.Game.ClientField::<SpellZone>k__BackingField
	ClientCardU5BU5D_t920986C159D59CAC4045BE02C84E9885D39EAE39* ___U3CSpellZoneU3Ek__BackingField_2;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::<Graveyard>k__BackingField
	RuntimeObject* ___U3CGraveyardU3Ek__BackingField_3;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::<Banished>k__BackingField
	RuntimeObject* ___U3CBanishedU3Ek__BackingField_4;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::<Deck>k__BackingField
	RuntimeObject* ___U3CDeckU3Ek__BackingField_5;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::<ExtraDeck>k__BackingField
	RuntimeObject* ___U3CExtraDeckU3Ek__BackingField_6;
	// System.Int32 WindBot.Game.ClientField::LifePoints
	int32_t ___LifePoints_7;
	// WindBot.Game.ClientCard WindBot.Game.ClientField::BattlingMonster
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___BattlingMonster_8;
	// System.Boolean WindBot.Game.ClientField::UnderAttack
	bool ___UnderAttack_9;
};

// WindBot.Game.GameAI
struct GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963  : public RuntimeObject
{
	// WindBot.Game.GameClient WindBot.Game.GameAI::<Game>k__BackingField
	GameClient_t5A33670CD7BB53EF0570C5CE18D21CCA688D12A0* ___U3CGameU3Ek__BackingField_0;
	// WindBot.Game.Duel WindBot.Game.GameAI::<Duel>k__BackingField
	Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___U3CDuelU3Ek__BackingField_1;
	// WindBot.Game.AI.Executor WindBot.Game.GameAI::<Executor>k__BackingField
	Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* ___U3CExecutorU3Ek__BackingField_2;
	// WindBot.Game.AI.Dialogs WindBot.Game.GameAI::_dialogs
	Dialogs_t8658B7B0342102EC5C4614D8FFD96B8A85F9DC5E* ____dialogs_3;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> WindBot.Game.GameAI::_activatedCards
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ____activatedCards_4;
	// WindBot.Game.AI.CardSelector WindBot.Game.GameAI::m_materialSelector
	CardSelector_tD75C4F33C8AF35886287569D762948336D850D13* ___m_materialSelector_5;
	// System.Int32 WindBot.Game.GameAI::m_materialSelectorHint
	int32_t ___m_materialSelectorHint_6;
	// System.Int32 WindBot.Game.GameAI::m_place
	int32_t ___m_place_7;
	// System.Int32 WindBot.Game.GameAI::m_option
	int32_t ___m_option_8;
	// System.Int32 WindBot.Game.GameAI::m_number
	int32_t ___m_number_9;
	// System.Int32 WindBot.Game.GameAI::m_announce
	int32_t ___m_announce_10;
	// System.Int32 WindBot.Game.GameAI::m_yesno
	int32_t ___m_yesno_11;
	// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardAttribute> WindBot.Game.GameAI::m_attributes
	RuntimeObject* ___m_attributes_12;
	// System.Collections.Generic.IList`1<WindBot.Game.AI.CardSelector> WindBot.Game.GameAI::m_selector
	RuntimeObject* ___m_selector_13;
	// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardPosition> WindBot.Game.GameAI::m_position
	RuntimeObject* ___m_position_14;
	// System.Int32 WindBot.Game.GameAI::m_selector_pointer
	int32_t ___m_selector_pointer_15;
	// System.Collections.Generic.IList`1<YGOSharp.OCGWrapper.Enums.CardRace> WindBot.Game.GameAI::m_races
	RuntimeObject* ___m_races_16;
};

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// WindBot.Game.AI.Decks.ZefraExecutor/<>c
struct U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87  : public RuntimeObject
{
};

// WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0
struct U3CU3Ec__DisplayClass77_0_tE895338B8B0F926B323A6BF3F2F9A7EF5573FF3E  : public RuntimeObject
{
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0::level
	int32_t ___level_0;
	// WindBot.Game.AI.Decks.ZefraExecutor WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0::<>4__this
	ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* ___U3CU3E4__this_1;
};

// WindBot.Game.AI.Decks.ZefraExecutor/Func
struct Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F  : public RuntimeObject
{
	// System.Collections.Generic.IList`1<System.Object> WindBot.Game.AI.Decks.ZefraExecutor/Func::_parameters
	RuntimeObject* ____parameters_0;
	// System.Collections.Generic.List`1<System.Int32> WindBot.Game.AI.Decks.ZefraExecutor/Func::no_p_spsummon_ids
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___no_p_spsummon_ids_1;
	// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor/Func::selectCardList
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ___selectCardList_2;
	// System.Collections.Generic.List`1<System.Int32> WindBot.Game.AI.Decks.ZefraExecutor/Func::selectCardIdList
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___selectCardIdList_3;
};

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor/CardId
struct CardId_tDC859E1E9CD22AAF608046410ACC38ABA2A950DA  : public RuntimeObject
{
};

// WindBot.Game.AI.Decks.ZoodiacExecutor/CardId
struct CardId_t493C1F60A0CFB6BE32EA7E39991862ACF80A4E3C  : public RuntimeObject
{
};

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0
struct U3CU3Ec__DisplayClass17_0_t3C4D4EE7E6524FB29D68B9043B03E17A15D9BBDD  : public RuntimeObject
{
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0::delegate
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___delegate_0;
};

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0
struct U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C  : public RuntimeObject
{
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::feceup
	bool ___feceup_0;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::disable
	bool ___disable_1;
};

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0
struct U3CU3Ec__DisplayClass32_0_t9A72BB44DF8E46921AB9AC829D6D7C0BBBD875A9  : public RuntimeObject
{
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0::setcode
	int32_t ___setcode_0;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0::setcode2
	int32_t ___setcode2_1;
};

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0
struct U3CU3Ec__DisplayClass35_0_t92CE76AB7A9281F20FE93D2F38778051384ADC9E  : public RuntimeObject
{
	// WindBot.Game.ClientCard WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::lcard
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___lcard_0;
	// WindBot.Game.ClientCard WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::rcard
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___rcard_1;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::MinScale
	int32_t ___MinScale_2;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::MaxScale
	int32_t ___MaxScale_3;
	// WindBot.Game.AI.Decks.ZefraExecutor/Func WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::<>4__this
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* ___U3CU3E4__this_4;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::llimit
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___llimit_5;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::rlimit
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___rlimit_6;
};

// System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>
struct Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 
{
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::_list
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ____list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::_index
	int32_t ____index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::_version
	int32_t ____version_2;
	// T System.Collections.Generic.List`1/Enumerator::_current
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ____current_3;
};

// System.Collections.Generic.List`1/Enumerator<System.Object>
struct Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A 
{
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::_list
	List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* ____list_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::_index
	int32_t ____index_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::_version
	int32_t ____version_2;
	// T System.Collections.Generic.List`1/Enumerator::_current
	RuntimeObject* ____current_3;
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17 
{
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;
};

// System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2  : public ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F
{
};
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_com
{
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

// System.UInt32
struct UInt32_t1833D51FFA667B18A5AA4B8D34DE284F8495D29B 
{
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=1024
struct __StaticArrayInitTypeSizeU3D1024_t4A9D9610B3331D96BFF9BD065239C4091A2300C7 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D1024_t4A9D9610B3331D96BFF9BD065239C4091A2300C7__padding[1024];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12
struct __StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F__padding[12];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=122
struct __StaticArrayInitTypeSizeU3D122_tB9B42E26959822BDC35A82A61F1DCCFA675498AF 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D122_tB9B42E26959822BDC35A82A61F1DCCFA675498AF__padding[122];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=140
struct __StaticArrayInitTypeSizeU3D140_t776C480D92CD62EDA4D119C37110664E3D9283A3 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D140_t776C480D92CD62EDA4D119C37110664E3D9283A3__padding[140];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16
struct __StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23__padding[16];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20
struct __StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72__padding[20];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24
struct __StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A__padding[24];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256
struct __StaticArrayInitTypeSizeU3D256_tD03A67F7FF737E6BC9D67A9F479BD26FCEAD3898 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D256_tD03A67F7FF737E6BC9D67A9F479BD26FCEAD3898__padding[256];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28
struct __StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2__padding[28];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32
struct __StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069__padding[32];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36
struct __StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792__padding[36];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40
struct __StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3__padding[40];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44
struct __StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9__padding[44];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48
struct __StaticArrayInitTypeSizeU3D48_tB184AFC7E0116F4B6DAFA18B66C9B248A3A9F2FE 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D48_tB184AFC7E0116F4B6DAFA18B66C9B248A3A9F2FE__padding[48];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52
struct __StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71__padding[52];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56
struct __StaticArrayInitTypeSizeU3D56_tF90903548CF34D92C9F741BD6D3F8DC6C822EF4E 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D56_tF90903548CF34D92C9F741BD6D3F8DC6C822EF4E__padding[56];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=580
struct __StaticArrayInitTypeSizeU3D580_t7177A4BBA75ED20CA1A352FB967C34235AE48422 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D580_t7177A4BBA75ED20CA1A352FB967C34235AE48422__padding[580];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=60
struct __StaticArrayInitTypeSizeU3D60_t28DCDB387E585965787FF852575673A4F7B6A5E3 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D60_t28DCDB387E585965787FF852575673A4F7B6A5E3__padding[60];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=64
struct __StaticArrayInitTypeSizeU3D64_tC5DCC92F71FF4937EDBB6F52C59AD832172ABE88 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D64_tC5DCC92F71FF4937EDBB6F52C59AD832172ABE88__padding[64];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=648
struct __StaticArrayInitTypeSizeU3D648_tE3A7BE76C119987E420B4D758C218C61C87115D4 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D648_tE3A7BE76C119987E420B4D758C218C61C87115D4__padding[648];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68
struct __StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5__padding[68];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=80
struct __StaticArrayInitTypeSizeU3D80_t144B9F4F4C74AB89365AB7716EE83DECD70D210D 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D80_t144B9F4F4C74AB89365AB7716EE83DECD70D210D__padding[80];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=84
struct __StaticArrayInitTypeSizeU3D84_t9CAC1B1FF7C797961D00EA13F20F629B9C2B6BD9 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D84_t9CAC1B1FF7C797961D00EA13F20F629B9C2B6BD9__padding[84];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=88
struct __StaticArrayInitTypeSizeU3D88_t65BF68A956A9F2B6A6A963A48EBFFFB69B60BAEE 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D88_t65BF68A956A9F2B6A6A963A48EBFFFB69B60BAEE__padding[88];
	};
};

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=96
struct __StaticArrayInitTypeSizeU3D96_tE962D346DA0011435482BCE5513DB1E0D88A8DEB 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D96_tE962D346DA0011435482BCE5513DB1E0D88A8DEB__padding[96];
	};
};

// YGOSharp.OCGWrapper.Enums.CardAttribute
struct CardAttribute_t62E3340A4E3784BE2BB3EA03B010BE7339049EB8 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.CardAttribute::value__
	int32_t ___value___2;
};

// YGOSharp.OCGWrapper.Enums.CardLocation
struct CardLocation_t76541D6F9FF8A50508B8ECC6865522C910B185DE 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.CardLocation::value__
	int32_t ___value___2;
};

// YGOSharp.OCGWrapper.Enums.CardPosition
struct CardPosition_tC01C606B78E1B075A2A3030F3508056411041437 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.CardPosition::value__
	int32_t ___value___2;
};

// YGOSharp.OCGWrapper.Enums.CardRace
struct CardRace_t98AA7A6D9E9C1E09A9AAB54F7E00ED403245BB5A 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.CardRace::value__
	int32_t ___value___2;
};

// YGOSharp.OCGWrapper.Enums.CardType
struct CardType_t205FD13E6CA55867CBD43B08863573E25E20C62E 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.CardType::value__
	int32_t ___value___2;
};

// System.Delegate
struct Delegate_t  : public RuntimeObject
{
	// System.IntPtr System.Delegate::method_ptr
	intptr_t ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject* ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.IntPtr System.Delegate::interp_method
	intptr_t ___interp_method_7;
	// System.IntPtr System.Delegate::interp_invoke_impl
	intptr_t ___interp_invoke_impl_8;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t* ___method_info_9;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t* ___original_method_info_10;
	// System.DelegateData System.Delegate::data
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_12;
};
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};

// YGOSharp.OCGWrapper.Enums.DuelPhase
struct DuelPhase_t64AB0279C8536792E289871D3BFED96A567175A2 
{
	// System.Int32 YGOSharp.OCGWrapper.Enums.DuelPhase::value__
	int32_t ___value___2;
};

// WindBot.Game.AI.ExecutorType
struct ExecutorType_t4DA9E27F605A25406C3CEF991F405449957C4BD4 
{
	// System.Int32 WindBot.Game.AI.ExecutorType::value__
	int32_t ___value___2;
};

// System.RuntimeFieldHandle
struct RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 
{
	// System.IntPtr System.RuntimeFieldHandle::value
	intptr_t ___value_0;
};

// WindBot.Game.ClientCard
struct ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59  : public RuntimeObject
{
	// System.Int32 WindBot.Game.ClientCard::<Id>k__BackingField
	int32_t ___U3CIdU3Ek__BackingField_0;
	// YGOSharp.OCGWrapper.NamedCard WindBot.Game.ClientCard::<Data>k__BackingField
	NamedCard_tEB4CE4D34CA54A76C86A9D7DDB9D5BBC838C5015* ___U3CDataU3Ek__BackingField_1;
	// System.String WindBot.Game.ClientCard::<Name>k__BackingField
	String_t* ___U3CNameU3Ek__BackingField_2;
	// System.Int32 WindBot.Game.ClientCard::<Position>k__BackingField
	int32_t ___U3CPositionU3Ek__BackingField_3;
	// System.Int32 WindBot.Game.ClientCard::<Sequence>k__BackingField
	int32_t ___U3CSequenceU3Ek__BackingField_4;
	// YGOSharp.OCGWrapper.Enums.CardLocation WindBot.Game.ClientCard::<Location>k__BackingField
	int32_t ___U3CLocationU3Ek__BackingField_5;
	// YGOSharp.OCGWrapper.Enums.CardLocation WindBot.Game.ClientCard::<LastLocation>k__BackingField
	int32_t ___U3CLastLocationU3Ek__BackingField_6;
	// System.Int32 WindBot.Game.ClientCard::<Alias>k__BackingField
	int32_t ___U3CAliasU3Ek__BackingField_7;
	// System.Int32 WindBot.Game.ClientCard::<Level>k__BackingField
	int32_t ___U3CLevelU3Ek__BackingField_8;
	// System.Int32 WindBot.Game.ClientCard::<Rank>k__BackingField
	int32_t ___U3CRankU3Ek__BackingField_9;
	// System.Int32 WindBot.Game.ClientCard::<Type>k__BackingField
	int32_t ___U3CTypeU3Ek__BackingField_10;
	// System.Int32 WindBot.Game.ClientCard::<Attribute>k__BackingField
	int32_t ___U3CAttributeU3Ek__BackingField_11;
	// System.Int32 WindBot.Game.ClientCard::<Race>k__BackingField
	int32_t ___U3CRaceU3Ek__BackingField_12;
	// System.Int32 WindBot.Game.ClientCard::<Attack>k__BackingField
	int32_t ___U3CAttackU3Ek__BackingField_13;
	// System.Int32 WindBot.Game.ClientCard::<Defense>k__BackingField
	int32_t ___U3CDefenseU3Ek__BackingField_14;
	// System.Int32 WindBot.Game.ClientCard::<LScale>k__BackingField
	int32_t ___U3CLScaleU3Ek__BackingField_15;
	// System.Int32 WindBot.Game.ClientCard::<RScale>k__BackingField
	int32_t ___U3CRScaleU3Ek__BackingField_16;
	// System.Int32 WindBot.Game.ClientCard::<LinkCount>k__BackingField
	int32_t ___U3CLinkCountU3Ek__BackingField_17;
	// System.Int32 WindBot.Game.ClientCard::<LinkMarker>k__BackingField
	int32_t ___U3CLinkMarkerU3Ek__BackingField_18;
	// System.Int32 WindBot.Game.ClientCard::<BaseAttack>k__BackingField
	int32_t ___U3CBaseAttackU3Ek__BackingField_19;
	// System.Int32 WindBot.Game.ClientCard::<BaseDefense>k__BackingField
	int32_t ___U3CBaseDefenseU3Ek__BackingField_20;
	// System.Int32 WindBot.Game.ClientCard::<RealPower>k__BackingField
	int32_t ___U3CRealPowerU3Ek__BackingField_21;
	// System.Collections.Generic.List`1<System.Int32> WindBot.Game.ClientCard::<Overlays>k__BackingField
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___U3COverlaysU3Ek__BackingField_22;
	// System.Int32 WindBot.Game.ClientCard::<Owner>k__BackingField
	int32_t ___U3COwnerU3Ek__BackingField_23;
	// System.Int32 WindBot.Game.ClientCard::<Controller>k__BackingField
	int32_t ___U3CControllerU3Ek__BackingField_24;
	// System.Int32 WindBot.Game.ClientCard::<Disabled>k__BackingField
	int32_t ___U3CDisabledU3Ek__BackingField_25;
	// System.Int32 WindBot.Game.ClientCard::<ProcCompleted>k__BackingField
	int32_t ___U3CProcCompletedU3Ek__BackingField_26;
	// System.Int32 WindBot.Game.ClientCard::<SelectSeq>k__BackingField
	int32_t ___U3CSelectSeqU3Ek__BackingField_27;
	// System.Int32 WindBot.Game.ClientCard::<OpParam1>k__BackingField
	int32_t ___U3COpParam1U3Ek__BackingField_28;
	// System.Int32 WindBot.Game.ClientCard::<OpParam2>k__BackingField
	int32_t ___U3COpParam2U3Ek__BackingField_29;
	// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientCard::<EquipCards>k__BackingField
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ___U3CEquipCardsU3Ek__BackingField_30;
	// WindBot.Game.ClientCard WindBot.Game.ClientCard::EquipTarget
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___EquipTarget_31;
	// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientCard::<OwnTargets>k__BackingField
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ___U3COwnTargetsU3Ek__BackingField_32;
	// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientCard::<TargetCards>k__BackingField
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ___U3CTargetCardsU3Ek__BackingField_33;
	// System.Boolean WindBot.Game.ClientCard::<CanDirectAttack>k__BackingField
	bool ___U3CCanDirectAttackU3Ek__BackingField_34;
	// System.Boolean WindBot.Game.ClientCard::<ShouldDirectAttack>k__BackingField
	bool ___U3CShouldDirectAttackU3Ek__BackingField_35;
	// System.Boolean WindBot.Game.ClientCard::<Attacked>k__BackingField
	bool ___U3CAttackedU3Ek__BackingField_36;
	// System.Boolean WindBot.Game.ClientCard::<IsLastAttacker>k__BackingField
	bool ___U3CIsLastAttackerU3Ek__BackingField_37;
	// System.Boolean WindBot.Game.ClientCard::<IsSpecialSummoned>k__BackingField
	bool ___U3CIsSpecialSummonedU3Ek__BackingField_38;
	// System.Int32[] WindBot.Game.ClientCard::<ActionIndex>k__BackingField
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___U3CActionIndexU3Ek__BackingField_39;
	// System.Collections.Generic.IDictionary`2<System.Int32,System.Int32> WindBot.Game.ClientCard::<ActionActivateIndex>k__BackingField
	RuntimeObject* ___U3CActionActivateIndexU3Ek__BackingField_40;
};

// WindBot.Game.Duel
struct Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D  : public RuntimeObject
{
	// System.Boolean WindBot.Game.Duel::<IsFirst>k__BackingField
	bool ___U3CIsFirstU3Ek__BackingField_0;
	// System.Boolean WindBot.Game.Duel::<IsNewRule>k__BackingField
	bool ___U3CIsNewRuleU3Ek__BackingField_1;
	// System.Boolean WindBot.Game.Duel::<IsNewRule2020>k__BackingField
	bool ___U3CIsNewRule2020U3Ek__BackingField_2;
	// WindBot.Game.ClientField[] WindBot.Game.Duel::<Fields>k__BackingField
	ClientFieldU5BU5D_t66AC8C298450829D5148BE66B83BE8F7C24AA3DD* ___U3CFieldsU3Ek__BackingField_3;
	// System.Int32 WindBot.Game.Duel::<Turn>k__BackingField
	int32_t ___U3CTurnU3Ek__BackingField_4;
	// System.Int32 WindBot.Game.Duel::<Player>k__BackingField
	int32_t ___U3CPlayerU3Ek__BackingField_5;
	// YGOSharp.OCGWrapper.Enums.DuelPhase WindBot.Game.Duel::<Phase>k__BackingField
	int32_t ___U3CPhaseU3Ek__BackingField_6;
	// WindBot.Game.MainPhase WindBot.Game.Duel::<MainPhase>k__BackingField
	MainPhase_tF8EAFFFF36B94E244A2142388709CB36CCBFF1E7* ___U3CMainPhaseU3Ek__BackingField_7;
	// WindBot.Game.BattlePhase WindBot.Game.Duel::<BattlePhase>k__BackingField
	BattlePhase_tB98E96A1E999317CDA55AF9A088CA9821CAF00C2* ___U3CBattlePhaseU3Ek__BackingField_8;
	// System.Int32 WindBot.Game.Duel::<LastChainPlayer>k__BackingField
	int32_t ___U3CLastChainPlayerU3Ek__BackingField_9;
	// YGOSharp.OCGWrapper.Enums.CardLocation WindBot.Game.Duel::<LastChainLocation>k__BackingField
	int32_t ___U3CLastChainLocationU3Ek__BackingField_10;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<CurrentChain>k__BackingField
	RuntimeObject* ___U3CCurrentChainU3Ek__BackingField_11;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<ChainTargets>k__BackingField
	RuntimeObject* ___U3CChainTargetsU3Ek__BackingField_12;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<LastChainTargets>k__BackingField
	RuntimeObject* ___U3CLastChainTargetsU3Ek__BackingField_13;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<ChainTargetOnly>k__BackingField
	RuntimeObject* ___U3CChainTargetOnlyU3Ek__BackingField_14;
	// System.Int32 WindBot.Game.Duel::<LastSummonPlayer>k__BackingField
	int32_t ___U3CLastSummonPlayerU3Ek__BackingField_15;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<SummoningCards>k__BackingField
	RuntimeObject* ___U3CSummoningCardsU3Ek__BackingField_16;
	// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::<LastSummonedCards>k__BackingField
	RuntimeObject* ___U3CLastSummonedCardsU3Ek__BackingField_17;
	// System.Int32 WindBot.Game.Duel::<SolvingChainIndex>k__BackingField
	int32_t ___U3CSolvingChainIndexU3Ek__BackingField_18;
	// System.Collections.Generic.IList`1<System.Int32> WindBot.Game.Duel::<NegatedChainIndexList>k__BackingField
	RuntimeObject* ___U3CNegatedChainIndexListU3Ek__BackingField_19;
};

// WindBot.Game.AI.Executor
struct Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083  : public RuntimeObject
{
	// System.String WindBot.Game.AI.Executor::<Deck>k__BackingField
	String_t* ___U3CDeckU3Ek__BackingField_0;
	// WindBot.Game.Duel WindBot.Game.AI.Executor::<Duel>k__BackingField
	Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___U3CDuelU3Ek__BackingField_1;
	// System.Collections.Generic.IList`1<WindBot.Game.AI.CardExecutor> WindBot.Game.AI.Executor::<Executors>k__BackingField
	RuntimeObject* ___U3CExecutorsU3Ek__BackingField_2;
	// WindBot.Game.GameAI WindBot.Game.AI.Executor::<AI>k__BackingField
	GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* ___U3CAIU3Ek__BackingField_3;
	// WindBot.Game.AI.AIUtil WindBot.Game.AI.Executor::<Util>k__BackingField
	AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* ___U3CUtilU3Ek__BackingField_4;
	// WindBot.Game.MainPhase WindBot.Game.AI.Executor::<Main>k__BackingField
	MainPhase_tF8EAFFFF36B94E244A2142388709CB36CCBFF1E7* ___U3CMainU3Ek__BackingField_5;
	// WindBot.Game.BattlePhase WindBot.Game.AI.Executor::<Battle>k__BackingField
	BattlePhase_tB98E96A1E999317CDA55AF9A088CA9821CAF00C2* ___U3CBattleU3Ek__BackingField_6;
	// WindBot.Game.AI.ExecutorType WindBot.Game.AI.Executor::<Type>k__BackingField
	int32_t ___U3CTypeU3Ek__BackingField_7;
	// WindBot.Game.ClientCard WindBot.Game.AI.Executor::<Card>k__BackingField
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___U3CCardU3Ek__BackingField_8;
	// System.Int32 WindBot.Game.AI.Executor::<ActivateDescription>k__BackingField
	int32_t ___U3CActivateDescriptionU3Ek__BackingField_9;
	// System.Int32 WindBot.Game.AI.Executor::<CurrentTiming>k__BackingField
	int32_t ___U3CCurrentTimingU3Ek__BackingField_10;
	// WindBot.Game.ClientField WindBot.Game.AI.Executor::<Bot>k__BackingField
	ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* ___U3CBotU3Ek__BackingField_11;
	// WindBot.Game.ClientField WindBot.Game.AI.Executor::<Enemy>k__BackingField
	ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* ___U3CEnemyU3Ek__BackingField_12;
};

// System.MulticastDelegate
struct MulticastDelegate_t  : public Delegate_t
{
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771* ___delegates_13;
};
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_13;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_13;
};

// System.Func`1<System.Boolean>
struct Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457  : public MulticastDelegate_t
{
};

// WindBot.Game.AI.DefaultExecutor
struct DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317  : public Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083
{
	// System.Int32 WindBot.Game.AI.DefaultExecutor::lightningStormOption
	int32_t ___lightningStormOption_13;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> WindBot.Game.AI.DefaultExecutor::calledbytheGraveIdCountMap
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___calledbytheGraveIdCountMap_14;
	// System.Collections.Generic.List`1<System.Int32> WindBot.Game.AI.DefaultExecutor::crossoutDesignatorIdList
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___crossoutDesignatorIdList_15;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Func`2<WindBot.Game.ClientCard,System.Boolean>> WindBot.Game.AI.DefaultExecutor::DefenderProtectRule
	Dictionary_2_t8A1454E151C07322C358242DF1647EBCA3D20773* ___DefenderProtectRule_16;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Func`3<WindBot.Game.ClientCard,System.Collections.Generic.List`1<WindBot.Game.ClientCard>,System.Boolean>> WindBot.Game.AI.DefaultExecutor::DefenderInvisbleRule
	Dictionary_2_t8C0665560BCD0EB04534B6117705CA76262B784E* ___DefenderInvisbleRule_17;
};

// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate
struct Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE  : public MulticastDelegate_t
{
};

// WindBot.Game.AI.Decks.ZefraExecutor
struct ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48  : public DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317
{
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::opt_0
	bool ___opt_0_18;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::opt_1
	bool ___opt_1_19;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::opt_2
	bool ___opt_2_20;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor::p_count
	int32_t ___p_count_23;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor::spell_activate_count
	int32_t ___spell_activate_count_24;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::summoned
	bool ___summoned_25;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::link_summoned
	bool ___link_summoned_26;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::p_summoned
	bool ___p_summoned_27;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::p_summoning
	bool ___p_summoning_28;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_SupremeKingDragonDarkwurm_1
	bool ___activate_SupremeKingDragonDarkwurm_1_29;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_p_Zefraath
	bool ___activate_p_Zefraath_30;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_OracleofZefra
	bool ___activate_OracleofZefra_31;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_ZefraProvidence
	bool ___activate_ZefraProvidence_32;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_SupremeKingDragonDarkwurm_2
	bool ___activate_SupremeKingDragonDarkwurm_2_33;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_JetSynchron
	bool ___activate_JetSynchron_34;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_Blackwing_ZephyrostheElite
	bool ___activate_Blackwing_ZephyrostheElite_35;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_DragonShrine
	bool ___activate_DragonShrine_36;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_SpellPowerMastery
	bool ___activate_SpellPowerMastery_37;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_DestrudotheLostDragon_Frisson
	bool ___activate_DestrudotheLostDragon_Frisson_38;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_DarkContractwiththGate
	bool ___activate_DarkContractwiththGate_39;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_SecretoftheYangZing
	bool ___activate_SecretoftheYangZing_40;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_ShaddollZefracore
	bool ___activate_ShaddollZefracore_41;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::activate_DDLamia
	bool ___activate_DDLamia_42;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::xyz_mode
	bool ___xyz_mode_43;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::Blackwing_ZephyrostheElite_activate
	bool ___Blackwing_ZephyrostheElite_activate_44;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::HeavymetalfoesElectrumite_activate
	bool ___HeavymetalfoesElectrumite_activate_45;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::should_destory
	bool ___should_destory_46;
	// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor::Odd_EyesMeteorburstDragon_materials
	List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ___Odd_EyesMeteorburstDragon_materials_47;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::duel_start
	bool ___duel_start_48;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor::activate_count
	int32_t ___activate_count_49;
	// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor::summon_count
	int32_t ___summon_count_50;
	// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::enemy_activate
	bool ___enemy_activate_51;
	// WindBot.Game.AI.Decks.ZefraExecutor/Func WindBot.Game.AI.Decks.ZefraExecutor::func
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* ___func_52;
};

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor
struct ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E  : public DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317
{
};

// WindBot.Game.AI.Decks.ZoodiacExecutor
struct ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA  : public DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317
{
	// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::TigermortarSpsummoned
	bool ___TigermortarSpsummoned_18;
	// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::ChakanineSpsummoned
	bool ___ChakanineSpsummoned_19;
	// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::BroadbullSpsummoned
	bool ___BroadbullSpsummoned_20;
};

// System.EmptyArray`1<System.Object>
struct EmptyArray_1_tDF0DD7256B115243AA6BD5558417387A734240EE_StaticFields
{
	// T[] System.EmptyArray`1::Value
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___Value_0;
};

// System.EmptyArray`1<System.Object>

// System.Collections.Generic.List`1<WindBot.Game.ClientCard>
struct List_1_tFD3517A71322E467BC146AEAF76EC021968D868F_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ClientCardU5BU5D_t920986C159D59CAC4045BE02C84E9885D39EAE39* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<WindBot.Game.ClientCard>

// System.Collections.Generic.List`1<System.Int32>
struct List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.Int32>

// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.Object>

// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA_StaticFields
{
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::0008BF354F4BF8AF819550461C908786DA85CFD6A21C93822B19CAB95C32C3D0
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___0008BF354F4BF8AF819550461C908786DA85CFD6A21C93822B19CAB95C32C3D0_0;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::0104B95C962CBD4EDB206037EB02626174E8AC61DA3698AF65B5DF06322AE002
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___0104B95C962CBD4EDB206037EB02626174E8AC61DA3698AF65B5DF06322AE002_1;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::013A62B950D963C08A08FD714EDCB4C420F3975B97F9584D8ABC45311D7BB069
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___013A62B950D963C08A08FD714EDCB4C420F3975B97F9584D8ABC45311D7BB069_2;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::033DD09ABBE33E59188D7A247EAF70F4F9AEB2C00C1A239A2243A4DF3BFEB1E0
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___033DD09ABBE33E59188D7A247EAF70F4F9AEB2C00C1A239A2243A4DF3BFEB1E0_3;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::035D2E6337893E15F60392D717480E20B596B8925A60EBC9299818CA257E719D
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___035D2E6337893E15F60392D717480E20B596B8925A60EBC9299818CA257E719D_4;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::063BE5ADBDEF9E7364B438AF26DB3A3CB660962E01D2D608D61B3278024B2DE1
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___063BE5ADBDEF9E7364B438AF26DB3A3CB660962E01D2D608D61B3278024B2DE1_5;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::06AF99BB37095F5C26F953656609B5CF4B32D09BCDFF2CF63E8D047672F4B8D1
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___06AF99BB37095F5C26F953656609B5CF4B32D09BCDFF2CF63E8D047672F4B8D1_6;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::06C5EE9115CC4FDA0BBA9F8CEB8DC51E00364AF4323F169DCA639566C4E2BC7E
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___06C5EE9115CC4FDA0BBA9F8CEB8DC51E00364AF4323F169DCA639566C4E2BC7E_7;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=88 <PrivateImplementationDetails>::073F9BD9678E873AAA0396F62C87DE5DCC6E74C71126D6FB109CA95941A12F3B
	__StaticArrayInitTypeSizeU3D88_t65BF68A956A9F2B6A6A963A48EBFFFB69B60BAEE ___073F9BD9678E873AAA0396F62C87DE5DCC6E74C71126D6FB109CA95941A12F3B_8;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::07F953EB3DB1131FBDB6AA2748FD8EC70F792C02BF125F3577B8988B69AF80B0
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___07F953EB3DB1131FBDB6AA2748FD8EC70F792C02BF125F3577B8988B69AF80B0_9;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::086F497F7EA5F585F575A89573A9CE18330790B8DCEA8FA441D47EB26C6FCB84
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___086F497F7EA5F585F575A89573A9CE18330790B8DCEA8FA441D47EB26C6FCB84_10;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=140 <PrivateImplementationDetails>::088D611988F50574E9389E48A380101D7E7145634B9EEDFF39CC0DB84F2556D4
	__StaticArrayInitTypeSizeU3D140_t776C480D92CD62EDA4D119C37110664E3D9283A3 ___088D611988F50574E9389E48A380101D7E7145634B9EEDFF39CC0DB84F2556D4_11;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::08B63E1D4069AE2E9ADFD04DC51D98FE3B6B9B322BF645402A83A6A4D4E067D3
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___08B63E1D4069AE2E9ADFD04DC51D98FE3B6B9B322BF645402A83A6A4D4E067D3_12;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::09274524DF36909E2F48969EA418813FCA81DE8C9A3BC010444FD0EC4B687AE5
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___09274524DF36909E2F48969EA418813FCA81DE8C9A3BC010444FD0EC4B687AE5_13;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::093E7BD25F734E8BFF4AC6D27AFD25B63F9569FDBB0B373BA13863F1E1DF5583
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___093E7BD25F734E8BFF4AC6D27AFD25B63F9569FDBB0B373BA13863F1E1DF5583_14;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::09F6B0194E72CD0E82905D08FD1D8BF81B7295E5A11D7B9C7523EC157C2C24FF
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___09F6B0194E72CD0E82905D08FD1D8BF81B7295E5A11D7B9C7523EC157C2C24FF_15;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::0A24E66E1C43B22B5A544FC6AC13FF71EBA4348EC2564B1FBF4CAD8BE56B2F55
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___0A24E66E1C43B22B5A544FC6AC13FF71EBA4348EC2564B1FBF4CAD8BE56B2F55_16;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::0A6E7EC11ADB35D280C343AB7719B815C1C9A153ECEA935AC23C10E1526F7484
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___0A6E7EC11ADB35D280C343AB7719B815C1C9A153ECEA935AC23C10E1526F7484_17;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::0BAA56B98C8A8AE7D84629F4C5BDFDFA1E26485DBCB7E488ED34FE39544BBA10
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___0BAA56B98C8A8AE7D84629F4C5BDFDFA1E26485DBCB7E488ED34FE39544BBA10_18;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::0D32CEA4449DEE0C99D8D61682DBFCAA808069D269E947B9B2D3DAC86291DF24
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___0D32CEA4449DEE0C99D8D61682DBFCAA808069D269E947B9B2D3DAC86291DF24_19;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::0D623E1A8832F3B96A4739C97B129B34B59C10B88B1C363841EF0BAC2650D261
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___0D623E1A8832F3B96A4739C97B129B34B59C10B88B1C363841EF0BAC2650D261_20;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::0F412DF24AC9290FE7E1437CFBDD763AF51920EBBB0D859291A157DFCB268D65
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___0F412DF24AC9290FE7E1437CFBDD763AF51920EBBB0D859291A157DFCB268D65_21;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::10319A18FEA4034ABCB58C86A0384892A19A1C3320201789AA8CCB00276CA3C6
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___10319A18FEA4034ABCB58C86A0384892A19A1C3320201789AA8CCB00276CA3C6_22;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::108710702D56B721FE6351364171D9FE220305A52FF09CA45DBB65E1CEB31854
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___108710702D56B721FE6351364171D9FE220305A52FF09CA45DBB65E1CEB31854_23;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::11D3D996031BC26F127272A1B5CBD67149AEE9E04C7546841F3E5BEF00EE914E
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___11D3D996031BC26F127272A1B5CBD67149AEE9E04C7546841F3E5BEF00EE914E_24;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::135A71913DC1B3907631A9F7D3A6116CB941542F4C7090BC64B193FD5371AE8D
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___135A71913DC1B3907631A9F7D3A6116CB941542F4C7090BC64B193FD5371AE8D_25;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::13A62E2063453ECC08B8CF25F042D599BF981D87D776953010C8E7ACEC98127D
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___13A62E2063453ECC08B8CF25F042D599BF981D87D776953010C8E7ACEC98127D_26;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=648 <PrivateImplementationDetails>::14FFF267A4A37A666DC8352E9EB53A5BAE66458ABADB3CB0E525C4401B7DC44E
	__StaticArrayInitTypeSizeU3D648_tE3A7BE76C119987E420B4D758C218C61C87115D4 ___14FFF267A4A37A666DC8352E9EB53A5BAE66458ABADB3CB0E525C4401B7DC44E_27;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=122 <PrivateImplementationDetails>::161F51800FFB8F4BCF0540684A15730BC0A7830303ED887EB886C051E79B7C68
	__StaticArrayInitTypeSizeU3D122_tB9B42E26959822BDC35A82A61F1DCCFA675498AF ___161F51800FFB8F4BCF0540684A15730BC0A7830303ED887EB886C051E79B7C68_28;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::182ED499F81DAC84087162DE826118CA2BF57BD9A7288DC9FC978F3188AADE62
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___182ED499F81DAC84087162DE826118CA2BF57BD9A7288DC9FC978F3188AADE62_29;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::1944FAC0A882BD61B01ABD7BC83B19D4BE105C26F4EC8BB4B008998058B228DC
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___1944FAC0A882BD61B01ABD7BC83B19D4BE105C26F4EC8BB4B008998058B228DC_30;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::1A82B8EBBF02C176CBA52CB78D73EDE178D7F579B0E90341E93B2DC605F5D2E7
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___1A82B8EBBF02C176CBA52CB78D73EDE178D7F579B0E90341E93B2DC605F5D2E7_31;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::1B979100D0E3A42D3A63C48DD8FDB8410912A0E507B062DC19FBDA2DC6DC3511
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___1B979100D0E3A42D3A63C48DD8FDB8410912A0E507B062DC19FBDA2DC6DC3511_32;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::1DD651206242F383619303EAF1A7C3672C804BD978A981EE5511F23796A12ED6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___1DD651206242F383619303EAF1A7C3672C804BD978A981EE5511F23796A12ED6_33;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::1DEE9012BE9101EC9E92596C919E86C2FA363DE6B69190AA7B4AB5DF537BCB3C
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___1DEE9012BE9101EC9E92596C919E86C2FA363DE6B69190AA7B4AB5DF537BCB3C_34;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::201E5B7C96EAB22EFE78F2AA5B12E6BCD8646C0F95A2F02A0F8E11EF8110E7EF
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___201E5B7C96EAB22EFE78F2AA5B12E6BCD8646C0F95A2F02A0F8E11EF8110E7EF_35;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::22BA1161DE3AA7F92BB4F6F3973583C7947BACA5C384573D56BDB3640189AA5E
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___22BA1161DE3AA7F92BB4F6F3973583C7947BACA5C384573D56BDB3640189AA5E_36;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::22BA1750925DDD20403E2600F9E5ABC1E47FF4C5F1DBC72625962D5B8AFC1BBF
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___22BA1750925DDD20403E2600F9E5ABC1E47FF4C5F1DBC72625962D5B8AFC1BBF_37;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::26183F11ACB1573D3E305BB10EA87B81FF5F9EC70B1EDD8C07A45C10A2CB9DF3
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___26183F11ACB1573D3E305BB10EA87B81FF5F9EC70B1EDD8C07A45C10A2CB9DF3_38;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::262B27961F0316D74A6A64234DDEBAB61111542D42DE1DDFA3E177167DF3BA35
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___262B27961F0316D74A6A64234DDEBAB61111542D42DE1DDFA3E177167DF3BA35_39;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::265907F08298FF45335BA21D6064886AD13226C4F4FAEA0B89E6FE38528420B6
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___265907F08298FF45335BA21D6064886AD13226C4F4FAEA0B89E6FE38528420B6_40;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::279FCC29546E3936D7D301ADBCEEE3B587F4B8553B609EBBA658183E3247D0CC
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___279FCC29546E3936D7D301ADBCEEE3B587F4B8553B609EBBA658183E3247D0CC_41;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::27CB985EBB1F21C3059C1ABB47E44B6677D597D847B95096124057708CEBABEF
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___27CB985EBB1F21C3059C1ABB47E44B6677D597D847B95096124057708CEBABEF_42;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::28AAB6B3FC75A3AC1AE0C34D0CDB47B50086F79C54038ACF747E7C298CD0263C
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___28AAB6B3FC75A3AC1AE0C34D0CDB47B50086F79C54038ACF747E7C298CD0263C_43;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::2B632D50F7E3C07C6B3E832EE6A3974B457CAF1B11F9CE8EE2F47B7F05B8F2C1
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___2B632D50F7E3C07C6B3E832EE6A3974B457CAF1B11F9CE8EE2F47B7F05B8F2C1_44;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::2C86AA5D7D3B49D5366BB3E4378D98B9AB6633F98DB3B67C5589063664EAB759
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___2C86AA5D7D3B49D5366BB3E4378D98B9AB6633F98DB3B67C5589063664EAB759_45;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::2D56A6E78787D27864EDD1901E10290A2589EB029215FF52CD7387ECB935BC32
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___2D56A6E78787D27864EDD1901E10290A2589EB029215FF52CD7387ECB935BC32_46;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::2E0E9A749854B9272DD4D373060CFF7C8C6D4399C9CF3CF020ACDB0C965CEC42
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___2E0E9A749854B9272DD4D373060CFF7C8C6D4399C9CF3CF020ACDB0C965CEC42_47;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::2EDAD47E0143C2DA8588B79DB3AAAA5BDA5E2CB78B61C1A94A079ACBFD562A53
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___2EDAD47E0143C2DA8588B79DB3AAAA5BDA5E2CB78B61C1A94A079ACBFD562A53_48;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::2F4F323698C9FC4561959368A79502FCE191E2FBC7E900B99C954641AE510135
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___2F4F323698C9FC4561959368A79502FCE191E2FBC7E900B99C954641AE510135_49;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::2FE906152D4F4714CEF35AC753F6AF6CCA202400B6D9F7538E735BE32FC2FCF4
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___2FE906152D4F4714CEF35AC753F6AF6CCA202400B6D9F7538E735BE32FC2FCF4_50;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::300343C102F8B5BCA5981272ECBB5982FF54CB0B6EC9309D0401A1F2584E2548
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___300343C102F8B5BCA5981272ECBB5982FF54CB0B6EC9309D0401A1F2584E2548_51;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::3022B4CB3264F63DB5B21DCF671D822D3BD4CA5DCB324868D6E7E0EB950D9151
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___3022B4CB3264F63DB5B21DCF671D822D3BD4CA5DCB324868D6E7E0EB950D9151_52;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::31763EF6B74C0C490716B3A664F92A3BF2214254B3C045EE21A3FB2D0458C474
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___31763EF6B74C0C490716B3A664F92A3BF2214254B3C045EE21A3FB2D0458C474_53;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::318115AEBBA1DBA3F742A939258F5370012D2DB4D41AADE57D6CCBA2E05AB611
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___318115AEBBA1DBA3F742A939258F5370012D2DB4D41AADE57D6CCBA2E05AB611_54;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::325A8FDC753967A01C662964EFD0B2F05976247BA3F9B0A370CA631B7AE5931B
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___325A8FDC753967A01C662964EFD0B2F05976247BA3F9B0A370CA631B7AE5931B_55;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::3276363E5E2124A87383A8F098CB5EE351C869A2AD081789DB28BD9FADFAFCD1
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___3276363E5E2124A87383A8F098CB5EE351C869A2AD081789DB28BD9FADFAFCD1_56;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::34201146E5448E72EE2FD19E76B03D654DB3FB37418B666C62989088FCEFD7CB
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___34201146E5448E72EE2FD19E76B03D654DB3FB37418B666C62989088FCEFD7CB_57;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::343E4CFBED076F0E53DB079971D02D918CFB8863B737373C5F93519793F66078
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___343E4CFBED076F0E53DB079971D02D918CFB8863B737373C5F93519793F66078_58;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::347C0EBA8E6B4E683688898CF78A8CFA045FAC477B7C02336C10AF855F3EF6A0
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___347C0EBA8E6B4E683688898CF78A8CFA045FAC477B7C02336C10AF855F3EF6A0_59;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::34EC8C36A856D7056AB67EC68AC3DAD34C7FDB6A8A862FC050BF32656067C7DB
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___34EC8C36A856D7056AB67EC68AC3DAD34C7FDB6A8A862FC050BF32656067C7DB_60;
	// System.Int64 <PrivateImplementationDetails>::3505B8A2248AC03FE41ACADF8F29294572BBADEE1DD2E1A45D025766681C012C
	int64_t ___3505B8A2248AC03FE41ACADF8F29294572BBADEE1DD2E1A45D025766681C012C_61;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::35B5210B4BDA5FE2517890B76DD2C5D447272108B643F5C4BC36E186F0AE33E9
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___35B5210B4BDA5FE2517890B76DD2C5D447272108B643F5C4BC36E186F0AE33E9_62;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256 <PrivateImplementationDetails>::3625C05CEC11E381DC84EA45D47F9006BB5268A77CF60F1F5E8BF60D71A001A0
	__StaticArrayInitTypeSizeU3D256_tD03A67F7FF737E6BC9D67A9F479BD26FCEAD3898 ___3625C05CEC11E381DC84EA45D47F9006BB5268A77CF60F1F5E8BF60D71A001A0_63;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::36FC988A3EEC8A640974CB0CD6ED4BE2E196D5CF05E91DA38C2B315D8E50CDF8
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___36FC988A3EEC8A640974CB0CD6ED4BE2E196D5CF05E91DA38C2B315D8E50CDF8_64;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=96 <PrivateImplementationDetails>::37ADA3AEE755417DE1E59C68192E082386506E066B9DC7C37B97587271434446
	__StaticArrayInitTypeSizeU3D96_tE962D346DA0011435482BCE5513DB1E0D88A8DEB ___37ADA3AEE755417DE1E59C68192E082386506E066B9DC7C37B97587271434446_65;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::37D6046DC5EB7D5C039CED3D656346032D02D9B816FAF92DFEF3F24BD319960C
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___37D6046DC5EB7D5C039CED3D656346032D02D9B816FAF92DFEF3F24BD319960C_66;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::37DBAE93932A9D6C485CA2E4E7B5B9CA89A7CD27E86EB53ED06159C62969D211
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___37DBAE93932A9D6C485CA2E4E7B5B9CA89A7CD27E86EB53ED06159C62969D211_67;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3813CDFC5D577AAD8F31AB9563286D6596E59F30C1411FBECF67B1A557C4DFDB
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3813CDFC5D577AAD8F31AB9563286D6596E59F30C1411FBECF67B1A557C4DFDB_68;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::3998767119F47290C13D44B65D672FEF467B686AD75E5F2B5608DE3310A3FEBD
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___3998767119F47290C13D44B65D672FEF467B686AD75E5F2B5608DE3310A3FEBD_69;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::39DC07F1FA789A64AB02D035B5341E313955B8615D325F6844D8733818D459D8
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___39DC07F1FA789A64AB02D035B5341E313955B8615D325F6844D8733818D459D8_70;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3A5583265AEC928E446721252CCB55E6821F239678B6A0CBB03E495586D46E82
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3A5583265AEC928E446721252CCB55E6821F239678B6A0CBB03E495586D46E82_71;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::3AB0E3017BFBA8FA69B7965F658A3B9D9E1ED9E1B325E7D804373ABBAEE2D152
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___3AB0E3017BFBA8FA69B7965F658A3B9D9E1ED9E1B325E7D804373ABBAEE2D152_72;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3AF505C1A5F91592C1E9E57DE6CBBC8306A1D22FAA99D93CEC5CBFFCAA9A47A7
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3AF505C1A5F91592C1E9E57DE6CBBC8306A1D22FAA99D93CEC5CBFFCAA9A47A7_73;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3B694D15FD5CADD5FE586AD493C923A4704704CF72AD60B45A6D6270C97EDE0E
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3B694D15FD5CADD5FE586AD493C923A4704704CF72AD60B45A6D6270C97EDE0E_74;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::3B6EE5EA599EDCC2FF483FA54ABB841A177C81E5118F0C2BB0D4CF42C1B15A1A
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___3B6EE5EA599EDCC2FF483FA54ABB841A177C81E5118F0C2BB0D4CF42C1B15A1A_75;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3BB2B3BDE1D506F25D939A0AD839453A31DFC65EDAF1BE8306B07B65B3D14333
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3BB2B3BDE1D506F25D939A0AD839453A31DFC65EDAF1BE8306B07B65B3D14333_76;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::3BB81B88214D27D554C018390B3943EA06748445C39A5E6B909EC155733B776C
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___3BB81B88214D27D554C018390B3943EA06748445C39A5E6B909EC155733B776C_77;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::3BDD63EFDCF0A0CEA2395D68C838B5BA47C73C0CE2BBA3C285A394544F4FC24D
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___3BDD63EFDCF0A0CEA2395D68C838B5BA47C73C0CE2BBA3C285A394544F4FC24D_78;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::3C9368AD1AF8DA93271616C558F5052140C7459902FEA1A18F269584131E6A6B
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___3C9368AD1AF8DA93271616C558F5052140C7459902FEA1A18F269584131E6A6B_79;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::3D8B4541724E7146BF638C7A9C75572B7073DF1C89EC9C80C5051F0660B8E4C2
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___3D8B4541724E7146BF638C7A9C75572B7073DF1C89EC9C80C5051F0660B8E4C2_80;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::3DEAF093265AF4EEC46EFE3321D42FBAD2B18508D61F6480DADD5DEC9327B2DE
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___3DEAF093265AF4EEC46EFE3321D42FBAD2B18508D61F6480DADD5DEC9327B2DE_81;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::3ED82547E9BD5FB7617E169A99F37E2F6121DB1DFBB1E61F4178978F7E770BAC
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___3ED82547E9BD5FB7617E169A99F37E2F6121DB1DFBB1E61F4178978F7E770BAC_82;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::3EF5E96B58CF3C8FF9668077699352FCB1918FF573F13152CB5CE49BDE7B3AAE
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___3EF5E96B58CF3C8FF9668077699352FCB1918FF573F13152CB5CE49BDE7B3AAE_83;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::401B16525AEC9007E822722CB2BA3CB92BA1140F0A2ADFE08371137879EF3B1C
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___401B16525AEC9007E822722CB2BA3CB92BA1140F0A2ADFE08371137879EF3B1C_84;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::42E2A8B45012329DC16EB0680F6A2F20CCB83175D44D01379FF27DFDCA9C4CDD
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___42E2A8B45012329DC16EB0680F6A2F20CCB83175D44D01379FF27DFDCA9C4CDD_85;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::44C723622815A190A189BADC358688812A56231D91A9F758FD8108620738767E
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___44C723622815A190A189BADC358688812A56231D91A9F758FD8108620738767E_86;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::44F8921C986AD42BD76C1F7A83A41D8419E8ED840720079928E3C8231A87D871
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___44F8921C986AD42BD76C1F7A83A41D8419E8ED840720079928E3C8231A87D871_87;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::45DBEBBAB50D4934776BD46BEE43DC5C8759CAEFFD7B1795192EBFB1770426E9
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___45DBEBBAB50D4934776BD46BEE43DC5C8759CAEFFD7B1795192EBFB1770426E9_88;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::4658A9F91C7899BAA1F32C6D7A573540CF1559A1AF3BD98BB87294BC7252A8F9
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___4658A9F91C7899BAA1F32C6D7A573540CF1559A1AF3BD98BB87294BC7252A8F9_89;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::47056AC0DA7F68C4029C023FA92B1691A86B3AA2D398F55DF2F5D18B7C10C26D
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___47056AC0DA7F68C4029C023FA92B1691A86B3AA2D398F55DF2F5D18B7C10C26D_90;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::4BD5D87F09692EE6038FD4F79994AEA2BA45942D6608FE404A911B284D8658A0
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___4BD5D87F09692EE6038FD4F79994AEA2BA45942D6608FE404A911B284D8658A0_91;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::4C0E29A4139526D2B0F6365005FA67722210E461ABAA5812ED3510886909831D
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___4C0E29A4139526D2B0F6365005FA67722210E461ABAA5812ED3510886909831D_92;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256 <PrivateImplementationDetails>::4C77AAC59817D1AAFE2FC0DD87EEAB41C73F3E808FE7D883B3E214A50D5DAF80
	__StaticArrayInitTypeSizeU3D256_tD03A67F7FF737E6BC9D67A9F479BD26FCEAD3898 ___4C77AAC59817D1AAFE2FC0DD87EEAB41C73F3E808FE7D883B3E214A50D5DAF80_93;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::4DEB358BD4DCBB820BEEFA78DB1DD2A145F6A8D98959AFA16ECBFAD914B195BD
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___4DEB358BD4DCBB820BEEFA78DB1DD2A145F6A8D98959AFA16ECBFAD914B195BD_94;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::4DEE8EBC873433D34C5F20757233F2584059B009D978A87E1443B11E8FD7503E
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___4DEE8EBC873433D34C5F20757233F2584059B009D978A87E1443B11E8FD7503E_95;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::4E5F6429AE3CD49D176D3BB0B8B54DD1CAC073FF544D901259886429CD621B53
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___4E5F6429AE3CD49D176D3BB0B8B54DD1CAC073FF544D901259886429CD621B53_96;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::4E90313FD2428587A82788026D3458A35F4A9F16ED24BBB4C45C92DF07C5E31F
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___4E90313FD2428587A82788026D3458A35F4A9F16ED24BBB4C45C92DF07C5E31F_97;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::4F94706BDF211C39D955F9926D9D50695D7B552795C0D0A34A6336B92D56DE34
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___4F94706BDF211C39D955F9926D9D50695D7B552795C0D0A34A6336B92D56DE34_98;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::50A85ECA47561F6885FF9460D339D6B97855D09851B117E3048D033480DFEB7D
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___50A85ECA47561F6885FF9460D339D6B97855D09851B117E3048D033480DFEB7D_99;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::512602EB1E4BC9C5C1E802535BE6C72F9FD37FAC7B966721557039264274C385
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___512602EB1E4BC9C5C1E802535BE6C72F9FD37FAC7B966721557039264274C385_100;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::51F58A7579C0CC8BA15D3169B64D25F78BAF7245D8B0D228B51DD52BEC689B31
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___51F58A7579C0CC8BA15D3169B64D25F78BAF7245D8B0D228B51DD52BEC689B31_101;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::5220DACEFCBB6F67F6DC657877CA27AC0473EBF558A416EAB0CF81AC1BF2D207
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___5220DACEFCBB6F67F6DC657877CA27AC0473EBF558A416EAB0CF81AC1BF2D207_102;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::52C64076DB91C752808D3048E6FBCA87E43F4DABF0710494FF4ABAD149F4425D
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___52C64076DB91C752808D3048E6FBCA87E43F4DABF0710494FF4ABAD149F4425D_103;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::52CA86664438DCE1E58D046659E7EBEE750765DCAD6E4E91838B4A11E0EB5EF9
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___52CA86664438DCE1E58D046659E7EBEE750765DCAD6E4E91838B4A11E0EB5EF9_104;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::5593F1AAE0656CCB5BE70A58C6CED4F7CFED42BC8DD0ADE1B33AE7FC14C68591
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___5593F1AAE0656CCB5BE70A58C6CED4F7CFED42BC8DD0ADE1B33AE7FC14C68591_105;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::568612503415B974A7DBAEB0F80D62D7D0EBBDB95B44A504507F2B2BA6FC0B01
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___568612503415B974A7DBAEB0F80D62D7D0EBBDB95B44A504507F2B2BA6FC0B01_107;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::56FB1E7235E87D69106D2FCD0E25B928B6103D1C9324D128CA34786B2C0E1400
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___56FB1E7235E87D69106D2FCD0E25B928B6103D1C9324D128CA34786B2C0E1400_108;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::58120C82F8DF0ADF88E332C87D1B701F63E5F8275C48998C70A7198D983EBA9F
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___58120C82F8DF0ADF88E332C87D1B701F63E5F8275C48998C70A7198D983EBA9F_109;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::5859EF04E94C8A4748BB8D7D90E35D71AF54F884E01756F8C8837813C9819FFB
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___5859EF04E94C8A4748BB8D7D90E35D71AF54F884E01756F8C8837813C9819FFB_110;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::5861847429152C2F17DF5D6439D8C0BD53FE89A65395B72B8A4F2EC44BA77CC1
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___5861847429152C2F17DF5D6439D8C0BD53FE89A65395B72B8A4F2EC44BA77CC1_111;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::5B4CF157C2F10921822CD7687881E5DC2824083C35BBF544252DC35C49B896AD
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___5B4CF157C2F10921822CD7687881E5DC2824083C35BBF544252DC35C49B896AD_112;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::5B947FD5BA503FEF07237816EDFD578DCB6F54F58BA36930B9C0A31EE6EDE558
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___5B947FD5BA503FEF07237816EDFD578DCB6F54F58BA36930B9C0A31EE6EDE558_113;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::5BD05D4E30C2F409D5EAF5970A7F75E954B5DBBA4F0A42DCBD25D25B11ADB5CC
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___5BD05D4E30C2F409D5EAF5970A7F75E954B5DBBA4F0A42DCBD25D25B11ADB5CC_114;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::5BF3591800AF00CE0A7C0CD8A9518B9891F2D76C0EFEA2E40E9ED66CDF89564F
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___5BF3591800AF00CE0A7C0CD8A9518B9891F2D76C0EFEA2E40E9ED66CDF89564F_115;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::5C35E3D1202D9525D0B9B7E21D166669EF35226BFE85679B9357499E3CF77FC6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___5C35E3D1202D9525D0B9B7E21D166669EF35226BFE85679B9357499E3CF77FC6_116;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::5C518040AADAF54665D8BD5AB9C29BE687B9C094C430FBDAD3D3E29B918C57F8
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___5C518040AADAF54665D8BD5AB9C29BE687B9C094C430FBDAD3D3E29B918C57F8_117;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::5CA71A99167DAC82C90510F1ACA95D96B6CA4786F1773495A1904C04ECBABE22
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___5CA71A99167DAC82C90510F1ACA95D96B6CA4786F1773495A1904C04ECBABE22_118;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::5CC86296BB64DE740EBD89E2662CCEA286C8C846022C0C0AD40504D8D0409878
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___5CC86296BB64DE740EBD89E2662CCEA286C8C846022C0C0AD40504D8D0409878_119;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::5D1C0737734ACB3248F8E51558E7D7B849FE1C344FC4618531A9B6735F262361
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___5D1C0737734ACB3248F8E51558E7D7B849FE1C344FC4618531A9B6735F262361_120;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::5E6F08DCFDFFAD3E2973D32F8A99C0258ED1CB36F53EC59EA7F6BBD97AD3C12D
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___5E6F08DCFDFFAD3E2973D32F8A99C0258ED1CB36F53EC59EA7F6BBD97AD3C12D_121;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::607CD0570667D26DA0DCAC21BC730018B2538C379328EEAA01BABB952CE33E93
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___607CD0570667D26DA0DCAC21BC730018B2538C379328EEAA01BABB952CE33E93_122;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::624692357E9E5010AA5094E2FCFAF2319831FF390DA6916FCEA643F2B7817BE8
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___624692357E9E5010AA5094E2FCFAF2319831FF390DA6916FCEA643F2B7817BE8_123;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::62CB43725F16FA97B70CF1E0B908CE767997162E849731418EE29056D34448F2
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___62CB43725F16FA97B70CF1E0B908CE767997162E849731418EE29056D34448F2_124;
	// System.Int64 <PrivateImplementationDetails>::635977557E0426652C011DCAB402133ABD15F32A14E78AE863212406F86B0F42
	int64_t ___635977557E0426652C011DCAB402133ABD15F32A14E78AE863212406F86B0F42_125;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=580 <PrivateImplementationDetails>::6383AD8D3ACB5400C9BB99B6431A223D7472A06120C1C15C09458B0FCB291E2B
	__StaticArrayInitTypeSizeU3D580_t7177A4BBA75ED20CA1A352FB967C34235AE48422 ___6383AD8D3ACB5400C9BB99B6431A223D7472A06120C1C15C09458B0FCB291E2B_126;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::63BBA2B46D325365B88D69DBF88BAE2A2CF7B123FB85FAA33A6830396B047827
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___63BBA2B46D325365B88D69DBF88BAE2A2CF7B123FB85FAA33A6830396B047827_127;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::640E9A5B2D969F19710D9464A44577B46319C40114D6C7F8CBB951D261300583
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___640E9A5B2D969F19710D9464A44577B46319C40114D6C7F8CBB951D261300583_128;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::64A077BEBBA59201738F199F0C1B6B46DBC4F4E677ADB9628DBB32F1361E8053
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___64A077BEBBA59201738F199F0C1B6B46DBC4F4E677ADB9628DBB32F1361E8053_129;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::64C1A6DA613C2B82E1C2E94694D6516B521904DE59D93174186C0D3D4EAE2BAB
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___64C1A6DA613C2B82E1C2E94694D6516B521904DE59D93174186C0D3D4EAE2BAB_130;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::6620AD63C5E9CBD2475856AAF0488699ACA035E9A566AE49ABD7ABF2F7E85FD4
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___6620AD63C5E9CBD2475856AAF0488699ACA035E9A566AE49ABD7ABF2F7E85FD4_131;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::66E5E7AB424DD096605E51332FF630ADED08E0DE27F408C52F23E62160961EB1
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___66E5E7AB424DD096605E51332FF630ADED08E0DE27F408C52F23E62160961EB1_132;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::675B69E0213D2A517EF9395ADDFF37C94BDCDB3F88C9714E4EDCA5318BFAE786
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___675B69E0213D2A517EF9395ADDFF37C94BDCDB3F88C9714E4EDCA5318BFAE786_133;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::681FEEF111C94B333AE53E81F95F407D313D9806C11D48E069723C625B4BE2FD
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___681FEEF111C94B333AE53E81F95F407D313D9806C11D48E069723C625B4BE2FD_134;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::68814672AD5FB1D0C798D16A71D2C8E08D429CAAAD5A22E58C516F72F7642A69
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___68814672AD5FB1D0C798D16A71D2C8E08D429CAAAD5A22E58C516F72F7642A69_135;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::697BE5CDE31F5C321C6D64E117580E0BA313D24A25902C49ED3938334E9CF084
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___697BE5CDE31F5C321C6D64E117580E0BA313D24A25902C49ED3938334E9CF084_136;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::6A48E7A3AD36801F687A42A24C10C5922E971D0F4D644CF389EE2E9CC07AAB9B
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___6A48E7A3AD36801F687A42A24C10C5922E971D0F4D644CF389EE2E9CC07AAB9B_137;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6A7B1880BEA2EAA6B5CDC428541F8D9992354CCF55218B8B89EC4ED7298045C6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6A7B1880BEA2EAA6B5CDC428541F8D9992354CCF55218B8B89EC4ED7298045C6_138;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6B8BB6DD282A787CCAC06DE7EF734264916521025DF199F0E5497082AC580ADF
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6B8BB6DD282A787CCAC06DE7EF734264916521025DF199F0E5497082AC580ADF_139;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6C30D44EA7A13F718571429E4D8F6621A45B7CF0122465EDFEABA6E80FB87330
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6C30D44EA7A13F718571429E4D8F6621A45B7CF0122465EDFEABA6E80FB87330_140;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::6C5D0CBF114D662AC1E2386802B1266F2809CE3AEE8A443D164CB79092F36AFE
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___6C5D0CBF114D662AC1E2386802B1266F2809CE3AEE8A443D164CB79092F36AFE_141;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6CBC2F221CD0EC09C35D897C25706B38071B5CB529C2FE2975347E2F58B11A96
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6CBC2F221CD0EC09C35D897C25706B38071B5CB529C2FE2975347E2F58B11A96_142;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=80 <PrivateImplementationDetails>::6CD6F22E48C32F7A481A618A665B6B4ED74667B3B141883FFE46B8F48034A1B9
	__StaticArrayInitTypeSizeU3D80_t144B9F4F4C74AB89365AB7716EE83DECD70D210D ___6CD6F22E48C32F7A481A618A665B6B4ED74667B3B141883FFE46B8F48034A1B9_143;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::6CDE45BDA08B55851846630D80149ED24D8AEF83E3B07BBAABD1C564DC1044F1
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___6CDE45BDA08B55851846630D80149ED24D8AEF83E3B07BBAABD1C564DC1044F1_144;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::6D2F97FA698759FB9262B298743554980333A876EE8DF086EDA56638A8A78834
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___6D2F97FA698759FB9262B298743554980333A876EE8DF086EDA56638A8A78834_145;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::6E09C0FC98E406FCCD7F2623E4035602205AA3E7E8C2C9C10069D5FFA1F61EC5
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___6E09C0FC98E406FCCD7F2623E4035602205AA3E7E8C2C9C10069D5FFA1F61EC5_146;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::6E17FEE205C1C20B774A8BA24F020CD045FD4122529F32AD144296AA0356A2B5
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___6E17FEE205C1C20B774A8BA24F020CD045FD4122529F32AD144296AA0356A2B5_147;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6F1F0DC52AC678B17AFB705B6CF89EAD2F3261C3DA07C9989E43C7DCF6E960F1
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6F1F0DC52AC678B17AFB705B6CF89EAD2F3261C3DA07C9989E43C7DCF6E960F1_148;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6F2C9B30804CCF6C2FC189B4C318D293F95CAD8A09852E6D03E51F7A106EC2E3
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6F2C9B30804CCF6C2FC189B4C318D293F95CAD8A09852E6D03E51F7A106EC2E3_149;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::6F662300FF1DD8C7F482B7343CE76CFF72697818B8F67B9568748F9A7FECA726
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___6F662300FF1DD8C7F482B7343CE76CFF72697818B8F67B9568748F9A7FECA726_150;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::73C51B990F9B4865C43F83B6B1C2D31903975E6A32596A097F2DB2DA29F908C6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___73C51B990F9B4865C43F83B6B1C2D31903975E6A32596A097F2DB2DA29F908C6_151;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::7401236E106BCF9C9117CA90C8FF74F5F7D142EA0F191C461A1A829386EAD2F1
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___7401236E106BCF9C9117CA90C8FF74F5F7D142EA0F191C461A1A829386EAD2F1_152;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::74CF9302FBE15E2B4246F34CA0135A71F824FE2F9DBFE05DDAF207EF445EAD12
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___74CF9302FBE15E2B4246F34CA0135A71F824FE2F9DBFE05DDAF207EF445EAD12_153;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::74F53E03659898132848F049D6F9ACCF7E804E27A95FB9F0999B4BB13787B09D
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___74F53E03659898132848F049D6F9ACCF7E804E27A95FB9F0999B4BB13787B09D_154;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1_155;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::773C6CE57E1CA4558EE8D2F9F84478B08F5C4AFDA39E2A0E7AE2ABD5DDC234E9
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___773C6CE57E1CA4558EE8D2F9F84478B08F5C4AFDA39E2A0E7AE2ABD5DDC234E9_156;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::77CD021EE16F4D99FF1E46E049E2668EADDC68561DBA9EDE4733EB72689C9F06
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___77CD021EE16F4D99FF1E46E049E2668EADDC68561DBA9EDE4733EB72689C9F06_157;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::7D243B4E43463452F3E6EA1EBB925286D0E940A893249CB04D59CD7D1D6F3C74
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___7D243B4E43463452F3E6EA1EBB925286D0E940A893249CB04D59CD7D1D6F3C74_159;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256 <PrivateImplementationDetails>::7F4B3FCA7AE869DDE706ED3A88AFFA44F7C21B1E4A2C8867E27611FD8332BE71
	__StaticArrayInitTypeSizeU3D256_tD03A67F7FF737E6BC9D67A9F479BD26FCEAD3898 ___7F4B3FCA7AE869DDE706ED3A88AFFA44F7C21B1E4A2C8867E27611FD8332BE71_160;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::83D865C53313236C95417C8D524ECD1B0E4F316DC8F54D7A37F98559831B17A3
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___83D865C53313236C95417C8D524ECD1B0E4F316DC8F54D7A37F98559831B17A3_161;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::84AFE3F4AE71AB261F710B639C7475FBFA06FFB8A27B90E8172C2DF63F7FD363
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___84AFE3F4AE71AB261F710B639C7475FBFA06FFB8A27B90E8172C2DF63F7FD363_162;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::84D827AE746C63CEFCF75671A567E3B97B5B352FA977F648C3198F4543462B28
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___84D827AE746C63CEFCF75671A567E3B97B5B352FA977F648C3198F4543462B28_163;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::85D15662B08FB3CF478B1F1C065E21614A415DC8F8B896590680C8946A24A41A
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___85D15662B08FB3CF478B1F1C065E21614A415DC8F8B896590680C8946A24A41A_164;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::85E5D8679095F920E0D82A01751AD25E9B00475680A4154FCFCFADC6E30A20AB
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___85E5D8679095F920E0D82A01751AD25E9B00475680A4154FCFCFADC6E30A20AB_165;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::861F25D74DBF3A816FB6F0D495AD802381B9EFFA4C562074AFCB64A0F5196CE6
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___861F25D74DBF3A816FB6F0D495AD802381B9EFFA4C562074AFCB64A0F5196CE6_166;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::86F01946387CF934FBE389D802000FD9FA2F4D2947F575FF469B6920A3B414F7
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___86F01946387CF934FBE389D802000FD9FA2F4D2947F575FF469B6920A3B414F7_167;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::873CDFBFC7F50E0F13CC3A5E56CF708CA91D68616E754EA195D073034A880781
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___873CDFBFC7F50E0F13CC3A5E56CF708CA91D68616E754EA195D073034A880781_168;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::8A3B5D97EE2E051CE2D8ADB905FDFE0CAEA1D83968F79859287E2F24264650D9
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___8A3B5D97EE2E051CE2D8ADB905FDFE0CAEA1D83968F79859287E2F24264650D9_169;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::8A47C0D7AE3A8C573870A1D8FBF7A327B907DDF22A68ED8A8B38D178E9B058C6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___8A47C0D7AE3A8C573870A1D8FBF7A327B907DDF22A68ED8A8B38D178E9B058C6_170;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::8A4C9F7A4EFA5FBB82B5183E606BC64A69542560383398EB624BE576BE57CE93
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___8A4C9F7A4EFA5FBB82B5183E606BC64A69542560383398EB624BE576BE57CE93_171;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::8A6021816FD08F6B9DFD4033BBCD7F32B59FCE03A959A5BEB2D2A14502486F73
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___8A6021816FD08F6B9DFD4033BBCD7F32B59FCE03A959A5BEB2D2A14502486F73_172;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::8AC047D9D802B1E9E9AFDB8C74C697E280B1D5D4F48D51A768EAD5E969F6BEEB
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___8AC047D9D802B1E9E9AFDB8C74C697E280B1D5D4F48D51A768EAD5E969F6BEEB_173;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::8B38C919EB5FBF7AC1B77E23F1CE9AAA56CE5FB499D0C1FFE9D3160CD2595EA0
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___8B38C919EB5FBF7AC1B77E23F1CE9AAA56CE5FB499D0C1FFE9D3160CD2595EA0_174;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=88 <PrivateImplementationDetails>::8B8C120F0875E2687063572F979F0C7FBEC3F0EA5EA9A7F8EACC21B600EEC664
	__StaticArrayInitTypeSizeU3D88_t65BF68A956A9F2B6A6A963A48EBFFFB69B60BAEE ___8B8C120F0875E2687063572F979F0C7FBEC3F0EA5EA9A7F8EACC21B600EEC664_175;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::8BD213B01B4906EFE8F0DE29393E7F02EAD5B8E049787033B5060A0A345DE86E
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___8BD213B01B4906EFE8F0DE29393E7F02EAD5B8E049787033B5060A0A345DE86E_176;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::8DB1AC136F6F97A5F0F5EDDB0852F70CF008D55AA9B37662DE5461E92F5A8483
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___8DB1AC136F6F97A5F0F5EDDB0852F70CF008D55AA9B37662DE5461E92F5A8483_177;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::8E6FD625AA1CDB2C13E2431B743731F69505C2278B89438B266E7285E763EF44
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___8E6FD625AA1CDB2C13E2431B743731F69505C2278B89438B266E7285E763EF44_178;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=60 <PrivateImplementationDetails>::8F29157D0E3B4DFCBF316F25E1BDC7A7C54996F1CA04282487C1CBACC50B9E08
	__StaticArrayInitTypeSizeU3D60_t28DCDB387E585965787FF852575673A4F7B6A5E3 ___8F29157D0E3B4DFCBF316F25E1BDC7A7C54996F1CA04282487C1CBACC50B9E08_179;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::9138E46CDFD5C591E02876A779E6E4B5B5CB111696E1C1A9CC2162477B7D221F
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___9138E46CDFD5C591E02876A779E6E4B5B5CB111696E1C1A9CC2162477B7D221F_180;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::916FE145F25D59342D835557D6A331DEBE4FDE1DF70D2F32D6CF07E44C1ACD62
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___916FE145F25D59342D835557D6A331DEBE4FDE1DF70D2F32D6CF07E44C1ACD62_181;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::920B04C5A9768865C874A9FE3F98E673124F34B477B9909750F143A5AC62C21F
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___920B04C5A9768865C874A9FE3F98E673124F34B477B9909750F143A5AC62C21F_182;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::922221953321BF02C8879927737D395F66272CECA025C2AC5D91DF246319708C
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___922221953321BF02C8879927737D395F66272CECA025C2AC5D91DF246319708C_183;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::94941967214E72B79606650EFF5BE0B6CF7B986599D7FB52DFE173E1FA8A9349
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___94941967214E72B79606650EFF5BE0B6CF7B986599D7FB52DFE173E1FA8A9349_184;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::94B6E5AEB9521073C9B506A09EF885D6A9728C9E8B5FCBF6DDA5644F8B03F205
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___94B6E5AEB9521073C9B506A09EF885D6A9728C9E8B5FCBF6DDA5644F8B03F205_185;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=648 <PrivateImplementationDetails>::9756902AC8E7C7A2FF0D58555FF97B544666BAFEA5B38BC7A0B6461BFF3F1C6D
	__StaticArrayInitTypeSizeU3D648_tE3A7BE76C119987E420B4D758C218C61C87115D4 ___9756902AC8E7C7A2FF0D58555FF97B544666BAFEA5B38BC7A0B6461BFF3F1C6D_186;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::97972F0864CB317E825C7B65BD79C9CCB1EBA1CC93861B2C38CFEF456BB49367
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___97972F0864CB317E825C7B65BD79C9CCB1EBA1CC93861B2C38CFEF456BB49367_187;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::97EC34402E26D88E3DAEA8A17725D0D6B0351837D770654C8A212531D341CF12
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___97EC34402E26D88E3DAEA8A17725D0D6B0351837D770654C8A212531D341CF12_188;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9940EFA0D5444736A3A82771B5E3EB31E8288F7389221956710C5C566003ED7B
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9940EFA0D5444736A3A82771B5E3EB31E8288F7389221956710C5C566003ED7B_189;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9A02C56B617EFF64FD095865DAB69D360468FF726867C73F3BAE3F3B3AFFAB79
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9A02C56B617EFF64FD095865DAB69D360468FF726867C73F3BAE3F3B3AFFAB79_190;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::9A51CDB711FCB0D5AEC3330AA88D3325C492A8D2ACDC7E14870F80C75CC8376C
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___9A51CDB711FCB0D5AEC3330AA88D3325C492A8D2ACDC7E14870F80C75CC8376C_191;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::9A5726354FBE4A1D9E0A8481FEA0A70A6304724C3B6951CCE91CDB15F760528F
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___9A5726354FBE4A1D9E0A8481FEA0A70A6304724C3B6951CCE91CDB15F760528F_192;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::9A9F10C644B65298E073390DD6058765080DDDC836FA71F67BF371E92A225A0F
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___9A9F10C644B65298E073390DD6058765080DDDC836FA71F67BF371E92A225A0F_193;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::9B031A265600215C7C074E5ABB1B04D9DC7F1824A1966545C011DB470E2C0215
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___9B031A265600215C7C074E5ABB1B04D9DC7F1824A1966545C011DB470E2C0215_194;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9C20372E797EDB30F88A9EAB1D7B7B3DD8C6F9602B16E10D2859D8B3DC3E0DCE
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9C20372E797EDB30F88A9EAB1D7B7B3DD8C6F9602B16E10D2859D8B3DC3E0DCE_195;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9C612571059784972B8665B3857FC1FD8041D365E24E06CDD1E679C177BC7ABC
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9C612571059784972B8665B3857FC1FD8041D365E24E06CDD1E679C177BC7ABC_196;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::9C83BCF349B1E7E4596BAA05BB08C913B13F0C31E9FC0835D014D8F479545F04
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___9C83BCF349B1E7E4596BAA05BB08C913B13F0C31E9FC0835D014D8F479545F04_197;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::9CC022A833DFFDD6646771AE332B3A5D7FE3B84E83C581FA4C8E821EE2584468
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___9CC022A833DFFDD6646771AE332B3A5D7FE3B84E83C581FA4C8E821EE2584468_198;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9CC47C2A04820E146CA00E131165CF36CFFA5A3281B7C1DD0DC733A9F85CD465
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9CC47C2A04820E146CA00E131165CF36CFFA5A3281B7C1DD0DC733A9F85CD465_199;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9D61590678C1924844B2B639E88EB8F9D1CA3E18EFACD516A62E1D1EE25F260C
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9D61590678C1924844B2B639E88EB8F9D1CA3E18EFACD516A62E1D1EE25F260C_200;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::9D97292FE8BAF516671566FACE5733875434AA02C0F909A9E63EC1089031BC64
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___9D97292FE8BAF516671566FACE5733875434AA02C0F909A9E63EC1089031BC64_201;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::9E0D53D040166A546012AE72FB49FD58E6B8AB71D0F57D34D245F9EF2FEFE671
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___9E0D53D040166A546012AE72FB49FD58E6B8AB71D0F57D34D245F9EF2FEFE671_202;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::9E878E443B515CCF404813E40B26405A03ABD55A3E11D0A73A4F5727756BEFBD
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___9E878E443B515CCF404813E40B26405A03ABD55A3E11D0A73A4F5727756BEFBD_203;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::A00FE31E804C5FC43659D7B2F227832757CD31CDC4E9E13EA66A3B34F7F0EAE2
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___A00FE31E804C5FC43659D7B2F227832757CD31CDC4E9E13EA66A3B34F7F0EAE2_204;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::A13B49F15C03C67BA8EFB3769B5C3D938B724F76D621815556EB8129930746B4
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___A13B49F15C03C67BA8EFB3769B5C3D938B724F76D621815556EB8129930746B4_205;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::A1B1158FEFA54257BC412866F6F761A7757BF472961A4BD5C411DD0B41949D01
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___A1B1158FEFA54257BC412866F6F761A7757BF472961A4BD5C411DD0B41949D01_206;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::A3A1DACD5231636F689ECD1F39498B9C616275BCC1AA6C8B1F051EC48BC78A00
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___A3A1DACD5231636F689ECD1F39498B9C616275BCC1AA6C8B1F051EC48BC78A00_207;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48 <PrivateImplementationDetails>::A4886FC88EADB553F0300776411B64C557A02E7A09F9DF7DA871FB2F9F4C8278
	__StaticArrayInitTypeSizeU3D48_tB184AFC7E0116F4B6DAFA18B66C9B248A3A9F2FE ___A4886FC88EADB553F0300776411B64C557A02E7A09F9DF7DA871FB2F9F4C8278_208;
	// System.Int64 <PrivateImplementationDetails>::A553BADB17A168A36B44DA9D26F99CB2EEC465BFD5E69C5D695D0F2F66629EF5
	int64_t ___A553BADB17A168A36B44DA9D26F99CB2EEC465BFD5E69C5D695D0F2F66629EF5_209;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::A6B6CD1E63A8848C66E800B6291B1E8E4A8086B86E3C7CA512613793BDA0F0F8
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___A6B6CD1E63A8848C66E800B6291B1E8E4A8086B86E3C7CA512613793BDA0F0F8_210;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::A8E6F3543EA1F3A2AE236C68B686B3033D02F4E1906B0F12B11C0F337051CDBA
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___A8E6F3543EA1F3A2AE236C68B686B3033D02F4E1906B0F12B11C0F337051CDBA_211;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::A907C56D065442866F76567FE30FA552330DC6BBA117DA02C49CBF28C0A5BA47
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___A907C56D065442866F76567FE30FA552330DC6BBA117DA02C49CBF28C0A5BA47_212;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::A97867E38BB83E36A4BC17692364F6AD2E008B3B451E449E0E7D944576772A98
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___A97867E38BB83E36A4BC17692364F6AD2E008B3B451E449E0E7D944576772A98_213;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::A99025CF0F23EEC93A5EC79CE1B7CCB3BC79E29054B3A5BACC32BFFDBE281A0F
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___A99025CF0F23EEC93A5EC79CE1B7CCB3BC79E29054B3A5BACC32BFFDBE281A0F_214;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::AB4BE52CDD79F9448CE485A99B93452AFDE101AA73971AF5A26BA4601A273F2E
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___AB4BE52CDD79F9448CE485A99B93452AFDE101AA73971AF5A26BA4601A273F2E_215;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::AFEB048A6D9F9230284B06952FEF708C462804CFDFDE010F96FEF8A6BFD012CA
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___AFEB048A6D9F9230284B06952FEF708C462804CFDFDE010F96FEF8A6BFD012CA_216;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::AFF39163C20D6179B9E53C41B7819B3A236EEA535E819FA2D0EA77EF96C9E4CC
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___AFF39163C20D6179B9E53C41B7819B3A236EEA535E819FA2D0EA77EF96C9E4CC_217;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56 <PrivateImplementationDetails>::B07162360A24196C485A4CD84C719586FF98C1273BB35587F1015E822E146A72
	__StaticArrayInitTypeSizeU3D56_tF90903548CF34D92C9F741BD6D3F8DC6C822EF4E ___B07162360A24196C485A4CD84C719586FF98C1273BB35587F1015E822E146A72_218;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::B0DF4607936F04B115ABE287F1499D92C9C736B3919DFC851076616871B1C360
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___B0DF4607936F04B115ABE287F1499D92C9C736B3919DFC851076616871B1C360_219;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::B10B006404D9DA431F45BF1F6465B990B1496FFFDA5432E063E134E351C345E1
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___B10B006404D9DA431F45BF1F6465B990B1496FFFDA5432E063E134E351C345E1_220;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B186EACC6886BCFD4AF7F3692884C4E5CDC55BE8D95209B23C151A11B1DE255C
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B186EACC6886BCFD4AF7F3692884C4E5CDC55BE8D95209B23C151A11B1DE255C_221;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::B2059D748DC7392BDCAAC809DB985A4A2B0E2A5F572801F6B81B822B5FDC9C9E
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___B2059D748DC7392BDCAAC809DB985A4A2B0E2A5F572801F6B81B822B5FDC9C9E_222;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B4570AA177ED3F78CA9DB04894E0794007AD3B52578CDBA1DCB87A8A3F3323EE
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B4570AA177ED3F78CA9DB04894E0794007AD3B52578CDBA1DCB87A8A3F3323EE_223;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B5F53DABDC2D40444ED82802F012E3EEC52F51FA74650B9DC14E5F0723D9D89A
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B5F53DABDC2D40444ED82802F012E3EEC52F51FA74650B9DC14E5F0723D9D89A_224;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::B63DF9FB76B0F6E894A418E1B61B7FDF52F77CDE5B10B3CA831FB83C619A1C45
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___B63DF9FB76B0F6E894A418E1B61B7FDF52F77CDE5B10B3CA831FB83C619A1C45_225;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B6599D21CE74F24FA42D57991D6B0D0C5770322C90AF734EEB36A37F74090137
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B6599D21CE74F24FA42D57991D6B0D0C5770322C90AF734EEB36A37F74090137_226;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::B7578837808EEA752FA57DFD240C6918B8201730E41D547E33AC8F9D328B52B9
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___B7578837808EEA752FA57DFD240C6918B8201730E41D547E33AC8F9D328B52B9_227;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::B8AAC0B2535F749D5AF30A6508D718C62473BB732E4253999085E851BD68BD6D
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___B8AAC0B2535F749D5AF30A6508D718C62473BB732E4253999085E851BD68BD6D_228;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B8EF4B6722C962043F1E608EB00313D78EF4BA067CFAD8A8611C4CB13404E7A7
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B8EF4B6722C962043F1E608EB00313D78EF4BA067CFAD8A8611C4CB13404E7A7_229;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::B9775E5C66B54550D4543D0B527EEA928BDFF78D3170DC977B060DAD17C3C0E1
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___B9775E5C66B54550D4543D0B527EEA928BDFF78D3170DC977B060DAD17C3C0E1_230;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::B9BB64D36BB5B44357F1EEB212954DA57901429F8744EE67CD26DA6F2C29BC0A
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___B9BB64D36BB5B44357F1EEB212954DA57901429F8744EE67CD26DA6F2C29BC0A_231;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::B9BD6ADE68F48F3495171F58F91C0E390C0D0C9D7B5A7E8234D823171F6F8329
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___B9BD6ADE68F48F3495171F58F91C0E390C0D0C9D7B5A7E8234D823171F6F8329_232;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::BA718E3DED255F159544065CA7693F9D7B7B0E7C1548456C8490B6B24304431A
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___BA718E3DED255F159544065CA7693F9D7B7B0E7C1548456C8490B6B24304431A_233;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::BB3D0A80866E0616DD935CFB7423151BF2608A6E8695DDA0D857BD0599809A05
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___BB3D0A80866E0616DD935CFB7423151BF2608A6E8695DDA0D857BD0599809A05_234;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::BBDBE126749A9A567995F54E1A34249E47D56EF9BD063B3010A53296E87F510E
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___BBDBE126749A9A567995F54E1A34249E47D56EF9BD063B3010A53296E87F510E_235;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56 <PrivateImplementationDetails>::BC537B2506855BFC7B2F2150CC0AB9C9C70F7F06DFD2F66F51F3AA2A6C9AB7FD
	__StaticArrayInitTypeSizeU3D56_tF90903548CF34D92C9F741BD6D3F8DC6C822EF4E ___BC537B2506855BFC7B2F2150CC0AB9C9C70F7F06DFD2F66F51F3AA2A6C9AB7FD_236;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::BC972BE552BEDEE9F471AEDA02068ACC472C2443DF90535EA14F1FD2690AC66E
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___BC972BE552BEDEE9F471AEDA02068ACC472C2443DF90535EA14F1FD2690AC66E_237;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::BC9B5DB01C0368D30225D1F6659809CED20D91DFD116E2AE5FCAD937418133E3
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___BC9B5DB01C0368D30225D1F6659809CED20D91DFD116E2AE5FCAD937418133E3_238;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::BCAC3D7F2F9E332FDAEF6FA8FC30A0616EF05AFDC95D3C5228E434D244870853
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___BCAC3D7F2F9E332FDAEF6FA8FC30A0616EF05AFDC95D3C5228E434D244870853_239;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::BD0738D7C9D5FECF2A9CBEC856EAD6D5335A8298FB155662A1895EF8D2A2038D
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___BD0738D7C9D5FECF2A9CBEC856EAD6D5335A8298FB155662A1895EF8D2A2038D_240;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::BD5C2E0A91F1ECC84CF62822EC724B85102F62D93A89E039DC2339B72618A8AC
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___BD5C2E0A91F1ECC84CF62822EC724B85102F62D93A89E039DC2339B72618A8AC_241;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=64 <PrivateImplementationDetails>::BE0FA372785509D3CF35BE822960031AD25FDB4319BE1BF28ED0BADD99593969
	__StaticArrayInitTypeSizeU3D64_tC5DCC92F71FF4937EDBB6F52C59AD832172ABE88 ___BE0FA372785509D3CF35BE822960031AD25FDB4319BE1BF28ED0BADD99593969_242;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::BE1B7C040F46A858E925D3010FC918D360D02384ABA45652D7C0B4B94A88E876
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___BE1B7C040F46A858E925D3010FC918D360D02384ABA45652D7C0B4B94A88E876_243;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::BFBE4BB62036B11AB8AA966E904B7DC2E1B2F020A0714E70C2C4E42C5762ABED
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___BFBE4BB62036B11AB8AA966E904B7DC2E1B2F020A0714E70C2C4E42C5762ABED_244;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::BFD8331DDEC4B4B10E33E3E70EF726B6F1036B963C9E7D81C392A25014FDF7F6
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___BFD8331DDEC4B4B10E33E3E70EF726B6F1036B963C9E7D81C392A25014FDF7F6_245;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::C0755309CF35812DF4ADD23B902FF09D4F95BA1FE6389CA1DF62D06E9ED2DB9F
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___C0755309CF35812DF4ADD23B902FF09D4F95BA1FE6389CA1DF62D06E9ED2DB9F_246;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::C1E8CF52CCF3E3706F72C111A6664B90C736D77E774455029EFCBCA0B479C905
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___C1E8CF52CCF3E3706F72C111A6664B90C736D77E774455029EFCBCA0B479C905_247;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56 <PrivateImplementationDetails>::C2D2EE5C38760101FE989CB720E075F531765B2D10019610AB5CA156ABAB723F
	__StaticArrayInitTypeSizeU3D56_tF90903548CF34D92C9F741BD6D3F8DC6C822EF4E ___C2D2EE5C38760101FE989CB720E075F531765B2D10019610AB5CA156ABAB723F_248;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::C2EFB96D44834B7EA53771CEAE652CCD5F1A0E4F41092A490F2C17F317783EC0
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___C2EFB96D44834B7EA53771CEAE652CCD5F1A0E4F41092A490F2C17F317783EC0_249;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::C35F958D2EA552A8B3FC16DF1F3481614A8ECA96527C277EC06B570373614E96
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___C35F958D2EA552A8B3FC16DF1F3481614A8ECA96527C277EC06B570373614E96_250;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::C39E75F0FDE9B5E6330B103A1120EDA05C092A7C02409AE33215F94481761233
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___C39E75F0FDE9B5E6330B103A1120EDA05C092A7C02409AE33215F94481761233_251;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::C3D0E823C7FAD36C8BA14BC38375839FDA5BB9CA4D56EC569714151D054BCF12
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___C3D0E823C7FAD36C8BA14BC38375839FDA5BB9CA4D56EC569714151D054BCF12_252;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::C4755D406456E695DB2B9FAF87AE198CF4FE77C308D26499C6D83201190B58DF
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___C4755D406456E695DB2B9FAF87AE198CF4FE77C308D26499C6D83201190B58DF_253;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48 <PrivateImplementationDetails>::C4B60FBCB353853527B28174A4C98EF20A08C0AA7EB4C23C0D51D5981F23001C
	__StaticArrayInitTypeSizeU3D48_tB184AFC7E0116F4B6DAFA18B66C9B248A3A9F2FE ___C4B60FBCB353853527B28174A4C98EF20A08C0AA7EB4C23C0D51D5981F23001C_254;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::C5DEA22B4E77DCBB1CE4658670BD8FCC7969BDBD683002C46180CBD033767D49
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___C5DEA22B4E77DCBB1CE4658670BD8FCC7969BDBD683002C46180CBD033767D49_255;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::C699D3750DE7B2D83CAA1B84747F09401E982875DA67A0CBE36F0288C436BDF9
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___C699D3750DE7B2D83CAA1B84747F09401E982875DA67A0CBE36F0288C436BDF9_256;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::C7830C195CC71F3A08E20D1BA9C9DB012BFA75C1708902B5FA8A500C4C059D64
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___C7830C195CC71F3A08E20D1BA9C9DB012BFA75C1708902B5FA8A500C4C059D64_257;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::C8185DC090901A187F7582AE1A540C37D260DECB8A5B092C4D8A79B789289F57
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___C8185DC090901A187F7582AE1A540C37D260DECB8A5B092C4D8A79B789289F57_258;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::C881A58E0C50283A85282180E93215E1D53FF53F750014400F3B86468DDB6F4F
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___C881A58E0C50283A85282180E93215E1D53FF53F750014400F3B86468DDB6F4F_259;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::C96F2EBCBB10F4050DD5EE2F943F629E76F23EEE42660360D805B33FA7913374
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___C96F2EBCBB10F4050DD5EE2F943F629E76F23EEE42660360D805B33FA7913374_260;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::CA3B43AE23159FB95EB96D7ED3B99D40BC778E9AE6B4E7272B61BAB681267725
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___CA3B43AE23159FB95EB96D7ED3B99D40BC778E9AE6B4E7272B61BAB681267725_261;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::CA51E897967006FFCB4FD3F271E25380FCCEEBFA175C78F52430212A64BF9511
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___CA51E897967006FFCB4FD3F271E25380FCCEEBFA175C78F52430212A64BF9511_262;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::CB1CF0689348B07BFC308CFF234CC3E1DEECED752E91DE224125C76420D7349D
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___CB1CF0689348B07BFC308CFF234CC3E1DEECED752E91DE224125C76420D7349D_263;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::CBC9D1493E747769739A0A5D56654CAC7C73B7BD5B614B222B3C19F1FBA15464
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___CBC9D1493E747769739A0A5D56654CAC7C73B7BD5B614B222B3C19F1FBA15464_264;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::CC91326D93C5554F1BAB523404EC532B685F3282DAA88A87F8029FE585A04123
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___CC91326D93C5554F1BAB523404EC532B685F3282DAA88A87F8029FE585A04123_265;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::CCADC4882E99A79FC5AF28A1AADE2F4C1383A264CF790A6D00D1469A21C3DFEE
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___CCADC4882E99A79FC5AF28A1AADE2F4C1383A264CF790A6D00D1469A21C3DFEE_266;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::CCD3E9F1B8CD88544C237B3EEE901F9D9B5CC5B751F0AB7D29714CDE383CDF39
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___CCD3E9F1B8CD88544C237B3EEE901F9D9B5CC5B751F0AB7D29714CDE383CDF39_267;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::CE689E280AE2D5662D4C6A798E149D75C7B5EE2B25D79FE8920E592F55353306
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___CE689E280AE2D5662D4C6A798E149D75C7B5EE2B25D79FE8920E592F55353306_268;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::CE7BCFB39ED128BDABB818D6B8449CC69DD0A677B93F418A4BB29FA20CFF43A2
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___CE7BCFB39ED128BDABB818D6B8449CC69DD0A677B93F418A4BB29FA20CFF43A2_269;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::CF58A7C2FCCC14DCC0F4E45BFD95E7864096BC1ADF7F0B48E065BBEF4AAA514F
	__StaticArrayInitTypeSizeU3D32_tC3894D25C1E879699FE1C9BAB1BBF2787B405069 ___CF58A7C2FCCC14DCC0F4E45BFD95E7864096BC1ADF7F0B48E065BBEF4AAA514F_270;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::CFE7CE0F5DDFAF0C155A7E538668EB4E89DC5EDE4FE99E2E1B5A78AFFC1B94A8
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___CFE7CE0F5DDFAF0C155A7E538668EB4E89DC5EDE4FE99E2E1B5A78AFFC1B94A8_271;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::D013DBB50830B58EE87EFD2B8334E018742B55974AADC80E4333888059C7626F
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___D013DBB50830B58EE87EFD2B8334E018742B55974AADC80E4333888059C7626F_272;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::D0DC2836F5D93B08EF11DD5D0E82FF1310B6D4776D0FECB6CE9A9F6B71B4E8EB
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___D0DC2836F5D93B08EF11DD5D0E82FF1310B6D4776D0FECB6CE9A9F6B71B4E8EB_273;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::D0FAC11DA59EDABBFB2105A7E4C772634ACD7B7E5368E71647714539F26FDCFA
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___D0FAC11DA59EDABBFB2105A7E4C772634ACD7B7E5368E71647714539F26FDCFA_274;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::D11F8402B40EC96DD6A61455C41D6BF8F5E8B2B7E60BC43B6C32393FB3D452DA
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___D11F8402B40EC96DD6A61455C41D6BF8F5E8B2B7E60BC43B6C32393FB3D452DA_275;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36 <PrivateImplementationDetails>::D1C8C2936E4B0FFEC5BA839B62FC6A2B4E4D27CE17E347B829F556B285E2C045
	__StaticArrayInitTypeSizeU3D36_tE3135E025C70F21BBD65107243EE57F8AA699792 ___D1C8C2936E4B0FFEC5BA839B62FC6A2B4E4D27CE17E347B829F556B285E2C045_276;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::D42A49E0E184621C8A00094A3949785418937073F778D4B3F0B470C300FF703B
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___D42A49E0E184621C8A00094A3949785418937073F778D4B3F0B470C300FF703B_277;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::D4EC831A75DA4FAAE876CB34DC29BF3FF8FFDDDE43BB899E3F426034695C1979
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___D4EC831A75DA4FAAE876CB34DC29BF3FF8FFDDDE43BB899E3F426034695C1979_278;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::D557F2B5ED7B9F16C57AD352E38D82F0AC62E03184FFF16A2E322B813A84C3E4
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___D557F2B5ED7B9F16C57AD352E38D82F0AC62E03184FFF16A2E322B813A84C3E4_279;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::D566172A033DA445416546BB2F38B1795BB64762F5B02DD0AE87B3C5490236CA
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___D566172A033DA445416546BB2F38B1795BB64762F5B02DD0AE87B3C5490236CA_280;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::D5B003468F0EF169882177A905E2673578765591D43EB8FFFD7826748D1351AC
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___D5B003468F0EF169882177A905E2673578765591D43EB8FFFD7826748D1351AC_281;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=60 <PrivateImplementationDetails>::D822733F62996B603844DC44C09D8119E0407008DDF2CA0A8D0A602C5EF13BDD
	__StaticArrayInitTypeSizeU3D60_t28DCDB387E585965787FF852575673A4F7B6A5E3 ___D822733F62996B603844DC44C09D8119E0407008DDF2CA0A8D0A602C5EF13BDD_282;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::D87064FA9813CB5439408C97C857356484858B4DA0DE0864B571D917F62E8CB8
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___D87064FA9813CB5439408C97C857356484858B4DA0DE0864B571D917F62E8CB8_283;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44 <PrivateImplementationDetails>::D9842544146788BE6C76205189CC07B51402335D03CA246DEE66211DC647A10C
	__StaticArrayInitTypeSizeU3D44_tD483FB40E263381A07C87A97BBF2A1BD6BE3D1F9 ___D9842544146788BE6C76205189CC07B51402335D03CA246DEE66211DC647A10C_284;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::DB1F584B523F36FCE6602D0D04DB78DAB7AFF04848533ACBEA5EE8C7B94E116A
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___DB1F584B523F36FCE6602D0D04DB78DAB7AFF04848533ACBEA5EE8C7B94E116A_285;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::DBCFF6385D918CB19D22FD7408B08ACE7821B8BA9E24E08356DE0F0C3FFA5EDC
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___DBCFF6385D918CB19D22FD7408B08ACE7821B8BA9E24E08356DE0F0C3FFA5EDC_286;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::DC1D42499037ACD8465148A19883966EC730238E5C3AA1DF9E7E41D9B12D0E42
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___DC1D42499037ACD8465148A19883966EC730238E5C3AA1DF9E7E41D9B12D0E42_287;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::DCF8D5E3846033C97432F8E2852F002BD219E4E2C838648A19994477FB7632E8
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___DCF8D5E3846033C97432F8E2852F002BD219E4E2C838648A19994477FB7632E8_288;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::DD7477A8700AFDB6AF625224701A94969BBF0CCA848ADB3EC213712984D3EE12
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___DD7477A8700AFDB6AF625224701A94969BBF0CCA848ADB3EC213712984D3EE12_289;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::DDA728D9F9A5D8577C1ADCE453BDDFE0BEBBF0AE3C96FD331733CCAF7F23F4EE
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___DDA728D9F9A5D8577C1ADCE453BDDFE0BEBBF0AE3C96FD331733CCAF7F23F4EE_290;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::DDB13BF7D36145BA3424283864C3C6EB8CE986CF656FF20E97F2A841C862FF51
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___DDB13BF7D36145BA3424283864C3C6EB8CE986CF656FF20E97F2A841C862FF51_291;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::DE3BCA8F48DECF90ED8223F0D9F52307E62E210D8E9BEC33F14C1F53C7DB2048
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___DE3BCA8F48DECF90ED8223F0D9F52307E62E210D8E9BEC33F14C1F53C7DB2048_292;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::DE5859B5A095EEC3948A5BD9656FF92406D576751581F174EBC6F38C517B1E28
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___DE5859B5A095EEC3948A5BD9656FF92406D576751581F174EBC6F38C517B1E28_293;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::DF3A048366216DC94E037DD463273625D36F499FEFC457725D14B63CC7F1648C
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___DF3A048366216DC94E037DD463273625D36F499FEFC457725D14B63CC7F1648C_294;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::E2048B248E5931DD49F6CFED3DACBF51A46C9A143FFB34E7986F7E32CD7A155B
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___E2048B248E5931DD49F6CFED3DACBF51A46C9A143FFB34E7986F7E32CD7A155B_295;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::E2BABDF56C2D1B9DECC659CC40390089C98A8F2E5E78A94AA83644F6EFCA9045
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___E2BABDF56C2D1B9DECC659CC40390089C98A8F2E5E78A94AA83644F6EFCA9045_296;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::E2ECBD9A7A271BEB2E88282D3C24F971E35678BD759B97B7C9257A46C4002074
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___E2ECBD9A7A271BEB2E88282D3C24F971E35678BD759B97B7C9257A46C4002074_297;
	// System.Int64 <PrivateImplementationDetails>::E34558593A9EE51FCB84937EA3B8BE08C092CAAE330B95557B19C0CA7FF23821
	int64_t ___E34558593A9EE51FCB84937EA3B8BE08C092CAAE330B95557B19C0CA7FF23821_298;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::E34AF98E250871F595A2EEA36CDFC8E4ADA859ABCAF8C607DC519F81678BABE8
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___E34AF98E250871F595A2EEA36CDFC8E4ADA859ABCAF8C607DC519F81678BABE8_299;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::E3C316A3904D47FAAAB26B671F6E6A37D851BFBE58CF8A6DF4A17D40470875D4
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___E3C316A3904D47FAAAB26B671F6E6A37D851BFBE58CF8A6DF4A17D40470875D4_300;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::E40BCACFB43871F1F9E8A00969172FB6E32846FE965C77D557C2EF3A55ADEAAF
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___E40BCACFB43871F1F9E8A00969172FB6E32846FE965C77D557C2EF3A55ADEAAF_301;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::E641DEDE6EE2E4F2D0FD3194FCA86B5BB193066D452063AC9C642089F0AB099F
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___E641DEDE6EE2E4F2D0FD3194FCA86B5BB193066D452063AC9C642089F0AB099F_302;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::E74B325C01E38F08C2D31F79C554394BB553712819075AD4C6A9C33F37139194
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___E74B325C01E38F08C2D31F79C554394BB553712819075AD4C6A9C33F37139194_303;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::E86D3AE5C46778C1BFC65D4D9983961FE7F91516822D0095577FC169680E906F
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___E86D3AE5C46778C1BFC65D4D9983961FE7F91516822D0095577FC169680E906F_304;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::E9484E9181F8FEDF2C097076D63594DE2E285F7EEBCAE6303F4AAE44490FDFF4
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___E9484E9181F8FEDF2C097076D63594DE2E285F7EEBCAE6303F4AAE44490FDFF4_305;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::E9660B4F2318E8C7F657C5CBD43245F84F9F2A629C48CA438A17258132C94B55
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___E9660B4F2318E8C7F657C5CBD43245F84F9F2A629C48CA438A17258132C94B55_306;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::E97C1069904B81157D75F8FE72E08FAE570B49ACBB054F3D3D19B98DB024235A
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___E97C1069904B81157D75F8FE72E08FAE570B49ACBB054F3D3D19B98DB024235A_307;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=1024 <PrivateImplementationDetails>::EA3CF748EF2EED46C8D386654894EFB4A0ACA29E79789C2D3A4A27B57352CECD
	__StaticArrayInitTypeSizeU3D1024_t4A9D9610B3331D96BFF9BD065239C4091A2300C7 ___EA3CF748EF2EED46C8D386654894EFB4A0ACA29E79789C2D3A4A27B57352CECD_308;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::EAB62436D1A5E801E646B93D388A5AABFEEACC56D8225258B0A4905D78E91411
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___EAB62436D1A5E801E646B93D388A5AABFEEACC56D8225258B0A4905D78E91411_309;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::EB86821E2AA6BE324B814E73AB93BBF8452F9BAE0F1AB4B8ED326E798078D2D8
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___EB86821E2AA6BE324B814E73AB93BBF8452F9BAE0F1AB4B8ED326E798078D2D8_310;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::EBBB1CE96209B6C58389E344D4378A7BC2E2126C4384D3080046276EE5B71BD4
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___EBBB1CE96209B6C58389E344D4378A7BC2E2126C4384D3080046276EE5B71BD4_311;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::ED4B062D4B0C9BFF9BBA97602F1753F442ED6C55540B3B4B7E9E1EC08906875F
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___ED4B062D4B0C9BFF9BBA97602F1753F442ED6C55540B3B4B7E9E1EC08906875F_312;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::ED86DF4AFE9BE0DDD07686809E2879CAB3FA4186A66D790B7350864543BAC00C
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___ED86DF4AFE9BE0DDD07686809E2879CAB3FA4186A66D790B7350864543BAC00C_313;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::EDD75836071404EC5DCD2DA0D185E49951291D7335B336E49BFA77A46F338DC1
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___EDD75836071404EC5DCD2DA0D185E49951291D7335B336E49BFA77A46F338DC1_314;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::EE5DAE3DED105EC5BFF5EBE17488C3B7280CE88C23A43730D026F8FEAB397A76
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___EE5DAE3DED105EC5BFF5EBE17488C3B7280CE88C23A43730D026F8FEAB397A76_315;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::EE7C3E116E464671E45D6FFA73CC2643691C3390F4D9BED2D9342A34B7A90944
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___EE7C3E116E464671E45D6FFA73CC2643691C3390F4D9BED2D9342A34B7A90944_316;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::EF4F3C7D9B71F1C3A6142FBD17D0FB99F7FDB3B0FEBB1FD9BF9C87A668E428E9
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___EF4F3C7D9B71F1C3A6142FBD17D0FB99F7FDB3B0FEBB1FD9BF9C87A668E428E9_317;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::F0112A081BA1BF0B7AA3D8CB26C4786968862681751E9BBE50BF73736A11BDB0
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___F0112A081BA1BF0B7AA3D8CB26C4786968862681751E9BBE50BF73736A11BDB0_318;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::F1471E4ABCCC1A72C4ADDFB7B75247B0B96855B615366D4CD90B79C679940309
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___F1471E4ABCCC1A72C4ADDFB7B75247B0B96855B615366D4CD90B79C679940309_319;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::F3038D9FFFFF97511E2ABD1DDBF5E01EE39FD3B9DEE3B7B54D575B626A0620C5
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___F3038D9FFFFF97511E2ABD1DDBF5E01EE39FD3B9DEE3B7B54D575B626A0620C5_320;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::F3290AF51A82679F4AB24FDF0E1FBA44A1362F5347F09B738260AB5CD186A6C2
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___F3290AF51A82679F4AB24FDF0E1FBA44A1362F5347F09B738260AB5CD186A6C2_321;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::F3A3C0D34F4588F5741C55998A93E6C2B40FFBC8BEC5FC20B92143A7518EC99B
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___F3A3C0D34F4588F5741C55998A93E6C2B40FFBC8BEC5FC20B92143A7518EC99B_322;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::F42ACA88D464AED450A04EEF34589D45D7BBF9EFDAE6A965D00BA0F114889FD3
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___F42ACA88D464AED450A04EEF34589D45D7BBF9EFDAE6A965D00BA0F114889FD3_323;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::F47143F3AD86D91ADD15ADE4BAE54A6B9CDC392D2286818EC808383AEA39D5EB
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___F47143F3AD86D91ADD15ADE4BAE54A6B9CDC392D2286818EC808383AEA39D5EB_324;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::F485DBC7809638805F019BB16D12A1D94E127983CB97A243D4FB9536FB90C598
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___F485DBC7809638805F019BB16D12A1D94E127983CB97A243D4FB9536FB90C598_325;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::F53010C32C70ED509284F6446632E166E1934D8FD3F4C7DBD1B2759DB0164A93
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___F53010C32C70ED509284F6446632E166E1934D8FD3F4C7DBD1B2759DB0164A93_326;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::F5551793B11EC78B2B7CC32B5968B8E082DC8B736118186B5756B5F61DC41004
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___F5551793B11EC78B2B7CC32B5968B8E082DC8B736118186B5756B5F61DC41004_327;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::F5D76C9198F8507CF82079B19219EE21D92E08CC84B836A524E82E93BF71888B
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___F5D76C9198F8507CF82079B19219EE21D92E08CC84B836A524E82E93BF71888B_328;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::F616A0CB4D2DD7BA7731F7F9ECEC053D6EB28FB9748A5C75A35FC7DB7D060A22
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___F616A0CB4D2DD7BA7731F7F9ECEC053D6EB28FB9748A5C75A35FC7DB7D060A22_329;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28 <PrivateImplementationDetails>::F69BEB6D4EC13BC20A83D06A2B33D7D30CB84512B5FEF9AE3B05EC634555C6D6
	__StaticArrayInitTypeSizeU3D28_t523FB00435F599517548D4C121316CFE1B43E6C2 ___F69BEB6D4EC13BC20A83D06A2B33D7D30CB84512B5FEF9AE3B05EC634555C6D6_330;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::F7A385B962C0E3677425A33F0427AAA74B5E38B577BCD4E05856E1A67E49FE23
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___F7A385B962C0E3677425A33F0427AAA74B5E38B577BCD4E05856E1A67E49FE23_331;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::F7EA8E1580FD2A4D0B9C51D7F73208464A0E738F3514AC3DA226828C243F9377
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___F7EA8E1580FD2A4D0B9C51D7F73208464A0E738F3514AC3DA226828C243F9377_332;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::F8B09685F0F45D0D90BBED7CCE5AAA3B0E879072F59F90A8C873F4960F16ACF8
	__StaticArrayInitTypeSizeU3D12_t1BDD2193C3F925556BCD5FF35C0AC52DDB0CAB8F ___F8B09685F0F45D0D90BBED7CCE5AAA3B0E879072F59F90A8C873F4960F16ACF8_333;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::F8B1A943197570B6DE1E52A370F79AAEBF6FA3029B8E30F31C13C0A07DC9C7B3
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___F8B1A943197570B6DE1E52A370F79AAEBF6FA3029B8E30F31C13C0A07DC9C7B3_334;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::F93A7726D3A90B08EB74CC7980450AE77D8FA865D58EF42D5B0A3C6880F4432A
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___F93A7726D3A90B08EB74CC7980450AE77D8FA865D58EF42D5B0A3C6880F4432A_335;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=84 <PrivateImplementationDetails>::F95196E9D69EB29E6BFF06FA5FA6EEEF36FB372DC8D851CF000CF881B20F6EA0
	__StaticArrayInitTypeSizeU3D84_t9CAC1B1FF7C797961D00EA13F20F629B9C2B6BD9 ___F95196E9D69EB29E6BFF06FA5FA6EEEF36FB372DC8D851CF000CF881B20F6EA0_336;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::FA3ED4793B4A68D5C5978230A228D21CCB038E85B83A5800F9AE017F145F2932
	__StaticArrayInitTypeSizeU3D24_t3464DA68B6CCAB9A0A43F94B3DB9AA7E7FDDB19A ___FA3ED4793B4A68D5C5978230A228D21CCB038E85B83A5800F9AE017F145F2932_337;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52 <PrivateImplementationDetails>::FA8A196275F3E3EE6FFF5CAC1E864030ABE1F009869033F308BC1837D2B840A8
	__StaticArrayInitTypeSizeU3D52_t476AE0901E6E4D2C8E0A54312323C9D77D53BE71 ___FA8A196275F3E3EE6FFF5CAC1E864030ABE1F009869033F308BC1837D2B840A8_338;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68 <PrivateImplementationDetails>::FB7D017049F6F5BC45126DAD25ED758E9AE7ABB4F2BA3D96CA527768DDF3AEFF
	__StaticArrayInitTypeSizeU3D68_t1492D7B035AE52E6EA3A6DABCA1FE35C2CFC66A5 ___FB7D017049F6F5BC45126DAD25ED758E9AE7ABB4F2BA3D96CA527768DDF3AEFF_339;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40 <PrivateImplementationDetails>::FDE7C516B44C40A5FFCBE60626031B7B6740F09E0B9EB580431B758C7053FC02
	__StaticArrayInitTypeSizeU3D40_t68A41E1D2BAA1C55857C26F7E0C26D1CFDB100B3 ___FDE7C516B44C40A5FFCBE60626031B7B6740F09E0B9EB580431B758C7053FC02_340;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::FE465FCBDFBAD15DFBF55558C76FBBE675FC8720C32F6B08C78ADE18CCD3989E
	__StaticArrayInitTypeSizeU3D16_tFB2D94E174C3DFBC336BBEE6AD92E07462831A23 ___FE465FCBDFBAD15DFBF55558C76FBBE675FC8720C32F6B08C78ADE18CCD3989E_341;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20 <PrivateImplementationDetails>::FEA9F4CA8688E2AAC63B626BFBD34208AFCABFBD900A072570214FF1D5E94D9F
	__StaticArrayInitTypeSizeU3D20_tA394C0A7DC4F4F05D2190B09E23BDE8536718D72 ___FEA9F4CA8688E2AAC63B626BFBD34208AFCABFBD900A072570214FF1D5E94D9F_342;
};

// <PrivateImplementationDetails>

// WindBot.Game.AI.AIUtil

// WindBot.Game.AI.AIUtil

// WindBot.Game.ClientField

// WindBot.Game.ClientField

// WindBot.Game.GameAI

// WindBot.Game.GameAI

// System.String
struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// System.String

// WindBot.Game.AI.Decks.ZefraExecutor/<>c
struct U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields
{
	// WindBot.Game.AI.Decks.ZefraExecutor/<>c WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9
	U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* ___U3CU3E9_0;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__42_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__42_0_1;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__56_0
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__56_0_2;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__57_0
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__57_0_3;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__57_1
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__57_1_4;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__77_1
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__77_1_5;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__77_2
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__77_2_6;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__83_0
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__83_0_7;
	// System.Comparison`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__96_0
	Comparison_1_tCB6C68013648AE60E26CAC7EB38ADFF7FD206D46* ___U3CU3E9__96_0_8;
	// System.Comparison`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__103_0
	Comparison_1_tCB6C68013648AE60E26CAC7EB38ADFF7FD206D46* ___U3CU3E9__103_0_9;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__104_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__104_0_10;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__105_0
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__105_0_11;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__105_1
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__105_1_12;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__107_6
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__107_6_13;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__107_2
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__107_2_14;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__107_3
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__107_3_15;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__107_4
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__107_4_16;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__107_5
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__107_5_17;
	// System.Comparison`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__109_0
	Comparison_1_tCB6C68013648AE60E26CAC7EB38ADFF7FD206D46* ___U3CU3E9__109_0_18;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__109_1
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__109_1_19;
	// System.Func`2<WindBot.Game.ClientCard,System.Boolean> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__117_0
	Func_2_t71546D4401CF778C96F94375F7ECA52060D47BC2* ___U3CU3E9__117_0_20;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__124_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__124_0_21;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__127_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__127_0_22;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__129_1
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__129_1_23;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__143_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__143_0_24;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_0
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_0_25;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_4
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_4_26;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_5
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_5_27;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_6
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_6_28;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_1
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_1_29;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_2
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_2_30;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_7
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_7_31;
	// System.Comparison`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_8
	Comparison_1_tCB6C68013648AE60E26CAC7EB38ADFF7FD206D46* ___U3CU3E9__144_8_32;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_3
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_3_33;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_9
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_9_34;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_10
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_10_35;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_11
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_11_36;
	// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate WindBot.Game.AI.Decks.ZefraExecutor/<>c::<>9__144_12
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___U3CU3E9__144_12_37;
};

// WindBot.Game.AI.Decks.ZefraExecutor/<>c

// WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0

// WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func

// WindBot.Game.AI.Decks.ZefraExecutor/Func

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor/CardId

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor/CardId

// WindBot.Game.AI.Decks.ZoodiacExecutor/CardId

// WindBot.Game.AI.Decks.ZoodiacExecutor/CardId

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0

// WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0

// System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>

// System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>

// System.Collections.Generic.List`1/Enumerator<System.Object>

// System.Collections.Generic.List`1/Enumerator<System.Object>

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Boolean

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17_StaticFields
{
	// System.Byte[] System.Char::s_categoryForLatin1
	ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031* ___s_categoryForLatin1_3;
};

// System.Char

// System.Int32

// System.Int32

// System.IntPtr
struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// System.IntPtr

// System.UInt32

// System.UInt32

// System.Void

// System.Void

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=1024

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=1024

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=122

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=122

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=140

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=140

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=20

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=256

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=28

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=36

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=40

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=44

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=52

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=56

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=580

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=580

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=60

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=60

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=64

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=64

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=648

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=648

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=68

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=80

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=80

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=84

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=84

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=88

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=88

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=96

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=96

// YGOSharp.OCGWrapper.Enums.CardAttribute

// YGOSharp.OCGWrapper.Enums.CardAttribute

// YGOSharp.OCGWrapper.Enums.CardLocation

// YGOSharp.OCGWrapper.Enums.CardLocation

// YGOSharp.OCGWrapper.Enums.CardPosition

// YGOSharp.OCGWrapper.Enums.CardPosition

// YGOSharp.OCGWrapper.Enums.CardRace

// YGOSharp.OCGWrapper.Enums.CardRace

// YGOSharp.OCGWrapper.Enums.CardType

// YGOSharp.OCGWrapper.Enums.CardType

// YGOSharp.OCGWrapper.Enums.DuelPhase

// YGOSharp.OCGWrapper.Enums.DuelPhase

// WindBot.Game.AI.ExecutorType

// WindBot.Game.AI.ExecutorType

// System.RuntimeFieldHandle

// System.RuntimeFieldHandle

// WindBot.Game.ClientCard

// WindBot.Game.ClientCard

// WindBot.Game.Duel

// WindBot.Game.Duel

// WindBot.Game.AI.Executor

// WindBot.Game.AI.Executor

// System.Func`1<System.Boolean>

// System.Func`1<System.Boolean>

// WindBot.Game.AI.DefaultExecutor

// WindBot.Game.AI.DefaultExecutor

// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate

// WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate

// WindBot.Game.AI.Decks.ZefraExecutor

// WindBot.Game.AI.Decks.ZefraExecutor

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor

// WindBot.Game.AI.Decks.ZexalWeaponsExecutor

// WindBot.Game.AI.Decks.ZoodiacExecutor

// WindBot.Game.AI.Decks.ZoodiacExecutor
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C  : public RuntimeArray
{
	ALIGN_FIELD (8) int32_t m_Items[1];

	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918  : public RuntimeArray
{
	ALIGN_FIELD (8) RuntimeObject* m_Items[1];

	inline RuntimeObject* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline RuntimeObject* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};


// System.Boolean System.Collections.Generic.List`1<System.Int32>::Contains(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B_gshared (List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* __this, int32_t ___0_item, const RuntimeMethod* method) ;
// T[] System.Array::Empty<System.Object>()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_gshared_inline (const RuntimeMethod* method) ;
// System.Void System.Func`1<System.Boolean>::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22_gshared (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1/Enumerator<T> System.Collections.Generic.List`1<System.Object>::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A List_1_GetEnumerator_mD8294A7FA2BEB1929487127D476F8EC1CDC23BFC_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1/Enumerator<System.Object>::Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Enumerator_Dispose_mD9DC3E3C3697830A4823047AB29A77DBBB5ED419_gshared (Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1/Enumerator<System.Object>::get_Current()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* Enumerator_get_Current_m6330F15D18EE4F547C05DF9BF83C5EB710376027_gshared_inline (Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Object>::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_mE921CC8F29FBBDE7CC3209A0ED0D921D58D00BCB_gshared (Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;

// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2 (RuntimeObject* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate::Invoke(WindBot.Game.ClientCard)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Delegate_Invoke_m54D0E799B4210E0157DE6279F6458F9020DB0EA1_inline (Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::IsFaceup()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::IsDisabled()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_IsDisabled_m3E43E775A01C714E36F1B03E7B4C8BF9F38BAE4E (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasSetcode(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_setcode, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasType(YGOSharp.OCGWrapper.Enums.CardType)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_type, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_Level()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_Id()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.List`1<System.Int32>::Contains(T)
inline bool List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B (List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	return ((  bool (*) (List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73*, int32_t, const RuntimeMethod*))List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B_gshared)(__this, ___0_item, method);
}
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m3301CA4076FF903B568A0849179AF5925F7A137D (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::IsCode(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_id, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func::IsCode(WindBot.Game.ClientCard,System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___1_ids, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.AI.CardContainer::CompareCardLevel(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t CardContainer_CompareCardLevel_m4AAE7932231FA9CC19F46D24B122B3AD6405ADDF (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_cardA, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_cardB, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasRace(YGOSharp.OCGWrapper.Enums.CardRace)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasRace_m234DF96F8AEA29B13A59EDD1DFCEFC0E54C322EE (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_race, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func::HasSetCode(WindBot.Game.ClientCard,System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Func_HasSetCode_m35DB2E2FE9D9FDB7B83287C22BCADF21AAF34191 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___1_set_codes, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_LinkCount()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_LinkCount_m12CA020572EB98D3A1DB85EABC30D46FE0FCF10B_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// YGOSharp.OCGWrapper.Enums.CardLocation WindBot.Game.ClientCard::get_Location()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_Controller()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Controller_m28007482B2684652C06802B480F9F598C231DAD0_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Void System.Runtime.CompilerServices.RuntimeHelpers::InitializeArray(System.Array,System.RuntimeFieldHandle)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B (RuntimeArray* ___0_array, RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 ___1_fldHandle, const RuntimeMethod* method) ;
// WindBot.Game.ClientField WindBot.Game.AI.Executor::get_Bot()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::get_ExtraDeck()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_ExtraDeck_mAE2668EAF5688876EA70C0DD5CD1D9A8088AE11A_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Delegate__ctor_mDECCAD9085944EEC3B1A0A16631E227F69B5181C (Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method) ;
// T[] System.Array::Empty<System.Object>()
inline ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_inline (const RuntimeMethod* method)
{
	return ((  ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* (*) (const RuntimeMethod*))Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_gshared_inline)(method);
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func::CardsCheckAny(System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,WindBot.Game.AI.Decks.ZefraExecutor/Toos/Delegate,System.Object[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Func_CardsCheckAny_m9CBC3B4C36EA81D18B6FFE5B3D6045255524E7F2 (Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* __this, RuntimeObject* ___0_cards, Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* ___1_delegate, ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___2_parameters, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor::SecretoftheYangZingCheck(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZefraExecutor_SecretoftheYangZingCheck_mDF7F5B591520752B1F0404018817C510D667B04B (ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInExtra(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInExtra_m2BE03EF434011D09DF5EFE93509309010B5C4E10 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, int32_t ___0_cardId, const RuntimeMethod* method) ;
// System.Void WindBot.Game.AI.DefaultExecutor::.ctor(WindBot.Game.GameAI,WindBot.Game.Duel)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DefaultExecutor__ctor_mFB03F8D4D7C092E703EC737C97F2368B233B8F8A (DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317* __this, GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* ___0_ai, Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___1_duel, const RuntimeMethod* method) ;
// System.Void System.Func`1<System.Boolean>::.ctor(System.Object,System.IntPtr)
inline void Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22 (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method)
{
	((  void (*) (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*, RuntimeObject*, intptr_t, const RuntimeMethod*))Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22_gshared)(__this, ___0_object, ___1_method, method);
}
// System.Void WindBot.Game.AI.Executor::AddExecutor(WindBot.Game.AI.ExecutorType,System.Int32,System.Func`1<System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5 (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, int32_t ___0_type, int32_t ___1_cardId, Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* ___2_func, const RuntimeMethod* method) ;
// System.Void WindBot.Game.AI.Executor::AddExecutor(WindBot.Game.AI.ExecutorType,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30 (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, int32_t ___0_type, int32_t ___1_cardId, const RuntimeMethod* method) ;
// System.Void WindBot.Game.AI.Executor::AddExecutor(WindBot.Game.AI.ExecutorType,System.Func`1<System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Executor_AddExecutor_m289CA7A0A4918976416B3B734B8F478CDDF515D0 (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, int32_t ___0_type, Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* ___1_func, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.CardExtension::IsMonsterHasPreventActivationEffectInBattle(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool CardExtension_IsMonsterHasPreventActivationEffectInBattle_m2C71A673BE49220D06A8C77080EEC4C39253B010 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_Attribute()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Attribute_m2BF15C90C7580C500E07A65959685C82A2FC65BB_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInHand(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, int32_t ___0_cardId, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_RealPower()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_RealPower_m4832123BF47ECE4DE5ED8A240B6F0A6866B3B588_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.ClientCard::get_Attack()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Attack_m77751479CDA31D0D23600A59ADFADAA69F34364B_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Void WindBot.Game.ClientCard::set_RealPower(System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ClientCard_set_RealPower_m089EFE795FE98EAD61FE447D5B9A3CD25C21FBA7_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_value, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.DefaultExecutor::OnPreBattleBetween(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DefaultExecutor_OnPreBattleBetween_mA66327785BDDA23051E5C2CB5BDAFEC5087E964D (DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_attacker, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_defender, const RuntimeMethod* method) ;
// WindBot.Game.AI.AIUtil WindBot.Game.AI.Executor::get_Util()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.AI.AIUtil::SelectPreferredCards(System.Collections.Generic.IList`1<System.Int32>,System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* AIUtil_SelectPreferredCards_mF7650ACADAAE5251BAA51F59F435E933967C0D76 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, RuntimeObject* ___0_preferred, RuntimeObject* ___1_cards, int32_t ___2_min, int32_t ___3_max, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.AI.AIUtil::CheckSelectCount(System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* AIUtil_CheckSelectCount_mF0957A1BE342E93DD62F7AF39AA58B16124758AE (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, RuntimeObject* ___0__selected, RuntimeObject* ___1_cards, int32_t ___2_min, int32_t ___3_max, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.AIUtil::HasChainedTrap(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AIUtil_HasChainedTrap_m90DDFF98E8ABEA22AAF607094C650FECD84A60A4 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, int32_t ___0_player, const RuntimeMethod* method) ;
// WindBot.Game.Duel WindBot.Game.AI.Executor::get_Duel()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.Duel::get_Player()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_Player_m9193784EAEA68B33A6DBD25C84746FF9B4F21B14_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) ;
// YGOSharp.OCGWrapper.Enums.DuelPhase WindBot.Game.Duel::get_Phase()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) ;
// WindBot.Game.ClientCard WindBot.Game.AI.Executor::get_Card()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasXyzMaterial(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasXyzMaterial_m9C6FD0663219AEE4FAF385648DFB635BA715632E (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_count, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.AIUtil::IsOneEnemyBetterThanValue(System.Int32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AIUtil_IsOneEnemyBetterThanValue_mFE1B91B2577A3F5236B3D6925076D1D498BB4E4A (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, int32_t ___0_value, bool ___1_onlyATK, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.AI.Executor::get_ActivateDescription()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Executor_get_ActivateDescription_m2855E33CA44A88A7F15FFFA522E084F6E791604C_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.AI.AIUtil::GetStringId(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t AIUtil_GetStringId_mEA5B8E629F1A04FB9361B4AC4F6C736562A1A672 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, int32_t ___0_id, int32_t ___1_option, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::ZwWeapon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) ;
// WindBot.Game.GameAI WindBot.Game.AI.Executor::get_AI()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectCard(System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___0_ids, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::GetMonsters()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ClientField_GetMonsters_mD3C72712741F3DB1549B08EA2FBE37024F7BECC6 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1/Enumerator<T> System.Collections.Generic.List`1<WindBot.Game.ClientCard>::GetEnumerator()
inline Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108 (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* __this, const RuntimeMethod* method)
{
	return ((  Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 (*) (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F*, const RuntimeMethod*))List_1_GetEnumerator_mD8294A7FA2BEB1929487127D476F8EC1CDC23BFC_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>::Dispose()
inline void Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0 (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846* __this, const RuntimeMethod* method)
{
	((  void (*) (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846*, const RuntimeMethod*))Enumerator_Dispose_mD9DC3E3C3697830A4823047AB29A77DBBB5ED419_gshared)(__this, method);
}
// T System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>::get_Current()
inline ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_inline (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846* __this, const RuntimeMethod* method)
{
	return ((  ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* (*) (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846*, const RuntimeMethod*))Enumerator_get_Current_m6330F15D18EE4F547C05DF9BF83C5EB710376027_gshared_inline)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<WindBot.Game.ClientCard>::MoveNext()
inline bool Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76 (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846* __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846*, const RuntimeMethod*))Enumerator_MoveNext_mE921CC8F29FBBDE7CC3209A0ED0D921D58D00BCB_gshared)(__this, method);
}
// System.Void WindBot.Game.GameAI::SelectCard(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, int32_t ___0_cardId, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::get_Hand()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_Hand_m0C0F60D3ABFE161B581F21915DD028C46F61488E_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.AI.CardContainer::GetMonsters(System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* CardContainer_GetMonsters_m4EF93269A1EE13EAB9A78B645A6106D23A361E08 (RuntimeObject* ___0_cards, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::Equals(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_Equals_mD0D1DB381E502773C60748D1533EEC75A30886C6 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// WindBot.Game.ClientCard WindBot.Game.AI.AIUtil::GetLastChainCard()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* AIUtil_GetLastChainCard_m611B6F9EFFF776F4E0BC8C35BB4D35659B4036E5 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::IsCode(System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_IsCode_m63A6FFDC33AA76451064CDAF55B9B898036110EF (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___0_ids, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInHand(System.Collections.Generic.IList`1<System.Int32>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInHand_mCFAE19E46797EFE107A051446BA06C891518E10D (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, RuntimeObject* ___0_cardId, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectCard(System.Collections.Generic.IList`1<System.Int32>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectCard_mCFAE7CEA0FF2D502C64C6FD7D54DB162AE3AE649 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, RuntimeObject* ___0_ids, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectNextCard(System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___0_ids, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectPosition(YGOSharp.OCGWrapper.Enums.CardPosition)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, int32_t ___0_pos, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::IsAttack()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_IsAttack_m222452F0B994CD6410FFBB8643972BBC203E3913 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.DefaultExecutor::DefaultMonsterRepos()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DefaultExecutor_DefaultMonsterRepos_m99787A561C4CACBFD4D88353CA843B7598674C85 (DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317* __this, const RuntimeMethod* method) ;
// System.Void WindBot.Game.AI.DefaultExecutor::OnNewTurn()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DefaultExecutor_OnNewTurn_m3F03209FE11717A2E15EC706B4C91304A1BB50DB (DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.DefaultExecutor::DefaultCheckWhetherCardIsNegated(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DefaultExecutor_DefaultCheckWhetherCardIsNegated_mE335BD160D2D44EC641FDE5745CDD41C1C699A9D (DefaultExecutor_t5BA5ADE3DDD53943158F7DEABFF1C7030B7C6317* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.AI.AIUtil::IsOneEnemyBetter(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool AIUtil_IsOneEnemyBetter_mFD34E579A26FE83600B1E1C7BBF5BC79F6D00076 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, bool ___0_onlyATK, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::get_Graveyard()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// WindBot.Game.ClientField WindBot.Game.AI.Executor::get_Enemy()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* Executor_get_Enemy_mF9F9E24015075FB0C19396572F25879821E7660D_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<WindBot.Game.ClientCard>::.ctor()
inline void List_1__ctor_m16C7DC8619DE24DE2760056021DBB52CBB19ACAF (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// WindBot.Game.ClientCard WindBot.Game.AI.Decks.ZoodiacExecutor::GetAleisterInGrave()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ZoodiacExecutor_GetAleisterInGrave_m9EC7AB85888070EC8BA787661E78E3052A46BB4D (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasAttribute(YGOSharp.OCGWrapper.Enums.CardAttribute)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasAttribute_m635783178B1BECFA01B0B71C8DAB5AA5A75A276A (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_attribute, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectMaterials(System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectMaterials_mFA3B2AD902CDFC22A106D1AF96CF4704194FF017 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, RuntimeObject* ___0_cards, int32_t ___1_hint, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInMonstersZone(System.Int32,System.Boolean,System.Boolean,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, int32_t ___0_cardId, bool ___1_notDisabled, bool ___2_hasXyzMaterial, bool ___3_faceUp, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectMaterials(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, int32_t ___0_cardId, int32_t ___1_hint, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectYesNo(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, bool ___0_opt, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInGraveyard(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInGraveyard_mCB3594F299677CF121778BBB8C774262E414867D (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, int32_t ___0_cardId, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientField::HasInGraveyard(System.Collections.Generic.IList`1<System.Int32>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInGraveyard_mAED60820B814AA74D32462265A06DE0D93C7DBEF (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, RuntimeObject* ___0_cardId, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectNextCard(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectNextCard_mCE2E7113B1EAFDFB6999537F5EE9318A0B8BD68D (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, int32_t ___0_cardId, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectThirdCard(System.Int32[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectThirdCard_mBFF5B2E02CE0FB5251BA76DB92EFF75DC89BB571 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___0_ids, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectMaterials(System.Collections.Generic.IList`1<System.Int32>,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectMaterials_m2F980D71FCEB54FFC7CDE08C4D5041C4EFF0CB76 (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, RuntimeObject* ___0_ids, int32_t ___1_hint, const RuntimeMethod* method) ;
// System.Boolean WindBot.Game.ClientCard::HasXyzMaterial()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientCard_HasXyzMaterial_mF32DFDFB979DD73B7958A15A669B4FAACCAD49C0 (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) ;
// System.Int32 WindBot.Game.Duel::get_LastChainPlayer()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_LastChainPlayer_mC5B0E0859A850414FF721351866F32E42D7CF25E_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) ;
// WindBot.Game.ClientCard WindBot.Game.AI.AIUtil::GetBestEnemyCard(System.Boolean,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* AIUtil_GetBestEnemyCard_mBBB0AC8410DBC946860F12394240EF75061492C1 (AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* __this, bool ___0_onlyFaceup, bool ___1_canBeTarget, const RuntimeMethod* method) ;
// System.Void WindBot.Game.GameAI::SelectNextCard(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void GameAI_SelectNextCard_m7D4DE266B87FCBD8D9496386E25E7853FE93718B (GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::GetGraveyardMonsters()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ClientField_GetGraveyardMonsters_mCBB28BEF401FC8B467AC7625C33AD29858994281 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<WindBot.Game.ClientCard>::get_Count()
inline int32_t List_1_get_Count_mFD01966772F1C308D34514243361686DB88A421C_inline (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// System.Boolean WindBot.Game.ClientField::HasInSpellZone(System.Int32,System.Boolean,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ClientField_HasInSpellZone_m1113B0E04080515C3764EDDD27C32ABCEB740DE4 (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, int32_t ___0_cardId, bool ___1_notDisabled, bool ___2_faceUp, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<WindBot.Game.ClientCard> WindBot.Game.ClientField::GetSpells()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* ClientField_GetSpells_mD7EEB5F5D3FAF6C9CA8331CF5DF211C9F67CEA5B (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.Duel::get_CurrentChain()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* Duel_get_CurrentChain_m66427071DD3F49ECD30F770C94D41CB769FA79BA_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) ;
// System.Char System.String::get_Chars(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3 (String_t* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// System.Int32 System.String::get_Length()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline (String_t* __this, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass17_0__ctor_m1D473C5F60B7ADD6402D78C4E7018FFB9B1518B7 (U3CU3Ec__DisplayClass17_0_t3C4D4EE7E6524FB29D68B9043B03E17A15D9BBDD* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass17_0::<NegateFunc>b__0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass17_0_U3CNegateFuncU3Eb__0_mD327F87A931CBF877BD878C556C61BE6BC4B1639 (U3CU3Ec__DisplayClass17_0_t3C4D4EE7E6524FB29D68B9043B03E17A15D9BBDD* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card => { return !@delegate(card); };
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_0 = __this->___delegate_0;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_1 = ___0_card;
		NullCheck(L_0);
		bool L_2;
		L_2 = Delegate_Invoke_m54D0E799B4210E0157DE6279F6458F9020DB0EA1_inline(L_0, L_1, NULL);
		return (bool)((((int32_t)L_2) == ((int32_t)0))? 1 : 0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass28_0__ctor_m83325A294773B1BEBA97541F7177E257CD74E74E (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::<GetZoneCards>b__0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass28_0_U3CGetZoneCardsU3Eb__0_m120FF82ED78049D5DCBCFEEBE5B234AA0B7F9FC5 (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if ((loc & CardLocation.MonsterZone) > 0) result.AddRange(Toos.LinqWhere(player.MonsterZone, card => !(!card.IsFaceup() & feceup) && !(!card.IsDisabled() & disable)));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		bool L_2 = __this->___feceup_0;
		if (((int32_t)(((((int32_t)L_1) == ((int32_t)0))? 1 : 0)&(int32_t)L_2)))
		{
			goto IL_0026;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3 = ___0_card;
		NullCheck(L_3);
		bool L_4;
		L_4 = ClientCard_IsDisabled_m3E43E775A01C714E36F1B03E7B4C8BF9F38BAE4E(L_3, NULL);
		bool L_5 = __this->___disable_1;
		return (bool)((((int32_t)((int32_t)(((((int32_t)L_4) == ((int32_t)0))? 1 : 0)&(int32_t)L_5))) == ((int32_t)0))? 1 : 0);
	}

IL_0026:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::<GetZoneCards>b__1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass28_0_U3CGetZoneCardsU3Eb__1_m313604AED9C5A9C4D4F127662D3F9FC21468FCE0 (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if ((loc & CardLocation.SpellZone) > 0) result.AddRange(Toos.LinqWhere(player.SpellZone, card => !(!card.IsFaceup() & feceup) && !(!card.IsDisabled() & disable)));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		bool L_2 = __this->___feceup_0;
		if (((int32_t)(((((int32_t)L_1) == ((int32_t)0))? 1 : 0)&(int32_t)L_2)))
		{
			goto IL_0026;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3 = ___0_card;
		NullCheck(L_3);
		bool L_4;
		L_4 = ClientCard_IsDisabled_m3E43E775A01C714E36F1B03E7B4C8BF9F38BAE4E(L_3, NULL);
		bool L_5 = __this->___disable_1;
		return (bool)((((int32_t)((int32_t)(((((int32_t)L_4) == ((int32_t)0))? 1 : 0)&(int32_t)L_5))) == ((int32_t)0))? 1 : 0);
	}

IL_0026:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::<GetZoneCards>b__2(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass28_0_U3CGetZoneCardsU3Eb__2_m00A04A840CB2CE8F746917BED6CAA79AC2F9A450 (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if ((loc & CardLocation.PendulumZone) > 0) result.AddRange(Toos.LinqWhere(new List<ClientCard>() { player.SpellZone[0], player.SpellZone[4] }, card => !(!card.IsFaceup() & feceup) && !(!card.IsDisabled() & disable)));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		bool L_2 = __this->___feceup_0;
		if (((int32_t)(((((int32_t)L_1) == ((int32_t)0))? 1 : 0)&(int32_t)L_2)))
		{
			goto IL_0026;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3 = ___0_card;
		NullCheck(L_3);
		bool L_4;
		L_4 = ClientCard_IsDisabled_m3E43E775A01C714E36F1B03E7B4C8BF9F38BAE4E(L_3, NULL);
		bool L_5 = __this->___disable_1;
		return (bool)((((int32_t)((int32_t)(((((int32_t)L_4) == ((int32_t)0))? 1 : 0)&(int32_t)L_5))) == ((int32_t)0))? 1 : 0);
	}

IL_0026:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::<GetZoneCards>b__3(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass28_0_U3CGetZoneCardsU3Eb__3_m1BA85343060DCAAD3AAE7CA61987FC20F8EFF56F (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if ((loc & CardLocation.Removed) > 0) result.AddRange(Toos.LinqWhere(player.Banished, card => !(!card.IsFaceup() & feceup)));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		bool L_2 = __this->___feceup_0;
		return (bool)((((int32_t)((int32_t)(((((int32_t)L_1) == ((int32_t)0))? 1 : 0)&(int32_t)L_2))) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass28_0::<GetZoneCards>b__4(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass28_0_U3CGetZoneCardsU3Eb__4_m723BE99FC329B615DEFBDEBB0416D0697C09B453 (U3CU3Ec__DisplayClass28_0_t57E14477375DA36FAF66621D4C4B76BDEAFAE89C* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if ((loc & CardLocation.Extra) > 0) result.AddRange(Toos.LinqWhere(player.ExtraDeck, card => !(!card.IsFaceup() & feceup)));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		bool L_2 = __this->___feceup_0;
		return (bool)((((int32_t)((int32_t)(((((int32_t)L_1) == ((int32_t)0))? 1 : 0)&(int32_t)L_2))) == ((int32_t)0))? 1 : 0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass32_0__ctor_m923E3740DC8884FAA0630A9EF7FC444B668C584D (U3CU3Ec__DisplayClass32_0_t9A72BB44DF8E46921AB9AC829D6D7C0BBBD875A9* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass32_0::<GetPSpSummonLimilt>b__0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass32_0_U3CGetPSpSummonLimiltU3Eb__0_mEEA6DFA5E5B06C3629A86676DA569284A0D9DE25 (U3CU3Ec__DisplayClass32_0_t9A72BB44DF8E46921AB9AC829D6D7C0BBBD875A9* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	int32_t G_B3_0 = 0;
	{
		// return (setcode == -1 ? true : card.HasSetcode(setcode))
		//     || (setcode2 == -1 ? true : card.HasSetcode(setcode2));
		int32_t L_0 = __this->___setcode_0;
		if ((((int32_t)L_0) == ((int32_t)(-1))))
		{
			goto IL_0017;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_1 = ___0_card;
		int32_t L_2 = __this->___setcode_0;
		NullCheck(L_1);
		bool L_3;
		L_3 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_1, L_2, NULL);
		G_B3_0 = ((int32_t)(L_3));
		goto IL_0018;
	}

IL_0017:
	{
		G_B3_0 = 1;
	}

IL_0018:
	{
		if (G_B3_0)
		{
			goto IL_0032;
		}
	}
	{
		int32_t L_4 = __this->___setcode2_1;
		if ((((int32_t)L_4) == ((int32_t)(-1))))
		{
			goto IL_0030;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___0_card;
		int32_t L_6 = __this->___setcode2_1;
		NullCheck(L_5);
		bool L_7;
		L_7 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_5, L_6, NULL);
		return L_7;
	}

IL_0030:
	{
		return (bool)1;
	}

IL_0032:
	{
		return (bool)1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass35_0__ctor_mA41D0B3D6086F19DF93EFC6105353BAC07392C55 (U3CU3Ec__DisplayClass35_0_t92CE76AB7A9281F20FE93D2F38778051384ADC9E* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/Func/<>c__DisplayClass35_0::<GetPSpSummonMonster>b__0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass35_0_U3CGetPSpSummonMonsterU3Eb__0_mA6985D0BD3008F9A9D31DFB8F02BB209B9CFA382 (U3CU3Ec__DisplayClass35_0_t92CE76AB7A9281F20FE93D2F38778051384ADC9E* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		//      return card != lcard && card != rcard && card.HasType(CardType.Monster) && card.Level > MinScale && card.Level < MaxScale
		// && !no_p_spsummon_ids.Contains(card.Id) && @llimit(card) && @rlimit(card);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_1 = __this->___lcard_0;
		if ((((RuntimeObject*)(ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)L_0) == ((RuntimeObject*)(ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)L_1)))
		{
			goto IL_006a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3 = __this->___rcard_1;
		if ((((RuntimeObject*)(ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)L_2) == ((RuntimeObject*)(ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)L_3)))
		{
			goto IL_006a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = ___0_card;
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_4, 1, NULL);
		if (!L_5)
		{
			goto IL_006a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___0_card;
		NullCheck(L_6);
		int32_t L_7;
		L_7 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_6, NULL);
		int32_t L_8 = __this->___MinScale_2;
		if ((((int32_t)L_7) <= ((int32_t)L_8)))
		{
			goto IL_006a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9 = ___0_card;
		NullCheck(L_9);
		int32_t L_10;
		L_10 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_9, NULL);
		int32_t L_11 = __this->___MaxScale_3;
		if ((((int32_t)L_10) >= ((int32_t)L_11)))
		{
			goto IL_006a;
		}
	}
	{
		Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* L_12 = __this->___U3CU3E4__this_4;
		NullCheck(L_12);
		List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* L_13 = L_12->___no_p_spsummon_ids_1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_14 = ___0_card;
		NullCheck(L_14);
		int32_t L_15;
		L_15 = ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline(L_14, NULL);
		NullCheck(L_13);
		bool L_16;
		L_16 = List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B(L_13, L_15, List_1_Contains_m4FD96E89F15844C90032C7386BAB528817F1FF5B_RuntimeMethod_var);
		if (L_16)
		{
			goto IL_006a;
		}
	}
	{
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_17 = __this->___llimit_5;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_18 = ___0_card;
		NullCheck(L_17);
		bool L_19;
		L_19 = Delegate_Invoke_m54D0E799B4210E0157DE6279F6458F9020DB0EA1_inline(L_17, L_18, NULL);
		if (!L_19)
		{
			goto IL_006a;
		}
	}
	{
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_20 = __this->___rlimit_6;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_21 = ___0_card;
		NullCheck(L_20);
		bool L_22;
		L_22 = Delegate_Invoke_m54D0E799B4210E0157DE6279F6458F9020DB0EA1_inline(L_20, L_21, NULL);
		return L_22;
	}

IL_006a:
	{
		return (bool)0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m7FF48AED45B3D7F92124B27DFF6D24283A84E028 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* L_0 = (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87*)il2cpp_codegen_object_new(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CU3Ec__ctor_m3301CA4076FF903B568A0849179AF5925F7A137D(L_0, NULL);
		((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9_0 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9_0), (void*)L_0);
		return;
	}
}
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m3301CA4076FF903B568A0849179AF5925F7A137D (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<CheckShouldSpsummonExtraMonster>b__42_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CCheckShouldSpsummonExtraMonsterU3Eb__42_0_m71F29A41514112F1AB3390AD86F4FF6066BFF2A1 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// { return card.IsFaceup() && card.HasType(CardType.Pendulum); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		if (!L_1)
		{
			goto IL_0014;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)16777216), NULL);
		return L_3;
	}

IL_0014:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<Raidraptor_ArsenalFalconSummon>b__56_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CRaidraptor_ArsenalFalconSummonU3Eb__56_0_mD8D46DE6BA7936A603ED672509B7DFBE53291DDC (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.F_A_DawnDragster) && !card.IsCode(CardId.TheMightyMasterofMagic); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)33158448), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)3611830), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<Odd_EyesMeteorburstDragonCheck>b__57_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COdd_EyesMeteorburstDragonCheckU3Eb__57_0_m91FE3CDBE2FEB156AA682EB455DCB551DB1FA8CB (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.F_A_DawnDragster) && !card.IsCode(CardId.TheMightyMasterofMagic); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)33158448), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)3611830), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<Odd_EyesMeteorburstDragonCheck>b__57_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COdd_EyesMeteorburstDragonCheckU3Eb__57_1_m36A463F6026F6CDC1AED24ACC9C65547E1A4ED25 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// var materials_sy_lists = Util.GetSynchroMaterials(pre_materials, 7, 1, 1, false, true, null, card => { return !card.IsCode(CardId.MythicalBeastJackalKing) && !card.IsCode(CardId.HeraldoftheArcLight); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)27354732), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)79606837), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<IsCanSynchroSummon>b__77_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_1_m9D9AA859E7842E7C099EB279A2799B3EB03A756C (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_synchro_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// && func.CardsCheckAny(Bot.ExtraDeck, synchro_card => { return Func.IsCode(synchro_card, CardId.BorreloadSavageDragon, CardId.PSY_FramelordOmega); }))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_synchro_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)27548199));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)74586817));
		bool L_4;
		L_4 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_0, L_3, NULL);
		return L_4;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<IsCanSynchroSummon>b__77_2(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_2_mDF19FC72939BFC468F6E328844F567C4744D31B7 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_synchro_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// || (card.Level + level == 7 && SecretoftheYangZingCheck(card) && func.CardsCheckAny(Bot.ExtraDeck, synchro_card => { return Func.IsCode(synchro_card, CardId.Odd_EyesMeteorburstDragon, CardId.F_A_DawnDragster); }))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_synchro_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)80696379));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)33158448));
		bool L_4;
		L_4 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_0, L_3, NULL);
		return L_4;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<BorreloadSavageDragonSummon>b__83_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CBorreloadSavageDragonSummonU3Eb__83_0_mF0BCACB8DB262D4E53DE69479F56D2D6EA501ADA (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.F_A_DawnDragster) && !card.IsCode(CardId.TheMightyMasterofMagic) && !card.IsCode(CardId.HeraldoftheArcLight); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)33158448), NULL);
		if (L_1)
		{
			goto IL_0029;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)3611830), NULL);
		if (L_3)
		{
			goto IL_0029;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = ___0_card;
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_4, ((int32_t)79606837), NULL);
		return (bool)((((int32_t)L_5) == ((int32_t)0))? 1 : 0);
	}

IL_0029:
	{
		return (bool)0;
	}
}
// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/<>c::<LinkuribohSummon>b__96_0(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3CLinkuribohSummonU3Eb__96_0_m4EFC0707848712D5FE864A6B21BDF81E79B206DF (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_cardA, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_cardB, const RuntimeMethod* method) 
{
	{
		// if (cardA.HasType(CardType.Tuner) && !cardB.HasType(CardType.Tuner)) return 1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_cardA;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_0, ((int32_t)4096), NULL);
		if (!L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___1_cardB;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)4096), NULL);
		if (L_3)
		{
			goto IL_001c;
		}
	}
	{
		// if (cardA.HasType(CardType.Tuner) && !cardB.HasType(CardType.Tuner)) return 1;
		return 1;
	}

IL_001c:
	{
		// if (!cardA.HasType(CardType.Tuner) && cardB.HasType(CardType.Tuner)) return -1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = ___0_cardA;
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_4, ((int32_t)4096), NULL);
		if (L_5)
		{
			goto IL_0038;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___1_cardB;
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_6, ((int32_t)4096), NULL);
		if (!L_7)
		{
			goto IL_0038;
		}
	}
	{
		// if (!cardA.HasType(CardType.Tuner) && cardB.HasType(CardType.Tuner)) return -1;
		return (-1);
	}

IL_0038:
	{
		// return 0;
		return 0;
	}
}
// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/<>c::<HeavymetalfoesElectrumiteSummon>b__103_0(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3CHeavymetalfoesElectrumiteSummonU3Eb__103_0_m18ED881EEB7DAF9A686B84B9C845E9C7177C0573 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_cardA, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_cardB, const RuntimeMethod* method) 
{
	{
		// if ((cardA.Level == 3 || cardA.HasType(CardType.Tuner)) && cardB.Level != 3 && !cardB.HasType(CardType.Tuner)) return -1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_cardA;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_0, NULL);
		if ((((int32_t)L_1) == ((int32_t)3)))
		{
			goto IL_0016;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_cardA;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)4096), NULL);
		if (!L_3)
		{
			goto IL_002e;
		}
	}

IL_0016:
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = ___1_cardB;
		NullCheck(L_4);
		int32_t L_5;
		L_5 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_4, NULL);
		if ((((int32_t)L_5) == ((int32_t)3)))
		{
			goto IL_002e;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___1_cardB;
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_6, ((int32_t)4096), NULL);
		if (L_7)
		{
			goto IL_002e;
		}
	}
	{
		// if ((cardA.Level == 3 || cardA.HasType(CardType.Tuner)) && cardB.Level != 3 && !cardB.HasType(CardType.Tuner)) return -1;
		return (-1);
	}

IL_002e:
	{
		// if (cardA.Level != 3 && !cardA.HasType(CardType.Tuner) && (cardB.Level == 3 || cardB.HasType(CardType.Tuner))) return 1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_8 = ___0_cardA;
		NullCheck(L_8);
		int32_t L_9;
		L_9 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_8, NULL);
		if ((((int32_t)L_9) == ((int32_t)3)))
		{
			goto IL_005c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = ___0_cardA;
		NullCheck(L_10);
		bool L_11;
		L_11 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_10, ((int32_t)4096), NULL);
		if (L_11)
		{
			goto IL_005c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_12 = ___1_cardB;
		NullCheck(L_12);
		int32_t L_13;
		L_13 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_12, NULL);
		if ((((int32_t)L_13) == ((int32_t)3)))
		{
			goto IL_005a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_14 = ___1_cardB;
		NullCheck(L_14);
		bool L_15;
		L_15 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_14, ((int32_t)4096), NULL);
		if (!L_15)
		{
			goto IL_005c;
		}
	}

IL_005a:
	{
		// if (cardA.Level != 3 && !cardA.HasType(CardType.Tuner) && (cardB.Level == 3 || cardB.HasType(CardType.Tuner))) return 1;
		return 1;
	}

IL_005c:
	{
		// return CardContainer.CompareCardLevel(cardA, cardB);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_16 = ___0_cardA;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_17 = ___1_cardB;
		int32_t L_18;
		L_18 = CardContainer_CompareCardLevel_m4AAE7932231FA9CC19F46D24B122B3AD6405ADDF(L_16, L_17, NULL);
		return L_18;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<SecretoftheYangZingCheck>b__104_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSecretoftheYangZingCheckU3Eb__104_0_mE5B3FB9F0382BE68CFD2A4307C410AF8F940B9D1 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_p_card, const RuntimeMethod* method) 
{
	{
		// return p_card.HasSetcode(0xc4) && p_card.HasType(CardType.Pendulum);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_p_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_0, ((int32_t)196), NULL);
		if (!L_1)
		{
			goto IL_0019;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_p_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)16777216), NULL);
		return L_3;
	}

IL_0019:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<F_A_DawnDragsterSummon>b__105_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CF_A_DawnDragsterSummonU3Eb__105_0_m37F8C8C50B30A24A1781694FF0CC586C972C1705 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// var materials_lists = Util.GetSynchroMaterials(pre_materials, 7, 1, 1, false, true, null, card => { return !card.IsCode(CardId.MythicalBeastJackalKing) && !card.IsCode(CardId.HeraldoftheArcLight); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)27354732), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)79606837), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<F_A_DawnDragsterSummon>b__105_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CF_A_DawnDragsterSummonU3Eb__105_1_m2AA1D791429BE1FB9C1FE0EFDFA2CCE4B5B3401E (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card.HasType(CardType.Tuner) && card.HasRace(CardRace.Machine);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_0, ((int32_t)4096), NULL);
		if (!L_1)
		{
			goto IL_0016;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasRace_m234DF96F8AEA29B13A59EDD1DFCEFC0E54C322EE(L_2, ((int32_t)32), NULL);
		return L_3;
	}

IL_0016:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<MechaPhantomBeastAuroradonSummon>b__107_6(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CMechaPhantomBeastAuroradonSummonU3Eb__107_6_mC9D091FD556512A591B61956D99ACF129FEB3195 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_scard, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// { return Func.HasSetCode(scard, 0xaf, 0xae) && scard.Id != CardId.DDLamia; }) > 0);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_scard;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)175));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)174));
		bool L_4;
		L_4 = Func_HasSetCode_m35DB2E2FE9D9FDB7B83287C22BCADF21AAF34191(L_0, L_3, NULL);
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___0_scard;
		NullCheck(L_5);
		int32_t L_6;
		L_6 = ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline(L_5, NULL);
		return (bool)((((int32_t)((((int32_t)L_6) == ((int32_t)((int32_t)19580308)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_002f:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<MechaPhantomBeastAuroradonSummon>b__107_2(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CMechaPhantomBeastAuroradonSummonU3Eb__107_2_m3993E351D0EF217CA0FAD49C1FDF1F52973D5F6B (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if (!summoned) pre_materials.AddRange(func.CardsCheckWhere(Bot.Hand, card => { return !card.IsCode(CardId.DestrudotheLostDragon_Frisson) && card.Level < 5; }));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)5560911), NULL);
		if (L_1)
		{
			goto IL_0017;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		int32_t L_3;
		L_3 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_2, NULL);
		return (bool)((((int32_t)L_3) < ((int32_t)5))? 1 : 0);
	}

IL_0017:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<MechaPhantomBeastAuroradonSummon>b__107_3(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CMechaPhantomBeastAuroradonSummonU3Eb__107_3_mAF4E0FB8C8C12091B95610EDE9A12043F6916718 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// var synchro_materials_lists = Util.GetSynchroMaterials(pre_materials, 7, 1, 1, false, true, null, card => { return !card.IsCode(CardId.MythicalBeastJackalKing); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)27354732), NULL);
		return (bool)((((int32_t)L_1) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<MechaPhantomBeastAuroradonSummon>b__107_4(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CMechaPhantomBeastAuroradonSummonU3Eb__107_4_mEF4192E1D5789528BED1BE8580269C7E992811C0 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.F_A_DawnDragster) && !card.IsCode(CardId.TheMightyMasterofMagic); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)33158448), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)3611830), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<MechaPhantomBeastAuroradonSummon>b__107_5(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CMechaPhantomBeastAuroradonSummonU3Eb__107_5_m0A6AE9E55EB691A6644AF66CE7451EECA03E9E4D (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.F_A_DawnDragster) && !card.IsCode(CardId.TheMightyMasterofMagic); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)33158448), NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)3611830), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/<>c::<SaryujaSkullDreadSummon>b__109_0(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3CSaryujaSkullDreadSummonU3Eb__109_0_m72AA77086C538544550F04D05A0E9F3796A69FE3 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_cardA, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_cardB, const RuntimeMethod* method) 
{
	{
		// if ((cardA.HasType(CardType.Tuner) && cardB.HasType(CardType.Tuner))
		// || (!cardA.HasType(CardType.Tuner) && !cardB.HasType(CardType.Tuner)))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_cardA;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_0, ((int32_t)4096), NULL);
		if (!L_1)
		{
			goto IL_001a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___1_cardB;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)4096), NULL);
		if (L_3)
		{
			goto IL_0034;
		}
	}

IL_001a:
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = ___0_cardA;
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_4, ((int32_t)4096), NULL);
		if (L_5)
		{
			goto IL_003c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___1_cardB;
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_6, ((int32_t)4096), NULL);
		if (L_7)
		{
			goto IL_003c;
		}
	}

IL_0034:
	{
		// return CardContainer.CompareCardLevel(cardA, cardB);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_8 = ___0_cardA;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9 = ___1_cardB;
		int32_t L_10;
		L_10 = CardContainer_CompareCardLevel_m4AAE7932231FA9CC19F46D24B122B3AD6405ADDF(L_8, L_9, NULL);
		return L_10;
	}

IL_003c:
	{
		// else if (cardA.HasType(CardType.Tuner) && !cardB.HasType(CardType.Tuner)) return 1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_11 = ___0_cardA;
		NullCheck(L_11);
		bool L_12;
		L_12 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_11, ((int32_t)4096), NULL);
		if (!L_12)
		{
			goto IL_0058;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_13 = ___1_cardB;
		NullCheck(L_13);
		bool L_14;
		L_14 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_13, ((int32_t)4096), NULL);
		if (L_14)
		{
			goto IL_0058;
		}
	}
	{
		// else if (cardA.HasType(CardType.Tuner) && !cardB.HasType(CardType.Tuner)) return 1;
		return 1;
	}

IL_0058:
	{
		// return -1;
		return (-1);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<SaryujaSkullDreadSummon>b__109_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSaryujaSkullDreadSummonU3Eb__109_1_mCE1E50043A46F9131F5F81ABC584E0E5E5B508AA (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// (Bot, CardLocation.Onfield | CardLocation.Hand, true), card => { return Func.HasSetCode(card, 0xaf, 0xae) && card.Id != CardId.DDLamia; })
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)175));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)174));
		bool L_4;
		L_4 = Func_HasSetCode_m35DB2E2FE9D9FDB7B83287C22BCADF21AAF34191(L_0, L_3, NULL);
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___0_card;
		NullCheck(L_5);
		int32_t L_6;
		L_6 = ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline(L_5, NULL);
		return (bool)((((int32_t)((((int32_t)L_6) == ((int32_t)((int32_t)19580308)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_002f:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<Denglong_FirstoftheYangZingSummon>b__117_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CDenglong_FirstoftheYangZingSummonU3Eb__117_0_m0EB7CAAF1E18931215AD57D3D9D45F66D970C088 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// card => { return !card.IsCode(CardId.HeraldoftheArcLight); });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)79606837), NULL);
		return (bool)((((int32_t)L_1) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<JetSynchronEffect>b__124_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CJetSynchronEffectU3Eb__124_0_m3FE708C9BC3253E354BD68F9EDFA5F0ADC4E78D9 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (func.CardsCheckAny(Func.GetZoneCards(Bot, CardLocation.Extra), card => { return card.HasType(CardType.Synchro) || Func.IsCode(card, CardId.CrystronHalqifibrax, CardId.Linkuriboh); }))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_0, ((int32_t)8192), NULL);
		if (L_1)
		{
			goto IL_002a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = L_3;
		NullCheck(L_4);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)50588353));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = L_4;
		NullCheck(L_5);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)41999284));
		bool L_6;
		L_6 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_2, L_5, NULL);
		return L_6;
	}

IL_002a:
	{
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<SupremeKingDragonDarkwurmSummon>b__127_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSupremeKingDragonDarkwurmSummonU3Eb__127_0_mAB720D2EC86667C7822D0B4944D0F502519B9E11 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// || (func.CardsCheckAny(Func.GetZoneCards(Bot, CardLocation.Hand), card => { return card.LinkCount > 5; }) &&
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_LinkCount_m12CA020572EB98D3A1DB85EABC30D46FE0FCF10B_inline(L_0, NULL);
		return (bool)((((int32_t)L_1) > ((int32_t)5))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<IsCanSPSummonTunerLevel1>b__129_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CIsCanSPSummonTunerLevel1U3Eb__129_1_mACECDB2D303871F09D8F7ECC6EB24E2E68C0FF3B (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_scard, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return (card.IsCode(CardId.DDLamia) && !activate_DDLamia && func.CardsCheckCount(Func.GetZoneCards(Bot, CardLocation.Onfield | CardLocation.Hand, true), scard => { return Func.HasSetCode(scard, 0xaf, 0xae) && scard.Id != CardId.DDLamia; })
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_scard;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)175));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)174));
		bool L_4;
		L_4 = Func_HasSetCode_m35DB2E2FE9D9FDB7B83287C22BCADF21AAF34191(L_0, L_3, NULL);
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___0_scard;
		NullCheck(L_5);
		int32_t L_6;
		L_6 = ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline(L_5, NULL);
		return (bool)((((int32_t)((((int32_t)L_6) == ((int32_t)((int32_t)19580308)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_002f:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<_OnSelectPendulumSummon>b__143_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3C_OnSelectPendulumSummonU3Eb__143_0_m05C397A3FDED4ACD43298702CCAA1578EEC651BC (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card.HasSetcode(0xc4) && !card.IsCode(CardId.Zefraath);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_0, ((int32_t)196), NULL);
		if (!L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)29432356), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_0_mA0C1121FCCBC0B88733BB620EFFD8EAA7DFBDE5E (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if (func.CardsCheckAny(cards, card => { return card.Location == CardLocation.Deck && card.HasSetcode(0xc4); }))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_0, NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0015;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_2, ((int32_t)196), NULL);
		return L_3;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_4(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_4_m4A354C0E7D2264BF9B376B2D6A080D9EDDD41A45 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card.HasType(CardType.Pendulum) && !card.IsCode(CardId.Zefraath);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_0, ((int32_t)16777216), NULL);
		if (!L_1)
		{
			goto IL_001c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)29432356), NULL);
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}

IL_001c:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_5(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_5_mDFC6F559B624A9EF11DD716E9D1AA5E169A0BAAD (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if (func.CardsCheckAny(Bot.Hand, card => { return card.Level < 7 && card.HasType(CardType.Monster); })) ids.Add(CardId.DestrudotheLostDragon_Frisson);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_0, NULL);
		if ((((int32_t)L_1) >= ((int32_t)7)))
		{
			goto IL_0011;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, 1, NULL);
		return L_3;
	}

IL_0011:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_6(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_6_m9D1B436DE5AD745D63B2328709E580ADF30E8BDA (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if (!activate_ShaddollZefracore && func.CardsCheckAny(Func.GetZoneCards(Bot, CardLocation.PendulumZone, true), card => { return !card.IsCode(CardId.Zefraath) && card.HasSetcode(0xc4); })) ids.Add(CardId.ShaddollZefracore);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)29432356), NULL);
		if (L_1)
		{
			goto IL_0019;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasSetcode_m96B739072C39007F8B0EC44EA74EF17C9D51CDE7(L_2, ((int32_t)196), NULL);
		return L_3;
	}

IL_0019:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_1(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_1_m73655823B911D59198C41AF156FEB81BD380E96C (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card.IsCode(CardId.TheMightyMasterofMagic) || card.IsCode(CardId.MythicalBeastJackalKing);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)3611830), NULL);
		if (L_1)
		{
			goto IL_0019;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_2, ((int32_t)27354732), NULL);
		return L_3;
	}

IL_0019:
	{
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_2(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_2_m3163C61947AC54AD3C2B89FB9F49F256B903C54E (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// if (func.CardsCheckALL(cards, card => { return card.Controller == 0 && card.IsFaceup(); }, true))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Controller_m28007482B2684652C06802B480F9F598C231DAD0_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000f;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_2, NULL);
		return L_3;
	}

IL_000f:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_7(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_7_mFBF6B094CF52D10C6CD3DF748870BA28C6BA1FBE (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// List<ClientCard> scards = func.CardsCheckWhere(cards, card => { return card.Location == CardLocation.SpellZone; });
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_0, NULL);
		return (bool)((((int32_t)L_1) == ((int32_t)8))? 1 : 0);
	}
}
// System.Int32 WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_8(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t U3CU3Ec_U3COnSelectCardU3Eb__144_8_m39BABB2B06CE087C5B10D38FA524D565A112050D (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_cardA, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_cardB, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (Func.IsCode(cardA, CardId.OracleofZefra, CardId.DarkContractwiththGate) && !Func.IsCode(cardB, CardId.OracleofZefra, CardId.DarkContractwiththGate)) return 1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_cardA;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)32354768));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)46372010));
		bool L_4;
		L_4 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_0, L_3, NULL);
		if (!L_4)
		{
			goto IL_003e;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___1_cardB;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_6 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_7 = L_6;
		NullCheck(L_7);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)32354768));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_8 = L_7;
		NullCheck(L_8);
		(L_8)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)46372010));
		bool L_9;
		L_9 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_5, L_8, NULL);
		if (L_9)
		{
			goto IL_003e;
		}
	}
	{
		// if (Func.IsCode(cardA, CardId.OracleofZefra, CardId.DarkContractwiththGate) && !Func.IsCode(cardB, CardId.OracleofZefra, CardId.DarkContractwiththGate)) return 1;
		return 1;
	}

IL_003e:
	{
		// if (!Func.IsCode(cardA, CardId.OracleofZefra, CardId.DarkContractwiththGate) && Func.IsCode(cardB, CardId.OracleofZefra, CardId.DarkContractwiththGate)) return -1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = ___0_cardA;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_11 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_12 = L_11;
		NullCheck(L_12);
		(L_12)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)32354768));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_13 = L_12;
		NullCheck(L_13);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)46372010));
		bool L_14;
		L_14 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_10, L_13, NULL);
		if (L_14)
		{
			goto IL_007c;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_15 = ___1_cardB;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_16 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_17 = L_16;
		NullCheck(L_17);
		(L_17)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)32354768));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_18 = L_17;
		NullCheck(L_18);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)46372010));
		bool L_19;
		L_19 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_15, L_18, NULL);
		if (!L_19)
		{
			goto IL_007c;
		}
	}
	{
		// if (!Func.IsCode(cardA, CardId.OracleofZefra, CardId.DarkContractwiththGate) && Func.IsCode(cardB, CardId.OracleofZefra, CardId.DarkContractwiththGate)) return -1;
		return (-1);
	}

IL_007c:
	{
		// return 0;
		return 0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_3(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_3_m794D1A938AF6A352910328D91DBAC6DA37206A01 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// else if (func.CardsCheckAny(cards, card => { return card.Controller == 1 && (card.Location & CardLocation.Onfield) > 0; }) && min == 1 && max == 1)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Controller_m28007482B2684652C06802B480F9F598C231DAD0_inline(L_0, NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0016;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		int32_t L_3;
		L_3 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_2, NULL);
		return (bool)((((int32_t)((int32_t)((int32_t)L_3&((int32_t)12)))) > ((int32_t)0))? 1 : 0);
	}

IL_0016:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_9(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_9_mDEA7A6D06E9ED193AF337F590F72D497E6706EE9 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_ecard, const RuntimeMethod* method) 
{
	{
		// result = new List<ClientCard>(func.CardsCheckWhere(cards, ecard => { return ecard.Controller == 1; }));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_ecard;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Controller_m28007482B2684652C06802B480F9F598C231DAD0_inline(L_0, NULL);
		return (bool)((((int32_t)L_1) == ((int32_t)1))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_10(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_10_m62C1B674A05A1BDA30E0BAD50372F64469267820 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	{
		// return card.IsFaceup() && card.HasType(CardType.Tuner);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_0, NULL);
		if (!L_1)
		{
			goto IL_0014;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_card;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)4096), NULL);
		return L_3;
	}

IL_0014:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_11(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_11_m08BC5A8850C7C003BCC9626BF41F56C82825B3C3 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// && func.CardsCheckCount(Func.GetZoneCards(Bot, CardLocation.Onfield | CardLocation.Hand, true), card => { return Func.HasSetCode(card, 0xaf, 0xae) && card.Id != CardId.DDLamia; })
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)175));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)174));
		bool L_4;
		L_4 = Func_HasSetCode_m35DB2E2FE9D9FDB7B83287C22BCADF21AAF34191(L_0, L_3, NULL);
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = ___0_card;
		NullCheck(L_5);
		int32_t L_6;
		L_6 = ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline(L_5, NULL);
		return (bool)((((int32_t)((((int32_t)L_6) == ((int32_t)((int32_t)19580308)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_002f:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c::<OnSelectCard>b__144_12(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3COnSelectCardU3Eb__144_12_m5F5CD99DA74AA98C726651EE9843E69EF38129C1 (U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____DE5859B5A095EEC3948A5BD9656FF92406D576751581F174EBC6F38C517B1E28_293_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return Func.IsCode(card, CardId.LightoftheYangZing, CardId.PSY_FramegearGamma,
		// CardId.MechaPhantomBeastO_Lion, CardId.JetSynchron, CardId.Deskbot001, CardId.DDLamia);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)6);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____DE5859B5A095EEC3948A5BD9656FF92406D576751581F174EBC6F38C517B1E28_293_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		bool L_4;
		L_4 = Func_IsCode_m75C7719184012087DD18F11E77E20D5EF8AC25A5(L_0, L_2, NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass77_0__ctor_m9A9A9190264599A22F563481B3DDCC96F84BD5CB (U3CU3Ec__DisplayClass77_0_tE895338B8B0F926B323A6BF3F2F9A7EF5573FF3E* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZefraExecutor/<>c__DisplayClass77_0::<IsCanSynchroSummon>b__0(WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass77_0_U3CIsCanSynchroSummonU3Eb__0_mA5C4A954AD703991FB80E345883014591320B492 (U3CU3Ec__DisplayClass77_0_tE895338B8B0F926B323A6BF3F2F9A7EF5573FF3E* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_1_m9D9AA859E7842E7C099EB279A2799B3EB03A756C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_2_mDF19FC72939BFC468F6E328844F567C4744D31B7_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* G_B3_0 = NULL;
	RuntimeObject* G_B3_1 = NULL;
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* G_B3_2 = NULL;
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* G_B2_0 = NULL;
	RuntimeObject* G_B2_1 = NULL;
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* G_B2_2 = NULL;
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* G_B8_0 = NULL;
	RuntimeObject* G_B8_1 = NULL;
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* G_B8_2 = NULL;
	Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* G_B7_0 = NULL;
	RuntimeObject* G_B7_1 = NULL;
	Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* G_B7_2 = NULL;
	{
		// return (card.Level + level == 8
		// && func.CardsCheckAny(Bot.ExtraDeck, synchro_card => { return Func.IsCode(synchro_card, CardId.BorreloadSavageDragon, CardId.PSY_FramelordOmega); }))
		// || (card.Level + level == 7 && SecretoftheYangZingCheck(card) && func.CardsCheckAny(Bot.ExtraDeck, synchro_card => { return Func.IsCode(synchro_card, CardId.Odd_EyesMeteorburstDragon, CardId.F_A_DawnDragster); }))
		// || (card.Level + level == 5 && Bot.HasInExtra(CardId.Denglong_FirstoftheYangZing))
		// || (card.Level + level == 4 && Bot.HasInExtra(CardId.HeraldoftheArcLight));
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___0_card;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_0, NULL);
		int32_t L_2 = __this->___level_0;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_add(L_1, L_2))) == ((uint32_t)8))))
		{
			goto IL_0059;
		}
	}
	{
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_3 = __this->___U3CU3E4__this_1;
		NullCheck(L_3);
		Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* L_4 = L_3->___func_52;
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_5 = __this->___U3CU3E4__this_1;
		NullCheck(L_5);
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(L_5, NULL);
		NullCheck(L_6);
		RuntimeObject* L_7;
		L_7 = ClientField_get_ExtraDeck_mAE2668EAF5688876EA70C0DD5CD1D9A8088AE11A_inline(L_6, NULL);
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_8 = ((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_1_5;
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_9 = L_8;
		G_B2_0 = L_9;
		G_B2_1 = L_7;
		G_B2_2 = L_4;
		if (L_9)
		{
			G_B3_0 = L_9;
			G_B3_1 = L_7;
			G_B3_2 = L_4;
			goto IL_004a;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* L_10 = ((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_11 = (Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE*)il2cpp_codegen_object_new(Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE_il2cpp_TypeInfo_var);
		NullCheck(L_11);
		Delegate__ctor_mDECCAD9085944EEC3B1A0A16631E227F69B5181C(L_11, L_10, (intptr_t)((void*)U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_1_m9D9AA859E7842E7C099EB279A2799B3EB03A756C_RuntimeMethod_var), NULL);
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_12 = L_11;
		((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_1_5 = L_12;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_1_5), (void*)L_12);
		G_B3_0 = L_12;
		G_B3_1 = G_B2_1;
		G_B3_2 = G_B2_2;
	}

IL_004a:
	{
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_13;
		L_13 = Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_inline(Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_RuntimeMethod_var);
		NullCheck(G_B3_2);
		bool L_14;
		L_14 = Func_CardsCheckAny_m9CBC3B4C36EA81D18B6FFE5B3D6045255524E7F2(G_B3_2, G_B3_1, G_B3_0, L_13, NULL);
		if (L_14)
		{
			goto IL_010c;
		}
	}

IL_0059:
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_15 = ___0_card;
		NullCheck(L_15);
		int32_t L_16;
		L_16 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_15, NULL);
		int32_t L_17 = __this->___level_0;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_add(L_16, L_17))) == ((uint32_t)7))))
		{
			goto IL_00bd;
		}
	}
	{
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_18 = __this->___U3CU3E4__this_1;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_19 = ___0_card;
		NullCheck(L_18);
		bool L_20;
		L_20 = ZefraExecutor_SecretoftheYangZingCheck_mDF7F5B591520752B1F0404018817C510D667B04B(L_18, L_19, NULL);
		if (!L_20)
		{
			goto IL_00bd;
		}
	}
	{
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_21 = __this->___U3CU3E4__this_1;
		NullCheck(L_21);
		Func_t030ACC3ACFDBDED3F0DFBF2A32B3B043CBFD458F* L_22 = L_21->___func_52;
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_23 = __this->___U3CU3E4__this_1;
		NullCheck(L_23);
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_24;
		L_24 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(L_23, NULL);
		NullCheck(L_24);
		RuntimeObject* L_25;
		L_25 = ClientField_get_ExtraDeck_mAE2668EAF5688876EA70C0DD5CD1D9A8088AE11A_inline(L_24, NULL);
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_26 = ((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_2_6;
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_27 = L_26;
		G_B7_0 = L_27;
		G_B7_1 = L_25;
		G_B7_2 = L_22;
		if (L_27)
		{
			G_B8_0 = L_27;
			G_B8_1 = L_25;
			G_B8_2 = L_22;
			goto IL_00b1;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var);
		U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87* L_28 = ((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_29 = (Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE*)il2cpp_codegen_object_new(Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE_il2cpp_TypeInfo_var);
		NullCheck(L_29);
		Delegate__ctor_mDECCAD9085944EEC3B1A0A16631E227F69B5181C(L_29, L_28, (intptr_t)((void*)U3CU3Ec_U3CIsCanSynchroSummonU3Eb__77_2_mDF19FC72939BFC468F6E328844F567C4744D31B7_RuntimeMethod_var), NULL);
		Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* L_30 = L_29;
		((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_2_6 = L_30;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tBFF7F858F833EE204C8A3D954DB59655EA1E0B87_il2cpp_TypeInfo_var))->___U3CU3E9__77_2_6), (void*)L_30);
		G_B8_0 = L_30;
		G_B8_1 = G_B7_1;
		G_B8_2 = G_B7_2;
	}

IL_00b1:
	{
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_31;
		L_31 = Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_inline(Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_RuntimeMethod_var);
		NullCheck(G_B8_2);
		bool L_32;
		L_32 = Func_CardsCheckAny_m9CBC3B4C36EA81D18B6FFE5B3D6045255524E7F2(G_B8_2, G_B8_1, G_B8_0, L_31, NULL);
		if (L_32)
		{
			goto IL_010c;
		}
	}

IL_00bd:
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_33 = ___0_card;
		NullCheck(L_33);
		int32_t L_34;
		L_34 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_33, NULL);
		int32_t L_35 = __this->___level_0;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_add(L_34, L_35))) == ((uint32_t)5))))
		{
			goto IL_00e4;
		}
	}
	{
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_36 = __this->___U3CU3E4__this_1;
		NullCheck(L_36);
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_37;
		L_37 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(L_36, NULL);
		NullCheck(L_37);
		bool L_38;
		L_38 = ClientField_HasInExtra_m2BE03EF434011D09DF5EFE93509309010B5C4E10(L_37, ((int32_t)65536818), NULL);
		if (L_38)
		{
			goto IL_010c;
		}
	}

IL_00e4:
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_39 = ___0_card;
		NullCheck(L_39);
		int32_t L_40;
		L_40 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_39, NULL);
		int32_t L_41 = __this->___level_0;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_add(L_40, L_41))) == ((uint32_t)4))))
		{
			goto IL_010a;
		}
	}
	{
		ZefraExecutor_tC1C34586F16864E8E0977DA43553ACF858EACB48* L_42 = __this->___U3CU3E4__this_1;
		NullCheck(L_42);
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_43;
		L_43 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(L_42, NULL);
		NullCheck(L_43);
		bool L_44;
		L_44 = ClientField_HasInExtra_m2BE03EF434011D09DF5EFE93509309010B5C4E10(L_43, ((int32_t)79606837), NULL);
		return L_44;
	}

IL_010a:
	{
		return (bool)0;
	}

IL_010c:
	{
		return (bool)1;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZexalWeaponsExecutor::.ctor(WindBot.Game.GameAI,WindBot.Game.Duel)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ZexalWeaponsExecutor__ctor_mC13E0B7CD66A941CE7E25E77B1E544ABAF5DBEC4 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* ___0_ai, Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___1_duel, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultBreakthroughSkill_m09BB7FC45F746E9DDDBD3B241A510540A98C7B7B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultDarkHole_mB9930C5974260886FF733F8C03649F5463745299_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultHonestEffect_m9DAA75B44D48D55E94C10E94D21FBC8FD308ED20_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultMysticalSpaceTyphoon_mA2B4FCE8324CD396BA235FD5DC3333CA92C3DF97_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultNumberS39UtopiaTheLightningEffect_mCE1E815E90A7A6465C667AEA3CC49D863DE3D80D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultRaigeki_mC2CB36381BD51664EAA5460889ACA0C87F8E7B39_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultSolemnStrike_m00FC454C344F9E5BE6E56427AD6C0FC18D6531D9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultSolemnWarning_mA3F68F34432CCA786CA975746DB944073FC80E9C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultSpellSet_mFA02D4DE014BC67FA51265209892217571E194FC_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_GoblindberghEffect_m9ED19382B54E4C7D282E40AEF4F80FDD85DED5C8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_GoblindberghFirst_m8372ECC4F98346513FEB08E4BF1C6231D6F7F04A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_InstantFusion_mEDE9589E1BB7FE9DC6B37E1A2047C3CF3FC3B2A0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_KagetokageEffect_mA8E9E94B0B519E16D20E34F30371A0F59A615153_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_MonsterRepos_m63077AD390EC67DF9BC08EEDCD29C2AFA2910F5D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_Number39Utopia_mE132513090DE325CBDD4FEE725E0552873F35A03_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_Number61Volcasaurus_mCC4DD0DADA3EEADF91DDA02206F4C2788BBE79BC_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_ReinforcementOfTheArmy_m1E095C372509A4D8124D81908DEA172F2F213ADF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_SolarWindJammer_m2342B5EFE3BB8554E7D8C15B48389370B8C711BA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_SummonerMonkEffect_mC0B24686D98130FD7EC3D139A8390E6EFC8AE524_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_XyzChangeTactics_m763EA06DB8884BC07AD75CFD65610CA6597A5510_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_ZwLionArms_mD1CDB1ADCC0ACB04278F406CF8330EC6D1D4136D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// : base(ai, duel)
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0 = ___0_ai;
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_1 = ___1_duel;
		DefaultExecutor__ctor_mFB03F8D4D7C092E703EC737C97F2368B233B8F8A(__this, L_0, L_1, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.MysticalSpaceTyphoon, DefaultMysticalSpaceTyphoon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_2 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_2);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_2, __this, (intptr_t)((void*)DefaultExecutor_DefaultMysticalSpaceTyphoon_mA2B4FCE8324CD396BA235FD5DC3333CA92C3DF97_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)5318639), L_2, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.DarkHole, DefaultDarkHole);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_3 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_3);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_3, __this, (intptr_t)((void*)DefaultExecutor_DefaultDarkHole_mB9930C5974260886FF733F8C03649F5463745299_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)53129443), L_3, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Raigeki, DefaultRaigeki);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_4 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_4);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_4, __this, (intptr_t)((void*)DefaultExecutor_DefaultRaigeki_mC2CB36381BD51664EAA5460889ACA0C87F8E7B39_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)12580477), L_4, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ReinforcementOfTheArmy, ReinforcementOfTheArmy);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_5 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_5);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_5, __this, (intptr_t)((void*)ZexalWeaponsExecutor_ReinforcementOfTheArmy_m1E095C372509A4D8124D81908DEA172F2F213ADF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)32807846), L_5, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.XyzChangeTactics, XyzChangeTactics);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_6 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_6);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_6, __this, (intptr_t)((void*)ZexalWeaponsExecutor_XyzChangeTactics_m763EA06DB8884BC07AD75CFD65610CA6597A5510_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)11705261), L_6, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Number39Utopia);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)84013237), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.NumberS39UtopiaOne);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)86532744), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.NumberS39UtopiatheLightning);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)56832966), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Number61Volcasaurus, Number61Volcasaurus);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_7 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_7);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_7, __this, (intptr_t)((void*)ZexalWeaponsExecutor_Number61Volcasaurus_mCC4DD0DADA3EEADF91DDA02206F4C2788BBE79BC_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)29669359), L_7, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.ZwLionArms);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)60992364), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.AdreusKeeperOfArmageddon);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)94119480), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Number39Utopia, Number39Utopia);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_8 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_8);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_8, __this, (intptr_t)((void*)ZexalWeaponsExecutor_Number39Utopia_mE132513090DE325CBDD4FEE725E0552873F35A03_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)84013237), L_8, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.NumberS39UtopiaOne);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)86532744), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.NumberS39UtopiatheLightning, DefaultNumberS39UtopiaTheLightningEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_9 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_9);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_9, __this, (intptr_t)((void*)DefaultExecutor_DefaultNumberS39UtopiaTheLightningEffect_mCE1E815E90A7A6465C667AEA3CC49D863DE3D80D_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)56832966), L_9, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZwLionArms, ZwLionArms);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_10 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_10);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_10, __this, (intptr_t)((void*)ZexalWeaponsExecutor_ZwLionArms_mD1CDB1ADCC0ACB04278F406CF8330EC6D1D4136D_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)60992364), L_10, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.AdreusKeeperOfArmageddon);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)94119480), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Number61Volcasaurus);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)29669359), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZwTornadoBringer, ZwWeapon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_11 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_11);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_11, __this, (intptr_t)((void*)ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)81471108), L_11, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZwLightningBlade, ZwWeapon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_12 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_12);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_12, __this, (intptr_t)((void*)ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)45082499), L_12, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZwAsuraStrike, ZwWeapon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_13 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_13);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_13, __this, (intptr_t)((void*)ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)40941889), L_13, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.PhotonTrasher);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)65367484), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.CyberDragon);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)70095155), NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.SolarWindJammer, SolarWindJammer);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_14 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_14);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_14, __this, (intptr_t)((void*)ZexalWeaponsExecutor_SolarWindJammer_m2342B5EFE3BB8554E7D8C15B48389370B8C711BA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)33911264), L_14, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.InstantFusion, InstantFusion);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_15 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_15);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_15, __this, (intptr_t)((void*)ZexalWeaponsExecutor_InstantFusion_mEDE9589E1BB7FE9DC6B37E1A2047C3CF3FC3B2A0_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)1845204), L_15, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Goblindbergh, GoblindberghFirst);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_16 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_16);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_16, __this, (intptr_t)((void*)ZexalWeaponsExecutor_GoblindberghFirst_m8372ECC4F98346513FEB08E4BF1C6231D6F7F04A_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 0, ((int32_t)25259669), L_16, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.TinGoldfish, GoblindberghFirst);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_17 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_17);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_17, __this, (intptr_t)((void*)ZexalWeaponsExecutor_GoblindberghFirst_m8372ECC4F98346513FEB08E4BF1C6231D6F7F04A_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 0, ((int32_t)18063928), L_17, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.StarDrawing);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)24610207), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.SacredCrane);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)30914564), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.HeroicChallengerExtraSword);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)34143852), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Goblindbergh);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)25259669), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.TinGoldfish);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)18063928), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.SummonerMonk);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)423585), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Honest);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)37742478), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Goblindbergh, GoblindberghEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_18 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_18);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_18, __this, (intptr_t)((void*)ZexalWeaponsExecutor_GoblindberghEffect_m9ED19382B54E4C7D282E40AEF4F80FDD85DED5C8_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)25259669), L_18, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.TinGoldfish, GoblindberghEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_19 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_19);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_19, __this, (intptr_t)((void*)ZexalWeaponsExecutor_GoblindberghEffect_m9ED19382B54E4C7D282E40AEF4F80FDD85DED5C8_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)18063928), L_19, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Kagetokage, KagetokageEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_20 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_20);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_20, __this, (intptr_t)((void*)ZexalWeaponsExecutor_KagetokageEffect_mA8E9E94B0B519E16D20E34F30371A0F59A615153_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)94656263), L_20, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.SummonerMonk, SummonerMonkEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_21 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_21);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_21, __this, (intptr_t)((void*)ZexalWeaponsExecutor_SummonerMonkEffect_mC0B24686D98130FD7EC3D139A8390E6EFC8AE524_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)423585), L_21, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Honest, DefaultHonestEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_22 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_22);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_22, __this, (intptr_t)((void*)DefaultExecutor_DefaultHonestEffect_m9DAA75B44D48D55E94C10E94D21FBC8FD308ED20_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)37742478), L_22, NULL);
		// AddExecutor(ExecutorType.Repos, MonsterRepos);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_23 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_23);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_23, __this, (intptr_t)((void*)ZexalWeaponsExecutor_MonsterRepos_m63077AD390EC67DF9BC08EEDCD29C2AFA2910F5D_RuntimeMethod_var), NULL);
		Executor_AddExecutor_m289CA7A0A4918976416B3B734B8F478CDDF515D0(__this, 2, L_23, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.GaiaDragonTheThunderCharger);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)91949988), NULL);
		// AddExecutor(ExecutorType.SpellSet, DefaultSpellSet);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_24 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_24);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_24, __this, (intptr_t)((void*)DefaultExecutor_DefaultSpellSet_mFA02D4DE014BC67FA51265209892217571E194FC_RuntimeMethod_var), NULL);
		Executor_AddExecutor_m289CA7A0A4918976416B3B734B8F478CDDF515D0(__this, 4, L_24, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.BreakthroughSkill, DefaultBreakthroughSkill);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_25 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_25);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_25, __this, (intptr_t)((void*)DefaultExecutor_DefaultBreakthroughSkill_m09BB7FC45F746E9DDDBD3B241A510540A98C7B7B_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)78474168), L_25, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.SolemnWarning, DefaultSolemnWarning);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_26 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_26);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_26, __this, (intptr_t)((void*)DefaultExecutor_DefaultSolemnWarning_mA3F68F34432CCA786CA975746DB944073FC80E9C_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)84749824), L_26, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.SolemnStrike, DefaultSolemnStrike);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_27 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_27);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_27, __this, (intptr_t)((void*)DefaultExecutor_DefaultSolemnStrike_m00FC454C344F9E5BE6E56427AD6C0FC18D6531D9_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)40605147), L_27, NULL);
		// }
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::OnSelectHand()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_OnSelectHand_mC3D9894A90BFD05B385B4F940DE4032DC3335798 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::OnPreBattleBetween(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_OnPreBattleBetween_m5DBF5B43586E77153E6AFBE10502DEFA3A0143E8 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_attacker, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_defender, const RuntimeMethod* method) 
{
	{
		// if (!defender.IsMonsterHasPreventActivationEffectInBattle())
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___1_defender;
		bool L_1;
		L_1 = CardExtension_IsMonsterHasPreventActivationEffectInBattle_m2C71A673BE49220D06A8C77080EEC4C39253B010(L_0, NULL);
		if (L_1)
		{
			goto IL_0037;
		}
	}
	{
		// if (attacker.Attribute == (int)CardAttribute.Light && Bot.HasInHand(CardId.Honest))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_attacker;
		NullCheck(L_2);
		int32_t L_3;
		L_3 = ClientCard_get_Attribute_m2BF15C90C7580C500E07A65959685C82A2FC65BB_inline(L_2, NULL);
		if ((!(((uint32_t)L_3) == ((uint32_t)((int32_t)16)))))
		{
			goto IL_0037;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_4, ((int32_t)37742478), NULL);
		if (!L_5)
		{
			goto IL_0037;
		}
	}
	{
		// attacker.RealPower = attacker.RealPower + defender.Attack;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___0_attacker;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_7 = ___0_attacker;
		NullCheck(L_7);
		int32_t L_8;
		L_8 = ClientCard_get_RealPower_m4832123BF47ECE4DE5ED8A240B6F0A6866B3B588_inline(L_7, NULL);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9 = ___1_defender;
		NullCheck(L_9);
		int32_t L_10;
		L_10 = ClientCard_get_Attack_m77751479CDA31D0D23600A59ADFADAA69F34364B_inline(L_9, NULL);
		NullCheck(L_6);
		ClientCard_set_RealPower_m089EFE795FE98EAD61FE447D5B9A3CD25C21FBA7_inline(L_6, ((int32_t)il2cpp_codegen_add(L_8, L_10)), NULL);
	}

IL_0037:
	{
		// return base.OnPreBattleBetween(attacker, defender);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_11 = ___0_attacker;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_12 = ___1_defender;
		bool L_13;
		L_13 = DefaultExecutor_OnPreBattleBetween_mA66327785BDDA23051E5C2CB5BDAFEC5087E964D(__this, L_11, L_12, NULL);
		return L_13;
	}
}
// System.Collections.Generic.IList`1<WindBot.Game.ClientCard> WindBot.Game.AI.Decks.ZexalWeaponsExecutor::OnSelectXyzMaterial(System.Collections.Generic.IList`1<WindBot.Game.ClientCard>,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* ZexalWeaponsExecutor_OnSelectXyzMaterial_mF5B3A02781FFA9273D5F4F5C088C15949F9F2034 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, RuntimeObject* ___0_cards, int32_t ___1_min, int32_t ___2_max, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4658A9F91C7899BAA1F32C6D7A573540CF1559A1AF3BD98BB87294BC7252A8F9_89_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	{
		// IList<ClientCard> result = Util.SelectPreferredCards(new[] {
		//     CardId.StarDrawing,
		//     CardId.SolarWindJammer,
		//     CardId.Goblindbergh
		// }, cards, min, max);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_0;
		L_0 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4658A9F91C7899BAA1F32C6D7A573540CF1559A1AF3BD98BB87294BC7252A8F9_89_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		RuntimeObject* L_4 = ___0_cards;
		int32_t L_5 = ___1_min;
		int32_t L_6 = ___2_max;
		NullCheck(L_0);
		RuntimeObject* L_7;
		L_7 = AIUtil_SelectPreferredCards_mF7650ACADAAE5251BAA51F59F435E933967C0D76(L_0, (RuntimeObject*)L_2, L_4, L_5, L_6, NULL);
		V_0 = L_7;
		// return Util.CheckSelectCount(result, cards, min, max);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_8;
		L_8 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		RuntimeObject* L_9 = V_0;
		RuntimeObject* L_10 = ___0_cards;
		int32_t L_11 = ___1_min;
		int32_t L_12 = ___2_max;
		NullCheck(L_8);
		RuntimeObject* L_13;
		L_13 = AIUtil_CheckSelectCount_mF0957A1BE342E93DD62F7AF39AA58B16124758AE(L_8, L_9, L_10, L_11, L_12, NULL);
		return L_13;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::Number39Utopia()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_Number39Utopia_mE132513090DE325CBDD4FEE725E0552873F35A03 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// if (!Util.HasChainedTrap(0) && Duel.Player == 1 && Duel.Phase == DuelPhase.BattleStart && Card.HasXyzMaterial(2))
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_0;
		L_0 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = AIUtil_HasChainedTrap_m90DDFF98E8ABEA22AAF607094C650FECD84A60A4(L_0, 0, NULL);
		if (L_1)
		{
			goto IL_003a;
		}
	}
	{
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_2;
		L_2 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_2);
		int32_t L_3;
		L_3 = Duel_get_Player_m9193784EAEA68B33A6DBD25C84746FF9B4F21B14_inline(L_2, NULL);
		if ((!(((uint32_t)L_3) == ((uint32_t)1))))
		{
			goto IL_003a;
		}
	}
	{
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_4;
		L_4 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_4);
		int32_t L_5;
		L_5 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_4, NULL);
		if ((!(((uint32_t)L_5) == ((uint32_t)8))))
		{
			goto IL_003a;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6;
		L_6 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientCard_HasXyzMaterial_m9C6FD0663219AEE4FAF385648DFB635BA715632E(L_6, 2, NULL);
		if (!L_7)
		{
			goto IL_003a;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_003a:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::Number61Volcasaurus()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_Number61Volcasaurus_mCC4DD0DADA3EEADF91DDA02206F4C2788BBE79BC (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// return Util.IsOneEnemyBetterThanValue(2000, false);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_0;
		L_0 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = AIUtil_IsOneEnemyBetterThanValue_mFE1B91B2577A3F5236B3D6925076D1D498BB4E4A(L_0, ((int32_t)2000), (bool)0, NULL);
		return L_1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::ZwLionArms()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_ZwLionArms_mD1CDB1ADCC0ACB04278F406CF8330EC6D1D4136D (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// if (ActivateDescription == Util.GetStringId(CardId.ZwLionArms, 0))
		int32_t L_0;
		L_0 = Executor_get_ActivateDescription_m2855E33CA44A88A7F15FFFA522E084F6E791604C_inline(__this, NULL);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_1;
		L_1 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_1);
		int32_t L_2;
		L_2 = AIUtil_GetStringId_mEA5B8E629F1A04FB9361B4AC4F6C736562A1A672(L_1, ((int32_t)60992364), 0, NULL);
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_001b;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_001b:
	{
		// if (ActivateDescription == Util.GetStringId(CardId.ZwLionArms, 1))
		int32_t L_3;
		L_3 = Executor_get_ActivateDescription_m2855E33CA44A88A7F15FFFA522E084F6E791604C_inline(__this, NULL);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_4;
		L_4 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_4);
		int32_t L_5;
		L_5 = AIUtil_GetStringId_mEA5B8E629F1A04FB9361B4AC4F6C736562A1A672(L_4, ((int32_t)60992364), 1, NULL);
		if ((!(((uint32_t)L_3) == ((uint32_t)L_5))))
		{
			goto IL_004a;
		}
	}
	{
		// return !Card.IsDisabled() && ZwWeapon();
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6;
		L_6 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientCard_IsDisabled_m3E43E775A01C714E36F1B03E7B4C8BF9F38BAE4E(L_6, NULL);
		if (L_7)
		{
			goto IL_0048;
		}
	}
	{
		bool L_8;
		L_8 = ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA(__this, NULL);
		return L_8;
	}

IL_0048:
	{
		return (bool)0;
	}

IL_004a:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::ZwWeapon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_ZwWeapon_m6527141459F876C63B9242D42DA13658B3634FFA (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::ReinforcementOfTheArmy()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_ReinforcementOfTheArmy_m1E095C372509A4D8124D81908DEA172F2F213ADF (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____FEA9F4CA8688E2AAC63B626BFBD34208AFCABFBD900A072570214FF1D5E94D9F_342_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.Goblindbergh,
		//     CardId.TinGoldfish,
		//     CardId.StarDrawing,
		//     CardId.Kagetokage,
		//     CardId.SacredCrane
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)5);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____FEA9F4CA8688E2AAC63B626BFBD34208AFCABFBD900A072570214FF1D5E94D9F_342_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::InstantFusion()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_InstantFusion_mEDE9589E1BB7FE9DC6B37E1A2047C3CF3FC3B2A0 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 V_2;
	memset((&V_2), 0, sizeof(V_2));
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* G_B6_0 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* G_B5_0 = NULL;
	{
		// if (Bot.LifePoints <= 1000)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1 = L_0->___LifePoints_7;
		if ((((int32_t)L_1) > ((int32_t)((int32_t)1000))))
		{
			goto IL_0014;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0014:
	{
		// int count4 = 0;
		V_0 = 0;
		// int count5 = 0;
		V_1 = 0;
		// foreach (ClientCard card in Bot.GetMonsters())
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_2;
		L_2 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_2);
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_3;
		L_3 = ClientField_GetMonsters_mD3C72712741F3DB1549B08EA2FBE37024F7BECC6(L_2, NULL);
		NullCheck(L_3);
		Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 L_4;
		L_4 = List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108(L_3, List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		V_2 = L_4;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0056:
			{// begin finally (depth: 1)
				Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0((&V_2), Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
				return;
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_004b_1;
			}

IL_002b_1:
			{
				// foreach (ClientCard card in Bot.GetMonsters())
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5;
				L_5 = Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_inline((&V_2), Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
				// if (card.Level == 5)
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = L_5;
				NullCheck(L_6);
				int32_t L_7;
				L_7 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_6, NULL);
				G_B5_0 = L_6;
				if ((!(((uint32_t)L_7) == ((uint32_t)5))))
				{
					G_B6_0 = L_6;
					goto IL_003f_1;
				}
			}
			{
				// ++count5;
				int32_t L_8 = V_1;
				V_1 = ((int32_t)il2cpp_codegen_add(L_8, 1));
				G_B6_0 = G_B5_0;
			}

IL_003f_1:
			{
				// if (card.Level == 4)
				NullCheck(G_B6_0);
				int32_t L_9;
				L_9 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(G_B6_0, NULL);
				if ((!(((uint32_t)L_9) == ((uint32_t)4))))
				{
					goto IL_004b_1;
				}
			}
			{
				// ++count4;
				int32_t L_10 = V_0;
				V_0 = ((int32_t)il2cpp_codegen_add(L_10, 1));
			}

IL_004b_1:
			{
				// foreach (ClientCard card in Bot.GetMonsters())
				bool L_11;
				L_11 = Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76((&V_2), Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
				if (L_11)
				{
					goto IL_002b_1;
				}
			}
			{
				goto IL_0064;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0064:
	{
		// if (count5 == 1)
		int32_t L_12 = V_1;
		if ((!(((uint32_t)L_12) == ((uint32_t)1))))
		{
			goto IL_007a;
		}
	}
	{
		// AI.SelectCard(CardId.FlameSwordsman);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_13;
		L_13 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_13);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_13, ((int32_t)45231177), NULL);
		// return true;
		return (bool)1;
	}

IL_007a:
	{
		// else if (count4 == 1)
		int32_t L_14 = V_0;
		if ((!(((uint32_t)L_14) == ((uint32_t)1))))
		{
			goto IL_0090;
		}
	}
	{
		// AI.SelectCard(CardId.DarkfireDragon);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_15;
		L_15 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_15);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_15, ((int32_t)17881964), NULL);
		// return true;
		return (bool)1;
	}

IL_0090:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::XyzChangeTactics()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_XyzChangeTactics_m763EA06DB8884BC07AD75CFD65610CA6597A5510 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// return Bot.LifePoints > 500;
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1 = L_0->___LifePoints_7;
		return (bool)((((int32_t)L_1) > ((int32_t)((int32_t)500)))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::GoblindberghFirst()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_GoblindberghFirst_m8372ECC4F98346513FEB08E4BF1C6231D6F7F04A (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 V_0;
	memset((&V_0), 0, sizeof(V_0));
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_1 = NULL;
	bool V_2 = false;
	{
		// foreach (ClientCard card in Bot.Hand.GetMonsters())
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		RuntimeObject* L_1;
		L_1 = ClientField_get_Hand_m0C0F60D3ABFE161B581F21915DD028C46F61488E_inline(L_0, NULL);
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_2;
		L_2 = CardContainer_GetMonsters_m4EF93269A1EE13EAB9A78B645A6106D23A361E08(L_1, NULL);
		NullCheck(L_2);
		Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 L_3;
		L_3 = List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108(L_2, List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		V_0 = L_3;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0046:
			{// begin finally (depth: 1)
				Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0((&V_0), Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
				return;
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_003b_1;
			}

IL_0018_1:
			{
				// foreach (ClientCard card in Bot.Hand.GetMonsters())
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4;
				L_4 = Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_inline((&V_0), Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
				V_1 = L_4;
				// if (!card.Equals(Card) && card.Level == 4)
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_5 = V_1;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6;
				L_6 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
				NullCheck(L_5);
				bool L_7;
				L_7 = ClientCard_Equals_mD0D1DB381E502773C60748D1533EEC75A30886C6(L_5, L_6, NULL);
				if (L_7)
				{
					goto IL_003b_1;
				}
			}
			{
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_8 = V_1;
				NullCheck(L_8);
				int32_t L_9;
				L_9 = ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline(L_8, NULL);
				if ((!(((uint32_t)L_9) == ((uint32_t)4))))
				{
					goto IL_003b_1;
				}
			}
			{
				// return true;
				V_2 = (bool)1;
				goto IL_0056;
			}

IL_003b_1:
			{
				// foreach (ClientCard card in Bot.Hand.GetMonsters())
				bool L_10;
				L_10 = Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76((&V_0), Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
				if (L_10)
				{
					goto IL_0018_1;
				}
			}
			{
				goto IL_0054;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0054:
	{
		// return false;
		return (bool)0;
	}

IL_0056:
	{
		// }
		bool L_11 = V_2;
		return L_11;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::GoblindberghEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_GoblindberghEffect_m9ED19382B54E4C7D282E40AEF4F80FDD85DED5C8 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____A907C56D065442866F76567FE30FA552330DC6BBA117DA02C49CBF28C0A5BA47_212_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.SacredCrane,
		//     CardId.HeroicChallengerExtraSword,
		//     CardId.StarDrawing,
		//     CardId.SummonerMonk
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)4);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____A907C56D065442866F76567FE30FA552330DC6BBA117DA02C49CBF28C0A5BA47_212_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::KagetokageEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_KagetokageEffect_mA8E9E94B0B519E16D20E34F30371A0F59A615153 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_0 = NULL;
	{
		// var lastChainCard = Util.GetLastChainCard();
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_0;
		L_0 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_0);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_1;
		L_1 = AIUtil_GetLastChainCard_m611B6F9EFFF776F4E0BC8C35BB4D35659B4036E5(L_0, NULL);
		V_0 = L_1;
		// if (lastChainCard == null) return true;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = V_0;
		if (L_2)
		{
			goto IL_0011;
		}
	}
	{
		// if (lastChainCard == null) return true;
		return (bool)1;
	}

IL_0011:
	{
		// return !lastChainCard.IsCode(CardId.Goblindbergh, CardId.TinGoldfish);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3 = V_0;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = L_4;
		NullCheck(L_5);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)25259669));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_6 = L_5;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)18063928));
		NullCheck(L_3);
		bool L_7;
		L_7 = ClientCard_IsCode_m63A6FFDC33AA76451064CDAF55B9B898036110EF(L_3, L_6, NULL);
		return (bool)((((int32_t)L_7) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::SummonerMonkEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_SummonerMonkEffect_mC0B24686D98130FD7EC3D139A8390E6EFC8AE524 (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____108710702D56B721FE6351364171D9FE220305A52FF09CA45DBB65E1CEB31854_23_FieldInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C8185DC090901A187F7582AE1A540C37D260DECB8A5B092C4D8A79B789289F57_258_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	{
		// IList<int> costs = new[]
		//     {
		//         CardId.XyzChangeTactics,
		//         CardId.DarkHole,
		//         CardId.MysticalSpaceTyphoon,
		//         CardId.InstantFusion
		//     };
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_0 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)4);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = L_0;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_2 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____108710702D56B721FE6351364171D9FE220305A52FF09CA45DBB65E1CEB31854_23_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_1, L_2, NULL);
		V_0 = (RuntimeObject*)L_1;
		// if (Bot.HasInHand(costs))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_3;
		L_3 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		RuntimeObject* L_4 = V_0;
		NullCheck(L_3);
		bool L_5;
		L_5 = ClientField_HasInHand_mCFAE19E46797EFE107A051446BA06C891518E10D(L_3, L_4, NULL);
		if (!L_5)
		{
			goto IL_0056;
		}
	}
	{
		// AI.SelectCard(costs);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_6;
		L_6 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		RuntimeObject* L_7 = V_0;
		NullCheck(L_6);
		GameAI_SelectCard_mCFAE7CEA0FF2D502C64C6FD7D54DB162AE3AE649(L_6, L_7, NULL);
		// AI.SelectNextCard(
		//     CardId.SacredCrane,
		//     CardId.StarDrawing,
		//     CardId.Goblindbergh,
		//     CardId.TinGoldfish
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_8;
		L_8 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_9 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)4);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_10 = L_9;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_11 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C8185DC090901A187F7582AE1A540C37D260DECB8A5B092C4D8A79B789289F57_258_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_10, L_11, NULL);
		NullCheck(L_8);
		GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502(L_8, L_10, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_12;
		L_12 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_12);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_12, 4, NULL);
		// return true;
		return (bool)1;
	}

IL_0056:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::SolarWindJammer()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_SolarWindJammer_m2342B5EFE3BB8554E7D8C15B48389370B8C711BA (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (!Bot.HasInHand(new[] {
		//         CardId.StarDrawing,
		//         CardId.InstantFusion
		//     }))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)24610207));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)1845204));
		NullCheck(L_0);
		bool L_4;
		L_4 = ClientField_HasInHand_mCFAE19E46797EFE107A051446BA06C891518E10D(L_0, (RuntimeObject*)L_3, NULL);
		if (L_4)
		{
			goto IL_0025;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0025:
	{
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_5);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_5, 4, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZexalWeaponsExecutor::MonsterRepos()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZexalWeaponsExecutor_MonsterRepos_m63077AD390EC67DF9BC08EEDCD29C2AFA2910F5D (ZexalWeaponsExecutor_tC0084B39CF889CF2F042691B98E34338E8654B6E* __this, const RuntimeMethod* method) 
{
	{
		// if (Card.IsCode(CardId.NumberS39UtopiatheLightning) && Card.IsAttack())
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0;
		L_0 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)56832966), NULL);
		if (!L_1)
		{
			goto IL_0021;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2;
		L_2 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsAttack_m222452F0B994CD6410FFBB8643972BBC203E3913(L_2, NULL);
		if (!L_3)
		{
			goto IL_0021;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0021:
	{
		// return base.DefaultMonsterRepos();
		bool L_4;
		L_4 = DefaultExecutor_DefaultMonsterRepos_m99787A561C4CACBFD4D88353CA843B7598674C85(__this, NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZexalWeaponsExecutor/CardId::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CardId__ctor_mE4D05DF289C4245B578F2E139DBC26E31E96A429 (CardId_tDC859E1E9CD22AAF608046410ACC38ABA2A950DA* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZoodiacExecutor::.ctor(WindBot.Game.GameAI,WindBot.Game.Duel)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ZoodiacExecutor__ctor_mDD6E488C93FAE7B484E5BE39F7515DF5DAFF50FB (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* ___0_ai, Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* ___1_duel, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultDarkHole_mB9930C5974260886FF733F8C03649F5463745299_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultInterruptedKaijuSlumber_mD6A134DB30D2D34F4E1F54B6489114C11D0D4191_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultNumberS39UtopiaTheLightningEffect_mCE1E815E90A7A6465C667AEA3CC49D863DE3D80D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultNumberS39UtopiaTheLightningSummon_m9E867AFB489F0DF1BA5CED4D37B7800694F78E33_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&DefaultExecutor_DefaultTrap_mF6AF4A6CC17A4E3FC40BEB6BB0CC3F00645C3998_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_AleisterTheInvokerEffect_mF7CC8E892AEC5AA225341B545945D076944B7E33_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_BroadbullEffect_m58423C9AEF280904C98C1F98A59309DDC0167853_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_BroadbullSummon_m2B7299A2A14FF5F212DAC18B9785D3E075307DA6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_BroadbullXYZSummon_mE970E9CC798A0C5CFF07BDC5A683268BB27BE8CA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_ChakanineEffect_mBF76840856B026046F1C53523EB6744ADE29A124_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_ChakanineSummon_m99FA65841520A8057D3F5A0843A668F1C95365DB_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_DaigustoEmeralEffect_m35420E1998490817CF77BB6F5FEE2EC0D9A5CAF3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_DaigustoEmeralSummon_m0E1AB7FB015BD4534E63E320D2021DDEE2D12677_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_DridentEffect_m49B4EDBE2FC4DBBB43031BCD06F764FF124D0141_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_DridentSummon_mE76044F95CF9E22E2F692FC8142A35189AAAA7A6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_FireFormationTenkiEffect_mAA0B505305FDC869DB24CA34A240BF16828AF05C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_InvocationEffect_mC0FF065213093F9AF9858B7032B83EA62C508553_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_MonsterRebornEffect_m2CAF7F71963167C4947B2776333EAB377CC68EEA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_MonsterRepos_mB1E09B2A017BB01CA5C26FFB68B957BB2627B2B4_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_PhotonThrasherSummon_m45C0C8DBBCC1A48A118DB318A06B40F2DA3BC6D8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_RatpierEffect_m4A512209CB118E70E4784E51DFDA1C714235B827_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_RatpierMaterialEffect_mA083061D495C295650BF2551FA4B2DD67F6F0335_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_TigermortarEffect_m89C12A32939C22435DC8B937DFB47BBB1E0C7985_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_TigermortarSummon_m265F2BEEFDD7D5C119BF7B516BDE5662400A6BF9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_WhiptailEffect_mB911200A480506535F01029F54B88D405ED49CB6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_ZoodiacBarrageEffect_mE7FC8E95902A2F19ECE91861D5970CE112731FDB_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ZoodiacExecutor_ZoodiacComboEffect_mF31C9066BB24F5001AD5A6205826AC35B8B56A96_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// : base(ai, duel)
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0 = ___0_ai;
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_1 = ___1_duel;
		DefaultExecutor__ctor_mFB03F8D4D7C092E703EC737C97F2368B233B8F8A(__this, L_0, L_1, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.HarpiesFeatherDuster);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)18144506), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.InterruptedKaijuSlumber, DefaultInterruptedKaijuSlumber);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_2 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_2);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_2, __this, (intptr_t)((void*)DefaultExecutor_DefaultInterruptedKaijuSlumber_mD6A134DB30D2D34F4E1F54B6489114C11D0D4191_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)99330325), L_2, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.DarkHole, DefaultDarkHole);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_3 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_3);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_3, __this, (intptr_t)((void*)DefaultExecutor_DefaultDarkHole_mB9930C5974260886FF733F8C03649F5463745299_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)53129443), L_3, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.GamecieltheSeaTurtleKaiju, DefaultKaijuSpsummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_4 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_4);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_4, __this, (intptr_t)((void*)DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)55063751), L_4, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.KumongoustheStickyStringKaiju, DefaultKaijuSpsummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_5 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_5);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_5, __this, (intptr_t)((void*)DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)29726552), L_5, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.GadarlatheMysteryDustKaiju, DefaultKaijuSpsummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_6 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_6);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_6, __this, (intptr_t)((void*)DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)36956512), L_6, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.RadiantheMultidimensionalKaiju, DefaultKaijuSpsummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_7 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_7);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_7, __this, (intptr_t)((void*)DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)28674152), L_7, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.JizukirutheStarDestroyingKaiju, DefaultKaijuSpsummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_8 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_8);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_8, __this, (intptr_t)((void*)DefaultExecutor_DefaultKaijuSpsummon_mE2762BEDB22226D1D5926B256B891C8FF3CF74FF_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)63941210), L_8, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Terraforming);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)73628505), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.MagicalMeltdown);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 5, ((int32_t)47679935), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.FireFormationTenki, FireFormationTenkiEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_9 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_9);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_9, __this, (intptr_t)((void*)ZoodiacExecutor_FireFormationTenkiEffect_mAA0B505305FDC869DB24CA34A240BF16828AF05C_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)57103969), L_9, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZoodiacBarrage, ZoodiacBarrageEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_10 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_10);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_10, __this, (intptr_t)((void*)ZoodiacExecutor_ZoodiacBarrageEffect_mE7FC8E95902A2F19ECE91861D5970CE112731FDB_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)46060017), L_10, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.DaigustoEmeral, DaigustoEmeralEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_11 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_11);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_11, __this, (intptr_t)((void*)ZoodiacExecutor_DaigustoEmeralEffect_m35420E1998490817CF77BB6F5FEE2EC0D9A5CAF3_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)581014), L_11, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.PhotonThrasher, PhotonThrasherSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_12 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_12);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_12, __this, (intptr_t)((void*)ZoodiacExecutor_PhotonThrasherSummon_m45C0C8DBBCC1A48A118DB318A06B40F2DA3BC6D8_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)65367484), L_12, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Number39Utopia, DefaultNumberS39UtopiaTheLightningSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_13 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_13);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_13, __this, (intptr_t)((void*)DefaultExecutor_DefaultNumberS39UtopiaTheLightningSummon_m9E867AFB489F0DF1BA5CED4D37B7800694F78E33_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)84013237), L_13, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.NumberS39UtopiatheLightning);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)56832966), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.NumberS39UtopiatheLightning, DefaultNumberS39UtopiaTheLightningEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_14 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_14);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_14, __this, (intptr_t)((void*)DefaultExecutor_DefaultNumberS39UtopiaTheLightningEffect_mCE1E815E90A7A6465C667AEA3CC49D863DE3D80D_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)56832966), L_14, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.InvokedMechaba, DefaultTrap);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_15 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_15);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_15, __this, (intptr_t)((void*)DefaultExecutor_DefaultTrap_mF6AF4A6CC17A4E3FC40BEB6BB0CC3F00645C3998_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)75286621), L_15, NULL);
		// AddExecutor(ExecutorType.Activate, RatpierMaterialEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_16 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_16);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_16, __this, (intptr_t)((void*)ZoodiacExecutor_RatpierMaterialEffect_mA083061D495C295650BF2551FA4B2DD67F6F0335_RuntimeMethod_var), NULL);
		Executor_AddExecutor_m289CA7A0A4918976416B3B734B8F478CDDF515D0(__this, 5, L_16, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Drident, DridentEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_17 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_17);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_17, __this, (intptr_t)((void*)ZoodiacExecutor_DridentEffect_m49B4EDBE2FC4DBBB43031BCD06F764FF124D0141_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)48905153), L_17, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Broadbull, BroadbullEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_18 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_18);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_18, __this, (intptr_t)((void*)ZoodiacExecutor_BroadbullEffect_m58423C9AEF280904C98C1F98A59309DDC0167853_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)85115440), L_18, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Tigermortar, TigermortarEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_19 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_19);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_19, __this, (intptr_t)((void*)ZoodiacExecutor_TigermortarEffect_m89C12A32939C22435DC8B937DFB47BBB1E0C7985_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)11510448), L_19, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Chakanine, ChakanineEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_20 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_20);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_20, __this, (intptr_t)((void*)ZoodiacExecutor_ChakanineEffect_mBF76840856B026046F1C53523EB6744ADE29A124_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)41375811), L_20, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Chakanine, ChakanineSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_21 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_21);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_21, __this, (intptr_t)((void*)ZoodiacExecutor_ChakanineSummon_m99FA65841520A8057D3F5A0843A668F1C95365DB_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)41375811), L_21, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Tigermortar, TigermortarSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_22 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_22);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_22, __this, (intptr_t)((void*)ZoodiacExecutor_TigermortarSummon_m265F2BEEFDD7D5C119BF7B516BDE5662400A6BF9_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)11510448), L_22, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Broadbull, BroadbullSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_23 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_23);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_23, __this, (intptr_t)((void*)ZoodiacExecutor_BroadbullSummon_m2B7299A2A14FF5F212DAC18B9785D3E075307DA6_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)85115440), L_23, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Drident, DridentSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_24 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_24);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_24, __this, (intptr_t)((void*)ZoodiacExecutor_DridentSummon_mE76044F95CF9E22E2F692FC8142A35189AAAA7A6_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)48905153), L_24, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Ratpier);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)78872731), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Ratpier, RatpierEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_25 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_25);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_25, __this, (intptr_t)((void*)ZoodiacExecutor_RatpierEffect_m4A512209CB118E70E4784E51DFDA1C714235B827_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)78872731), L_25, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Thoroughblade);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)77150143), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Thoroughblade, RatpierEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_26 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_26);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_26, __this, (intptr_t)((void*)ZoodiacExecutor_RatpierEffect_m4A512209CB118E70E4784E51DFDA1C714235B827_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)77150143), L_26, NULL);
		// AddExecutor(ExecutorType.Summon, CardId.AleisterTheInvoker);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)86120751), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.AleisterTheInvoker, AleisterTheInvokerEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_27 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_27);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_27, __this, (intptr_t)((void*)ZoodiacExecutor_AleisterTheInvokerEffect_mF7CC8E892AEC5AA225341B545945D076944B7E33_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)86120751), L_27, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.DaigustoEmeral, DaigustoEmeralSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_28 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_28);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_28, __this, (intptr_t)((void*)ZoodiacExecutor_DaigustoEmeralSummon_m0E1AB7FB015BD4534E63E320D2021DDEE2D12677_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)581014), L_28, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.Broadbull, BroadbullXYZSummon);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_29 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_29);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_29, __this, (intptr_t)((void*)ZoodiacExecutor_BroadbullXYZSummon_mE970E9CC798A0C5CFF07BDC5A683268BB27BE8CA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 1, ((int32_t)85115440), L_29, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.MonsterReborn, MonsterRebornEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_30 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_30);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_30, __this, (intptr_t)((void*)ZoodiacExecutor_MonsterRebornEffect_m2CAF7F71963167C4947B2776333EAB377CC68EEA_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)83764718), L_30, NULL);
		// AddExecutor(ExecutorType.SpSummon, CardId.PhotonThrasher);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 1, ((int32_t)65367484), NULL);
		// AddExecutor(ExecutorType.Summon, CardId.Whiptail);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 0, ((int32_t)31755044), NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Invocation, InvocationEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_31 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_31);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_31, __this, (intptr_t)((void*)ZoodiacExecutor_InvocationEffect_mC0FF065213093F9AF9858B7032B83EA62C508553_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)74063034), L_31, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.Whiptail, WhiptailEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_32 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_32);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_32, __this, (intptr_t)((void*)ZoodiacExecutor_WhiptailEffect_mB911200A480506535F01029F54B88D405ED49CB6_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)31755044), L_32, NULL);
		// AddExecutor(ExecutorType.Activate, CardId.ZoodiacCombo, ZoodiacComboEffect);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_33 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_33);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_33, __this, (intptr_t)((void*)ZoodiacExecutor_ZoodiacComboEffect_mF31C9066BB24F5001AD5A6205826AC35B8B56A96_RuntimeMethod_var), NULL);
		Executor_AddExecutor_mB79DBCCB83030E41F8DA2982ABB2BDCB9D9A9CD5(__this, 5, ((int32_t)73881652), L_33, NULL);
		// AddExecutor(ExecutorType.SpellSet, CardId.ZoodiacCombo);
		Executor_AddExecutor_m0E6F09AD8991ACCA117E8B127E1682D395D57B30(__this, 4, ((int32_t)73881652), NULL);
		// AddExecutor(ExecutorType.Repos, MonsterRepos);
		Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457* L_34 = (Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457*)il2cpp_codegen_object_new(Func_1_t2BE7F58348C9CC544A8973B3A9E55541DE43C457_il2cpp_TypeInfo_var);
		NullCheck(L_34);
		Func_1__ctor_mDFFAE9C73346372438B5B04C4558AC42F1A3DA22(L_34, __this, (intptr_t)((void*)ZoodiacExecutor_MonsterRepos_mB1E09B2A017BB01CA5C26FFB68B957BB2627B2B4_RuntimeMethod_var), NULL);
		Executor_AddExecutor_m289CA7A0A4918976416B3B734B8F478CDDF515D0(__this, 2, L_34, NULL);
		// }
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::OnSelectHand()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_OnSelectHand_m327DFAC45C847E4EE8D976D2E027DC6B83A2DEF5 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// return true;
		return (bool)1;
	}
}
// System.Void WindBot.Game.AI.Decks.ZoodiacExecutor::OnNewTurn()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ZoodiacExecutor_OnNewTurn_m5662F086AAA4D55B9EF2B2A23A56BEFD30B0DE0B (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// TigermortarSpsummoned = false;
		__this->___TigermortarSpsummoned_18 = (bool)0;
		// ChakanineSpsummoned = false;
		__this->___ChakanineSpsummoned_19 = (bool)0;
		// BroadbullSpsummoned = false;
		__this->___BroadbullSpsummoned_20 = (bool)0;
		// base.OnNewTurn();
		DefaultExecutor_OnNewTurn_m3F03209FE11717A2E15EC706B4C91304A1BB50DB(__this, NULL);
		// }
		return;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::OnPreBattleBetween(WindBot.Game.ClientCard,WindBot.Game.ClientCard)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_OnPreBattleBetween_m841184BE81A9B9A3613B3C873E4D74CDC5E0020F (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_attacker, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___1_defender, const RuntimeMethod* method) 
{
	{
		// if (!defender.IsMonsterHasPreventActivationEffectInBattle())
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = ___1_defender;
		bool L_1;
		L_1 = CardExtension_IsMonsterHasPreventActivationEffectInBattle_m2C71A673BE49220D06A8C77080EEC4C39253B010(L_0, NULL);
		if (L_1)
		{
			goto IL_0036;
		}
	}
	{
		// if (attacker.HasType(CardType.Fusion) && Bot.HasInHand(CardId.AleisterTheInvoker))
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2 = ___0_attacker;
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_HasType_m18C71ABB8DB920C6D3BEE05FBA9FA8AF86391960(L_2, ((int32_t)64), NULL);
		if (!L_3)
		{
			goto IL_0036;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_4, ((int32_t)86120751), NULL);
		if (!L_5)
		{
			goto IL_0036;
		}
	}
	{
		// attacker.RealPower = attacker.RealPower + 1000;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6 = ___0_attacker;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_7 = ___0_attacker;
		NullCheck(L_7);
		int32_t L_8;
		L_8 = ClientCard_get_RealPower_m4832123BF47ECE4DE5ED8A240B6F0A6866B3B588_inline(L_7, NULL);
		NullCheck(L_6);
		ClientCard_set_RealPower_m089EFE795FE98EAD61FE447D5B9A3CD25C21FBA7_inline(L_6, ((int32_t)il2cpp_codegen_add(L_8, ((int32_t)1000))), NULL);
	}

IL_0036:
	{
		// return base.OnPreBattleBetween(attacker, defender);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9 = ___0_attacker;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = ___1_defender;
		bool L_11;
		L_11 = DefaultExecutor_OnPreBattleBetween_mA66327785BDDA23051E5C2CB5BDAFEC5087E964D(__this, L_9, L_10, NULL);
		return L_11;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::PhotonThrasherSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_PhotonThrasherSummon_m45C0C8DBBCC1A48A118DB318A06B40F2DA3BC6D8 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// return Bot.HasInHand(CardId.AleisterTheInvoker)
		//     && !Bot.HasInHand(CardId.Ratpier)
		//     && !Bot.HasInHand(CardId.Thoroughblade);
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_0, ((int32_t)86120751), NULL);
		if (!L_1)
		{
			goto IL_0038;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_2;
		L_2 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_2, ((int32_t)78872731), NULL);
		if (L_3)
		{
			goto IL_0038;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_4, ((int32_t)77150143), NULL);
		return (bool)((((int32_t)L_5) == ((int32_t)0))? 1 : 0);
	}

IL_0038:
	{
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::AleisterTheInvokerEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_AleisterTheInvokerEffect_mF7CC8E892AEC5AA225341B545945D076944B7E33 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (Card.Location == CardLocation.Hand)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0;
		L_0 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_0, NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)2))))
		{
			goto IL_0068;
		}
	}
	{
		// if (DefaultCheckWhetherCardIsNegated(Card)) return false;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2;
		L_2 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		bool L_3;
		L_3 = DefaultExecutor_DefaultCheckWhetherCardIsNegated_mE335BD160D2D44EC641FDE5745CDD41C1C699A9D(__this, L_2, NULL);
		if (!L_3)
		{
			goto IL_001e;
		}
	}
	{
		// if (DefaultCheckWhetherCardIsNegated(Card)) return false;
		return (bool)0;
	}

IL_001e:
	{
		// if (!(Duel.Phase == DuelPhase.BattleStep
		//     || Duel.Phase == DuelPhase.BattleStart
		//     || Duel.Phase == DuelPhase.Damage))
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_4;
		L_4 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_4);
		int32_t L_5;
		L_5 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_4, NULL);
		if ((((int32_t)L_5) == ((int32_t)((int32_t)16))))
		{
			goto IL_004c;
		}
	}
	{
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_6;
		L_6 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_6);
		int32_t L_7;
		L_7 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_6, NULL);
		if ((((int32_t)L_7) == ((int32_t)8)))
		{
			goto IL_004c;
		}
	}
	{
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_8;
		L_8 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_8);
		int32_t L_9;
		L_9 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_8, NULL);
		if ((((int32_t)L_9) == ((int32_t)((int32_t)32))))
		{
			goto IL_004c;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_004c:
	{
		// return Duel.Player==0
		//     || Util.IsOneEnemyBetter();
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_10;
		L_10 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_10);
		int32_t L_11;
		L_11 = Duel_get_Player_m9193784EAEA68B33A6DBD25C84746FF9B4F21B14_inline(L_10, NULL);
		if (!L_11)
		{
			goto IL_0066;
		}
	}
	{
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_12;
		L_12 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_12);
		bool L_13;
		L_13 = AIUtil_IsOneEnemyBetter_mFD34E579A26FE83600B1E1C7BBF5BC79F6D00076(L_12, (bool)0, NULL);
		return L_13;
	}

IL_0066:
	{
		return (bool)1;
	}

IL_0068:
	{
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::InvocationEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_InvocationEffect_mC0FF065213093F9AF9858B7032B83EA62C508553 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m16C7DC8619DE24DE2760056021DBB52CBB19ACAF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tFD3517A71322E467BC146AEAF76EC021968D868F_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	RuntimeObject* V_1 = NULL;
	RuntimeObject* V_2 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_3 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_4 = NULL;
	RuntimeObject* V_5 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_6 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_7 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_8 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_9 = NULL;
	{
		// if (Card.Location == CardLocation.Grave)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0;
		L_0 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1;
		L_1 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_0, NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)((int32_t)16)))))
		{
			goto IL_0011;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_0011:
	{
		// IList<ClientCard> materials0 = Bot.Graveyard;
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_2;
		L_2 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_2);
		RuntimeObject* L_3;
		L_3 = ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline(L_2, NULL);
		V_0 = L_3;
		// IList<ClientCard> materials1 = Enemy.Graveyard;
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Enemy_mF9F9E24015075FB0C19396572F25879821E7660D_inline(__this, NULL);
		NullCheck(L_4);
		RuntimeObject* L_5;
		L_5 = ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline(L_4, NULL);
		V_1 = L_5;
		// IList<ClientCard> mats = new List<ClientCard>();
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_6 = (List_1_tFD3517A71322E467BC146AEAF76EC021968D868F*)il2cpp_codegen_object_new(List_1_tFD3517A71322E467BC146AEAF76EC021968D868F_il2cpp_TypeInfo_var);
		NullCheck(L_6);
		List_1__ctor_m16C7DC8619DE24DE2760056021DBB52CBB19ACAF(L_6, List_1__ctor_m16C7DC8619DE24DE2760056021DBB52CBB19ACAF_RuntimeMethod_var);
		V_2 = L_6;
		// ClientCard aleister = GetAleisterInGrave();
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_7;
		L_7 = ZoodiacExecutor_GetAleisterInGrave_m9EC7AB85888070EC8BA787661E78E3052A46BB4D(__this, NULL);
		V_3 = L_7;
		// if (aleister != null)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_8 = V_3;
		if (!L_8)
		{
			goto IL_0040;
		}
	}
	{
		// mats.Add(aleister);
		RuntimeObject* L_9 = V_2;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = V_3;
		NullCheck(L_9);
		InterfaceActionInvoker1< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(2 /* System.Void System.Collections.Generic.ICollection`1<WindBot.Game.ClientCard>::Add(T) */, ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var, L_9, L_10);
	}

IL_0040:
	{
		// ClientCard mat = null;
		V_4 = (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)NULL;
		// foreach (ClientCard card in materials0)
		RuntimeObject* L_11 = V_0;
		NullCheck(L_11);
		RuntimeObject* L_12;
		L_12 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_11);
		V_5 = L_12;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0072:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_13 = V_5;
					if (!L_13)
					{
						goto IL_007d;
					}
				}
				{
					RuntimeObject* L_14 = V_5;
					NullCheck(L_14);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_14);
				}

IL_007d:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_0067_1;
			}

IL_004d_1:
			{
				// foreach (ClientCard card in materials0)
				RuntimeObject* L_15 = V_5;
				NullCheck(L_15);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_16;
				L_16 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_15);
				V_6 = L_16;
				// if (card.HasAttribute(CardAttribute.Light))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_17 = V_6;
				NullCheck(L_17);
				bool L_18;
				L_18 = ClientCard_HasAttribute_m635783178B1BECFA01B0B71C8DAB5AA5A75A276A(L_17, ((int32_t)16), NULL);
				if (!L_18)
				{
					goto IL_0067_1;
				}
			}
			{
				// mat = card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_19 = V_6;
				V_4 = L_19;
				// break;
				goto IL_007e;
			}

IL_0067_1:
			{
				// foreach (ClientCard card in materials0)
				RuntimeObject* L_20 = V_5;
				NullCheck(L_20);
				bool L_21;
				L_21 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_20);
				if (L_21)
				{
					goto IL_004d_1;
				}
			}
			{
				goto IL_007e;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_007e:
	{
		// foreach (ClientCard card in materials1)
		RuntimeObject* L_22 = V_1;
		NullCheck(L_22);
		RuntimeObject* L_23;
		L_23 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_22);
		V_5 = L_23;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_00ad:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_24 = V_5;
					if (!L_24)
					{
						goto IL_00b8;
					}
				}
				{
					RuntimeObject* L_25 = V_5;
					NullCheck(L_25);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_25);
				}

IL_00b8:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_00a2_1;
			}

IL_0088_1:
			{
				// foreach (ClientCard card in materials1)
				RuntimeObject* L_26 = V_5;
				NullCheck(L_26);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_27;
				L_27 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_26);
				V_7 = L_27;
				// if (card.HasAttribute(CardAttribute.Light))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_28 = V_7;
				NullCheck(L_28);
				bool L_29;
				L_29 = ClientCard_HasAttribute_m635783178B1BECFA01B0B71C8DAB5AA5A75A276A(L_28, ((int32_t)16), NULL);
				if (!L_29)
				{
					goto IL_00a2_1;
				}
			}
			{
				// mat = card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_30 = V_7;
				V_4 = L_30;
				// break;
				goto IL_00b9;
			}

IL_00a2_1:
			{
				// foreach (ClientCard card in materials1)
				RuntimeObject* L_31 = V_5;
				NullCheck(L_31);
				bool L_32;
				L_32 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_31);
				if (L_32)
				{
					goto IL_0088_1;
				}
			}
			{
				goto IL_00b9;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_00b9:
	{
		// if (mat != null)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_33 = V_4;
		if (!L_33)
		{
			goto IL_00f0;
		}
	}
	{
		// mats.Add(mat);
		RuntimeObject* L_34 = V_2;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_35 = V_4;
		NullCheck(L_34);
		InterfaceActionInvoker1< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(2 /* System.Void System.Collections.Generic.ICollection`1<WindBot.Game.ClientCard>::Add(T) */, ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var, L_34, L_35);
		// AI.SelectCard(CardId.InvokedMechaba);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_36;
		L_36 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_36);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_36, ((int32_t)75286621), NULL);
		// AI.SelectMaterials(mats);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_37;
		L_37 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		RuntimeObject* L_38 = V_2;
		NullCheck(L_37);
		GameAI_SelectMaterials_mFA3B2AD902CDFC22A106D1AF96CF4704194FF017(L_37, L_38, 0, NULL);
		// AI.SelectPosition(CardPosition.FaceUpAttack);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_39;
		L_39 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_39);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_39, 1, NULL);
		// return true;
		return (bool)1;
	}

IL_00f0:
	{
		// foreach (ClientCard card in materials0)
		RuntimeObject* L_40 = V_0;
		NullCheck(L_40);
		RuntimeObject* L_41;
		L_41 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_40);
		V_5 = L_41;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_011e:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_42 = V_5;
					if (!L_42)
					{
						goto IL_0129;
					}
				}
				{
					RuntimeObject* L_43 = V_5;
					NullCheck(L_43);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_43);
				}

IL_0129:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_0113_1;
			}

IL_00fa_1:
			{
				// foreach (ClientCard card in materials0)
				RuntimeObject* L_44 = V_5;
				NullCheck(L_44);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_45;
				L_45 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_44);
				V_8 = L_45;
				// if (card.HasAttribute(CardAttribute.Earth))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_46 = V_8;
				NullCheck(L_46);
				bool L_47;
				L_47 = ClientCard_HasAttribute_m635783178B1BECFA01B0B71C8DAB5AA5A75A276A(L_46, 1, NULL);
				if (!L_47)
				{
					goto IL_0113_1;
				}
			}
			{
				// mat = card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_48 = V_8;
				V_4 = L_48;
				// break;
				goto IL_012a;
			}

IL_0113_1:
			{
				// foreach (ClientCard card in materials0)
				RuntimeObject* L_49 = V_5;
				NullCheck(L_49);
				bool L_50;
				L_50 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_49);
				if (L_50)
				{
					goto IL_00fa_1;
				}
			}
			{
				goto IL_012a;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_012a:
	{
		// foreach (ClientCard card in materials1)
		RuntimeObject* L_51 = V_1;
		NullCheck(L_51);
		RuntimeObject* L_52;
		L_52 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_51);
		V_5 = L_52;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0158:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_53 = V_5;
					if (!L_53)
					{
						goto IL_0163;
					}
				}
				{
					RuntimeObject* L_54 = V_5;
					NullCheck(L_54);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_54);
				}

IL_0163:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_014d_1;
			}

IL_0134_1:
			{
				// foreach (ClientCard card in materials1)
				RuntimeObject* L_55 = V_5;
				NullCheck(L_55);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_56;
				L_56 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_55);
				V_9 = L_56;
				// if (card.HasAttribute(CardAttribute.Earth))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_57 = V_9;
				NullCheck(L_57);
				bool L_58;
				L_58 = ClientCard_HasAttribute_m635783178B1BECFA01B0B71C8DAB5AA5A75A276A(L_57, 1, NULL);
				if (!L_58)
				{
					goto IL_014d_1;
				}
			}
			{
				// mat = card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_59 = V_9;
				V_4 = L_59;
				// break;
				goto IL_0164;
			}

IL_014d_1:
			{
				// foreach (ClientCard card in materials1)
				RuntimeObject* L_60 = V_5;
				NullCheck(L_60);
				bool L_61;
				L_61 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_60);
				if (L_61)
				{
					goto IL_0134_1;
				}
			}
			{
				goto IL_0164;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0164:
	{
		// if (mat != null)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_62 = V_4;
		if (!L_62)
		{
			goto IL_019b;
		}
	}
	{
		// mats.Add(mat);
		RuntimeObject* L_63 = V_2;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_64 = V_4;
		NullCheck(L_63);
		InterfaceActionInvoker1< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(2 /* System.Void System.Collections.Generic.ICollection`1<WindBot.Game.ClientCard>::Add(T) */, ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var, L_63, L_64);
		// AI.SelectCard(CardId.InvokedMagellanica);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_65;
		L_65 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_65);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_65, ((int32_t)48791583), NULL);
		// AI.SelectMaterials(mats);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_66;
		L_66 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		RuntimeObject* L_67 = V_2;
		NullCheck(L_66);
		GameAI_SelectMaterials_mFA3B2AD902CDFC22A106D1AF96CF4704194FF017(L_66, L_67, 0, NULL);
		// AI.SelectPosition(CardPosition.FaceUpAttack);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_68;
		L_68 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_68);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_68, 1, NULL);
		// return true;
		return (bool)1;
	}

IL_019b:
	{
		// return false;
		return (bool)0;
	}
}
// WindBot.Game.ClientCard WindBot.Game.AI.Decks.ZoodiacExecutor::GetAleisterInGrave()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ZoodiacExecutor_GetAleisterInGrave_m9EC7AB85888070EC8BA787661E78E3052A46BB4D (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_1 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_2 = NULL;
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_3 = NULL;
	{
		// foreach (ClientCard card in Enemy.Graveyard)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Enemy_mF9F9E24015075FB0C19396572F25879821E7660D_inline(__this, NULL);
		NullCheck(L_0);
		RuntimeObject* L_1;
		L_1 = ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline(L_0, NULL);
		NullCheck(L_1);
		RuntimeObject* L_2;
		L_2 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_1);
		V_0 = L_2;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0035:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_3 = V_0;
					if (!L_3)
					{
						goto IL_003e;
					}
				}
				{
					RuntimeObject* L_4 = V_0;
					NullCheck(L_4);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_4);
				}

IL_003e:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_002b_1;
			}

IL_0013_1:
			{
				// foreach (ClientCard card in Enemy.Graveyard)
				RuntimeObject* L_5 = V_0;
				NullCheck(L_5);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6;
				L_6 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_5);
				V_1 = L_6;
				// if (card.IsCode(CardId.AleisterTheInvoker))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_7 = V_1;
				NullCheck(L_7);
				bool L_8;
				L_8 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_7, ((int32_t)86120751), NULL);
				if (!L_8)
				{
					goto IL_002b_1;
				}
			}
			{
				// return card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9 = V_1;
				V_2 = L_9;
				goto IL_0080;
			}

IL_002b_1:
			{
				// foreach (ClientCard card in Enemy.Graveyard)
				RuntimeObject* L_10 = V_0;
				NullCheck(L_10);
				bool L_11;
				L_11 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_10);
				if (L_11)
				{
					goto IL_0013_1;
				}
			}
			{
				goto IL_003f;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_003f:
	{
		// foreach (ClientCard card in Bot.Graveyard)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_12;
		L_12 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_12);
		RuntimeObject* L_13;
		L_13 = ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline(L_12, NULL);
		NullCheck(L_13);
		RuntimeObject* L_14;
		L_14 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.Generic.IEnumerator`1<T> System.Collections.Generic.IEnumerable`1<WindBot.Game.ClientCard>::GetEnumerator() */, IEnumerable_1_t93CF982EEE55C02D347A38F99527D39B1FDBF74A_il2cpp_TypeInfo_var, L_13);
		V_0 = L_14;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0074:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_15 = V_0;
					if (!L_15)
					{
						goto IL_007d;
					}
				}
				{
					RuntimeObject* L_16 = V_0;
					NullCheck(L_16);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_16);
				}

IL_007d:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_006a_1;
			}

IL_0052_1:
			{
				// foreach (ClientCard card in Bot.Graveyard)
				RuntimeObject* L_17 = V_0;
				NullCheck(L_17);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_18;
				L_18 = InterfaceFuncInvoker0< ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* >::Invoke(0 /* T System.Collections.Generic.IEnumerator`1<WindBot.Game.ClientCard>::get_Current() */, IEnumerator_1_t25BDA250EB60546BC30619F52F8247F8EEE76728_il2cpp_TypeInfo_var, L_17);
				V_3 = L_18;
				// if (card.IsCode(CardId.AleisterTheInvoker))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_19 = V_3;
				NullCheck(L_19);
				bool L_20;
				L_20 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_19, ((int32_t)86120751), NULL);
				if (!L_20)
				{
					goto IL_006a_1;
				}
			}
			{
				// return card;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_21 = V_3;
				V_2 = L_21;
				goto IL_0080;
			}

IL_006a_1:
			{
				// foreach (ClientCard card in Bot.Graveyard)
				RuntimeObject* L_22 = V_0;
				NullCheck(L_22);
				bool L_23;
				L_23 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_22);
				if (L_23)
				{
					goto IL_0052_1;
				}
			}
			{
				goto IL_007e;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_007e:
	{
		// return null;
		return (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)NULL;
	}

IL_0080:
	{
		// }
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_24 = V_2;
		return L_24;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::ChakanineSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_ChakanineSummon_m99FA65841520A8057D3F5A0843A668F1C95365DB (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (Bot.HasInMonstersZone(CardId.Ratpier) && !ChakanineSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_0, ((int32_t)78872731), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_1)
		{
			goto IL_004f;
		}
	}
	{
		bool L_2 = __this->___ChakanineSpsummoned_19;
		if (L_2)
		{
			goto IL_004f;
		}
	}
	{
		// AI.SelectMaterials(CardId.Ratpier);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_3;
		L_3 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_3);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_3, ((int32_t)78872731), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_4;
		L_4 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_4);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_4, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_5);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_5, 4, NULL);
		// ChakanineSpsummoned = true;
		__this->___ChakanineSpsummoned_19 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_004f:
	{
		// if (Bot.HasInMonstersZone(CardId.Broadbull) && !ChakanineSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_6, ((int32_t)85115440), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_7)
		{
			goto IL_009e;
		}
	}
	{
		bool L_8 = __this->___ChakanineSpsummoned_19;
		if (L_8)
		{
			goto IL_009e;
		}
	}
	{
		// AI.SelectMaterials(CardId.Broadbull);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_9;
		L_9 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_9);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_9, ((int32_t)85115440), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_10;
		L_10 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_10);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_10, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_11;
		L_11 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_11);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_11, 4, NULL);
		// ChakanineSpsummoned = true;
		__this->___ChakanineSpsummoned_19 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_009e:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::ChakanineEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_ChakanineEffect_mBF76840856B026046F1C53523EB6744ADE29A124 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (Bot.HasInGraveyard(CardId.Whiptail) || Bot.HasInGraveyard(CardId.Thoroughblade))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInGraveyard_mCB3594F299677CF121778BBB8C774262E414867D(L_0, ((int32_t)31755044), NULL);
		if (L_1)
		{
			goto IL_0024;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_2;
		L_2 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientField_HasInGraveyard_mCB3594F299677CF121778BBB8C774262E414867D(L_2, ((int32_t)77150143), NULL);
		if (!L_3)
		{
			goto IL_0063;
		}
	}

IL_0024:
	{
		// AI.SelectCard(
		//     CardId.Broadbull,
		//     CardId.Tigermortar,
		//     CardId.Chakanine,
		//     CardId.Thoroughblade,
		//     CardId.Ratpier,
		//     CardId.Whiptail
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_4;
		L_4 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)6);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_6 = L_5;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_7 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_6, L_7, NULL);
		NullCheck(L_4);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_4, L_6, NULL);
		// AI.SelectNextCard(
		//     CardId.Whiptail,
		//     CardId.Thoroughblade
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_8;
		L_8 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_9 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_10 = L_9;
		NullCheck(L_10);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)31755044));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_11 = L_10;
		NullCheck(L_11);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)77150143));
		NullCheck(L_8);
		GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502(L_8, L_11, NULL);
		// return true;
		return (bool)1;
	}

IL_0063:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::TigermortarSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_TigermortarSummon_m265F2BEEFDD7D5C119BF7B516BDE5662400A6BF9 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (Bot.HasInMonstersZone(CardId.Chakanine) && !TigermortarSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_0, ((int32_t)41375811), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_1)
		{
			goto IL_004f;
		}
	}
	{
		bool L_2 = __this->___TigermortarSpsummoned_18;
		if (L_2)
		{
			goto IL_004f;
		}
	}
	{
		// AI.SelectMaterials(CardId.Chakanine);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_3;
		L_3 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_3);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_3, ((int32_t)41375811), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_4;
		L_4 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_4);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_4, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_5);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_5, 4, NULL);
		// TigermortarSpsummoned = true;
		__this->___TigermortarSpsummoned_18 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_004f:
	{
		// if (Bot.HasInMonstersZone(CardId.Ratpier) && !TigermortarSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_6, ((int32_t)78872731), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_7)
		{
			goto IL_009e;
		}
	}
	{
		bool L_8 = __this->___TigermortarSpsummoned_18;
		if (L_8)
		{
			goto IL_009e;
		}
	}
	{
		// AI.SelectMaterials(CardId.Ratpier);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_9;
		L_9 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_9);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_9, ((int32_t)78872731), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_10;
		L_10 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_10);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_10, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_11;
		L_11 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_11);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_11, 4, NULL);
		// TigermortarSpsummoned = true;
		__this->___TigermortarSpsummoned_18 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_009e:
	{
		// if (Bot.HasInMonstersZone(CardId.Thoroughblade) && !TigermortarSpsummoned
		//     && Bot.HasInGraveyard(new[]
		//     {
		//         CardId.Whiptail,
		//         CardId.Ratpier
		//     }))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_12;
		L_12 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_12);
		bool L_13;
		L_13 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_12, ((int32_t)77150143), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_13)
		{
			goto IL_0104;
		}
	}
	{
		bool L_14 = __this->___TigermortarSpsummoned_18;
		if (L_14)
		{
			goto IL_0104;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_15;
		L_15 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_16 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_17 = L_16;
		NullCheck(L_17);
		(L_17)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)31755044));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_18 = L_17;
		NullCheck(L_18);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)78872731));
		NullCheck(L_15);
		bool L_19;
		L_19 = ClientField_HasInGraveyard_mAED60820B814AA74D32462265A06DE0D93C7DBEF(L_15, (RuntimeObject*)L_18, NULL);
		if (!L_19)
		{
			goto IL_0104;
		}
	}
	{
		// AI.SelectMaterials(CardId.Thoroughblade);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_20;
		L_20 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_20);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_20, ((int32_t)77150143), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_21;
		L_21 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_21);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_21, (bool)1, NULL);
		// TigermortarSpsummoned = true;
		__this->___TigermortarSpsummoned_18 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_0104:
	{
		// if (Bot.HasInMonstersZone(CardId.Whiptail) && !TigermortarSpsummoned
		//     && Bot.HasInGraveyard(CardId.Ratpier))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_22;
		L_22 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_22);
		bool L_23;
		L_23 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_22, ((int32_t)31755044), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_23)
		{
			goto IL_0159;
		}
	}
	{
		bool L_24 = __this->___TigermortarSpsummoned_18;
		if (L_24)
		{
			goto IL_0159;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_25;
		L_25 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_25);
		bool L_26;
		L_26 = ClientField_HasInGraveyard_mCB3594F299677CF121778BBB8C774262E414867D(L_25, ((int32_t)78872731), NULL);
		if (!L_26)
		{
			goto IL_0159;
		}
	}
	{
		// AI.SelectMaterials(CardId.Whiptail);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_27;
		L_27 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_27);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_27, ((int32_t)31755044), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_28;
		L_28 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_28);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_28, (bool)1, NULL);
		// TigermortarSpsummoned = true;
		__this->___TigermortarSpsummoned_18 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_0159:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::TigermortarEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_TigermortarEffect_m89C12A32939C22435DC8B937DFB47BBB1E0C7985 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(CardId.Chakanine);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_0, ((int32_t)41375811), NULL);
		// AI.SelectNextCard(CardId.Tigermortar);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_1;
		L_1 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_1);
		GameAI_SelectNextCard_mCE2E7113B1EAFDFB6999537F5EE9318A0B8BD68D(L_1, ((int32_t)11510448), NULL);
		// AI.SelectThirdCard(CardId.Ratpier, CardId.Whiptail, CardId.Thoroughblade);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_2;
		L_2 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = L_3;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_5 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_4, L_5, NULL);
		NullCheck(L_2);
		GameAI_SelectThirdCard_mBFF5B2E02CE0FB5251BA76DB92EFF75DC89BB571(L_2, L_4, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::BroadbullSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_BroadbullSummon_m2B7299A2A14FF5F212DAC18B9785D3E075307DA6 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (Bot.HasInMonstersZone(CardId.Tigermortar) && !BroadbullSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_0, ((int32_t)11510448), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_1)
		{
			goto IL_004f;
		}
	}
	{
		bool L_2 = __this->___BroadbullSpsummoned_20;
		if (L_2)
		{
			goto IL_004f;
		}
	}
	{
		// AI.SelectMaterials(CardId.Tigermortar);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_3;
		L_3 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_3);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_3, ((int32_t)11510448), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_4;
		L_4 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_4);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_4, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_5);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_5, 4, NULL);
		// BroadbullSpsummoned = true;
		__this->___BroadbullSpsummoned_20 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_004f:
	{
		// if (Bot.HasInMonstersZone(CardId.Chakanine) && !BroadbullSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_6, ((int32_t)41375811), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_7)
		{
			goto IL_009e;
		}
	}
	{
		bool L_8 = __this->___BroadbullSpsummoned_20;
		if (L_8)
		{
			goto IL_009e;
		}
	}
	{
		// AI.SelectMaterials(CardId.Chakanine);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_9;
		L_9 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_9);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_9, ((int32_t)41375811), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_10;
		L_10 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_10);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_10, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_11;
		L_11 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_11);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_11, 4, NULL);
		// BroadbullSpsummoned = true;
		__this->___BroadbullSpsummoned_20 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_009e:
	{
		// if (Bot.HasInMonstersZone(CardId.Ratpier) && !BroadbullSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_12;
		L_12 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_12);
		bool L_13;
		L_13 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_12, ((int32_t)78872731), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_13)
		{
			goto IL_00ed;
		}
	}
	{
		bool L_14 = __this->___BroadbullSpsummoned_20;
		if (L_14)
		{
			goto IL_00ed;
		}
	}
	{
		// AI.SelectMaterials(CardId.Ratpier);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_15;
		L_15 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_15);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_15, ((int32_t)78872731), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_16;
		L_16 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_16);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_16, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_17;
		L_17 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_17);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_17, 4, NULL);
		// BroadbullSpsummoned = true;
		__this->___BroadbullSpsummoned_20 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_00ed:
	{
		// if (Bot.HasInMonstersZone(CardId.Thoroughblade) && !BroadbullSpsummoned)
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_18;
		L_18 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_18);
		bool L_19;
		L_19 = ClientField_HasInMonstersZone_mAD776341E794AADE8ECC54A04BE04AF1D31CE298(L_18, ((int32_t)77150143), (bool)0, (bool)0, (bool)0, NULL);
		if (!L_19)
		{
			goto IL_013c;
		}
	}
	{
		bool L_20 = __this->___BroadbullSpsummoned_20;
		if (L_20)
		{
			goto IL_013c;
		}
	}
	{
		// AI.SelectMaterials(CardId.Thoroughblade);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_21;
		L_21 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_21);
		GameAI_SelectMaterials_m34727ED0090334327DF22FF24118B55D65812720(L_21, ((int32_t)77150143), 0, NULL);
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_22;
		L_22 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_22);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_22, (bool)1, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_23;
		L_23 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_23);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_23, 4, NULL);
		// BroadbullSpsummoned = true;
		__this->___BroadbullSpsummoned_20 = (bool)1;
		// return true;
		return (bool)1;
	}

IL_013c:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::BroadbullEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_BroadbullEffect_m58423C9AEF280904C98C1F98A59309DDC0167853 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____B10B006404D9DA431F45BF1F6465B990B1496FFFDA5432E063E134E351C345E1_220_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.Tigermortar,
		//     CardId.Chakanine,
		//     CardId.Drident,
		//     CardId.AleisterTheInvoker,
		//     CardId.PhotonThrasher
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)5);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____B10B006404D9DA431F45BF1F6465B990B1496FFFDA5432E063E134E351C345E1_220_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// if (Bot.HasInHand(CardId.Whiptail) && !Bot.HasInHand(CardId.Ratpier))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_4, ((int32_t)31755044), NULL);
		if (!L_5)
		{
			goto IL_0052;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_6);
		bool L_7;
		L_7 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_6, ((int32_t)78872731), NULL);
		if (L_7)
		{
			goto IL_0052;
		}
	}
	{
		// AI.SelectNextCard(CardId.Ratpier);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_8;
		L_8 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_8);
		GameAI_SelectNextCard_mCE2E7113B1EAFDFB6999537F5EE9318A0B8BD68D(L_8, ((int32_t)78872731), NULL);
		goto IL_0062;
	}

IL_0052:
	{
		// AI.SelectNextCard(CardId.Whiptail);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_9;
		L_9 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_9);
		GameAI_SelectNextCard_mCE2E7113B1EAFDFB6999537F5EE9318A0B8BD68D(L_9, ((int32_t)31755044), NULL);
	}

IL_0062:
	{
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::BroadbullXYZSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_BroadbullXYZSummon_mE970E9CC798A0C5CFF07BDC5A683268BB27BE8CA (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4E90313FD2428587A82788026D3458A35F4A9F16ED24BBB4C45C92DF07C5E31F_97_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectYesNo(false);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_0);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_0, (bool)0, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_1;
		L_1 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_1);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_1, 4, NULL);
		// AI.SelectMaterials(new[]
		//     {
		//         CardId.Ratpier,
		//         CardId.PhotonThrasher,
		//         CardId.Whiptail,
		//         CardId.AleisterTheInvoker
		//     });
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_2;
		L_2 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)4);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = L_3;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_5 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____4E90313FD2428587A82788026D3458A35F4A9F16ED24BBB4C45C92DF07C5E31F_97_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_4, L_5, NULL);
		NullCheck(L_2);
		GameAI_SelectMaterials_m2F980D71FCEB54FFC7CDE08C4D5041C4EFF0CB76(L_2, (RuntimeObject*)L_4, 0, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::DridentSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_DridentSummon_mE76044F95CF9E22E2F692FC8142A35189AAAA7A6 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5593F1AAE0656CCB5BE70A58C6CED4F7CFED42BC8DD0ADE1B33AE7FC14C68591_105_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectMaterials(new[]
		//     {
		//         CardId.Broadbull,
		//         CardId.Tigermortar,
		//         CardId.Chakanine,
		//         CardId.Thoroughblade
		//     });
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)4);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5593F1AAE0656CCB5BE70A58C6CED4F7CFED42BC8DD0ADE1B33AE7FC14C68591_105_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectMaterials_m2F980D71FCEB54FFC7CDE08C4D5041C4EFF0CB76(L_0, (RuntimeObject*)L_2, 0, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::RatpierMaterialEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_RatpierMaterialEffect_mA083061D495C295650BF2551FA4B2DD67F6F0335 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (ActivateDescription == Util.GetStringId(CardId.Ratpier, 1))
		int32_t L_0;
		L_0 = Executor_get_ActivateDescription_m2855E33CA44A88A7F15FFFA522E084F6E791604C_inline(__this, NULL);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_1;
		L_1 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_1);
		int32_t L_2;
		L_2 = AIUtil_GetStringId_mEA5B8E629F1A04FB9361B4AC4F6C736562A1A672(L_1, ((int32_t)78872731), 1, NULL);
		if ((!(((uint32_t)L_0) == ((uint32_t)L_2))))
		{
			goto IL_0027;
		}
	}
	{
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_3;
		L_3 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_3);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_3, 4, NULL);
		// return true;
		return (bool)1;
	}

IL_0027:
	{
		// return false;
		return (bool)0;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::WhiptailEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_WhiptailEffect_mB911200A480506535F01029F54B88D405ED49CB6 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_0 = NULL;
	Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 V_1;
	memset((&V_1), 0, sizeof(V_1));
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_2 = NULL;
	{
		// if (Duel.Phase == DuelPhase.Main1 || Duel.Phase == DuelPhase.Main2)
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_0;
		L_0 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1;
		L_1 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_0, NULL);
		if ((((int32_t)L_1) == ((int32_t)4)))
		{
			goto IL_0020;
		}
	}
	{
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_2;
		L_2 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_2);
		int32_t L_3;
		L_3 = Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline(L_2, NULL);
		if ((!(((uint32_t)L_3) == ((uint32_t)((int32_t)256)))))
		{
			goto IL_0022;
		}
	}

IL_0020:
	{
		// return false;
		return (bool)0;
	}

IL_0022:
	{
		// if (DefaultCheckWhetherCardIsNegated(Card)) return false;
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4;
		L_4 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		bool L_5;
		L_5 = DefaultExecutor_DefaultCheckWhetherCardIsNegated_mE335BD160D2D44EC641FDE5745CDD41C1C699A9D(__this, L_4, NULL);
		if (!L_5)
		{
			goto IL_0032;
		}
	}
	{
		// if (DefaultCheckWhetherCardIsNegated(Card)) return false;
		return (bool)0;
	}

IL_0032:
	{
		// ClientCard target = null;
		V_0 = (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*)NULL;
		// List<ClientCard> monsters = Bot.GetMonsters();
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_6;
		L_6 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_6);
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_7;
		L_7 = ClientField_GetMonsters_mD3C72712741F3DB1549B08EA2FBE37024F7BECC6(L_6, NULL);
		// foreach (ClientCard monster in monsters)
		NullCheck(L_7);
		Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 L_8;
		L_8 = List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108(L_7, List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		V_1 = L_8;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_007b:
			{// begin finally (depth: 1)
				Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0((&V_1), Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
				return;
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_0070_1;
			}

IL_0047_1:
			{
				// foreach (ClientCard monster in monsters)
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_9;
				L_9 = Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_inline((&V_1), Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
				V_2 = L_9;
				// if (monster.IsFaceup() && monster.IsCode(CardId.Drident) && !monster.HasXyzMaterial())
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = V_2;
				NullCheck(L_10);
				bool L_11;
				L_11 = ClientCard_IsFaceup_m722E617CA1CB9D5D62259B0E8B0EC38685253E0D(L_10, NULL);
				if (!L_11)
				{
					goto IL_0070_1;
				}
			}
			{
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_12 = V_2;
				NullCheck(L_12);
				bool L_13;
				L_13 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_12, ((int32_t)48905153), NULL);
				if (!L_13)
				{
					goto IL_0070_1;
				}
			}
			{
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_14 = V_2;
				NullCheck(L_14);
				bool L_15;
				L_15 = ClientCard_HasXyzMaterial_mF32DFDFB979DD73B7958A15A669B4FAACCAD49C0(L_14, NULL);
				if (L_15)
				{
					goto IL_0070_1;
				}
			}
			{
				// target = monster;
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_16 = V_2;
				V_0 = L_16;
				// break;
				goto IL_0089;
			}

IL_0070_1:
			{
				// foreach (ClientCard monster in monsters)
				bool L_17;
				L_17 = Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76((&V_1), Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
				if (L_17)
				{
					goto IL_0047_1;
				}
			}
			{
				goto IL_0089;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0089:
	{
		// if (target == null)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_18 = V_0;
		if (L_18)
		{
			goto IL_00a5;
		}
	}
	{
		// AI.SelectCard(new[]
		//     {
		//         CardId.Drident
		//     });
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_19;
		L_19 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_20 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)1);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_21 = L_20;
		NullCheck(L_21);
		(L_21)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)48905153));
		NullCheck(L_19);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_19, L_21, NULL);
	}

IL_00a5:
	{
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::RatpierEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_RatpierEffect_m4A512209CB118E70E4784E51DFDA1C714235B827 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____773C6CE57E1CA4558EE8D2F9F84478B08F5C4AFDA39E2A0E7AE2ABD5DDC234E9_156_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.ZoodiacCombo,
		//     CardId.Thoroughblade,
		//     CardId.ZoodiacBarrage
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____773C6CE57E1CA4558EE8D2F9F84478B08F5C4AFDA39E2A0E7AE2ABD5DDC234E9_156_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::DridentEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_DridentEffect_m49B4EDBE2FC4DBBB43031BCD06F764FF124D0141 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_0 = NULL;
	{
		// if (Duel.LastChainPlayer == 0)
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_0;
		L_0 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_0);
		int32_t L_1;
		L_1 = Duel_get_LastChainPlayer_mC5B0E0859A850414FF721351866F32E42D7CF25E_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000f;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_000f:
	{
		// ClientCard target = Util.GetBestEnemyCard(true);
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_2;
		L_2 = Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline(__this, NULL);
		NullCheck(L_2);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3;
		L_3 = AIUtil_GetBestEnemyCard_mBBB0AC8410DBC946860F12394240EF75061492C1(L_2, (bool)1, (bool)0, NULL);
		V_0 = L_3;
		// if (target == null)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = V_0;
		if (L_4)
		{
			goto IL_0022;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0022:
	{
		// AI.SelectCard(
		//     CardId.Broadbull,
		//     CardId.Tigermortar,
		//     CardId.Chakanine,
		//     CardId.Thoroughblade,
		//     CardId.Ratpier,
		//     CardId.Whiptail
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_6 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)6);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_7 = L_6;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_8 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5677551DD0A49C4AA8E6A1BC40458F0026F50386894F8F41B66DEE3580E3757D_106_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_7, L_8, NULL);
		NullCheck(L_5);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_5, L_7, NULL);
		// AI.SelectNextCard(target);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_9;
		L_9 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_10 = V_0;
		NullCheck(L_9);
		GameAI_SelectNextCard_m7D4DE266B87FCBD8D9496386E25E7853FE93718B(L_9, L_10, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::DaigustoEmeralSummon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_DaigustoEmeralSummon_m0E1AB7FB015BD4534E63E320D2021DDEE2D12677 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mFD01966772F1C308D34514243361686DB88A421C_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectMaterials(new[]
		//     {
		//         CardId.PhotonThrasher,
		//         CardId.AleisterTheInvoker
		//     });
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)65367484));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = L_2;
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)86120751));
		NullCheck(L_0);
		GameAI_SelectMaterials_m2F980D71FCEB54FFC7CDE08C4D5041C4EFF0CB76(L_0, (RuntimeObject*)L_3, 0, NULL);
		// return Bot.GetGraveyardMonsters().Count >= 3;
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_5;
		L_5 = ClientField_GetGraveyardMonsters_mCBB28BEF401FC8B467AC7625C33AD29858994281(L_4, NULL);
		NullCheck(L_5);
		int32_t L_6;
		L_6 = List_1_get_Count_mFD01966772F1C308D34514243361686DB88A421C_inline(L_5, List_1_get_Count_mFD01966772F1C308D34514243361686DB88A421C_RuntimeMethod_var);
		return (bool)((((int32_t)((((int32_t)L_6) < ((int32_t)3))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::DaigustoEmeralEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_DaigustoEmeralEffect_m35420E1998490817CF77BB6F5FEE2EC0D9A5CAF3 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____E9484E9181F8FEDF2C097076D63594DE2E285F7EEBCAE6303F4AAE44490FDFF4_305_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.Ratpier,
		//     CardId.AleisterTheInvoker,
		//     CardId.Whiptail
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____E9484E9181F8FEDF2C097076D63594DE2E285F7EEBCAE6303F4AAE44490FDFF4_305_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// AI.SelectNextCard(
		//     CardId.Ratpier,
		//     CardId.DaigustoEmeral
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_4;
		L_4 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)2);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_6 = L_5;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(0), (int32_t)((int32_t)78872731));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_7 = L_6;
		NullCheck(L_7);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(1), (int32_t)((int32_t)581014));
		NullCheck(L_4);
		GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502(L_4, L_7, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::FireFormationTenkiEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_FireFormationTenkiEffect_mAA0B505305FDC869DB24CA34A240BF16828AF05C (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (Bot.HasInHand(CardId.ZoodiacBarrage)
		//    || Bot.HasInSpellZone(CardId.ZoodiacBarrage)
		//    || Bot.HasInHand(CardId.Ratpier))
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_0, ((int32_t)46060017), NULL);
		if (L_1)
		{
			goto IL_0038;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_2;
		L_2 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientField_HasInSpellZone_m1113B0E04080515C3764EDDD27C32ABCEB740DE4(L_2, ((int32_t)46060017), (bool)0, (bool)0, NULL);
		if (L_3)
		{
			goto IL_0038;
		}
	}
	{
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_4;
		L_4 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_4);
		bool L_5;
		L_5 = ClientField_HasInHand_m0DAF553C7215761926F3EA9ED688EECDEE37E2E7(L_4, ((int32_t)78872731), NULL);
		if (!L_5)
		{
			goto IL_004a;
		}
	}

IL_0038:
	{
		// AI.SelectCard(CardId.Whiptail);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_6;
		L_6 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_6);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_6, ((int32_t)31755044), NULL);
		goto IL_005a;
	}

IL_004a:
	{
		// AI.SelectCard(CardId.Ratpier);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_7;
		L_7 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_7);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_7, ((int32_t)78872731), NULL);
	}

IL_005a:
	{
		// AI.SelectYesNo(true);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_8;
		L_8 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_8);
		GameAI_SelectYesNo_m9C61FEFC1247ECEB472F95566308C1AA2CC0E05B(L_8, (bool)1, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::ZoodiacBarrageEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_ZoodiacBarrageEffect_mE7FC8E95902A2F19ECE91861D5970CE112731FDB (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____66E5E7AB424DD096605E51332FF630ADED08E0DE27F408C52F23E62160961EB1_132_FieldInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 V_0;
	memset((&V_0), 0, sizeof(V_0));
	ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* V_1 = NULL;
	bool V_2 = false;
	{
		// foreach (ClientCard spell in Bot.GetSpells())
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0;
		L_0 = Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline(__this, NULL);
		NullCheck(L_0);
		List_1_tFD3517A71322E467BC146AEAF76EC021968D868F* L_1;
		L_1 = ClientField_GetSpells_mD7EEB5F5D3FAF6C9CA8331CF5DF211C9F67CEA5B(L_0, NULL);
		NullCheck(L_1);
		Enumerator_t68177699C21438C2DA8EF4C7E21C59A9FBBDD846 L_2;
		L_2 = List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108(L_1, List_1_GetEnumerator_m2CD0B97411227AE50FCD41AD22E5B9CE81B7C108_RuntimeMethod_var);
		V_0 = L_2;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0045:
			{// begin finally (depth: 1)
				Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0((&V_0), Enumerator_Dispose_m51D6CFCA39252B1F0FE8F6CCF5F1BDF98E19E4C0_RuntimeMethod_var);
				return;
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_003a_1;
			}

IL_0013_1:
			{
				// foreach (ClientCard spell in Bot.GetSpells())
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3;
				L_3 = Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_inline((&V_0), Enumerator_get_Current_m1CF3D1DE5E3A5ED12BB283421FB4D30EFA320F5C_RuntimeMethod_var);
				V_1 = L_3;
				// if (spell.IsCode(CardId.ZoodiacBarrage) && !Card.Equals(spell))
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_4 = V_1;
				NullCheck(L_4);
				bool L_5;
				L_5 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_4, ((int32_t)46060017), NULL);
				if (!L_5)
				{
					goto IL_003a_1;
				}
			}
			{
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_6;
				L_6 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
				ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_7 = V_1;
				NullCheck(L_6);
				bool L_8;
				L_8 = ClientCard_Equals_mD0D1DB381E502773C60748D1533EEC75A30886C6(L_6, L_7, NULL);
				if (L_8)
				{
					goto IL_003a_1;
				}
			}
			{
				// return false;
				V_2 = (bool)0;
				goto IL_0099;
			}

IL_003a_1:
			{
				// foreach (ClientCard spell in Bot.GetSpells())
				bool L_9;
				L_9 = Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76((&V_0), Enumerator_MoveNext_mFB217C26CADCEC3416944E61EF9FF8716BBD7A76_RuntimeMethod_var);
				if (L_9)
				{
					goto IL_0013_1;
				}
			}
			{
				goto IL_0053;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0053:
	{
		// AI.SelectCard(
		//     CardId.FireFormationTenki,
		//     CardId.MagicalMeltdown,
		//     CardId.ZoodiacBarrage
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_10;
		L_10 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_11 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_12 = L_11;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_13 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____66E5E7AB424DD096605E51332FF630ADED08E0DE27F408C52F23E62160961EB1_132_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_12, L_13, NULL);
		NullCheck(L_10);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_10, L_12, NULL);
		// AI.SelectNextCard(
		//     CardId.Ratpier,
		//     CardId.Whiptail,
		//     CardId.Thoroughblade
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_14;
		L_14 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_15 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_16 = L_15;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_17 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____790EE8F0BA838FA465B186AA0FE64428AC706DBDA505E657555C2E034B6847AA_158_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_16, L_17, NULL);
		NullCheck(L_14);
		GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502(L_14, L_16, NULL);
		// AI.SelectPosition(CardPosition.FaceUpDefence);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_18;
		L_18 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_18);
		GameAI_SelectPosition_m5BE05DB4F7D53CB956C9F5BF980EA32F42D3070D(L_18, 4, NULL);
		// return true;
		return (bool)1;
	}

IL_0099:
	{
		// }
		bool L_19 = V_2;
		return L_19;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::ZoodiacComboEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_ZoodiacComboEffect_mF31C9066BB24F5001AD5A6205826AC35B8B56A96 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C39E75F0FDE9B5E6330B103A1120EDA05C092A7C02409AE33215F94481761233_251_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (Duel.CurrentChain.Count > 0)
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_0;
		L_0 = Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline(__this, NULL);
		NullCheck(L_0);
		RuntimeObject* L_1;
		L_1 = Duel_get_CurrentChain_m66427071DD3F49ECD30F770C94D41CB769FA79BA_inline(L_0, NULL);
		NullCheck(L_1);
		int32_t L_2;
		L_2 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.Generic.ICollection`1<WindBot.Game.ClientCard>::get_Count() */, ICollection_1_tCBC53CFBB23BAE6096C48BC3EED2CCFF570A5AD1_il2cpp_TypeInfo_var, L_1);
		if ((((int32_t)L_2) <= ((int32_t)0)))
		{
			goto IL_0015;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0015:
	{
		// if (Card.Location != CardLocation.Grave)
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_3;
		L_3 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_3);
		int32_t L_4;
		L_4 = ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline(L_3, NULL);
		if ((((int32_t)L_4) == ((int32_t)((int32_t)16))))
		{
			goto IL_0050;
		}
	}
	{
		// AI.SelectCard(CardId.Drident);
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_5;
		L_5 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		NullCheck(L_5);
		GameAI_SelectCard_mB86684FBD9BEE246C95C9A45341883BFCB56D829(L_5, ((int32_t)48905153), NULL);
		// AI.SelectNextCard(
		//     CardId.Whiptail,
		//     CardId.Ratpier,
		//     CardId.Thoroughblade
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_6;
		L_6 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_7 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)3);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_8 = L_7;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_9 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____C39E75F0FDE9B5E6330B103A1120EDA05C092A7C02409AE33215F94481761233_251_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_8, L_9, NULL);
		NullCheck(L_6);
		GameAI_SelectNextCard_mE4D2D443D120DE045A2EA9EFF1DD886F739B7502(L_6, L_8, NULL);
	}

IL_0050:
	{
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::MonsterRebornEffect()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_MonsterRebornEffect_m2CAF7F71963167C4947B2776333EAB377CC68EEA (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5B4CF157C2F10921822CD7687881E5DC2824083C35BBF544252DC35C49B896AD_112_FieldInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// AI.SelectCard(
		//     CardId.Ratpier,
		//     CardId.Whiptail,
		//     CardId.InvokedMechaba,
		//     CardId.JizukirutheStarDestroyingKaiju,
		//     CardId.InvokedMagellanica,
		//     CardId.Tigermortar,
		//     CardId.Chakanine,
		//     CardId.Broadbull
		//     );
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0;
		L_0 = Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline(__this, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)8);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = L_1;
		RuntimeFieldHandle_t6E4C45B6D2EA12FC99185805A7E77527899B25C5 L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3E_t0F5473E849A5A5185A9F4C5246F0C32816C49FCA____5B4CF157C2F10921822CD7687881E5DC2824083C35BBF544252DC35C49B896AD_112_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m751372AA3F24FBF6DA9B9D687CBFA2DE436CAB9B((RuntimeArray*)L_2, L_3, NULL);
		NullCheck(L_0);
		GameAI_SelectCard_m01D71D1DC548FE6F471A5D89C2BA75426DE4EFF3(L_0, L_2, NULL);
		// return true;
		return (bool)1;
	}
}
// System.Boolean WindBot.Game.AI.Decks.ZoodiacExecutor::MonsterRepos()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ZoodiacExecutor_MonsterRepos_mB1E09B2A017BB01CA5C26FFB68B957BB2627B2B4 (ZoodiacExecutor_t6712D89E5ED15AB4B38AF32ED2C4CA6922CC16CA* __this, const RuntimeMethod* method) 
{
	{
		// if (Card.IsCode(CardId.NumberS39UtopiatheLightning) && Card.IsAttack())
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0;
		L_0 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_0);
		bool L_1;
		L_1 = ClientCard_IsCode_m15D2AC3B061F604EB576689DB70DA47576BDE033(L_0, ((int32_t)56832966), NULL);
		if (!L_1)
		{
			goto IL_0021;
		}
	}
	{
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_2;
		L_2 = Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline(__this, NULL);
		NullCheck(L_2);
		bool L_3;
		L_3 = ClientCard_IsAttack_m222452F0B994CD6410FFBB8643972BBC203E3913(L_2, NULL);
		if (!L_3)
		{
			goto IL_0021;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0021:
	{
		// return base.DefaultMonsterRepos();
		bool L_4;
		L_4 = DefaultExecutor_DefaultMonsterRepos_m99787A561C4CACBFD4D88353CA843B7598674C85(__this, NULL);
		return L_4;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void WindBot.Game.AI.Decks.ZoodiacExecutor/CardId::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CardId__ctor_m30E7F7BA9039C54C0CF3A4C2B69F06C61D180E38 (CardId_t493C1F60A0CFB6BE32EA7E39991862ACF80A4E3C* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.UInt32 <PrivateImplementationDetails>::ComputeStringHash(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t U3CPrivateImplementationDetailsU3E_ComputeStringHash_m6EA1F233618497AEFF8902A5EDFA24C74E2F2876 (String_t* ___0_s, const RuntimeMethod* method) 
{
	uint32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		String_t* L_0 = ___0_s;
		if (!L_0)
		{
			goto IL_002a;
		}
	}
	{
		V_0 = ((int32_t)-2128831035);
		V_1 = 0;
		goto IL_0021;
	}

IL_000d:
	{
		String_t* L_1 = ___0_s;
		int32_t L_2 = V_1;
		NullCheck(L_1);
		Il2CppChar L_3;
		L_3 = String_get_Chars_mC49DF0CD2D3BE7BE97B3AD9C995BE3094F8E36D3(L_1, L_2, NULL);
		uint32_t L_4 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_multiply(((int32_t)((int32_t)L_3^(int32_t)L_4)), ((int32_t)16777619)));
		int32_t L_5 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_5, 1));
	}

IL_0021:
	{
		int32_t L_6 = V_1;
		String_t* L_7 = ___0_s;
		NullCheck(L_7);
		int32_t L_8;
		L_8 = String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline(L_7, NULL);
		if ((((int32_t)L_6) < ((int32_t)L_8)))
		{
			goto IL_000d;
		}
	}

IL_002a:
	{
		uint32_t L_9 = V_0;
		return L_9;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Delegate_Invoke_m54D0E799B4210E0157DE6279F6458F9020DB0EA1_inline (Delegate_tDC5E4938E080A8D2B5EEED1B8B96919650C9E9FE* __this, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* ___0_card, const RuntimeMethod* method) 
{
	typedef bool (*FunctionPointerType) (RuntimeObject*, ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59*, const RuntimeMethod*);
	return ((FunctionPointerType)__this->___invoke_impl_1)((Il2CppObject*)__this->___method_code_6, ___0_card, reinterpret_cast<RuntimeMethod*>(__this->___method_3));
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Level_mE451E509A6BD53B026954CFBCDEECBEA9F4051E1_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int Level { get; private set; }
		int32_t L_0 = __this->___U3CLevelU3Ek__BackingField_8;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Id_m9AB0BFD2E5484D64FB4E1803B7F1EA4C61CA6356_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int Id { get; private set; }
		int32_t L_0 = __this->___U3CIdU3Ek__BackingField_0;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_LinkCount_m12CA020572EB98D3A1DB85EABC30D46FE0FCF10B_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int LinkCount { get; private set; }
		int32_t L_0 = __this->___U3CLinkCountU3Ek__BackingField_17;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Location_m0090BC8F6A14959865FD09A6E9B67959525F7FF2_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public CardLocation Location { get; set; }
		int32_t L_0 = __this->___U3CLocationU3Ek__BackingField_5;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Controller_m28007482B2684652C06802B480F9F598C231DAD0_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int Controller { get; set; }
		int32_t L_0 = __this->___U3CControllerU3Ek__BackingField_24;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* Executor_get_Bot_mDEEFD1B8B3815D626BE2F1396F773FA9EC68C358_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// protected ClientField Bot { get; private set; }
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0 = __this->___U3CBotU3Ek__BackingField_11;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_ExtraDeck_mAE2668EAF5688876EA70C0DD5CD1D9A8088AE11A_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) 
{
	{
		// public IList<ClientCard> ExtraDeck { get; private set; }
		RuntimeObject* L_0 = __this->___U3CExtraDeckU3Ek__BackingField_6;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Attribute_m2BF15C90C7580C500E07A65959685C82A2FC65BB_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int Attribute { get; private set; }
		int32_t L_0 = __this->___U3CAttributeU3Ek__BackingField_11;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_RealPower_m4832123BF47ECE4DE5ED8A240B6F0A6866B3B588_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int RealPower { get; set; }
		int32_t L_0 = __this->___U3CRealPowerU3Ek__BackingField_21;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ClientCard_get_Attack_m77751479CDA31D0D23600A59ADFADAA69F34364B_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, const RuntimeMethod* method) 
{
	{
		// public int Attack { get; private set; }
		int32_t L_0 = __this->___U3CAttackU3Ek__BackingField_13;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void ClientCard_set_RealPower_m089EFE795FE98EAD61FE447D5B9A3CD25C21FBA7_inline (ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		// public int RealPower { get; set; }
		int32_t L_0 = ___0_value;
		__this->___U3CRealPowerU3Ek__BackingField_21 = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* Executor_get_Util_m1A2D2C784705498FF2F0EAE76EA21D623DD648F7_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// public AIUtil Util { get; private set; }
		AIUtil_tCA507A6CF86289A7E846D7B07ABAF4DF8E6B56FF* L_0 = __this->___U3CUtilU3Ek__BackingField_4;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* Executor_get_Duel_m3B7443DF734C95E4A546DF7931FC95D220F56364_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// public Duel Duel { get; private set; }
		Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* L_0 = __this->___U3CDuelU3Ek__BackingField_1;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_Player_m9193784EAEA68B33A6DBD25C84746FF9B4F21B14_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) 
{
	{
		// public int Player { get; set; }
		int32_t L_0 = __this->___U3CPlayerU3Ek__BackingField_5;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_Phase_m8B13FE9AE1CE2F12CEFF43EBB4367ED0AD45D30C_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) 
{
	{
		// public DuelPhase Phase { get; set; }
		int32_t L_0 = __this->___U3CPhaseU3Ek__BackingField_6;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* Executor_get_Card_m3D289506AF22718AD88F4C24EBDCF5B378638E10_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// protected ClientCard Card { get; private set; }
		ClientCard_t462AD935733345E5759C18AF96C9DE579BB7BD59* L_0 = __this->___U3CCardU3Ek__BackingField_8;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Executor_get_ActivateDescription_m2855E33CA44A88A7F15FFFA522E084F6E791604C_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// protected int ActivateDescription { get; private set; }
		int32_t L_0 = __this->___U3CActivateDescriptionU3Ek__BackingField_9;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* Executor_get_AI_m2F72E3A88CC6899880C2A487752A1BA10968A5CF_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// public GameAI AI { get; private set; }
		GameAI_tF5CBEC871B0732F1CB3670F75FA91153A57F8963* L_0 = __this->___U3CAIU3Ek__BackingField_3;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_Hand_m0C0F60D3ABFE161B581F21915DD028C46F61488E_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) 
{
	{
		// public IList<ClientCard> Hand { get; private set; }
		RuntimeObject* L_0 = __this->___U3CHandU3Ek__BackingField_0;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* ClientField_get_Graveyard_m39E5CCDFF031F857355FA335EAEF962419B57A82_inline (ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* __this, const RuntimeMethod* method) 
{
	{
		// public IList<ClientCard> Graveyard { get; private set; }
		RuntimeObject* L_0 = __this->___U3CGraveyardU3Ek__BackingField_3;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* Executor_get_Enemy_mF9F9E24015075FB0C19396572F25879821E7660D_inline (Executor_tA1AE105409AFC510F47738CDBB86D74A0049A083* __this, const RuntimeMethod* method) 
{
	{
		// protected ClientField Enemy { get; private set; }
		ClientField_t10BA8643FA62F40E6AE8FA08202F4CE950D175C7* L_0 = __this->___U3CEnemyU3Ek__BackingField_12;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Duel_get_LastChainPlayer_mC5B0E0859A850414FF721351866F32E42D7CF25E_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) 
{
	{
		// public int LastChainPlayer { get; set; }
		int32_t L_0 = __this->___U3CLastChainPlayerU3Ek__BackingField_9;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* Duel_get_CurrentChain_m66427071DD3F49ECD30F770C94D41CB769FA79BA_inline (Duel_t93B0A80A0ACE7F74FC7390A76251757BFED2D73D* __this, const RuntimeMethod* method) 
{
	{
		// public IList<ClientCard> CurrentChain { get; set; }
		RuntimeObject* L_0 = __this->___U3CCurrentChainU3Ek__BackingField_11;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t String_get_Length_m42625D67623FA5CC7A44D47425CE86FB946542D2_inline (String_t* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->____stringLength_4;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* Array_Empty_TisRuntimeObject_mFB8A63D602BB6974D31E20300D9EB89C6FE7C278_gshared_inline (const RuntimeMethod* method) 
{
	{
		il2cpp_codegen_runtime_class_init_inline(il2cpp_rgctx_data(method->rgctx_data, 0));
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_0 = ((EmptyArray_1_tDF0DD7256B115243AA6BD5558417387A734240EE_StaticFields*)il2cpp_codegen_static_fields_for(il2cpp_rgctx_data(method->rgctx_data, 0)))->___Value_0;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RuntimeObject* Enumerator_get_Current_m6330F15D18EE4F547C05DF9BF83C5EB710376027_gshared_inline (Enumerator_t9473BAB568A27E2339D48C1F91319E0F6D244D7A* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->____current_3;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->____size_2;
		return L_0;
	}
}
