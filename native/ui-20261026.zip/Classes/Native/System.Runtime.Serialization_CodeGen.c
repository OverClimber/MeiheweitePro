﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 TArray[] System.Xml.ArrayHelper`2::ReadArray(System.Xml.XmlDictionaryReader,TArgument,TArgument,System.Int32)
// 0x00000002 System.Int32 System.Xml.ArrayHelper`2::ReadArray(System.Xml.XmlDictionaryReader,TArgument,TArgument,TArray[],System.Int32,System.Int32)
// 0x00000003 System.Void System.Xml.ArrayHelper`2::.ctor()
// 0x00000004 System.Int32 System.Xml.BooleanArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Boolean[],System.Int32,System.Int32)
extern void BooleanArrayHelperWithDictionaryString_ReadArray_m26AC51B1FD9B838F50C7FE3EDE044D95AE9B0DF2 (void);
// 0x00000005 System.Void System.Xml.BooleanArrayHelperWithDictionaryString::.ctor()
extern void BooleanArrayHelperWithDictionaryString__ctor_m33069EE3D60E3B0F39A3840C65EADF7532BF9C37 (void);
// 0x00000006 System.Void System.Xml.BooleanArrayHelperWithDictionaryString::.cctor()
extern void BooleanArrayHelperWithDictionaryString__cctor_mC3F239A037F7127862CADD32B7EFC9B02AD0ACAA (void);
// 0x00000007 System.Int32 System.Xml.Int32ArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32[],System.Int32,System.Int32)
extern void Int32ArrayHelperWithDictionaryString_ReadArray_mF61A206C6CDCF3ECB1425E069554E600434B9792 (void);
// 0x00000008 System.Void System.Xml.Int32ArrayHelperWithDictionaryString::.ctor()
extern void Int32ArrayHelperWithDictionaryString__ctor_mAE1001338D5F50D5CB1CEF55DEBBCBCD33015056 (void);
// 0x00000009 System.Void System.Xml.Int32ArrayHelperWithDictionaryString::.cctor()
extern void Int32ArrayHelperWithDictionaryString__cctor_mA223CEE851C08872B47FF9D5134741DDD8B2A766 (void);
// 0x0000000A System.Int32 System.Xml.Int64ArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int64[],System.Int32,System.Int32)
extern void Int64ArrayHelperWithDictionaryString_ReadArray_mD4E56F5CE2C7D05112EB36471A70D36C3A077DD5 (void);
// 0x0000000B System.Void System.Xml.Int64ArrayHelperWithDictionaryString::.ctor()
extern void Int64ArrayHelperWithDictionaryString__ctor_m3F1ADF49433BC0A9101DE81F044B8CA543BE0F15 (void);
// 0x0000000C System.Void System.Xml.Int64ArrayHelperWithDictionaryString::.cctor()
extern void Int64ArrayHelperWithDictionaryString__cctor_mC9A90B5AF35E64DCED886DA4BEF52FBA85415535 (void);
// 0x0000000D System.Int32 System.Xml.SingleArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Single[],System.Int32,System.Int32)
extern void SingleArrayHelperWithDictionaryString_ReadArray_mE2BDB6B4CD8ACB377C4E60FFFD681A8A506C6A6F (void);
// 0x0000000E System.Void System.Xml.SingleArrayHelperWithDictionaryString::.ctor()
extern void SingleArrayHelperWithDictionaryString__ctor_mB535940165C39976B93C1A15CD387BA43E430860 (void);
// 0x0000000F System.Void System.Xml.SingleArrayHelperWithDictionaryString::.cctor()
extern void SingleArrayHelperWithDictionaryString__cctor_m1DF8B1BBEC0E74EA73FF6FAFBE468A642B5926C9 (void);
// 0x00000010 System.Int32 System.Xml.DoubleArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Double[],System.Int32,System.Int32)
extern void DoubleArrayHelperWithDictionaryString_ReadArray_m4189BD9311A409C4EC2E0D7CC7969A7402B9C166 (void);
// 0x00000011 System.Void System.Xml.DoubleArrayHelperWithDictionaryString::.ctor()
extern void DoubleArrayHelperWithDictionaryString__ctor_m0F7582B2F9C5F1F56450F2D0B74B921695F47912 (void);
// 0x00000012 System.Void System.Xml.DoubleArrayHelperWithDictionaryString::.cctor()
extern void DoubleArrayHelperWithDictionaryString__cctor_m2B448A4F17C277EB892ECD6A8D9A510BD8E6991D (void);
// 0x00000013 System.Int32 System.Xml.DecimalArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Decimal[],System.Int32,System.Int32)
extern void DecimalArrayHelperWithDictionaryString_ReadArray_m33DF1C6CBA34B3DCB6E90BCC505E1B077EA81F78 (void);
// 0x00000014 System.Void System.Xml.DecimalArrayHelperWithDictionaryString::.ctor()
extern void DecimalArrayHelperWithDictionaryString__ctor_mD61892DE83B455C4539258D73CEFFEE2BAD18F61 (void);
// 0x00000015 System.Void System.Xml.DecimalArrayHelperWithDictionaryString::.cctor()
extern void DecimalArrayHelperWithDictionaryString__cctor_m14A5E9949B0429826C0F2C3991AFC5562ED792B2 (void);
// 0x00000016 System.Int32 System.Xml.DateTimeArrayHelperWithDictionaryString::ReadArray(System.Xml.XmlDictionaryReader,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.DateTime[],System.Int32,System.Int32)
extern void DateTimeArrayHelperWithDictionaryString_ReadArray_mB27C8338F8F4E32B5B227699FAC0AC000E5C509D (void);
// 0x00000017 System.Void System.Xml.DateTimeArrayHelperWithDictionaryString::.ctor()
extern void DateTimeArrayHelperWithDictionaryString__ctor_m03F6B0C1D7EF35CEAD694AAB2BE363B4D3270E0E (void);
// 0x00000018 System.Void System.Xml.DateTimeArrayHelperWithDictionaryString::.cctor()
extern void DateTimeArrayHelperWithDictionaryString__cctor_m82273079E650CDB72DBFD2203860C6CB8FD8DBD1 (void);
// 0x00000019 System.Void System.Xml.EncodingStreamWrapper::.ctor(System.IO.Stream,System.Text.Encoding)
extern void EncodingStreamWrapper__ctor_m69BFB0B372D850771D5642F2B28670276F44C7EA (void);
// 0x0000001A System.Void System.Xml.EncodingStreamWrapper::SetReadDocumentEncoding(System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_SetReadDocumentEncoding_m584A704F25FCEE64E7413C5DB98FF4901139DC6D (void);
// 0x0000001B System.Text.Encoding System.Xml.EncodingStreamWrapper::GetEncoding(System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_GetEncoding_m7BC513B52DBAC0D5251E3F0EF8F2FD03C0806C90 (void);
// 0x0000001C System.String System.Xml.EncodingStreamWrapper::GetEncodingName(System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_GetEncodingName_mAA6E4CDD6CC05492407BC82D10E824D079CC6162 (void);
// 0x0000001D System.Xml.EncodingStreamWrapper/SupportedEncoding System.Xml.EncodingStreamWrapper::GetSupportedEncoding(System.Text.Encoding)
extern void EncodingStreamWrapper_GetSupportedEncoding_mF62637209A7257DA3EBC1C3DF8E199E992C19425 (void);
// 0x0000001E System.Xml.EncodingStreamWrapper/SupportedEncoding System.Xml.EncodingStreamWrapper::ReadBOMEncoding(System.Boolean)
extern void EncodingStreamWrapper_ReadBOMEncoding_mD2CEB2E6763AB4F9B0D9E9CADB5160C6A25A7A50 (void);
// 0x0000001F System.Xml.EncodingStreamWrapper/SupportedEncoding System.Xml.EncodingStreamWrapper::ReadBOMEncoding(System.Byte,System.Byte,System.Byte,System.Byte,System.Boolean,System.Int32&)
extern void EncodingStreamWrapper_ReadBOMEncoding_m49410D4763F2083048302533D40EE416ADF4BEFA (void);
// 0x00000020 System.Void System.Xml.EncodingStreamWrapper::FillBuffer(System.Int32)
extern void EncodingStreamWrapper_FillBuffer_mB7AC1008BB751163CBF0B3C2E34A084FC65B9126 (void);
// 0x00000021 System.Void System.Xml.EncodingStreamWrapper::EnsureBuffers()
extern void EncodingStreamWrapper_EnsureBuffers_mDCB1AC2EE463756726EBDEF05C8CD1543528F629 (void);
// 0x00000022 System.Void System.Xml.EncodingStreamWrapper::EnsureByteBuffer()
extern void EncodingStreamWrapper_EnsureByteBuffer_mE8D64EBA62A1301DDF61FE35D138F2D24C6A4264 (void);
// 0x00000023 System.Void System.Xml.EncodingStreamWrapper::CheckUTF8DeclarationEncoding(System.Byte[],System.Int32,System.Int32,System.Xml.EncodingStreamWrapper/SupportedEncoding,System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_CheckUTF8DeclarationEncoding_mC46BCA9EC98AE81CC45A0E6FE50ED6B6BF29250E (void);
// 0x00000024 System.Boolean System.Xml.EncodingStreamWrapper::CompareCaseInsensitive(System.Byte[],System.Byte[],System.Int32)
extern void EncodingStreamWrapper_CompareCaseInsensitive_mC994883B7ACBB0328A525881837D35DE52BE064E (void);
// 0x00000025 System.Boolean System.Xml.EncodingStreamWrapper::Compare(System.Byte[],System.Byte[],System.Int32)
extern void EncodingStreamWrapper_Compare_mA0FDF745579F2443672C452C5AAA05C16628F489 (void);
// 0x00000026 System.Boolean System.Xml.EncodingStreamWrapper::IsWhitespace(System.Byte)
extern void EncodingStreamWrapper_IsWhitespace_mBFCC377AA35A50995FFC1BDDC79E6DB8C2A5E74C (void);
// 0x00000027 System.Void System.Xml.EncodingStreamWrapper::ThrowExpectedEncodingMismatch(System.Xml.EncodingStreamWrapper/SupportedEncoding,System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_ThrowExpectedEncodingMismatch_mF09F05586AED86130B7C6DE4C056B81131491CB2 (void);
// 0x00000028 System.Void System.Xml.EncodingStreamWrapper::ThrowEncodingMismatch(System.String,System.Xml.EncodingStreamWrapper/SupportedEncoding)
extern void EncodingStreamWrapper_ThrowEncodingMismatch_mD660972193FFE64D98233709D2643DF5B9E5D0A7 (void);
// 0x00000029 System.Void System.Xml.EncodingStreamWrapper::ThrowEncodingMismatch(System.String,System.String)
extern void EncodingStreamWrapper_ThrowEncodingMismatch_m5115FCE5BEBCF008B8EBF2ABACE296A5D8E227D8 (void);
// 0x0000002A System.Boolean System.Xml.EncodingStreamWrapper::get_CanRead()
extern void EncodingStreamWrapper_get_CanRead_m40E1D3B9AB5087FBD675D555A61264797E22A4BA (void);
// 0x0000002B System.Boolean System.Xml.EncodingStreamWrapper::get_CanSeek()
extern void EncodingStreamWrapper_get_CanSeek_mDA06B11F044C0C68BF56A456DA9E73D5F9E6E6CB (void);
// 0x0000002C System.Boolean System.Xml.EncodingStreamWrapper::get_CanWrite()
extern void EncodingStreamWrapper_get_CanWrite_mEB548CE93185ACB6501CA22042700AE3736D6507 (void);
// 0x0000002D System.Int64 System.Xml.EncodingStreamWrapper::get_Position()
extern void EncodingStreamWrapper_get_Position_mD1CBF1DFDEE1A100C0004751A26B1119A720F8C9 (void);
// 0x0000002E System.Void System.Xml.EncodingStreamWrapper::set_Position(System.Int64)
extern void EncodingStreamWrapper_set_Position_m2B4CCEA543C4DE9AE47A8BFC496FB2D149397B62 (void);
// 0x0000002F System.Void System.Xml.EncodingStreamWrapper::Close()
extern void EncodingStreamWrapper_Close_m464DCFE28B8279C3E115EB7EB2B164709445AAC3 (void);
// 0x00000030 System.Void System.Xml.EncodingStreamWrapper::Flush()
extern void EncodingStreamWrapper_Flush_m4776C25FD540A67A6C928FA3A0477E002942A7DA (void);
// 0x00000031 System.Int32 System.Xml.EncodingStreamWrapper::ReadByte()
extern void EncodingStreamWrapper_ReadByte_m974CFBB46709773F176671A73F87E19F0761290F (void);
// 0x00000032 System.Int32 System.Xml.EncodingStreamWrapper::Read(System.Byte[],System.Int32,System.Int32)
extern void EncodingStreamWrapper_Read_m5CF8D5557299EB4BD6438C43E8545F30A0E94CA4 (void);
// 0x00000033 System.Void System.Xml.EncodingStreamWrapper::CleanupCharBreak()
extern void EncodingStreamWrapper_CleanupCharBreak_mF892CB119A1126D94C6826FA1C516FF34B627C47 (void);
// 0x00000034 System.Int64 System.Xml.EncodingStreamWrapper::Seek(System.Int64,System.IO.SeekOrigin)
extern void EncodingStreamWrapper_Seek_mD28CA138AEF63E0DB37174402286A20DB78EE6FF (void);
// 0x00000035 System.Void System.Xml.EncodingStreamWrapper::WriteByte(System.Byte)
extern void EncodingStreamWrapper_WriteByte_m7E594627D586CED07AFE02926DA5BC876107D976 (void);
// 0x00000036 System.Void System.Xml.EncodingStreamWrapper::Write(System.Byte[],System.Int32,System.Int32)
extern void EncodingStreamWrapper_Write_mC83D9CB91021E68A8F6FB1C8BCA33E67EF26DE71 (void);
// 0x00000037 System.Boolean System.Xml.EncodingStreamWrapper::get_CanTimeout()
extern void EncodingStreamWrapper_get_CanTimeout_m11A9C4F9365452949C39F4FD65D355EED2E6EC68 (void);
// 0x00000038 System.Int64 System.Xml.EncodingStreamWrapper::get_Length()
extern void EncodingStreamWrapper_get_Length_m1F220847DE8CA657BC776F11D929B7132E8B4112 (void);
// 0x00000039 System.Int32 System.Xml.EncodingStreamWrapper::get_ReadTimeout()
extern void EncodingStreamWrapper_get_ReadTimeout_m54947FEFBD6C5BD7846323CCF702F5963452BF79 (void);
// 0x0000003A System.Void System.Xml.EncodingStreamWrapper::set_ReadTimeout(System.Int32)
extern void EncodingStreamWrapper_set_ReadTimeout_m072660233E58B62B7ECD20E5CC753CE25A124941 (void);
// 0x0000003B System.Int32 System.Xml.EncodingStreamWrapper::get_WriteTimeout()
extern void EncodingStreamWrapper_get_WriteTimeout_m4BE2AE6CFD4A572AF056C9A0F5182C6F72839223 (void);
// 0x0000003C System.Void System.Xml.EncodingStreamWrapper::set_WriteTimeout(System.Int32)
extern void EncodingStreamWrapper_set_WriteTimeout_m06472100B6546F3464FC269C7D35DF260D50CAAB (void);
// 0x0000003D System.Void System.Xml.EncodingStreamWrapper::SetLength(System.Int64)
extern void EncodingStreamWrapper_SetLength_mE1E7F37C79E8E469BB7B5ED0F1C531E76B807066 (void);
// 0x0000003E System.Void System.Xml.EncodingStreamWrapper::.cctor()
extern void EncodingStreamWrapper__cctor_m4CF63091FD89AE7C24C8AC74943C09804EC00256 (void);
// 0x0000003F System.Boolean System.Xml.IXmlDictionary::TryLookup(System.Int32,System.Xml.XmlDictionaryString&)
// 0x00000040 System.Void System.Xml.PrefixHandle::.ctor(System.Xml.XmlBufferReader)
extern void PrefixHandle__ctor_m9F17653A857DB8100700BD09E1D14742841A6510 (void);
// 0x00000041 System.Void System.Xml.PrefixHandle::SetValue(System.Xml.PrefixHandleType)
extern void PrefixHandle_SetValue_m405028A9E53FB2D4E87FDB759D32C4D47C279490 (void);
// 0x00000042 System.Void System.Xml.PrefixHandle::SetValue(System.Xml.PrefixHandle)
extern void PrefixHandle_SetValue_m1D14B2BC5B6FCA2C077D324F363FEB8B67E3C60D (void);
// 0x00000043 System.Void System.Xml.PrefixHandle::SetValue(System.Int32,System.Int32)
extern void PrefixHandle_SetValue_m110EC52337EBF807F854EB6B81C12075D53B47A8 (void);
// 0x00000044 System.Boolean System.Xml.PrefixHandle::get_IsEmpty()
extern void PrefixHandle_get_IsEmpty_mB031BAFB2F3FB8A8673A0EC0263CAB99D8EBF2E7 (void);
// 0x00000045 System.Boolean System.Xml.PrefixHandle::get_IsXmlns()
extern void PrefixHandle_get_IsXmlns_mFB8174A14A11FCA061185B57E5DC3599F5A932B1 (void);
// 0x00000046 System.Boolean System.Xml.PrefixHandle::get_IsXml()
extern void PrefixHandle_get_IsXml_mF9676C9F083B30F19C81E7369B0D59622FA3B32A (void);
// 0x00000047 System.Boolean System.Xml.PrefixHandle::TryGetShortPrefix(System.Xml.PrefixHandleType&)
extern void PrefixHandle_TryGetShortPrefix_m1FDF4904A709EC4048F49C77044D5BFE2901B96A (void);
// 0x00000048 System.String System.Xml.PrefixHandle::GetString(System.Xml.PrefixHandleType)
extern void PrefixHandle_GetString_m707C5C3842631CAAB16BF2E545F24350504CE51A (void);
// 0x00000049 System.Xml.PrefixHandleType System.Xml.PrefixHandle::GetAlphaPrefix(System.Int32)
extern void PrefixHandle_GetAlphaPrefix_mD5B580DAE3F131AD3D6B4DF0048E37153D33B81A (void);
// 0x0000004A System.Byte[] System.Xml.PrefixHandle::GetString(System.Xml.PrefixHandleType,System.Int32&,System.Int32&)
extern void PrefixHandle_GetString_mDCD7482FF0176CE85F0E0193E0E708994374E25B (void);
// 0x0000004B System.String System.Xml.PrefixHandle::GetString(System.Xml.XmlNameTable)
extern void PrefixHandle_GetString_m6FF9590CE327ADA02D0F0673705054C66E11A5FB (void);
// 0x0000004C System.String System.Xml.PrefixHandle::GetString()
extern void PrefixHandle_GetString_m9072D56B8E44C5A4DE2AA156DA75472B9325FC92 (void);
// 0x0000004D System.Byte[] System.Xml.PrefixHandle::GetString(System.Int32&,System.Int32&)
extern void PrefixHandle_GetString_m00079CF15D414936E8CE6867F3E6FCEA92AD6D77 (void);
// 0x0000004E System.Int32 System.Xml.PrefixHandle::CompareTo(System.Xml.PrefixHandle)
extern void PrefixHandle_CompareTo_m09521F2E60A338DB056FA4C5F9A7D6B84E4EB7A8 (void);
// 0x0000004F System.Boolean System.Xml.PrefixHandle::Equals2(System.Xml.PrefixHandle)
extern void PrefixHandle_Equals2_m764A7F64212802BA9A8A5BDEB81428B38872E37A (void);
// 0x00000050 System.Boolean System.Xml.PrefixHandle::Equals2(System.String)
extern void PrefixHandle_Equals2_m0E5E81FE14C81F41C441DEB4F6A2D80E23042994 (void);
// 0x00000051 System.Boolean System.Xml.PrefixHandle::Equals2(System.Xml.XmlDictionaryString)
extern void PrefixHandle_Equals2_mE5C13AD9FFDC44FEA1349FD4162EC8B67BD26C31 (void);
// 0x00000052 System.Boolean System.Xml.PrefixHandle::op_Equality(System.Xml.PrefixHandle,System.String)
extern void PrefixHandle_op_Equality_mD2969E7287DD678C229CD21D0A552E4478C1EEF9 (void);
// 0x00000053 System.Boolean System.Xml.PrefixHandle::op_Equality(System.Xml.PrefixHandle,System.Xml.XmlDictionaryString)
extern void PrefixHandle_op_Equality_mDEE5F0BB72FB13C346665386B832DFCA1C5804E8 (void);
// 0x00000054 System.Boolean System.Xml.PrefixHandle::op_Equality(System.Xml.PrefixHandle,System.Xml.PrefixHandle)
extern void PrefixHandle_op_Equality_mAA77AEC7710772FDCE7DAE8E96FC9146EE4AE9E0 (void);
// 0x00000055 System.Boolean System.Xml.PrefixHandle::Equals(System.Object)
extern void PrefixHandle_Equals_mB931D5BD29A96E827BEF5B9323526DC4CDA0DD0A (void);
// 0x00000056 System.String System.Xml.PrefixHandle::ToString()
extern void PrefixHandle_ToString_m4689D517FBF2DB68A41D1A9F25CC1EB442D6CED9 (void);
// 0x00000057 System.Int32 System.Xml.PrefixHandle::GetHashCode()
extern void PrefixHandle_GetHashCode_mA2D611E7F9C20302C157399FC8137D714A157C79 (void);
// 0x00000058 System.Void System.Xml.PrefixHandle::.cctor()
extern void PrefixHandle__cctor_m8DA6CAC4640BC958A5DC844F3070737C7E963FE8 (void);
// 0x00000059 System.Void System.Xml.StringHandle::.ctor(System.Xml.XmlBufferReader)
extern void StringHandle__ctor_mDE97B7A6217B44FD2573205B644CE9A24E420A84 (void);
// 0x0000005A System.Void System.Xml.StringHandle::SetValue(System.Int32,System.Int32)
extern void StringHandle_SetValue_mCBA3A46D8DDA5A6CC121DA66D7BD75EA98B316E8 (void);
// 0x0000005B System.Void System.Xml.StringHandle::SetConstantValue(System.Xml.StringHandleConstStringType)
extern void StringHandle_SetConstantValue_m454D7BA581FAFAFD3114898D60849D42371DFA85 (void);
// 0x0000005C System.Void System.Xml.StringHandle::SetValue(System.Int32,System.Int32,System.Boolean)
extern void StringHandle_SetValue_m802803727082C68C0C40A8505F699A59238F918B (void);
// 0x0000005D System.Void System.Xml.StringHandle::SetValue(System.Xml.StringHandle)
extern void StringHandle_SetValue_mB6E4F034BC09A533CAFFF1C14CB54AA46E953778 (void);
// 0x0000005E System.Boolean System.Xml.StringHandle::get_IsEmpty()
extern void StringHandle_get_IsEmpty_m553233D784A7125C73260D258182B89709B9EDC9 (void);
// 0x0000005F System.Boolean System.Xml.StringHandle::get_IsXmlns()
extern void StringHandle_get_IsXmlns_m660949D26AC182877F06D3935C4E9B038481BC5D (void);
// 0x00000060 System.Void System.Xml.StringHandle::ToPrefixHandle(System.Xml.PrefixHandle)
extern void StringHandle_ToPrefixHandle_mBCBAA2E52225D1E4A438485F16A6546B4731DD0F (void);
// 0x00000061 System.String System.Xml.StringHandle::GetString(System.Xml.XmlNameTable)
extern void StringHandle_GetString_m95A2ABA786D3D3EF229B8CB61AA3D0E4EA640299 (void);
// 0x00000062 System.String System.Xml.StringHandle::GetString()
extern void StringHandle_GetString_m4CBF4A1BF6DFA1FA15205E33F7A6FB0CE6D75C34 (void);
// 0x00000063 System.Byte[] System.Xml.StringHandle::GetString(System.Int32&,System.Int32&)
extern void StringHandle_GetString_mFF4D54EBB24E91B7DC236ABA49FC3B4853F5B940 (void);
// 0x00000064 System.String System.Xml.StringHandle::ToString()
extern void StringHandle_ToString_mE850A963374D8C2135AEC5A36C9E47032146727C (void);
// 0x00000065 System.Boolean System.Xml.StringHandle::Equals2(System.Int32,System.Xml.XmlBufferReader)
extern void StringHandle_Equals2_m765636B91010EE6D914EE11E32EE77195DA73FF4 (void);
// 0x00000066 System.Boolean System.Xml.StringHandle::Equals2(System.Xml.XmlDictionaryString)
extern void StringHandle_Equals2_m07763F818662CDB54F2EFD5E82D2A468A08A63AF (void);
// 0x00000067 System.Boolean System.Xml.StringHandle::Equals2(System.String)
extern void StringHandle_Equals2_m8B4A5B0C5DB0DC0DBE983A56A48DCF1BE37A880F (void);
// 0x00000068 System.Boolean System.Xml.StringHandle::Equals2(System.Int32,System.Int32,System.Xml.XmlBufferReader)
extern void StringHandle_Equals2_m5600E177912550762308D4ED3811866E132624DD (void);
// 0x00000069 System.Boolean System.Xml.StringHandle::Equals2(System.Xml.StringHandle)
extern void StringHandle_Equals2_mCDE5597F6C90C1E7224EFA410867379812617EE5 (void);
// 0x0000006A System.Boolean System.Xml.StringHandle::op_Equality(System.Xml.StringHandle,System.Xml.XmlDictionaryString)
extern void StringHandle_op_Equality_m61E3C94F5701D2E2C2A6F68FE34A8240ED8674EC (void);
// 0x0000006B System.Boolean System.Xml.StringHandle::op_Equality(System.Xml.StringHandle,System.String)
extern void StringHandle_op_Equality_m2024941945F1E2162BF419554F313A63C57748AF (void);
// 0x0000006C System.Boolean System.Xml.StringHandle::op_Inequality(System.Xml.StringHandle,System.String)
extern void StringHandle_op_Inequality_mDF90628E59F219816ED9DA5B6FA7768466EF0447 (void);
// 0x0000006D System.Boolean System.Xml.StringHandle::op_Equality(System.Xml.StringHandle,System.Xml.StringHandle)
extern void StringHandle_op_Equality_m0D56AFB3EE5BD92D1A91AC4F7B7797B97A40F583 (void);
// 0x0000006E System.Int32 System.Xml.StringHandle::CompareTo(System.Xml.StringHandle)
extern void StringHandle_CompareTo_mC04397EF0821B364B15C47E12B35B8BFDAC86A17 (void);
// 0x0000006F System.Boolean System.Xml.StringHandle::Equals(System.Object)
extern void StringHandle_Equals_mE6EBF84A3DF8E9FC34EF142F45EE10AC7539AE2B (void);
// 0x00000070 System.Int32 System.Xml.StringHandle::GetHashCode()
extern void StringHandle_GetHashCode_mF20795DE3342C0565F05B99D99F7AD9D19F8A5A2 (void);
// 0x00000071 System.Void System.Xml.StringHandle::.cctor()
extern void StringHandle__cctor_mB834487733CA9285BF7E2748623971236FE03464 (void);
// 0x00000072 System.Void System.Xml.UniqueId::.ctor(System.Byte[],System.Int32)
extern void UniqueId__ctor_m886CA3FD85A18088143B2940819D540A06782622 (void);
// 0x00000073 System.Void System.Xml.UniqueId::.ctor(System.String)
extern void UniqueId__ctor_mBF4FAD5CA8AEB23CE686C1879F2A3B2FB9ACE600 (void);
// 0x00000074 System.Int32 System.Xml.UniqueId::get_CharArrayLength()
extern void UniqueId_get_CharArrayLength_m1E206BF698096EB61058DC4895105A3A20A16187 (void);
// 0x00000075 System.Int32 System.Xml.UniqueId::UnsafeDecode(System.Int16*,System.Char,System.Char)
extern void UniqueId_UnsafeDecode_mF61CB8D67C0EC3A2A4B4A5F2C53EF6B326CD6631 (void);
// 0x00000076 System.Void System.Xml.UniqueId::UnsafeEncode(System.Char*,System.Byte,System.Char*)
extern void UniqueId_UnsafeEncode_m3520B6A366F594FC46EF67EF2FC8EB815A82F6CD (void);
// 0x00000077 System.Boolean System.Xml.UniqueId::get_IsGuid()
extern void UniqueId_get_IsGuid_m0FDA658ACB8FBEF9530D588474FBD429AF93A55A (void);
// 0x00000078 System.Void System.Xml.UniqueId::UnsafeParse(System.Char*,System.Int32)
extern void UniqueId_UnsafeParse_m055742AD013BB3BE4046942227BC716EE1085B15 (void);
// 0x00000079 System.Int32 System.Xml.UniqueId::ToCharArray(System.Char[],System.Int32)
extern void UniqueId_ToCharArray_mC8665EBAE036B8519D4C55C80AB50415ADF3FE38 (void);
// 0x0000007A System.String System.Xml.UniqueId::ToString()
extern void UniqueId_ToString_mD2ACE4CCB2F55A872D39EA847EC73CBCC0A77274 (void);
// 0x0000007B System.Boolean System.Xml.UniqueId::op_Equality(System.Xml.UniqueId,System.Xml.UniqueId)
extern void UniqueId_op_Equality_m25F4CBB4DB5FE72A49E727116FF8C95C0425890C (void);
// 0x0000007C System.Boolean System.Xml.UniqueId::Equals(System.Object)
extern void UniqueId_Equals_m5B6FA8978449B0996D25075C113612346C8039EC (void);
// 0x0000007D System.Int32 System.Xml.UniqueId::GetHashCode()
extern void UniqueId_GetHashCode_m84E07067446D9C50DD3312C26C2E70A9DC86D232 (void);
// 0x0000007E System.Int64 System.Xml.UniqueId::UnsafeGetInt64(System.Byte*)
extern void UniqueId_UnsafeGetInt64_m2DFBDF726D2BB2505B004185EA3A016327591452 (void);
// 0x0000007F System.Int32 System.Xml.UniqueId::UnsafeGetInt32(System.Byte*)
extern void UniqueId_UnsafeGetInt32_m2E7232530828E965560ED26C62D9CB015C8E1CD5 (void);
// 0x00000080 System.Void System.Xml.UniqueId::UnsafeSetInt64(System.Int64,System.Byte*)
extern void UniqueId_UnsafeSetInt64_mAF2E1188C17D8617AC738CCB8A1D0D1F32DFC232 (void);
// 0x00000081 System.Void System.Xml.UniqueId::UnsafeSetInt32(System.Int32,System.Byte*)
extern void UniqueId_UnsafeSetInt32_m41EBF7129D9345B868912116D840704318B4B5D6 (void);
// 0x00000082 System.Void System.Xml.UniqueId::.cctor()
extern void UniqueId__cctor_mF512E2CFAD256FF2D0E31A54BF2845DB17B9391E (void);
// 0x00000083 System.Void System.Xml.ValueHandle::.ctor(System.Xml.XmlBufferReader)
extern void ValueHandle__ctor_mAD8231FAFF5D4DC76A9E0EC09DCB7F23A2AB8159 (void);
// 0x00000084 System.Text.Base64Encoding System.Xml.ValueHandle::get_Base64Encoding()
extern void ValueHandle_get_Base64Encoding_m372C49738E26305D63B7C04751FB70F1880E4C3D (void);
// 0x00000085 System.Void System.Xml.ValueHandle::SetConstantValue(System.Xml.ValueHandleConstStringType)
extern void ValueHandle_SetConstantValue_m96F1A888C46454EFA762FFD1681AD4B6DE828CF8 (void);
// 0x00000086 System.Void System.Xml.ValueHandle::SetValue(System.Xml.ValueHandleType)
extern void ValueHandle_SetValue_m356A8BDA96D10DABBDEF5D5DB0893CF0DE34FF60 (void);
// 0x00000087 System.Void System.Xml.ValueHandle::SetDictionaryValue(System.Int32)
extern void ValueHandle_SetDictionaryValue_mACAD6AB51EC46D49571993C792CA009BD6C526F6 (void);
// 0x00000088 System.Void System.Xml.ValueHandle::SetCharValue(System.Int32)
extern void ValueHandle_SetCharValue_mAA94C0908502C2471C6AE69E99B9DA59ADEB2998 (void);
// 0x00000089 System.Void System.Xml.ValueHandle::SetQNameValue(System.Int32,System.Int32)
extern void ValueHandle_SetQNameValue_mF29FAF7C971F8712F050DCAC764C9291F5BEA123 (void);
// 0x0000008A System.Void System.Xml.ValueHandle::SetValue(System.Xml.ValueHandleType,System.Int32,System.Int32)
extern void ValueHandle_SetValue_mF2B1AE8F642E915422D2720AE9FE803199B490DC (void);
// 0x0000008B System.Boolean System.Xml.ValueHandle::IsWhitespace()
extern void ValueHandle_IsWhitespace_m2A76785471E48705B3E222E55D50054C34BBA4F3 (void);
// 0x0000008C System.Type System.Xml.ValueHandle::ToType()
extern void ValueHandle_ToType_m1A4E656088980A95D6EC720A786F1656669206FF (void);
// 0x0000008D System.Boolean System.Xml.ValueHandle::ToBoolean()
extern void ValueHandle_ToBoolean_mA990A6A9C114D768D603CEECA71A45DE6079213B (void);
// 0x0000008E System.Int32 System.Xml.ValueHandle::ToInt()
extern void ValueHandle_ToInt_m704A8FC5077954C0AAF362F02F2E48CECDCE0494 (void);
// 0x0000008F System.Int64 System.Xml.ValueHandle::ToLong()
extern void ValueHandle_ToLong_mBD2363E63BC67188A6C834A52C1F31480970B3CE (void);
// 0x00000090 System.UInt64 System.Xml.ValueHandle::ToULong()
extern void ValueHandle_ToULong_mD71E568F1CD897B8ED8A10E277B6BB35A2EF6E1F (void);
// 0x00000091 System.Single System.Xml.ValueHandle::ToSingle()
extern void ValueHandle_ToSingle_mC22BA59930D584C633D8D5D82D3657CCBFEAE08F (void);
// 0x00000092 System.Double System.Xml.ValueHandle::ToDouble()
extern void ValueHandle_ToDouble_mB259752241D5F61CC399A1C81B1539EFA1DA70CB (void);
// 0x00000093 System.Decimal System.Xml.ValueHandle::ToDecimal()
extern void ValueHandle_ToDecimal_m10C964F454FC9FF4EB27B7976A0A4FB7030259A9 (void);
// 0x00000094 System.DateTime System.Xml.ValueHandle::ToDateTime()
extern void ValueHandle_ToDateTime_m2A48FC176F0B4E8608929456BFE54A30768FBFB0 (void);
// 0x00000095 System.Xml.UniqueId System.Xml.ValueHandle::ToUniqueId()
extern void ValueHandle_ToUniqueId_m3E004FDEE456D420718B07A659950524B88A8CD1 (void);
// 0x00000096 System.TimeSpan System.Xml.ValueHandle::ToTimeSpan()
extern void ValueHandle_ToTimeSpan_mF991840664966EDA7D570EF9F8232CF711B5773D (void);
// 0x00000097 System.Guid System.Xml.ValueHandle::ToGuid()
extern void ValueHandle_ToGuid_mC32890FEF8418AB07925EF0F945261D69BC590FD (void);
// 0x00000098 System.String System.Xml.ValueHandle::ToString()
extern void ValueHandle_ToString_m0F4CC35B1A7A9FCDF4AC91153556C97C1EF8FE04 (void);
// 0x00000099 System.Byte[] System.Xml.ValueHandle::ToByteArray()
extern void ValueHandle_ToByteArray_mA469EC9E08C564CAF908E7B5AD6AE0958FD970BB (void);
// 0x0000009A System.String System.Xml.ValueHandle::GetString()
extern void ValueHandle_GetString_mF7091CAFD37C487CCDD77780F4FE18703262CA4F (void);
// 0x0000009B System.Boolean System.Xml.ValueHandle::Equals2(System.String,System.Boolean)
extern void ValueHandle_Equals2_m36B1CBEF9063168019AB827055BF8CB726546443 (void);
// 0x0000009C System.Void System.Xml.ValueHandle::Sign(System.Xml.XmlSigningNodeWriter)
extern void ValueHandle_Sign_m4CF0265044FBCF863B4C3FEE0F81EE35B4512598 (void);
// 0x0000009D System.Object[] System.Xml.ValueHandle::ToList()
extern void ValueHandle_ToList_m515BF8A7C1937168F1FAFC06EB47C48E879B50D5 (void);
// 0x0000009E System.Object System.Xml.ValueHandle::ToObject()
extern void ValueHandle_ToObject_m2B291F7278E104EF72AF84052159C0C0496EC43C (void);
// 0x0000009F System.Boolean System.Xml.ValueHandle::TryReadBase64(System.Byte[],System.Int32,System.Int32,System.Int32&)
extern void ValueHandle_TryReadBase64_m521B0B213C6571C1653476F3F21D3106D2818575 (void);
// 0x000000A0 System.Boolean System.Xml.ValueHandle::TryReadChars(System.Char[],System.Int32,System.Int32,System.Int32&)
extern void ValueHandle_TryReadChars_m2ADD2B702FBB2D914B6D12621BC2CC6CF721DBDE (void);
// 0x000000A1 System.Boolean System.Xml.ValueHandle::TryReadUnicodeChars(System.Char[],System.Int32,System.Int32,System.Int32&)
extern void ValueHandle_TryReadUnicodeChars_mAF5C09321FD757DB0D06112A90F635037ED2F9F0 (void);
// 0x000000A2 System.Boolean System.Xml.ValueHandle::TryGetByteArrayLength(System.Int32&)
extern void ValueHandle_TryGetByteArrayLength_mB3D0ACDC3CC15D78E77C80DCF7AAB8924A25330B (void);
// 0x000000A3 System.String System.Xml.ValueHandle::GetCharsText()
extern void ValueHandle_GetCharsText_m1A986DB4003EC211AAA7317559FBC9526CFBA623 (void);
// 0x000000A4 System.String System.Xml.ValueHandle::GetUnicodeCharsText()
extern void ValueHandle_GetUnicodeCharsText_mA9EAD91EC02802BC6B4A0E252ED877C751242FE7 (void);
// 0x000000A5 System.String System.Xml.ValueHandle::GetEscapedCharsText()
extern void ValueHandle_GetEscapedCharsText_m788CAB2DE923930DB4DAC222A4ACE79121884E79 (void);
// 0x000000A6 System.String System.Xml.ValueHandle::GetCharText()
extern void ValueHandle_GetCharText_m45341A1276C01BCBDA3EA984CB34FF25FF78BD61 (void);
// 0x000000A7 System.Int32 System.Xml.ValueHandle::GetChar()
extern void ValueHandle_GetChar_m0C9FB6819351D919AF6BB7569EE30FFFE01DC066 (void);
// 0x000000A8 System.Int32 System.Xml.ValueHandle::GetInt8()
extern void ValueHandle_GetInt8_mF08095855C8E7C52039787026E76D82319D05F1B (void);
// 0x000000A9 System.Int32 System.Xml.ValueHandle::GetInt16()
extern void ValueHandle_GetInt16_m7062162DB994E19F82B4E066D32D8E54F22A8ECA (void);
// 0x000000AA System.Int32 System.Xml.ValueHandle::GetInt32()
extern void ValueHandle_GetInt32_m919F4B53BEAFF48C11FE18021547EED9F0825874 (void);
// 0x000000AB System.Int64 System.Xml.ValueHandle::GetInt64()
extern void ValueHandle_GetInt64_m7ACE2532869A0046298109BEF75F2B8DBD7FCF40 (void);
// 0x000000AC System.UInt64 System.Xml.ValueHandle::GetUInt64()
extern void ValueHandle_GetUInt64_m58C0F0B93EA26621AE6A3F1853A9D977D312D3D4 (void);
// 0x000000AD System.Single System.Xml.ValueHandle::GetSingle()
extern void ValueHandle_GetSingle_m5995EB4362146798FA63BF5134C1E3CB28DAF37C (void);
// 0x000000AE System.Double System.Xml.ValueHandle::GetDouble()
extern void ValueHandle_GetDouble_m695617D79319AE93A566DDE885FB24C956AB3A47 (void);
// 0x000000AF System.Decimal System.Xml.ValueHandle::GetDecimal()
extern void ValueHandle_GetDecimal_m77261DD408FE5371267EEBCA80E06F5890D37590 (void);
// 0x000000B0 System.Xml.UniqueId System.Xml.ValueHandle::GetUniqueId()
extern void ValueHandle_GetUniqueId_m1D6F13C05710AC43A55510980B03D081E0FBFB42 (void);
// 0x000000B1 System.Guid System.Xml.ValueHandle::GetGuid()
extern void ValueHandle_GetGuid_m86D893B84979361977DD1CFBD8265207DF8A957B (void);
// 0x000000B2 System.Void System.Xml.ValueHandle::GetBase64(System.Byte[],System.Int32,System.Int32)
extern void ValueHandle_GetBase64_m38CCDAA9D4EA7922C432C9C585837864C116B058 (void);
// 0x000000B3 System.Xml.XmlDictionaryString System.Xml.ValueHandle::GetDictionaryString()
extern void ValueHandle_GetDictionaryString_m93E8286073B86561A550D91D5D472EC78B5C9E5C (void);
// 0x000000B4 System.String System.Xml.ValueHandle::GetQNameDictionaryText()
extern void ValueHandle_GetQNameDictionaryText_m052B0ABF6008DC43E18A0B271BA40100A89F72A6 (void);
// 0x000000B5 System.Void System.Xml.ValueHandle::.cctor()
extern void ValueHandle__cctor_mE40A64F092B3D01F97D9C99AF008C64DA4786EEB (void);
// 0x000000B6 System.Void System.Xml.XmlBaseReader::.ctor()
extern void XmlBaseReader__ctor_mE29E82F290BFD039B9057F2C57775AD90F309A79 (void);
// 0x000000B7 System.Text.BinHexEncoding System.Xml.XmlBaseReader::get_BinHexEncoding()
extern void XmlBaseReader_get_BinHexEncoding_m620A0A7921E315B69073E23936C5934533237C02 (void);
// 0x000000B8 System.Text.Base64Encoding System.Xml.XmlBaseReader::get_Base64Encoding()
extern void XmlBaseReader_get_Base64Encoding_mF917B0BF359D5B7ECBF7EAA97C4C0D66326EAB4D (void);
// 0x000000B9 System.Xml.XmlBufferReader System.Xml.XmlBaseReader::get_BufferReader()
extern void XmlBaseReader_get_BufferReader_m92B09A265A7CB4B97DEE0CAF53D111F488780BFA (void);
// 0x000000BA System.Xml.XmlDictionaryReaderQuotas System.Xml.XmlBaseReader::get_Quotas()
extern void XmlBaseReader_get_Quotas_m17CB2856E9380A6D928B80B39D4742FE5A6E214D (void);
// 0x000000BB System.Xml.XmlBaseReader/XmlNode System.Xml.XmlBaseReader::get_Node()
extern void XmlBaseReader_get_Node_mB1796DF90267696B3952E50816728DE9E3B75319 (void);
// 0x000000BC System.Void System.Xml.XmlBaseReader::MoveToNode(System.Xml.XmlBaseReader/XmlNode)
extern void XmlBaseReader_MoveToNode_m50C5F7663F9A5CA06FE8E87A60A9575B6384D1D3 (void);
// 0x000000BD System.Void System.Xml.XmlBaseReader::MoveToInitial(System.Xml.XmlDictionaryReaderQuotas)
extern void XmlBaseReader_MoveToInitial_mF7FB58BCC6BAF3BD2DD1C568CEB8159009598839 (void);
// 0x000000BE System.Xml.XmlBaseReader/XmlDeclarationNode System.Xml.XmlBaseReader::MoveToDeclaration()
extern void XmlBaseReader_MoveToDeclaration_m5C33F84DF26864C8217152FB86BBE5ECD0CDF9C7 (void);
// 0x000000BF System.Boolean System.Xml.XmlBaseReader::CheckStandalone(System.Int32)
extern void XmlBaseReader_CheckStandalone_mF2642E0842737C83167ADDE62AA81BCC8BF4B5BD (void);
// 0x000000C0 System.Boolean System.Xml.XmlBaseReader::CheckDeclAttribute(System.Int32,System.String,System.String,System.Boolean,System.String)
extern void XmlBaseReader_CheckDeclAttribute_mFB835BAB36BDB55B0F34AB15D45968B5D94BDFCD (void);
// 0x000000C1 System.Xml.XmlBaseReader/XmlCommentNode System.Xml.XmlBaseReader::MoveToComment()
extern void XmlBaseReader_MoveToComment_m775806AA4C6692EAC8F185FEEBF6BBB17A136AF6 (void);
// 0x000000C2 System.Xml.XmlBaseReader/XmlCDataNode System.Xml.XmlBaseReader::MoveToCData()
extern void XmlBaseReader_MoveToCData_mD9B0493F16E139B83F3D4698CD107ED42D59B8AD (void);
// 0x000000C3 System.Xml.XmlBaseReader/XmlAtomicTextNode System.Xml.XmlBaseReader::MoveToAtomicText()
extern void XmlBaseReader_MoveToAtomicText_m3DDEAB54FD32B2D2A477DA76159D4EB5E79E8FA7 (void);
// 0x000000C4 System.Xml.XmlBaseReader/XmlComplexTextNode System.Xml.XmlBaseReader::MoveToComplexText()
extern void XmlBaseReader_MoveToComplexText_m7CC28853D739C5F20FABDED89F60A94FB945DCFA (void);
// 0x000000C5 System.Xml.XmlBaseReader/XmlTextNode System.Xml.XmlBaseReader::MoveToWhitespaceText()
extern void XmlBaseReader_MoveToWhitespaceText_m61A276025A7344F5C8D5DC80042246B8ED24AB1D (void);
// 0x000000C6 System.Xml.XmlBaseReader/XmlElementNode System.Xml.XmlBaseReader::get_ElementNode()
extern void XmlBaseReader_get_ElementNode_mAA432C55978B3DD21EF182655559E257528F0BA3 (void);
// 0x000000C7 System.Void System.Xml.XmlBaseReader::MoveToEndElement()
extern void XmlBaseReader_MoveToEndElement_m6C8FE7FCFEF032404B5BC13921E274A0ADA7674C (void);
// 0x000000C8 System.Void System.Xml.XmlBaseReader::MoveToEndOfFile()
extern void XmlBaseReader_MoveToEndOfFile_m7ED872B60EC0D9B314D2E9A91B56317A2B239B61 (void);
// 0x000000C9 System.Xml.XmlBaseReader/XmlElementNode System.Xml.XmlBaseReader::EnterScope()
extern void XmlBaseReader_EnterScope_m9896064455A22C212855BEE696095C9EAACF6FE7 (void);
// 0x000000CA System.Void System.Xml.XmlBaseReader::ExitScope()
extern void XmlBaseReader_ExitScope_m4BD40F3305D4ACEAC1554AA34C1421EE472E6E01 (void);
// 0x000000CB System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::AddAttribute(System.Xml.XmlBaseReader/QNameType,System.Boolean)
extern void XmlBaseReader_AddAttribute_mBFDFB2AA7E80B736BC920DE9B4AD66202EE05D9F (void);
// 0x000000CC System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader::AddNamespace()
extern void XmlBaseReader_AddNamespace_mA1B422AFF9D9F857E7547AFEA6CC0D7889A0F639 (void);
// 0x000000CD System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::AddAttribute()
extern void XmlBaseReader_AddAttribute_m920516731EFBF60395C8202C5730751C70CBC646 (void);
// 0x000000CE System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::AddXmlAttribute()
extern void XmlBaseReader_AddXmlAttribute_m2414BEB88038F4AEB32C8E589B475CC2DAED6A5F (void);
// 0x000000CF System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::AddXmlnsAttribute(System.Xml.XmlBaseReader/Namespace)
extern void XmlBaseReader_AddXmlnsAttribute_mB4AE3256F8A17F853A22E25351EC7FDDB5A27048 (void);
// 0x000000D0 System.Void System.Xml.XmlBaseReader::FixXmlAttribute(System.Xml.XmlBaseReader/XmlAttributeNode)
extern void XmlBaseReader_FixXmlAttribute_m19C8C7ACE466C4318C64AFD5C5C75AFD039A1931 (void);
// 0x000000D1 System.Boolean System.Xml.XmlBaseReader::get_OutsideRootElement()
extern void XmlBaseReader_get_OutsideRootElement_m5B68A6DF2B1E4D46F0E5F5FE2A05EBE4DE4A0C2A (void);
// 0x000000D2 System.Boolean System.Xml.XmlBaseReader::get_CanReadValueChunk()
extern void XmlBaseReader_get_CanReadValueChunk_mD16BA6D3B6E669ADEE20495DF59863706C141612 (void);
// 0x000000D3 System.String System.Xml.XmlBaseReader::get_BaseURI()
extern void XmlBaseReader_get_BaseURI_m7FEBBFBC7CA0AB8C9AA8397CAB5FE14AD157ACCD (void);
// 0x000000D4 System.Boolean System.Xml.XmlBaseReader::get_IsDefault()
extern void XmlBaseReader_get_IsDefault_mEE181B5B6C4036188239CBC4E5905C6AF6F8812B (void);
// 0x000000D5 System.Int32 System.Xml.XmlBaseReader::get_AttributeCount()
extern void XmlBaseReader_get_AttributeCount_mFD9FF79D1E0CFDB4E3D0CB4C6AE0A48767CCF1BF (void);
// 0x000000D6 System.Void System.Xml.XmlBaseReader::Close()
extern void XmlBaseReader_Close_mBBEAD1B07A63C2F346C6CDE00CC233C0B57A4056 (void);
// 0x000000D7 System.Int32 System.Xml.XmlBaseReader::get_Depth()
extern void XmlBaseReader_get_Depth_mA8CD78BB8DF3C9282187002121C196EBB8EE5E45 (void);
// 0x000000D8 System.Boolean System.Xml.XmlBaseReader::get_EOF()
extern void XmlBaseReader_get_EOF_mB0208C6123123A6C1F6AAC36BC55663ACBABDA53 (void);
// 0x000000D9 System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::GetAttributeNode(System.Int32)
extern void XmlBaseReader_GetAttributeNode_mBDC181C8DBC6255345051B8163C848D7A390177A (void);
// 0x000000DA System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::GetAttributeNode(System.String)
extern void XmlBaseReader_GetAttributeNode_m8792CF2B025DAEFD6E222CA76E7C083527F89636 (void);
// 0x000000DB System.Xml.XmlBaseReader/XmlAttributeNode System.Xml.XmlBaseReader::GetAttributeNode(System.String,System.String)
extern void XmlBaseReader_GetAttributeNode_m2ED3B85D68FF7920F1D4F617D10F167B56DD3CBC (void);
// 0x000000DC System.String System.Xml.XmlBaseReader::GetAttribute(System.Int32)
extern void XmlBaseReader_GetAttribute_m82D6D1838383DB930D0C52D01DAEFE2817DFAB7A (void);
// 0x000000DD System.String System.Xml.XmlBaseReader::GetAttribute(System.String)
extern void XmlBaseReader_GetAttribute_m5481F734FEB51B5C67033342D2CBE6B55B3CC8B8 (void);
// 0x000000DE System.String System.Xml.XmlBaseReader::GetAttribute(System.String,System.String)
extern void XmlBaseReader_GetAttribute_m939E0E67302D54C605A0DDE9CE45431DF03B2C2B (void);
// 0x000000DF System.Boolean System.Xml.XmlBaseReader::get_IsEmptyElement()
extern void XmlBaseReader_get_IsEmptyElement_m649B777553B6CE32F1BB71BBCE9E7DF86D1CCA70 (void);
// 0x000000E0 System.String System.Xml.XmlBaseReader::get_LocalName()
extern void XmlBaseReader_get_LocalName_mEBD48190382F41AEA75DA80BB2C64D1D762F948F (void);
// 0x000000E1 System.String System.Xml.XmlBaseReader::LookupNamespace(System.String)
extern void XmlBaseReader_LookupNamespace_m1945C9B7E0B81B9C23489EBF142F6230B27D6A3C (void);
// 0x000000E2 System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader::LookupNamespace(System.Xml.PrefixHandle)
extern void XmlBaseReader_LookupNamespace_mA81AF7919E1CE9138AE69624A5C0CB5FB70D0DF9 (void);
// 0x000000E3 System.Void System.Xml.XmlBaseReader::ProcessAttributes()
extern void XmlBaseReader_ProcessAttributes_m6A1F209E7DEBD286F887DC5CEDABF25F57EEB1C8 (void);
// 0x000000E4 System.Void System.Xml.XmlBaseReader::ProcessAttributes(System.Xml.XmlBaseReader/XmlAttributeNode[],System.Int32)
extern void XmlBaseReader_ProcessAttributes_m916535993745D7238F84905B09D6E669349186ED (void);
// 0x000000E5 System.Void System.Xml.XmlBaseReader::CheckAttributes(System.Xml.XmlBaseReader/XmlAttributeNode[],System.Int32)
extern void XmlBaseReader_CheckAttributes_m04AFAC1C099FEF5813B1F98C6F9B6FA99F2A2B80 (void);
// 0x000000E6 System.Void System.Xml.XmlBaseReader::MoveToAttribute(System.Int32)
extern void XmlBaseReader_MoveToAttribute_mDEF0BFC3B49CD80305990B6C246F9E616AEE474C (void);
// 0x000000E7 System.Boolean System.Xml.XmlBaseReader::MoveToAttribute(System.String)
extern void XmlBaseReader_MoveToAttribute_mCF5E85077C0F22F913A6640958BA6F18D3104941 (void);
// 0x000000E8 System.Boolean System.Xml.XmlBaseReader::MoveToAttribute(System.String,System.String)
extern void XmlBaseReader_MoveToAttribute_mD6F29CAB8846F078C4DFD50E338554B26BC1BEC5 (void);
// 0x000000E9 System.Boolean System.Xml.XmlBaseReader::MoveToElement()
extern void XmlBaseReader_MoveToElement_m02F2A956851F7269DA58B30CD9E821500063FFF9 (void);
// 0x000000EA System.Xml.XmlNodeType System.Xml.XmlBaseReader::MoveToContent()
extern void XmlBaseReader_MoveToContent_m01130CAC1EEDB1B71EB70B9158DCEF0F1408E716 (void);
// 0x000000EB System.Boolean System.Xml.XmlBaseReader::MoveToFirstAttribute()
extern void XmlBaseReader_MoveToFirstAttribute_m688844B9998D75C759FC57663DF1688E8C42A252 (void);
// 0x000000EC System.Boolean System.Xml.XmlBaseReader::MoveToNextAttribute()
extern void XmlBaseReader_MoveToNextAttribute_mBF84DB160F107164606A5E118D4461268D1C5EB3 (void);
// 0x000000ED System.String System.Xml.XmlBaseReader::get_NamespaceURI()
extern void XmlBaseReader_get_NamespaceURI_m3F8B00FD7B7C52D3EE5ECFF3541B3728D0ED729F (void);
// 0x000000EE System.Xml.XmlNameTable System.Xml.XmlBaseReader::get_NameTable()
extern void XmlBaseReader_get_NameTable_m934015804D97E6B16F6E39B7329D8B23EB6D286C (void);
// 0x000000EF System.Xml.XmlNodeType System.Xml.XmlBaseReader::get_NodeType()
extern void XmlBaseReader_get_NodeType_mA2AC013A05ADCC16F573E209CB5EB244DEBA5978 (void);
// 0x000000F0 System.String System.Xml.XmlBaseReader::get_Prefix()
extern void XmlBaseReader_get_Prefix_mE4BD88D4D4537643009EB63B3D65F7D9AF3EED3E (void);
// 0x000000F1 System.Char System.Xml.XmlBaseReader::get_QuoteChar()
extern void XmlBaseReader_get_QuoteChar_m7D5425CB6B792C3BD2F9E61EC05D1410C69065A7 (void);
// 0x000000F2 System.String System.Xml.XmlBaseReader::GetLocalName(System.Boolean)
extern void XmlBaseReader_GetLocalName_mEF109F256CF95A98B9F717100F0EBAD1255083D8 (void);
// 0x000000F3 System.String System.Xml.XmlBaseReader::GetNamespaceUri(System.Boolean)
extern void XmlBaseReader_GetNamespaceUri_m85F9D77458C78D7627941C0BD821F6B8A747D4AF (void);
// 0x000000F4 System.Boolean System.Xml.XmlBaseReader::IsLocalName(System.String)
extern void XmlBaseReader_IsLocalName_m67B87169729E211E1DF05CA6CEB38DC1874C59AA (void);
// 0x000000F5 System.Boolean System.Xml.XmlBaseReader::IsLocalName(System.Xml.XmlDictionaryString)
extern void XmlBaseReader_IsLocalName_mB7BEB63C067476C1DA734560CF38E67C25A6BA39 (void);
// 0x000000F6 System.Boolean System.Xml.XmlBaseReader::IsNamespaceUri(System.String)
extern void XmlBaseReader_IsNamespaceUri_mCE4FE8DDFF7D2DAE4845BF24FB912AE2EDC22779 (void);
// 0x000000F7 System.Boolean System.Xml.XmlBaseReader::IsNamespaceUri(System.Xml.XmlDictionaryString)
extern void XmlBaseReader_IsNamespaceUri_mB9195D13D21C5C56C68C2BE8EB17AB94B91E4D22 (void);
// 0x000000F8 System.Boolean System.Xml.XmlBaseReader::IsStartElement()
extern void XmlBaseReader_IsStartElement_m2DEBA2F4B0193C22ABBB2C4CD47D2182CA53FAA8 (void);
// 0x000000F9 System.Boolean System.Xml.XmlBaseReader::IsStartElement(System.String,System.String)
extern void XmlBaseReader_IsStartElement_m6F25CA517E9B5EC5827D304490F8753669731CF7 (void);
// 0x000000FA System.Boolean System.Xml.XmlBaseReader::IsStartElement(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlBaseReader_IsStartElement_m4F632D958CB1F72DC5F6CDAC701B62C0EB19B20E (void);
// 0x000000FB System.Int32 System.Xml.XmlBaseReader::IndexOfLocalName(System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString)
extern void XmlBaseReader_IndexOfLocalName_mBE76DB33F2267A99FF5DA7D781609155CF66F9DF (void);
// 0x000000FC System.Int32 System.Xml.XmlBaseReader::ReadValueChunk(System.Char[],System.Int32,System.Int32)
extern void XmlBaseReader_ReadValueChunk_m5ACECAE7F6F0AB4E48691083DF17B03536C074D3 (void);
// 0x000000FD System.String System.Xml.XmlBaseReader::ReadElementContentAsString()
extern void XmlBaseReader_ReadElementContentAsString_m0C3511D4C5201A98A5279CCA241368B33DB07348 (void);
// 0x000000FE System.String System.Xml.XmlBaseReader::ReadElementString()
extern void XmlBaseReader_ReadElementString_m280B5ADDD913150662B536081ECE78C591DDD52F (void);
// 0x000000FF System.Void System.Xml.XmlBaseReader::ReadStartElement()
extern void XmlBaseReader_ReadStartElement_m3717AB44BFA2F5476B63972283F5A4A1DE56039C (void);
// 0x00000100 System.Void System.Xml.XmlBaseReader::ReadEndElement()
extern void XmlBaseReader_ReadEndElement_m84E9EE0533BF911BC26A428563E3C0BC594F50AC (void);
// 0x00000101 System.Boolean System.Xml.XmlBaseReader::ReadAttributeValue()
extern void XmlBaseReader_ReadAttributeValue_m72999AAF833FD92104884309706ACB583D499A3A (void);
// 0x00000102 System.Xml.ReadState System.Xml.XmlBaseReader::get_ReadState()
extern void XmlBaseReader_get_ReadState_mB0087C20D92F30B2C394826CA3D62DCC6D907A06 (void);
// 0x00000103 System.Void System.Xml.XmlBaseReader::SkipValue(System.Xml.XmlBaseReader/XmlNode)
extern void XmlBaseReader_SkipValue_m6664D12DA10C03BDA1DAB1DDA5D6E6620EBCE41D (void);
// 0x00000104 System.Boolean System.Xml.XmlBaseReader::TryGetBase64ContentLength(System.Int32&)
extern void XmlBaseReader_TryGetBase64ContentLength_m7DA7F41E2E7214082369EC6FE5A8B0ED504F8FBF (void);
// 0x00000105 System.Byte[] System.Xml.XmlBaseReader::ReadContentAsBase64()
extern void XmlBaseReader_ReadContentAsBase64_mF67C3818025B6F1CBAC790ACC67D0CE5D9B779A0 (void);
// 0x00000106 System.Int32 System.Xml.XmlBaseReader::ReadContentAsBase64(System.Byte[],System.Int32,System.Int32)
extern void XmlBaseReader_ReadContentAsBase64_m04E8E1ED6D3F9CFEC6A9A83CADC2C9B90506F7E5 (void);
// 0x00000107 System.Int32 System.Xml.XmlBaseReader::ReadContentAsBinHex(System.Byte[],System.Int32,System.Int32)
extern void XmlBaseReader_ReadContentAsBinHex_mC95BE7788121DE7A128667861695E88CDAAB83F3 (void);
// 0x00000108 System.Int32 System.Xml.XmlBaseReader::ReadBytes(System.Text.Encoding,System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern void XmlBaseReader_ReadBytes_m7EB745B00749346BFB21AB79988B9101E318D897 (void);
// 0x00000109 System.String System.Xml.XmlBaseReader::ReadContentAsString()
extern void XmlBaseReader_ReadContentAsString_m332383D98865CF85E580EC37368DB7153DCB3FC4 (void);
// 0x0000010A System.Boolean System.Xml.XmlBaseReader::ReadContentAsBoolean()
extern void XmlBaseReader_ReadContentAsBoolean_m4140218FD8B9A93E0DE1C026602CF74AE98E5CF7 (void);
// 0x0000010B System.Int64 System.Xml.XmlBaseReader::ReadContentAsLong()
extern void XmlBaseReader_ReadContentAsLong_m903C86BEE4FBE4100B36CFCE0CE5C53F9F7A0F8E (void);
// 0x0000010C System.Int32 System.Xml.XmlBaseReader::ReadContentAsInt()
extern void XmlBaseReader_ReadContentAsInt_m1417043783FE216EA2760F52BEF564ECDA6D334C (void);
// 0x0000010D System.DateTime System.Xml.XmlBaseReader::ReadContentAsDateTime()
extern void XmlBaseReader_ReadContentAsDateTime_m535CE1C81FEAD0D04668D4E617DEE4C9933F0D6A (void);
// 0x0000010E System.Double System.Xml.XmlBaseReader::ReadContentAsDouble()
extern void XmlBaseReader_ReadContentAsDouble_mCB089AF200C498A0649706A45327DD37B12DBB63 (void);
// 0x0000010F System.Single System.Xml.XmlBaseReader::ReadContentAsFloat()
extern void XmlBaseReader_ReadContentAsFloat_m66B042AB1BCED9C98D5F846EB7E1D378772F72AB (void);
// 0x00000110 System.Decimal System.Xml.XmlBaseReader::ReadContentAsDecimal()
extern void XmlBaseReader_ReadContentAsDecimal_m6CBE99F887BD3F3B7019985115F507BBD838F057 (void);
// 0x00000111 System.Xml.UniqueId System.Xml.XmlBaseReader::ReadContentAsUniqueId()
extern void XmlBaseReader_ReadContentAsUniqueId_mF0D066B6547B0712A70CD53DC018F32FA08C3F7A (void);
// 0x00000112 System.TimeSpan System.Xml.XmlBaseReader::ReadContentAsTimeSpan()
extern void XmlBaseReader_ReadContentAsTimeSpan_m0B777A7DF9D92619955E3E4710566667755AF68F (void);
// 0x00000113 System.Guid System.Xml.XmlBaseReader::ReadContentAsGuid()
extern void XmlBaseReader_ReadContentAsGuid_m4B28CFD313EFFEACE548EAA43091B32FB4496944 (void);
// 0x00000114 System.Object System.Xml.XmlBaseReader::ReadContentAsObject()
extern void XmlBaseReader_ReadContentAsObject_mE0FDD0E6D430ABE6710F1053BC0E911B2317447B (void);
// 0x00000115 System.Object System.Xml.XmlBaseReader::ReadContentAs(System.Type,System.Xml.IXmlNamespaceResolver)
extern void XmlBaseReader_ReadContentAs_mECB09CBBB3C353F017C5972445676CBA117C32B9 (void);
// 0x00000116 System.Void System.Xml.XmlBaseReader::ResolveEntity()
extern void XmlBaseReader_ResolveEntity_m36838D59634511B59F28D6D9A2CAB74E6756ABF3 (void);
// 0x00000117 System.Void System.Xml.XmlBaseReader::Skip()
extern void XmlBaseReader_Skip_mE0E025FE83C5B1514551269BA0C54529E8C172B0 (void);
// 0x00000118 System.String System.Xml.XmlBaseReader::get_Value()
extern void XmlBaseReader_get_Value_mCFF8D1E75706D3A22330A9B05A9C60CF3B75780D (void);
// 0x00000119 System.Type System.Xml.XmlBaseReader::get_ValueType()
extern void XmlBaseReader_get_ValueType_mE7BB327E97FAD2A6541956B32B48645BE2C32BEA (void);
// 0x0000011A System.String System.Xml.XmlBaseReader::get_XmlLang()
extern void XmlBaseReader_get_XmlLang_mBFFFCC5C91E534E8DB1F4D73221F99A664CA016D (void);
// 0x0000011B System.Xml.XmlSpace System.Xml.XmlBaseReader::get_XmlSpace()
extern void XmlBaseReader_get_XmlSpace_m116916C6CF0B9C090308B2583C4027DD606A96F8 (void);
// 0x0000011C System.String System.Xml.XmlBaseReader::GetOpenElements()
extern void XmlBaseReader_GetOpenElements_mF6C93E199919490F0C93B2202490BF983DF2289D (void);
// 0x0000011D System.Char[] System.Xml.XmlBaseReader::GetCharBuffer(System.Int32)
extern void XmlBaseReader_GetCharBuffer_m6386405D12B00EB50E6C3B6F36D485F43402F180 (void);
// 0x0000011E System.Void System.Xml.XmlBaseReader::SignStartElement(System.Xml.XmlSigningNodeWriter)
extern void XmlBaseReader_SignStartElement_m894080D504BB32CC4350DCEB4E31FD5B683EC43E (void);
// 0x0000011F System.Void System.Xml.XmlBaseReader::SignAttribute(System.Xml.XmlSigningNodeWriter,System.Xml.XmlBaseReader/XmlAttributeNode)
extern void XmlBaseReader_SignAttribute_mDC919012695F0AF7E6F3B725520A715A2D735FFF (void);
// 0x00000120 System.Void System.Xml.XmlBaseReader::SignEndElement(System.Xml.XmlSigningNodeWriter)
extern void XmlBaseReader_SignEndElement_m8A478C17732BF31A0A747D5CD460459D7E70A1A4 (void);
// 0x00000121 System.Void System.Xml.XmlBaseReader::SignNode(System.Xml.XmlSigningNodeWriter)
extern void XmlBaseReader_SignNode_m51F29EB50D3758506D0BCBA15CA03749940D5594 (void);
// 0x00000122 System.Void System.Xml.XmlBaseReader::SignNode()
extern void XmlBaseReader_SignNode_m2D742E5E792A4F5E0CAFF35F0C4DA5C631E323A3 (void);
// 0x00000123 System.Void System.Xml.XmlBaseReader::.cctor()
extern void XmlBaseReader__cctor_m4F35DF6636EBF3C52B238FF27C181D9B636D0A10 (void);
// 0x00000124 System.Void System.Xml.XmlBaseReader/XmlNode::.ctor(System.Xml.XmlNodeType,System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle,System.Xml.XmlBaseReader/XmlNode/XmlNodeFlags,System.Xml.ReadState,System.Xml.XmlBaseReader/XmlAttributeTextNode,System.Int32)
extern void XmlNode__ctor_m5B8080EEEBD08AB3917C1754DAB9E74251C1E01D (void);
// 0x00000125 System.Xml.ReadState System.Xml.XmlBaseReader/XmlNode::get_ReadState()
extern void XmlNode_get_ReadState_mD71DCD394E57B1415D2F0E98763845884357F5C5 (void);
// 0x00000126 System.Xml.StringHandle System.Xml.XmlBaseReader/XmlNode::get_LocalName()
extern void XmlNode_get_LocalName_mA4DCB272267C72DD38207BAFC5283855E211E71C (void);
// 0x00000127 System.Xml.PrefixHandle System.Xml.XmlBaseReader/XmlNode::get_Prefix()
extern void XmlNode_get_Prefix_m7067995DD22B79394BCE76D18472D9EE0704554B (void);
// 0x00000128 System.Boolean System.Xml.XmlBaseReader/XmlNode::get_CanGetAttribute()
extern void XmlNode_get_CanGetAttribute_mE26FBB9492E5A0611CDD788BE2121EFD0722C5E7 (void);
// 0x00000129 System.Boolean System.Xml.XmlBaseReader/XmlNode::get_CanMoveToElement()
extern void XmlNode_get_CanMoveToElement_m1237E934CA3693C3F876A0E8ADD57D981A1BC834 (void);
// 0x0000012A System.Xml.XmlBaseReader/XmlAttributeTextNode System.Xml.XmlBaseReader/XmlNode::get_AttributeText()
extern void XmlNode_get_AttributeText_mB8780DC3D6C2454D4A2284B8585B8C73B06791EE (void);
// 0x0000012B System.Boolean System.Xml.XmlBaseReader/XmlNode::get_SkipValue()
extern void XmlNode_get_SkipValue_mD05A023477207B91A5F4FC553264C4C55EE5735A (void);
// 0x0000012C System.Xml.ValueHandle System.Xml.XmlBaseReader/XmlNode::get_Value()
extern void XmlNode_get_Value_mBF80142EA81DA543907FFA2F75A4C9BC31D4900B (void);
// 0x0000012D System.Int32 System.Xml.XmlBaseReader/XmlNode::get_DepthDelta()
extern void XmlNode_get_DepthDelta_mAD0ADCF996B887C0066484650679002DF5550850 (void);
// 0x0000012E System.Boolean System.Xml.XmlBaseReader/XmlNode::get_HasContent()
extern void XmlNode_get_HasContent_mE7DD57C4D3356FDB57EF92ED4A4AB87E036CAF23 (void);
// 0x0000012F System.Xml.XmlNodeType System.Xml.XmlBaseReader/XmlNode::get_NodeType()
extern void XmlNode_get_NodeType_mD8FE4E387A3A852615DBCA96163E2D79F99D5CB5 (void);
// 0x00000130 System.Void System.Xml.XmlBaseReader/XmlNode::set_NodeType(System.Xml.XmlNodeType)
extern void XmlNode_set_NodeType_m71D8A3822934CAE66E1C5F4A8845C3831E868BEB (void);
// 0x00000131 System.Xml.XmlBaseReader/QNameType System.Xml.XmlBaseReader/XmlNode::get_QNameType()
extern void XmlNode_get_QNameType_m9ACF53395F5E64D80FE98155E970A594A538D6C0 (void);
// 0x00000132 System.Void System.Xml.XmlBaseReader/XmlNode::set_QNameType(System.Xml.XmlBaseReader/QNameType)
extern void XmlNode_set_QNameType_m374D456BAE763334D3684E9A8B53E5EFE561FB09 (void);
// 0x00000133 System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/XmlNode::get_Namespace()
extern void XmlNode_get_Namespace_m10F4E4A7A28A8E1437EB943709604C445F1D78A0 (void);
// 0x00000134 System.Void System.Xml.XmlBaseReader/XmlNode::set_Namespace(System.Xml.XmlBaseReader/Namespace)
extern void XmlNode_set_Namespace_m89CD2263936C38E35F7D52CE69E6F0E6DD816CCA (void);
// 0x00000135 System.Boolean System.Xml.XmlBaseReader/XmlNode::get_IsAtomicValue()
extern void XmlNode_get_IsAtomicValue_mD13343EC9B59F53B4693A3E90FDE00831E72AFD5 (void);
// 0x00000136 System.Void System.Xml.XmlBaseReader/XmlNode::set_IsAtomicValue(System.Boolean)
extern void XmlNode_set_IsAtomicValue_m507380030EBBFA9B85D81E9EBFAA905C6D722B9C (void);
// 0x00000137 System.Boolean System.Xml.XmlBaseReader/XmlNode::get_ExitScope()
extern void XmlNode_get_ExitScope_m6F3017359F00BE2FD9F8C568109E5F930BFB495B (void);
// 0x00000138 System.Void System.Xml.XmlBaseReader/XmlNode::set_ExitScope(System.Boolean)
extern void XmlNode_set_ExitScope_m6BC46F117B5B3AB4E938E2136CD3799659C18DCF (void);
// 0x00000139 System.Boolean System.Xml.XmlBaseReader/XmlNode::get_IsEmptyElement()
extern void XmlNode_get_IsEmptyElement_m5DEF8DF856EA49F368515D14D0E082E765DCAB14 (void);
// 0x0000013A System.Void System.Xml.XmlBaseReader/XmlNode::set_IsEmptyElement(System.Boolean)
extern void XmlNode_set_IsEmptyElement_m1B3C83C3537061144062D1D1D6FED46A695696F3 (void);
// 0x0000013B System.Char System.Xml.XmlBaseReader/XmlNode::get_QuoteChar()
extern void XmlNode_get_QuoteChar_mF43D4EEBD21A69C99F70C72417EB92A1B4F3183E (void);
// 0x0000013C System.Void System.Xml.XmlBaseReader/XmlNode::set_QuoteChar(System.Char)
extern void XmlNode_set_QuoteChar_m0FBFB8981AA7E5773FEA15A931D9440C7DCA6DD4 (void);
// 0x0000013D System.Boolean System.Xml.XmlBaseReader/XmlNode::IsLocalName(System.String)
extern void XmlNode_IsLocalName_m57ACF68173DF734A4F2648AF383E9559078FFC7A (void);
// 0x0000013E System.Boolean System.Xml.XmlBaseReader/XmlNode::IsLocalName(System.Xml.XmlDictionaryString)
extern void XmlNode_IsLocalName_m20EB45E1F59E5E8018E8DECB90179184B84D2ABB (void);
// 0x0000013F System.Boolean System.Xml.XmlBaseReader/XmlNode::IsNamespaceUri(System.String)
extern void XmlNode_IsNamespaceUri_mB96025A53A83F87683E641422038C08AE84E034D (void);
// 0x00000140 System.Boolean System.Xml.XmlBaseReader/XmlNode::IsNamespaceUri(System.Xml.XmlDictionaryString)
extern void XmlNode_IsNamespaceUri_mB396955ECC7A0EED810FDF5CCE13C38B8FDD7EAD (void);
// 0x00000141 System.Boolean System.Xml.XmlBaseReader/XmlNode::IsLocalNameAndNamespaceUri(System.String,System.String)
extern void XmlNode_IsLocalNameAndNamespaceUri_m70BBD0F9F2F6EA45C5E89F0D4FB0D735005936E5 (void);
// 0x00000142 System.Boolean System.Xml.XmlBaseReader/XmlNode::IsPrefixAndLocalName(System.String,System.String)
extern void XmlNode_IsPrefixAndLocalName_m6F691625A6322BEFCAB4DA6795F6138F1362B957 (void);
// 0x00000143 System.String System.Xml.XmlBaseReader/XmlNode::get_ValueAsString()
extern void XmlNode_get_ValueAsString_mB2C10FF7C67065C0C6AEB8FB4844D28BD3166013 (void);
// 0x00000144 System.Void System.Xml.XmlBaseReader/XmlElementNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlElementNode__ctor_mDBEA3CEAE1B973396D0EEACA2E5766ABD2482191 (void);
// 0x00000145 System.Void System.Xml.XmlBaseReader/XmlElementNode::.ctor(System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle)
extern void XmlElementNode__ctor_m57438F324430B5BF715E8AE9A2F1C7C47E36869B (void);
// 0x00000146 System.Xml.XmlBaseReader/XmlEndElementNode System.Xml.XmlBaseReader/XmlElementNode::get_EndElement()
extern void XmlElementNode_get_EndElement_mEE2161A2188D93FD1B83F0A80264C9FA7A479076 (void);
// 0x00000147 System.Int32 System.Xml.XmlBaseReader/XmlElementNode::get_BufferOffset()
extern void XmlElementNode_get_BufferOffset_mB2E0525858D5783007F7B00EC2360117AB2B802A (void);
// 0x00000148 System.Void System.Xml.XmlBaseReader/XmlElementNode::set_BufferOffset(System.Int32)
extern void XmlElementNode_set_BufferOffset_m08F4D4E76823BD5A1AFF903512105D69516366F7 (void);
// 0x00000149 System.Void System.Xml.XmlBaseReader/XmlAttributeNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlAttributeNode__ctor_m059B03E371BF74D999B6D2BE12A05799EB897720 (void);
// 0x0000014A System.Void System.Xml.XmlBaseReader/XmlAttributeNode::.ctor(System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle)
extern void XmlAttributeNode__ctor_m8D8F27B6496DAFC763ED1F3F2895FE699C1FF3BE (void);
// 0x0000014B System.Void System.Xml.XmlBaseReader/XmlEndElementNode::.ctor(System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle)
extern void XmlEndElementNode__ctor_m2796F9CBB127069098CE7EE3695914F00A2D1E86 (void);
// 0x0000014C System.Void System.Xml.XmlBaseReader/XmlTextNode::.ctor(System.Xml.XmlNodeType,System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle,System.Xml.XmlBaseReader/XmlNode/XmlNodeFlags,System.Xml.ReadState,System.Xml.XmlBaseReader/XmlAttributeTextNode,System.Int32)
extern void XmlTextNode__ctor_m9CA567587003012D2DDAF081B24FE0442CA58126 (void);
// 0x0000014D System.Void System.Xml.XmlBaseReader/XmlAtomicTextNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlAtomicTextNode__ctor_m7CA9FA40A5E686ABDE8E02BD35A8B09E542FD86E (void);
// 0x0000014E System.Void System.Xml.XmlBaseReader/XmlComplexTextNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlComplexTextNode__ctor_m70346868068DD5E55FB220A7E6D31CA1AE8DA90A (void);
// 0x0000014F System.Void System.Xml.XmlBaseReader/XmlWhitespaceTextNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlWhitespaceTextNode__ctor_m2892230BE7292A6C371E4E2EB48A52A965FCD1E3 (void);
// 0x00000150 System.Void System.Xml.XmlBaseReader/XmlCDataNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlCDataNode__ctor_m1B17D0C4EB63BC7611DA023F0F0A8FE8AD315027 (void);
// 0x00000151 System.Void System.Xml.XmlBaseReader/XmlAttributeTextNode::.ctor(System.Xml.PrefixHandle,System.Xml.StringHandle,System.Xml.ValueHandle)
extern void XmlAttributeTextNode__ctor_m49F1F00673430F4976BCB61426D330DADADE7286 (void);
// 0x00000152 System.Void System.Xml.XmlBaseReader/XmlInitialNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlInitialNode__ctor_m46E06ECA120CA4133F77494F701E9B82142274FD (void);
// 0x00000153 System.Void System.Xml.XmlBaseReader/XmlDeclarationNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlDeclarationNode__ctor_m5D9D8F84058CD91D3E1DF69928A638CCC961B755 (void);
// 0x00000154 System.Void System.Xml.XmlBaseReader/XmlCommentNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlCommentNode__ctor_mAC2703EA61639F984DE3B78C94B9860FB5A6951B (void);
// 0x00000155 System.Void System.Xml.XmlBaseReader/XmlEndOfFileNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlEndOfFileNode__ctor_m1F92B739E8E1E1BEB6093C2B128971109B52973A (void);
// 0x00000156 System.Void System.Xml.XmlBaseReader/XmlClosedNode::.ctor(System.Xml.XmlBufferReader)
extern void XmlClosedNode__ctor_m533542F67BE24F5AAF1C682CD33DE9AAEDEAC436 (void);
// 0x00000157 System.Boolean System.Xml.XmlBaseReader/AttributeSorter::Sort(System.Xml.XmlBaseReader/XmlAttributeNode[],System.Int32)
extern void AttributeSorter_Sort_m52A4018C7203468D226AEFB0468D6183D0D31F7A (void);
// 0x00000158 System.Void System.Xml.XmlBaseReader/AttributeSorter::GetIndeces(System.Int32&,System.Int32&)
extern void AttributeSorter_GetIndeces_mE8B46583937B6E3BE125DC3AB76CFDC0FF55D95E (void);
// 0x00000159 System.Void System.Xml.XmlBaseReader/AttributeSorter::Close()
extern void AttributeSorter_Close_m48ED81CA7277A9A388BF0C09F71A2FB9C9C0CEE8 (void);
// 0x0000015A System.Boolean System.Xml.XmlBaseReader/AttributeSorter::Sort()
extern void AttributeSorter_Sort_m4F19B0B91AE3A9FD35A16E39B2812E87E28C69CE (void);
// 0x0000015B System.Boolean System.Xml.XmlBaseReader/AttributeSorter::IsSorted()
extern void AttributeSorter_IsSorted_mE6DF0523D320923367C50A1352B0C72141695101 (void);
// 0x0000015C System.Int32 System.Xml.XmlBaseReader/AttributeSorter::Compare(System.Object,System.Object)
extern void AttributeSorter_Compare_mBDF728D2A2706CA2613646E6D785E4E4A119F018 (void);
// 0x0000015D System.Int32 System.Xml.XmlBaseReader/AttributeSorter::CompareQNameType(System.Xml.XmlBaseReader/QNameType,System.Xml.XmlBaseReader/QNameType)
extern void AttributeSorter_CompareQNameType_m3C0C5757FAC34F2E6F60CBE57D54E1008B7A17DA (void);
// 0x0000015E System.Void System.Xml.XmlBaseReader/AttributeSorter::.ctor()
extern void AttributeSorter__ctor_m0FD1D080C36CDA78F73ACA559DAE6483EC3BF94E (void);
// 0x0000015F System.Void System.Xml.XmlBaseReader/NamespaceManager::.ctor(System.Xml.XmlBufferReader)
extern void NamespaceManager__ctor_m885C0E7A4BCA3C7286A7BDD9C60B76E0EF43CA1D (void);
// 0x00000160 System.Void System.Xml.XmlBaseReader/NamespaceManager::Close()
extern void NamespaceManager_Close_m43231CA35BE81DE59897B95C73D86B93ACA708A0 (void);
// 0x00000161 System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::get_XmlNamespace()
extern void NamespaceManager_get_XmlNamespace_m669A702DDACF3F2E2AEF4DF103865EE7052B4AD5 (void);
// 0x00000162 System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::get_EmptyNamespace()
extern void NamespaceManager_get_EmptyNamespace_m9F2767A5C65A92E028C527323770D0ECCDBD088B (void);
// 0x00000163 System.String System.Xml.XmlBaseReader/NamespaceManager::get_XmlLang()
extern void NamespaceManager_get_XmlLang_mAD664DE74F6B5353FF30A3FA8BA800209C6D6688 (void);
// 0x00000164 System.Xml.XmlSpace System.Xml.XmlBaseReader/NamespaceManager::get_XmlSpace()
extern void NamespaceManager_get_XmlSpace_m551110613D13EDEB66E8358287A3D483388B320F (void);
// 0x00000165 System.Void System.Xml.XmlBaseReader/NamespaceManager::Clear()
extern void NamespaceManager_Clear_m9EDAB3CE4F090806ECF5FB198A518912A2E6EC32 (void);
// 0x00000166 System.Void System.Xml.XmlBaseReader/NamespaceManager::EnterScope()
extern void NamespaceManager_EnterScope_m6B498EF465485244DBB88C228F534E96454976F6 (void);
// 0x00000167 System.Void System.Xml.XmlBaseReader/NamespaceManager::ExitScope()
extern void NamespaceManager_ExitScope_mE31F7E76C94EFA1A3BF41CB87723D7055F197926 (void);
// 0x00000168 System.Void System.Xml.XmlBaseReader/NamespaceManager::AddLangAttribute(System.String)
extern void NamespaceManager_AddLangAttribute_m48C1565782F98409BA726EE503C10E7BE4AD0A9E (void);
// 0x00000169 System.Void System.Xml.XmlBaseReader/NamespaceManager::AddSpaceAttribute(System.Xml.XmlSpace)
extern void NamespaceManager_AddSpaceAttribute_m1F0D06BF2C83FEE1D4BFCE79711AD54F94A376E3 (void);
// 0x0000016A System.Void System.Xml.XmlBaseReader/NamespaceManager::AddAttribute()
extern void NamespaceManager_AddAttribute_mF431D9DA43BAD677524B87076D279C47E6EA9E86 (void);
// 0x0000016B System.Void System.Xml.XmlBaseReader/NamespaceManager::Register(System.Xml.XmlBaseReader/Namespace)
extern void NamespaceManager_Register_m3AD994FEC67ECE39A769D8CFFDB2FCE277A8C353 (void);
// 0x0000016C System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::AddNamespace()
extern void NamespaceManager_AddNamespace_m537ED8B1BA0595C095854BC09D456EDD81663ADB (void);
// 0x0000016D System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::LookupNamespace(System.Xml.PrefixHandleType)
extern void NamespaceManager_LookupNamespace_m613FFBC40C0F82802EF6BFFE92FFC8ACF4B33B9A (void);
// 0x0000016E System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::LookupNamespace(System.Xml.PrefixHandle)
extern void NamespaceManager_LookupNamespace_m8E4DC5E5707C2D308EF6C2837A6A32CAE09FB6BC (void);
// 0x0000016F System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/NamespaceManager::LookupNamespace(System.String)
extern void NamespaceManager_LookupNamespace_m6C50536B497D395740C94498645705FC3BCCBE9B (void);
// 0x00000170 System.Boolean System.Xml.XmlBaseReader/NamespaceManager::TryGetShortPrefix(System.String,System.Xml.PrefixHandleType&)
extern void NamespaceManager_TryGetShortPrefix_m4C3C3923B941C8720AC40EB6C30524392048B4B9 (void);
// 0x00000171 System.Void System.Xml.XmlBaseReader/NamespaceManager::.cctor()
extern void NamespaceManager__cctor_m913371041F3D34A0BA4A7F07CCEA35FC1D99FB13 (void);
// 0x00000172 System.Void System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::.ctor()
extern void XmlAttribute__ctor_mA187A0BBCB2DBE692FABADD0C6D0E2177F5980BB (void);
// 0x00000173 System.Int32 System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::get_Depth()
extern void XmlAttribute_get_Depth_m2D7D56BE4E96E7C593A0ED4B81A173F2D4A16D94 (void);
// 0x00000174 System.Void System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::set_Depth(System.Int32)
extern void XmlAttribute_set_Depth_m3F6B97F84CF0ACE2B27A11856A31CC5945D9C9B1 (void);
// 0x00000175 System.String System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::get_XmlLang()
extern void XmlAttribute_get_XmlLang_m0F1C77BD62394591A8F5CD30AD14BDDCEC18DB23 (void);
// 0x00000176 System.Void System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::set_XmlLang(System.String)
extern void XmlAttribute_set_XmlLang_m94F3F01A8593EA97CC01430C48BF80B4FCFBD453 (void);
// 0x00000177 System.Xml.XmlSpace System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::get_XmlSpace()
extern void XmlAttribute_get_XmlSpace_mEE25097FCF1846423533725FFC2A76F38B9062CA (void);
// 0x00000178 System.Void System.Xml.XmlBaseReader/NamespaceManager/XmlAttribute::set_XmlSpace(System.Xml.XmlSpace)
extern void XmlAttribute_set_XmlSpace_mF91942C8AF081D8A8E627E58B074806D43E5C82B (void);
// 0x00000179 System.Void System.Xml.XmlBaseReader/Namespace::.ctor(System.Xml.XmlBufferReader)
extern void Namespace__ctor_m9CF67CBD79F889F89F3ED6B7CC943EA3D0F4DEB3 (void);
// 0x0000017A System.Void System.Xml.XmlBaseReader/Namespace::Clear()
extern void Namespace_Clear_mAAB8979F724CDEA3BED5E73553F27FC794E73198 (void);
// 0x0000017B System.Int32 System.Xml.XmlBaseReader/Namespace::get_Depth()
extern void Namespace_get_Depth_mB4374D15E2A7D5FA2231ACB77A7D6F1156D7ADE6 (void);
// 0x0000017C System.Void System.Xml.XmlBaseReader/Namespace::set_Depth(System.Int32)
extern void Namespace_set_Depth_mC619153A63D25C7F404166ADD56C3C1B95DBD5F1 (void);
// 0x0000017D System.Xml.PrefixHandle System.Xml.XmlBaseReader/Namespace::get_Prefix()
extern void Namespace_get_Prefix_mA769918911319F2BE19889DC528575D522CE33EC (void);
// 0x0000017E System.Boolean System.Xml.XmlBaseReader/Namespace::IsUri(System.String)
extern void Namespace_IsUri_m3C46C66F712D44FA402E35B42A2ECB930FA44237 (void);
// 0x0000017F System.Boolean System.Xml.XmlBaseReader/Namespace::IsUri(System.Xml.XmlDictionaryString)
extern void Namespace_IsUri_m9BBA94343288B77072F10B8ADC5531FF2C62729D (void);
// 0x00000180 System.Xml.StringHandle System.Xml.XmlBaseReader/Namespace::get_Uri()
extern void Namespace_get_Uri_m87D0210E40FFE742FA268ABE74BCB7AD15FEEE20 (void);
// 0x00000181 System.Xml.XmlBaseReader/Namespace System.Xml.XmlBaseReader/Namespace::get_OuterUri()
extern void Namespace_get_OuterUri_mC501BD8B02DAA5EFF4CBED9151B464B51F4958B2 (void);
// 0x00000182 System.Void System.Xml.XmlBaseReader/Namespace::set_OuterUri(System.Xml.XmlBaseReader/Namespace)
extern void Namespace_set_OuterUri_m43C1655777E0C2C61CDFEE384B1A3B2CFF0B668F (void);
// 0x00000183 System.Void System.Xml.XmlBaseReader/QuotaNameTable::.ctor(System.Xml.XmlDictionaryReader,System.Int32)
extern void QuotaNameTable__ctor_m7D2498054D2F3B564F85748F225C4CEFD08FFA58 (void);
// 0x00000184 System.String System.Xml.XmlBaseReader/QuotaNameTable::Get(System.Char[],System.Int32,System.Int32)
extern void QuotaNameTable_Get_mE4214160C0918438524699B1DD9AB7157AE84441 (void);
// 0x00000185 System.String System.Xml.XmlBaseReader/QuotaNameTable::Get(System.String)
extern void QuotaNameTable_Get_m12256B09B56E573DAD819B283E9825F2CE46B9C0 (void);
// 0x00000186 System.Void System.Xml.XmlBaseReader/QuotaNameTable::Add(System.Int32)
extern void QuotaNameTable_Add_m4B91F07E98529F31E15092F0A910B8FFAED9E4DE (void);
// 0x00000187 System.String System.Xml.XmlBaseReader/QuotaNameTable::Add(System.Char[],System.Int32,System.Int32)
extern void QuotaNameTable_Add_m5B190B7BA1A526EE639F5D4538540E87B5F4CA8E (void);
// 0x00000188 System.String System.Xml.XmlBaseReader/QuotaNameTable::Add(System.String)
extern void QuotaNameTable_Add_mD7DFE10F9D38B029909B459D23099E87B4955C7F (void);
// 0x00000189 System.Boolean System.Xml.XmlBinaryReaderSession::TryLookup(System.Int32,System.Xml.XmlDictionaryString&)
extern void XmlBinaryReaderSession_TryLookup_m787FB2DE6AF6AA471892E86BB1BBB2E67FE6A1A8 (void);
// 0x0000018A System.Void System.Xml.XmlBufferReader::.ctor(System.Xml.XmlDictionaryReader)
extern void XmlBufferReader__ctor_m9EB77E390101608C9B477CCCC5FF9C4D6F1A91AC (void);
// 0x0000018B System.Void System.Xml.XmlBufferReader::.ctor(System.Byte[])
extern void XmlBufferReader__ctor_mE618914A053EE5F3B464D0055FA161816FA964E8 (void);
// 0x0000018C System.Xml.XmlBufferReader System.Xml.XmlBufferReader::get_Empty()
extern void XmlBufferReader_get_Empty_m832B2B4E712A7E463109534CD4E989ECDEF7C279 (void);
// 0x0000018D System.Byte[] System.Xml.XmlBufferReader::get_Buffer()
extern void XmlBufferReader_get_Buffer_mB32BD829069AF069FDCB0CCB1AD529DAED18E81C (void);
// 0x0000018E System.Boolean System.Xml.XmlBufferReader::get_IsStreamed()
extern void XmlBufferReader_get_IsStreamed_m38A1CF2C17CA4893AAEBA524D0B0F5F717C70D3A (void);
// 0x0000018F System.Void System.Xml.XmlBufferReader::SetBuffer(System.IO.Stream,System.Xml.IXmlDictionary,System.Xml.XmlBinaryReaderSession)
extern void XmlBufferReader_SetBuffer_m883A22CEA5DFCDD04F2969B0F4A4D4105FE83948 (void);
// 0x00000190 System.Void System.Xml.XmlBufferReader::SetBuffer(System.IO.Stream,System.Byte[],System.Int32,System.Int32,System.Xml.IXmlDictionary,System.Xml.XmlBinaryReaderSession)
extern void XmlBufferReader_SetBuffer_m21DEDF371817426BD60E7F04EB3401401E306117 (void);
// 0x00000191 System.Void System.Xml.XmlBufferReader::Close()
extern void XmlBufferReader_Close_mB88AAEC827180BCBC93743CA1FB7F580EE95D3D6 (void);
// 0x00000192 System.Boolean System.Xml.XmlBufferReader::get_EndOfFile()
extern void XmlBufferReader_get_EndOfFile_mFD06EEBC10D8FB02379957B55D40FF828225C7F3 (void);
// 0x00000193 System.Byte System.Xml.XmlBufferReader::GetByte()
extern void XmlBufferReader_GetByte_m1ADE8591788E8C7F6DD191710BC6CF52A342395B (void);
// 0x00000194 System.Void System.Xml.XmlBufferReader::SkipByte()
extern void XmlBufferReader_SkipByte_mBC6BF43391E55A8ACC88D99074E1037468EDB451 (void);
// 0x00000195 System.Byte System.Xml.XmlBufferReader::GetByteHard()
extern void XmlBufferReader_GetByteHard_mC8D4B64944608B46A7833526788E66CCBE298926 (void);
// 0x00000196 System.Byte[] System.Xml.XmlBufferReader::GetBuffer(System.Int32,System.Int32&)
extern void XmlBufferReader_GetBuffer_mCB41B785954DFC4BAF050876FFDB7D3734E2D28F (void);
// 0x00000197 System.Byte[] System.Xml.XmlBufferReader::GetBuffer(System.Int32,System.Int32&,System.Int32&)
extern void XmlBufferReader_GetBuffer_m9596467F2402ED1D68733AC97049AE6441730EA9 (void);
// 0x00000198 System.Byte[] System.Xml.XmlBufferReader::GetBuffer(System.Int32&,System.Int32&)
extern void XmlBufferReader_GetBuffer_m791A75F75E8F164B581E3D8E97A260107822DA8B (void);
// 0x00000199 System.Byte[] System.Xml.XmlBufferReader::GetBufferHard(System.Int32,System.Int32&)
extern void XmlBufferReader_GetBufferHard_m59C748233C300A4A96A6BA108DAB1553C5BFB402 (void);
// 0x0000019A System.Void System.Xml.XmlBufferReader::EnsureByte()
extern void XmlBufferReader_EnsureByte_m57AE11F2C521FA5A84420124CEC7B1950A67C106 (void);
// 0x0000019B System.Boolean System.Xml.XmlBufferReader::TryEnsureByte()
extern void XmlBufferReader_TryEnsureByte_m3DAAD44BEB6FA875C9E4F3E62E2D165DFEBA6E63 (void);
// 0x0000019C System.Void System.Xml.XmlBufferReader::EnsureBytes(System.Int32)
extern void XmlBufferReader_EnsureBytes_m7ED528EE62021598F931E85A1A57B24ECAE6E667 (void);
// 0x0000019D System.Boolean System.Xml.XmlBufferReader::TryEnsureBytes(System.Int32)
extern void XmlBufferReader_TryEnsureBytes_mBA2FC98382D52AD353119746F792F695F89FD590 (void);
// 0x0000019E System.Void System.Xml.XmlBufferReader::Advance(System.Int32)
extern void XmlBufferReader_Advance_m27717A43FFF12A15277B063938BD527368DA150B (void);
// 0x0000019F System.Void System.Xml.XmlBufferReader::SetWindow(System.Int32,System.Int32)
extern void XmlBufferReader_SetWindow_m5E622E24BD5C0D2481695072DF936FE2674E6B21 (void);
// 0x000001A0 System.Int32 System.Xml.XmlBufferReader::get_Offset()
extern void XmlBufferReader_get_Offset_m988B3C7EAB8EA101C6F84DF3FA478E5EE5951AA7 (void);
// 0x000001A1 System.Void System.Xml.XmlBufferReader::set_Offset(System.Int32)
extern void XmlBufferReader_set_Offset_m51900647465BEEED94F3BC14B9DDBCD6DF8D90F9 (void);
// 0x000001A2 System.Int32 System.Xml.XmlBufferReader::ReadBytes(System.Int32)
extern void XmlBufferReader_ReadBytes_m29C550071AF959CD115683A4A292C43A77932379 (void);
// 0x000001A3 System.Int32 System.Xml.XmlBufferReader::ReadMultiByteUInt31()
extern void XmlBufferReader_ReadMultiByteUInt31_m6428FD3BC61882415D8509A2980D62B8A2BDDF0D (void);
// 0x000001A4 System.Int32 System.Xml.XmlBufferReader::ReadUInt8()
extern void XmlBufferReader_ReadUInt8_mECFF347CB626172CEB0D999323095C6E9C0E8C59 (void);
// 0x000001A5 System.Int32 System.Xml.XmlBufferReader::ReadUInt16()
extern void XmlBufferReader_ReadUInt16_m1B7ABAB8BFE13E96F5B88EB9BF0930A0DDCB3148 (void);
// 0x000001A6 System.Int32 System.Xml.XmlBufferReader::ReadInt32()
extern void XmlBufferReader_ReadInt32_m41DE9DC4208F80173AA909455C97B79807DABAFF (void);
// 0x000001A7 System.Int32 System.Xml.XmlBufferReader::ReadUInt31()
extern void XmlBufferReader_ReadUInt31_m4DE8DF14BE15FEDD826473D186E632B4D50CA0DE (void);
// 0x000001A8 System.Char[] System.Xml.XmlBufferReader::GetCharBuffer(System.Int32)
extern void XmlBufferReader_GetCharBuffer_mDDF51E8D1FFF0E8A3695B5AFB597F06A8CCDA97D (void);
// 0x000001A9 System.Int32 System.Xml.XmlBufferReader::GetChars(System.Int32,System.Int32,System.Char[])
extern void XmlBufferReader_GetChars_m902B7AA72D2E9CD9D58CCA459D72083FD3F491CA (void);
// 0x000001AA System.Int32 System.Xml.XmlBufferReader::GetChars(System.Int32,System.Int32,System.Char[],System.Int32)
extern void XmlBufferReader_GetChars_mB06FEEBED01A9882FE43911E8C6BF9B8B3B54F53 (void);
// 0x000001AB System.String System.Xml.XmlBufferReader::GetString(System.Int32,System.Int32)
extern void XmlBufferReader_GetString_m2FC1C286AE1C1EE228462C91DF5FC412A27F2CF4 (void);
// 0x000001AC System.String System.Xml.XmlBufferReader::GetUnicodeString(System.Int32,System.Int32)
extern void XmlBufferReader_GetUnicodeString_m0FAFBA9D9E696E86B2C6EF3B339B38B8B72A5C02 (void);
// 0x000001AD System.String System.Xml.XmlBufferReader::GetString(System.Int32,System.Int32,System.Xml.XmlNameTable)
extern void XmlBufferReader_GetString_mB489E7D6E985E870068DF0C95C14EA790FE39693 (void);
// 0x000001AE System.Int32 System.Xml.XmlBufferReader::GetEscapedChars(System.Int32,System.Int32,System.Char[])
extern void XmlBufferReader_GetEscapedChars_mBAE3C00395FD0FFF24852DA205681DC7648BFFD6 (void);
// 0x000001AF System.Boolean System.Xml.XmlBufferReader::IsAttrChar(System.Int32)
extern void XmlBufferReader_IsAttrChar_m10742C6A2ACA77B2B1D44A5A7A8CB9FE7FCEB6CA (void);
// 0x000001B0 System.String System.Xml.XmlBufferReader::GetEscapedString(System.Int32,System.Int32)
extern void XmlBufferReader_GetEscapedString_m22395D83CC92B584A9E1D35267F9BBD019B0E0F8 (void);
// 0x000001B1 System.String System.Xml.XmlBufferReader::GetEscapedString(System.Int32,System.Int32,System.Xml.XmlNameTable)
extern void XmlBufferReader_GetEscapedString_mC524551F9998A577A8DD51C1429207F58F26AE93 (void);
// 0x000001B2 System.Int32 System.Xml.XmlBufferReader::GetLessThanCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetLessThanCharEntity_m1DE4237A1399EBEE60566682AFD7A020FBB2FF80 (void);
// 0x000001B3 System.Int32 System.Xml.XmlBufferReader::GetGreaterThanCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetGreaterThanCharEntity_mAE06AA2E77AB2EC88148D2F6B7A578518E39F4CB (void);
// 0x000001B4 System.Int32 System.Xml.XmlBufferReader::GetQuoteCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetQuoteCharEntity_m3489FC2BF1C247B32A609CCD72B890BE1EABDF3C (void);
// 0x000001B5 System.Int32 System.Xml.XmlBufferReader::GetAmpersandCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetAmpersandCharEntity_m9A8915B60653EE7109AC2BF4DBC1AFEF3B13A68B (void);
// 0x000001B6 System.Int32 System.Xml.XmlBufferReader::GetApostropheCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetApostropheCharEntity_mBBC2B45E797EC24C22DE8BD094AA2BCE3B813950 (void);
// 0x000001B7 System.Int32 System.Xml.XmlBufferReader::GetDecimalCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetDecimalCharEntity_m1C10BF993708F62C5BB1DFA52FD914ADED3C0B8A (void);
// 0x000001B8 System.Int32 System.Xml.XmlBufferReader::GetHexCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetHexCharEntity_m8B67950E2756FEEA59B6B8959D838C24E34D403D (void);
// 0x000001B9 System.Int32 System.Xml.XmlBufferReader::GetCharEntity(System.Int32,System.Int32)
extern void XmlBufferReader_GetCharEntity_m67402A805BE6EF81F6D52395D66DC9EF37693A69 (void);
// 0x000001BA System.Boolean System.Xml.XmlBufferReader::IsWhitespaceKey(System.Int32)
extern void XmlBufferReader_IsWhitespaceKey_m93159ACFFA277C2148C51A64402F9C8CD13859FC (void);
// 0x000001BB System.Boolean System.Xml.XmlBufferReader::IsWhitespaceUTF8(System.Int32,System.Int32)
extern void XmlBufferReader_IsWhitespaceUTF8_m8FF0B9883B0C0C89DF8FAC54BF7BBFEFBAA6244C (void);
// 0x000001BC System.Boolean System.Xml.XmlBufferReader::IsWhitespaceUnicode(System.Int32,System.Int32)
extern void XmlBufferReader_IsWhitespaceUnicode_m9DF630DB7D9C3299D435DA991148AD10615B8464 (void);
// 0x000001BD System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Int32,System.Xml.XmlBufferReader)
extern void XmlBufferReader_Equals2_m25877650EBA88DF5F1555E6A31A29CF7B65AEFDC (void);
// 0x000001BE System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Xml.XmlDictionaryString)
extern void XmlBufferReader_Equals2_m2C69294F1B41D281E5C0ACA1A604F1D30D878F04 (void);
// 0x000001BF System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Int32,System.Byte[])
extern void XmlBufferReader_Equals2_m61E17500C814481A408FE6CDF14FDAF9D6980698 (void);
// 0x000001C0 System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Int32,System.Xml.XmlBufferReader,System.Int32,System.Int32)
extern void XmlBufferReader_Equals2_m1896A0E5E69B566E3C98A3918C1B897D0933D1F0 (void);
// 0x000001C1 System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Int32,System.Int32,System.Int32)
extern void XmlBufferReader_Equals2_m3321637DEEB129F87828A062C1AD71866B35A357 (void);
// 0x000001C2 System.Boolean System.Xml.XmlBufferReader::Equals2(System.Int32,System.Int32,System.String)
extern void XmlBufferReader_Equals2_mC27BF722E298E9E97A11E4BA08CAEFD9EA124846 (void);
// 0x000001C3 System.Int32 System.Xml.XmlBufferReader::Compare(System.Int32,System.Int32,System.Int32,System.Int32)
extern void XmlBufferReader_Compare_m2D2EF59FDF1FF2282C53C5712005B420E25A6A07 (void);
// 0x000001C4 System.Byte System.Xml.XmlBufferReader::GetByte(System.Int32)
extern void XmlBufferReader_GetByte_m3BA3C199782D75B97C837E6DE3060E9755E45638 (void);
// 0x000001C5 System.Int32 System.Xml.XmlBufferReader::GetInt8(System.Int32)
extern void XmlBufferReader_GetInt8_m393D325AB0437BB3B2A94BAC2B473BF430D55AD3 (void);
// 0x000001C6 System.Int32 System.Xml.XmlBufferReader::GetInt16(System.Int32)
extern void XmlBufferReader_GetInt16_mD59F82C30A9A3143D16A2E370A1C89D8BEBF8FD9 (void);
// 0x000001C7 System.Int32 System.Xml.XmlBufferReader::GetInt32(System.Int32)
extern void XmlBufferReader_GetInt32_mE9849BB1EC22E5E19C134F4E9F065413AB04EF0A (void);
// 0x000001C8 System.Int64 System.Xml.XmlBufferReader::GetInt64(System.Int32)
extern void XmlBufferReader_GetInt64_m2FDBB9FB699ECBAAED3D7FF8813ABF6F140ECA4C (void);
// 0x000001C9 System.UInt64 System.Xml.XmlBufferReader::GetUInt64(System.Int32)
extern void XmlBufferReader_GetUInt64_mF07504843F1D5F41A7B7BF1B518501BA40C0D33A (void);
// 0x000001CA System.Single System.Xml.XmlBufferReader::GetSingle(System.Int32)
extern void XmlBufferReader_GetSingle_m464D07A40695A242FA14E9B57610D99A44801925 (void);
// 0x000001CB System.Double System.Xml.XmlBufferReader::GetDouble(System.Int32)
extern void XmlBufferReader_GetDouble_mB24556397299E8A07B17DE16A71FD5CB0046D963 (void);
// 0x000001CC System.Decimal System.Xml.XmlBufferReader::GetDecimal(System.Int32)
extern void XmlBufferReader_GetDecimal_mAA7C999EE70293471E177EA368F9C6733A1EE150 (void);
// 0x000001CD System.Xml.UniqueId System.Xml.XmlBufferReader::GetUniqueId(System.Int32)
extern void XmlBufferReader_GetUniqueId_m871269B20107C168092976A2A4AFA8A39F6C7759 (void);
// 0x000001CE System.Guid System.Xml.XmlBufferReader::GetGuid(System.Int32)
extern void XmlBufferReader_GetGuid_mCEF297FBD3DAF553732177D676B36BA32BA4C977 (void);
// 0x000001CF System.Void System.Xml.XmlBufferReader::GetBase64(System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlBufferReader_GetBase64_m54015A054D2F2078D86CA5C704267DCC43B27D46 (void);
// 0x000001D0 System.Xml.XmlBinaryNodeType System.Xml.XmlBufferReader::GetNodeType()
extern void XmlBufferReader_GetNodeType_m433A78BF192D8E43986133A6140D105D11B56AD9 (void);
// 0x000001D1 System.Void System.Xml.XmlBufferReader::SkipNodeType()
extern void XmlBufferReader_SkipNodeType_mA4E6DE90F48D5375762F1311CBD28B4D9D2BD483 (void);
// 0x000001D2 System.Object[] System.Xml.XmlBufferReader::GetList(System.Int32,System.Int32)
extern void XmlBufferReader_GetList_m8086C513B3CB8E08FE8853F4737920D54B4BAAB8 (void);
// 0x000001D3 System.Xml.XmlDictionaryString System.Xml.XmlBufferReader::GetDictionaryString(System.Int32)
extern void XmlBufferReader_GetDictionaryString_m186636F2747A6B432AB3289BBFDE3CB6091ECFCE (void);
// 0x000001D4 System.Int32 System.Xml.XmlBufferReader::ReadDictionaryKey()
extern void XmlBufferReader_ReadDictionaryKey_mCE90FD66FDCF51C73703B9E3347CB729E321C368 (void);
// 0x000001D5 System.Void System.Xml.XmlBufferReader::ReadValue(System.Xml.XmlBinaryNodeType,System.Xml.ValueHandle)
extern void XmlBufferReader_ReadValue_mF62B3AF2C72257A9004C50EB0205A8393251D973 (void);
// 0x000001D6 System.Void System.Xml.XmlBufferReader::ReadValue(System.Xml.ValueHandle,System.Xml.ValueHandleType,System.Int32)
extern void XmlBufferReader_ReadValue_m8CAD70557F7EA9BB46BC7C91904AA77A69DB5290 (void);
// 0x000001D7 System.Void System.Xml.XmlBufferReader::ReadUnicodeValue(System.Xml.ValueHandle,System.Int32)
extern void XmlBufferReader_ReadUnicodeValue_m84456625B652F1BC302968BE4CA875BE94A7F01A (void);
// 0x000001D8 System.Void System.Xml.XmlBufferReader::ReadList(System.Xml.ValueHandle)
extern void XmlBufferReader_ReadList_m7E74F0F45F702FC66382FE481F4516F5A8CBFD2A (void);
// 0x000001D9 System.Void System.Xml.XmlBufferReader::ReadQName(System.Xml.ValueHandle)
extern void XmlBufferReader_ReadQName_m7883A52F995F9D219FB748770BA95F2A37BC4BB9 (void);
// 0x000001DA System.Int32[] System.Xml.XmlBufferReader::GetRows()
extern void XmlBufferReader_GetRows_m220BD73053EF5950062A14F05723E8A93EE79290 (void);
// 0x000001DB System.Void System.Xml.XmlBufferReader::.cctor()
extern void XmlBufferReader__cctor_m84D169D696E5EEDADCF5C7C287DC9FA680828F4E (void);
// 0x000001DC System.Void System.Xml.XmlCanonicalWriter::Flush()
extern void XmlCanonicalWriter_Flush_mA7DB15FF6D0D7A7C83F34569F4B079B7611170B8 (void);
// 0x000001DD System.Void System.Xml.XmlCanonicalWriter::Close()
extern void XmlCanonicalWriter_Close_m545BBBF4CD870A7FAF540DBDC447A39610094004 (void);
// 0x000001DE System.Void System.Xml.XmlCanonicalWriter::WriteDeclaration()
extern void XmlCanonicalWriter_WriteDeclaration_m611907368C146441D9EC32C591E4843786BEC010 (void);
// 0x000001DF System.Void System.Xml.XmlCanonicalWriter::WriteComment(System.String)
extern void XmlCanonicalWriter_WriteComment_m68599B6CC4A86EF54B29B91FFAF8FDA987D9AB68 (void);
// 0x000001E0 System.Void System.Xml.XmlCanonicalWriter::StartElement()
extern void XmlCanonicalWriter_StartElement_mDDFEDE2DFC093EF9A9B0E1DECD6E6C31EF4EB95B (void);
// 0x000001E1 System.Void System.Xml.XmlCanonicalWriter::EndElement()
extern void XmlCanonicalWriter_EndElement_m0B88A13CD36C345CA332CFD747F085542AA3AF8D (void);
// 0x000001E2 System.Void System.Xml.XmlCanonicalWriter::WriteStartElement(System.String,System.String)
extern void XmlCanonicalWriter_WriteStartElement_mCCF807E3BCBDE8B0CB107BDE767E1E43C47ECCD1 (void);
// 0x000001E3 System.Boolean System.Xml.XmlCanonicalWriter::IsInclusivePrefix(System.Xml.XmlCanonicalWriter/XmlnsAttribute&)
extern void XmlCanonicalWriter_IsInclusivePrefix_m11EFCD47F0E5EE2AACFC0395908A8394C04DF5A3 (void);
// 0x000001E4 System.Void System.Xml.XmlCanonicalWriter::WriteEndStartElement(System.Boolean)
extern void XmlCanonicalWriter_WriteEndStartElement_m9162FB8A594D8400A2EB240CFC40E6319E778D2A (void);
// 0x000001E5 System.Void System.Xml.XmlCanonicalWriter::WriteEndElement(System.String,System.String)
extern void XmlCanonicalWriter_WriteEndElement_mB1A988E12299CEBC0888ECEDF9438F99DF5D4442 (void);
// 0x000001E6 System.Void System.Xml.XmlCanonicalWriter::EnsureXmlnsBuffer(System.Int32)
extern void XmlCanonicalWriter_EnsureXmlnsBuffer_m26DC20981E73199F119CBD175E1A6B1E1A99AD01 (void);
// 0x000001E7 System.Void System.Xml.XmlCanonicalWriter::WriteXmlnsAttribute(System.String,System.String)
extern void XmlCanonicalWriter_WriteXmlnsAttribute_m7EC772F1A36376C6A9E82F8FC701133F8E051AC0 (void);
// 0x000001E8 System.Void System.Xml.XmlCanonicalWriter::WriteStartAttribute(System.String,System.String)
extern void XmlCanonicalWriter_WriteStartAttribute_m668F3C40EB1FD934BDC49CD71A59E92F6C51D276 (void);
// 0x000001E9 System.Void System.Xml.XmlCanonicalWriter::WriteEndAttribute()
extern void XmlCanonicalWriter_WriteEndAttribute_m16E55CBC6A14BC715EC5C490B3F3D9A7BCB6B22E (void);
// 0x000001EA System.Void System.Xml.XmlCanonicalWriter::WriteCharEntity(System.Int32)
extern void XmlCanonicalWriter_WriteCharEntity_m217D2F24591C33B58508073C997E6F250B67CFA1 (void);
// 0x000001EB System.Void System.Xml.XmlCanonicalWriter::WriteEscapedText(System.String)
extern void XmlCanonicalWriter_WriteEscapedText_m74BAA54875E657A8E2180E86F3D1B5E172F953E1 (void);
// 0x000001EC System.Void System.Xml.XmlCanonicalWriter::WriteEscapedText(System.Byte[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_WriteEscapedText_mDC72396933B0ADA14486EC36670822407BAD1354 (void);
// 0x000001ED System.Void System.Xml.XmlCanonicalWriter::WriteEscapedText(System.Char[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_WriteEscapedText_m0CD88F98FB1D52DFD58F84AD7F98D09F06CE9AD2 (void);
// 0x000001EE System.Void System.Xml.XmlCanonicalWriter::WriteText(System.Int32)
extern void XmlCanonicalWriter_WriteText_m28BA5D90E6247961179F98E7200778AF44802A2D (void);
// 0x000001EF System.Void System.Xml.XmlCanonicalWriter::WriteText(System.Byte[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_WriteText_mD2429BDF62A8825D0164D1E6F46E86A151ABC492 (void);
// 0x000001F0 System.Void System.Xml.XmlCanonicalWriter::WriteText(System.String)
extern void XmlCanonicalWriter_WriteText_m5F6463E5DC109BDC55BD0FFDC2F217ADF644B670 (void);
// 0x000001F1 System.Void System.Xml.XmlCanonicalWriter::WriteText(System.Char[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_WriteText_mF1AD81765E746842DF1911D19F89956E401274E7 (void);
// 0x000001F2 System.Void System.Xml.XmlCanonicalWriter::ThrowIfClosed()
extern void XmlCanonicalWriter_ThrowIfClosed_mE96AF3DA68DF57C202185A47FFE816E34E36F433 (void);
// 0x000001F3 System.Void System.Xml.XmlCanonicalWriter::ThrowClosed()
extern void XmlCanonicalWriter_ThrowClosed_m6833597C1B6C41B9BF3434B49AD7AC41819B7708 (void);
// 0x000001F4 System.Void System.Xml.XmlCanonicalWriter::WriteXmlnsAttribute(System.Xml.XmlCanonicalWriter/XmlnsAttribute&)
extern void XmlCanonicalWriter_WriteXmlnsAttribute_m67665521973E004745C24DC1360AD16700D7A100 (void);
// 0x000001F5 System.Void System.Xml.XmlCanonicalWriter::SortAttributes()
extern void XmlCanonicalWriter_SortAttributes_mE4BC62222324086EFBB2688C90B2C603B888818E (void);
// 0x000001F6 System.Void System.Xml.XmlCanonicalWriter::AddAttribute(System.Xml.XmlCanonicalWriter/Attribute&)
extern void XmlCanonicalWriter_AddAttribute_m8E4E915220AF7886BCE7BB0B63319DB8F9C2EDF2 (void);
// 0x000001F7 System.Void System.Xml.XmlCanonicalWriter::AddXmlnsAttribute(System.Xml.XmlCanonicalWriter/XmlnsAttribute&)
extern void XmlCanonicalWriter_AddXmlnsAttribute_mE862C0B435A11A3AF79F40FE7C89944061F40BA6 (void);
// 0x000001F8 System.Void System.Xml.XmlCanonicalWriter::ResolvePrefix(System.Int32,System.Int32,System.Int32&,System.Int32&)
extern void XmlCanonicalWriter_ResolvePrefix_m3FB98ECE5D6D8017595DBD5EBEDB9BCFACE7C79C (void);
// 0x000001F9 System.Void System.Xml.XmlCanonicalWriter::ResolvePrefix(System.Xml.XmlCanonicalWriter/Attribute&)
extern void XmlCanonicalWriter_ResolvePrefix_m5D9CCD5EBA30ECACEC817CFB8E04AD01A8945BF7 (void);
// 0x000001FA System.Void System.Xml.XmlCanonicalWriter::ResolvePrefixes()
extern void XmlCanonicalWriter_ResolvePrefixes_m5081AB877ED568BF93C130B740AEE6DB56B1F61E (void);
// 0x000001FB System.Int32 System.Xml.XmlCanonicalWriter::Compare(System.Xml.XmlCanonicalWriter/XmlnsAttribute&,System.Xml.XmlCanonicalWriter/XmlnsAttribute&)
extern void XmlCanonicalWriter_Compare_m3F3307E36DCCAC31BB60D49C2EA993DA20571F1F (void);
// 0x000001FC System.Int32 System.Xml.XmlCanonicalWriter::Compare(System.Xml.XmlCanonicalWriter/Attribute&,System.Xml.XmlCanonicalWriter/Attribute&)
extern void XmlCanonicalWriter_Compare_m22EB7156AD61365EF530801A8427B76F337953D4 (void);
// 0x000001FD System.Int32 System.Xml.XmlCanonicalWriter::Compare(System.Byte[],System.Int32,System.Int32,System.Int32,System.Int32)
extern void XmlCanonicalWriter_Compare_m57E74320549D321EBC016B9D6922CAC9AD85BC91 (void);
// 0x000001FE System.Int32 System.Xml.XmlCanonicalWriter::Compare(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_Compare_m53622C0208DA0E8063A07305F520100C750F0267 (void);
// 0x000001FF System.Boolean System.Xml.XmlCanonicalWriter::Equals(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlCanonicalWriter_Equals_m9320D7340C3736023DC2E926983C9A8653FCD0CA (void);
// 0x00000200 System.Void System.Xml.XmlCanonicalWriter::.cctor()
extern void XmlCanonicalWriter__cctor_m2F5B83408EB082378E7B01EA0B667002F1226659 (void);
// 0x00000201 System.Void System.Xml.XmlCanonicalWriter/AttributeSorter::.ctor(System.Xml.XmlCanonicalWriter)
extern void AttributeSorter__ctor_mB8587264A3284B3DF5523A6AA0284B8CBA0BE6A0 (void);
// 0x00000202 System.Void System.Xml.XmlCanonicalWriter/AttributeSorter::Sort()
extern void AttributeSorter_Sort_mC8C7CE57FA636C9DA3238696397D2E467C33AA96 (void);
// 0x00000203 System.Int32 System.Xml.XmlCanonicalWriter/AttributeSorter::Compare(System.Object,System.Object)
extern void AttributeSorter_Compare_mA9EA5CEBD7F0BEB64900197995134116DDD32A4B (void);
// 0x00000204 System.Text.Base64Encoding System.Xml.XmlConverter::get_Base64Encoding()
extern void XmlConverter_get_Base64Encoding_mBA0C13FD6E888644CBB27A21459E08F5770F5D4C (void);
// 0x00000205 System.Text.UTF8Encoding System.Xml.XmlConverter::get_UTF8Encoding()
extern void XmlConverter_get_UTF8Encoding_mF2244DA6C1B4485397B14B49C6E3BB8C135DE5ED (void);
// 0x00000206 System.Text.UnicodeEncoding System.Xml.XmlConverter::get_UnicodeEncoding()
extern void XmlConverter_get_UnicodeEncoding_m46209129C86A552F16EDA2D87C344A5062C817BF (void);
// 0x00000207 System.Boolean System.Xml.XmlConverter::ToBoolean(System.String)
extern void XmlConverter_ToBoolean_mE9AE6E78428700AF7AC1406003C07B42CA7541A4 (void);
// 0x00000208 System.Boolean System.Xml.XmlConverter::ToBoolean(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToBoolean_mFCDC25D8E3CF222EFCD19A80B36D0F16FCDBA93F (void);
// 0x00000209 System.Int32 System.Xml.XmlConverter::ToInt32(System.String)
extern void XmlConverter_ToInt32_mFFEEB51B8CFE70EAB2CA85522C1B289FB253AFA8 (void);
// 0x0000020A System.Int32 System.Xml.XmlConverter::ToInt32(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToInt32_m12B2B91A0D3727BE883B9A6B865EF8C2FE9FC680 (void);
// 0x0000020B System.Int64 System.Xml.XmlConverter::ToInt64(System.String)
extern void XmlConverter_ToInt64_m36399DE24F4D697DE8C9B098396A63FC0A5D7416 (void);
// 0x0000020C System.Int64 System.Xml.XmlConverter::ToInt64(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToInt64_m6E2AAFB8EE90CDBFC1D26137F8E1161F2234365C (void);
// 0x0000020D System.Single System.Xml.XmlConverter::ToSingle(System.String)
extern void XmlConverter_ToSingle_m5D56139487026923BA88B2DDB01AA7BFA126E2A9 (void);
// 0x0000020E System.Single System.Xml.XmlConverter::ToSingle(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToSingle_m93A141334C40D5EB45EC722903B4889477DF72CF (void);
// 0x0000020F System.Double System.Xml.XmlConverter::ToDouble(System.String)
extern void XmlConverter_ToDouble_mE95C50FC0C3060AB3A762647B7CE3A4DB8B77727 (void);
// 0x00000210 System.Double System.Xml.XmlConverter::ToDouble(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToDouble_m8D5C04612CF408114898B95F0343FEC000A2058A (void);
// 0x00000211 System.Decimal System.Xml.XmlConverter::ToDecimal(System.String)
extern void XmlConverter_ToDecimal_mA65B4259AED46C116691FBB8FCA935C6CC731BE6 (void);
// 0x00000212 System.Decimal System.Xml.XmlConverter::ToDecimal(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToDecimal_m518C3767757D3D5607EAAE7B821B631865B6F90F (void);
// 0x00000213 System.DateTime System.Xml.XmlConverter::ToDateTime(System.Int64)
extern void XmlConverter_ToDateTime_m81AB1612885E06EBE3412A04C9409EB42C8673F1 (void);
// 0x00000214 System.DateTime System.Xml.XmlConverter::ToDateTime(System.String)
extern void XmlConverter_ToDateTime_m4062BBC29003718C5BFD51B881622B9833EFD800 (void);
// 0x00000215 System.DateTime System.Xml.XmlConverter::ToDateTime(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToDateTime_m2BAECA489504FB11F7514840EDBF28F45D5A0E33 (void);
// 0x00000216 System.Xml.UniqueId System.Xml.XmlConverter::ToUniqueId(System.String)
extern void XmlConverter_ToUniqueId_mB2AC4D5D75EFF9B09C69CDA43824D59559D06944 (void);
// 0x00000217 System.Xml.UniqueId System.Xml.XmlConverter::ToUniqueId(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToUniqueId_m783D8FDE090E5BE2D589C4E48FC9FA44370CB603 (void);
// 0x00000218 System.TimeSpan System.Xml.XmlConverter::ToTimeSpan(System.String)
extern void XmlConverter_ToTimeSpan_m1DDC216C96E4BAB9B0FE8E1D2CF0449672A6400F (void);
// 0x00000219 System.TimeSpan System.Xml.XmlConverter::ToTimeSpan(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToTimeSpan_mECB46F078F57A6A23D19241E6C0FFD42B034645B (void);
// 0x0000021A System.Guid System.Xml.XmlConverter::ToGuid(System.String)
extern void XmlConverter_ToGuid_mD1D198FB36C5BEB6ECB43F2E8D80EB1EDAC58F77 (void);
// 0x0000021B System.Guid System.Xml.XmlConverter::ToGuid(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToGuid_m587B92DEB7BC6C607F6DB6E2930698A7C9E74591 (void);
// 0x0000021C System.UInt64 System.Xml.XmlConverter::ToUInt64(System.String)
extern void XmlConverter_ToUInt64_m4D7024367AF853E1AF71D7695B6B05E13AD5FCBE (void);
// 0x0000021D System.UInt64 System.Xml.XmlConverter::ToUInt64(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToUInt64_mEF5091DCB3B14A486BC9046D26AE0D7B47990984 (void);
// 0x0000021E System.String System.Xml.XmlConverter::ToString(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToString_m7A44A92A3100BF31F87FA0C26A474B1B0EDCFEB6 (void);
// 0x0000021F System.String System.Xml.XmlConverter::ToStringUnicode(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToStringUnicode_mAC5D9BB533BF1CABD62BBE092E5426172585A623 (void);
// 0x00000220 System.Byte[] System.Xml.XmlConverter::ToBytes(System.String)
extern void XmlConverter_ToBytes_m1953DE59A2A82EF03F11D36D9CDF484F37346F4D (void);
// 0x00000221 System.Int32 System.Xml.XmlConverter::ToChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void XmlConverter_ToChars_mDC8FC1B62411443907CA61E93D0900AB7273C33A (void);
// 0x00000222 System.String System.Xml.XmlConverter::ToString(System.Boolean)
extern void XmlConverter_ToString_m1433F7A935C7E548BA2D46C9385081081706C913 (void);
// 0x00000223 System.String System.Xml.XmlConverter::ToString(System.Int32)
extern void XmlConverter_ToString_m9332F121A42474A8C85093D4A9A3C4035AEDC19D (void);
// 0x00000224 System.String System.Xml.XmlConverter::ToString(System.Int64)
extern void XmlConverter_ToString_m6FE866D0EFBF066F58062513CA33F16620D59AAD (void);
// 0x00000225 System.String System.Xml.XmlConverter::ToString(System.Single)
extern void XmlConverter_ToString_mFCB26021B2998C1847DCA938CDC8F3F0B9466942 (void);
// 0x00000226 System.String System.Xml.XmlConverter::ToString(System.Double)
extern void XmlConverter_ToString_mEB0A94B676E1E8E9C265FC69194463D9440820B8 (void);
// 0x00000227 System.String System.Xml.XmlConverter::ToString(System.Decimal)
extern void XmlConverter_ToString_m34BD76A5AC24B95F44236747DB3897BC3EEC28F8 (void);
// 0x00000228 System.String System.Xml.XmlConverter::ToString(System.TimeSpan)
extern void XmlConverter_ToString_m59FEA065E8AF08706E83E25AD58E2ECB51A26552 (void);
// 0x00000229 System.String System.Xml.XmlConverter::ToString(System.Xml.UniqueId)
extern void XmlConverter_ToString_mF9F53B24599B02261A1FB21F25AD5C5684B4D28E (void);
// 0x0000022A System.String System.Xml.XmlConverter::ToString(System.Guid)
extern void XmlConverter_ToString_m08A96685B703799BCA9A9C0B0574B6D92EBA064E (void);
// 0x0000022B System.String System.Xml.XmlConverter::ToString(System.UInt64)
extern void XmlConverter_ToString_m20356067F814B0D8595AE157CAAFDCC7B8DE0C79 (void);
// 0x0000022C System.String System.Xml.XmlConverter::ToString(System.DateTime)
extern void XmlConverter_ToString_m0CCF6AA294A94216CA45CC2B64F835D81071D9BF (void);
// 0x0000022D System.String System.Xml.XmlConverter::ToString(System.Object)
extern void XmlConverter_ToString_m6633088E3C4BC8FCF5EB04C27749FEAA35DEEFBD (void);
// 0x0000022E System.String System.Xml.XmlConverter::ToString(System.Object[])
extern void XmlConverter_ToString_m5077778BA9F74BF2633C7F5E943DBCD1C7443D80 (void);
// 0x0000022F System.Boolean System.Xml.XmlConverter::TryParseInt32(System.Byte[],System.Int32,System.Int32,System.Int32&)
extern void XmlConverter_TryParseInt32_m5D01AA22682052CE632C3A6B163C2D3CB37496F1 (void);
// 0x00000230 System.Boolean System.Xml.XmlConverter::TryParseInt64(System.Byte[],System.Int32,System.Int32,System.Int64&)
extern void XmlConverter_TryParseInt64_mB88800CD694A70C6F91211E0AF79B0DCC63EE4BE (void);
// 0x00000231 System.Boolean System.Xml.XmlConverter::TryParseSingle(System.Byte[],System.Int32,System.Int32,System.Single&)
extern void XmlConverter_TryParseSingle_m2CBA17D516011E19A3168BBE5EBE64027008617D (void);
// 0x00000232 System.Boolean System.Xml.XmlConverter::TryParseDouble(System.Byte[],System.Int32,System.Int32,System.Double&)
extern void XmlConverter_TryParseDouble_m0B657D2110FE6FC658354AA2343C5CFE7983144C (void);
// 0x00000233 System.Int32 System.Xml.XmlConverter::ToInt32D2(System.Byte[],System.Int32)
extern void XmlConverter_ToInt32D2_m0C5B72210261E5BEFAB613AF89E7690FAC2C33D9 (void);
// 0x00000234 System.Int32 System.Xml.XmlConverter::ToInt32D4(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToInt32D4_mB7C2D7DAAF85723EE779C9D6F24B734E1850153A (void);
// 0x00000235 System.Int32 System.Xml.XmlConverter::ToInt32D7(System.Byte[],System.Int32,System.Int32)
extern void XmlConverter_ToInt32D7_m335587E7675C1778B655EA7189330B8C38CA74BA (void);
// 0x00000236 System.Boolean System.Xml.XmlConverter::TryParseDateTime(System.Byte[],System.Int32,System.Int32,System.DateTime&)
extern void XmlConverter_TryParseDateTime_mBD69384077B13D27153A34E4BD0825C20E36FE80 (void);
// 0x00000237 System.Int32 System.Xml.XmlConverter::ToCharsR(System.Int32,System.Byte[],System.Int32)
extern void XmlConverter_ToCharsR_mBB0F3685A99DB3020322C4FD52C54E21F3B38812 (void);
// 0x00000238 System.Int32 System.Xml.XmlConverter::ToChars(System.Int32,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_m925863EBC9E92EE8990EA6D9870C8338ACE525D2 (void);
// 0x00000239 System.Int32 System.Xml.XmlConverter::ToCharsR(System.Int64,System.Byte[],System.Int32)
extern void XmlConverter_ToCharsR_m8144097C125B7F665B2CC5B2A94C66D0903D42EF (void);
// 0x0000023A System.Int32 System.Xml.XmlConverter::ToChars(System.Int64,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_m72FA25B17203E5A0259729D7B467D031FABAE970 (void);
// 0x0000023B System.Boolean System.Xml.XmlConverter::IsNegativeZero(System.Single)
extern void XmlConverter_IsNegativeZero_m923D3535F752421E6B6CC6F31E04384C8EA67326 (void);
// 0x0000023C System.Boolean System.Xml.XmlConverter::IsNegativeZero(System.Double)
extern void XmlConverter_IsNegativeZero_mF2314BD43EE278FC3CBEA74C1757A263AEE8F2AD (void);
// 0x0000023D System.Int32 System.Xml.XmlConverter::ToInfinity(System.Boolean,System.Byte[],System.Int32)
extern void XmlConverter_ToInfinity_m3A59377C8B6A8F8CC4BC974A539A9F68659F2AB2 (void);
// 0x0000023E System.Int32 System.Xml.XmlConverter::ToZero(System.Boolean,System.Byte[],System.Int32)
extern void XmlConverter_ToZero_mBCF3D69E2A4AEF8677446444B0D1844E138925DA (void);
// 0x0000023F System.Int32 System.Xml.XmlConverter::ToChars(System.Double,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_mD23C14B220D2947B3E3C9C32EE3B8D99B16B3C10 (void);
// 0x00000240 System.Int32 System.Xml.XmlConverter::ToChars(System.Single,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_m63CA34D52B7682B5941E0895E6E94586618C5878 (void);
// 0x00000241 System.Int32 System.Xml.XmlConverter::ToChars(System.Decimal,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_m4044F229E0B0FFBD7AEED08100B89695D0FD72A7 (void);
// 0x00000242 System.Int32 System.Xml.XmlConverter::ToChars(System.UInt64,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_m14E932AF515C5D28220638360495DD5D7954161A (void);
// 0x00000243 System.Int32 System.Xml.XmlConverter::ToAsciiChars(System.String,System.Byte[],System.Int32)
extern void XmlConverter_ToAsciiChars_m37F512B5677C6FDF85B3616FCD097F49E284DD76 (void);
// 0x00000244 System.Int32 System.Xml.XmlConverter::ToCharsD2(System.Int32,System.Byte[],System.Int32)
extern void XmlConverter_ToCharsD2_m3DCEE867D85821B5A1E5E96A37C3C5517F88B1F4 (void);
// 0x00000245 System.Int32 System.Xml.XmlConverter::ToCharsD4(System.Int32,System.Byte[],System.Int32)
extern void XmlConverter_ToCharsD4_m6988851616847416E4F11EE7825D2A2A5A28F0A5 (void);
// 0x00000246 System.Int32 System.Xml.XmlConverter::ToCharsD7(System.Int32,System.Byte[],System.Int32)
extern void XmlConverter_ToCharsD7_m8C0A463B177582BB51F5F357072F09934A7673D3 (void);
// 0x00000247 System.Int32 System.Xml.XmlConverter::ToChars(System.DateTime,System.Byte[],System.Int32)
extern void XmlConverter_ToChars_mFC8C32C543B09D6A15162283F187A46310489251 (void);
// 0x00000248 System.Boolean System.Xml.XmlConverter::IsWhitespace(System.String)
extern void XmlConverter_IsWhitespace_m4A87F7A30154747765687793A9E7D80918BBCA7E (void);
// 0x00000249 System.Boolean System.Xml.XmlConverter::IsWhitespace(System.Char)
extern void XmlConverter_IsWhitespace_m012B47B3A9311728564D81C0310240D371D55E37 (void);
// 0x0000024A System.String System.Xml.XmlConverter::StripWhitespace(System.String)
extern void XmlConverter_StripWhitespace_m5A9A0830141974A95DF18F06D83E8758D032B405 (void);
// 0x0000024B System.String System.Xml.XmlConverter::Trim(System.String)
extern void XmlConverter_Trim_m37C261E6906910DB27ED04169A1A5AC9631A86E1 (void);
// 0x0000024C System.Void System.Xml.XmlConverter::.cctor()
extern void XmlConverter__cctor_m5108058988FCC1BEF8A57669FD70AC933CAA2E63 (void);
// 0x0000024D System.Void System.Xml.XmlDictionary::.ctor()
extern void XmlDictionary__ctor_m80149ADA3E27CEB5020314BE104C8EC6E8E316FE (void);
// 0x0000024E System.Void System.Xml.XmlDictionary::.ctor(System.Int32)
extern void XmlDictionary__ctor_m73092DA3FFF9A794AED84013880357EE5B7C78C7 (void);
// 0x0000024F System.Xml.XmlDictionaryString System.Xml.XmlDictionary::Add(System.String)
extern void XmlDictionary_Add_m58F151BCF05F610278077EF479D28261FF2E4FC0 (void);
// 0x00000250 System.Boolean System.Xml.XmlDictionary::TryLookup(System.Int32,System.Xml.XmlDictionaryString&)
extern void XmlDictionary_TryLookup_mD75EDA354C38466FE4BA3CDB24BC588932086D2A (void);
// 0x00000251 System.Void System.Xml.OnXmlDictionaryReaderClose::.ctor(System.Object,System.IntPtr)
extern void OnXmlDictionaryReaderClose__ctor_mD3DA44CCD35D157D284B57F9C6FE904704C4630E (void);
// 0x00000252 System.Void System.Xml.OnXmlDictionaryReaderClose::Invoke(System.Xml.XmlDictionaryReader)
extern void OnXmlDictionaryReaderClose_Invoke_m46D04A3210933F0E11318BE66952BB2E6AB00853 (void);
// 0x00000253 System.Xml.XmlDictionaryReader System.Xml.XmlDictionaryReader::CreateDictionaryReader(System.Xml.XmlReader)
extern void XmlDictionaryReader_CreateDictionaryReader_m18E876ACE129BAC911EF670483A6B3DB82C49889 (void);
// 0x00000254 System.Xml.XmlDictionaryReader System.Xml.XmlDictionaryReader::CreateTextReader(System.IO.Stream,System.Xml.XmlDictionaryReaderQuotas)
extern void XmlDictionaryReader_CreateTextReader_m1A71893F5FB45663233EE3C323D1C2A7734EC29F (void);
// 0x00000255 System.Xml.XmlDictionaryReader System.Xml.XmlDictionaryReader::CreateTextReader(System.IO.Stream,System.Text.Encoding,System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void XmlDictionaryReader_CreateTextReader_m99103BD84597F25404013DE4239DBCE6C48B462B (void);
// 0x00000256 System.Xml.XmlDictionaryReaderQuotas System.Xml.XmlDictionaryReader::get_Quotas()
extern void XmlDictionaryReader_get_Quotas_m56BC45C5DF654AEFBA290C5BA7ECBE58E12200E2 (void);
// 0x00000257 System.Void System.Xml.XmlDictionaryReader::MoveToStartElement()
extern void XmlDictionaryReader_MoveToStartElement_m46608243963F296EF0A06ACAEE363831F1039181 (void);
// 0x00000258 System.Boolean System.Xml.XmlDictionaryReader::IsLocalName(System.String)
extern void XmlDictionaryReader_IsLocalName_m69D8C62E52587B8B4406DF241853C7813F306760 (void);
// 0x00000259 System.Boolean System.Xml.XmlDictionaryReader::IsLocalName(System.Xml.XmlDictionaryString)
extern void XmlDictionaryReader_IsLocalName_mA3E8F8F860559FE47A1C44E469EE003A88D3F674 (void);
// 0x0000025A System.Boolean System.Xml.XmlDictionaryReader::IsNamespaceUri(System.String)
extern void XmlDictionaryReader_IsNamespaceUri_mC4D76CBDF93A05AB69BBEBA79E16DBCDFB2CE75D (void);
// 0x0000025B System.Boolean System.Xml.XmlDictionaryReader::IsNamespaceUri(System.Xml.XmlDictionaryString)
extern void XmlDictionaryReader_IsNamespaceUri_m6641C4C8C0FB6B3D610F28D6FCE796A797DEDB26 (void);
// 0x0000025C System.Boolean System.Xml.XmlDictionaryReader::IsStartElement(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlDictionaryReader_IsStartElement_mED109CB6A5050B97E0AF6F985923056FC2AF23F5 (void);
// 0x0000025D System.Int32 System.Xml.XmlDictionaryReader::IndexOfLocalName(System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString)
extern void XmlDictionaryReader_IndexOfLocalName_mFDA2182B6FBA5884CD957A148455F8C4559FA5E1 (void);
// 0x0000025E System.Boolean System.Xml.XmlDictionaryReader::TryGetBase64ContentLength(System.Int32&)
extern void XmlDictionaryReader_TryGetBase64ContentLength_m463D0E3366F9ABBED10380B8DE1FAEB7DDD95BCE (void);
// 0x0000025F System.Byte[] System.Xml.XmlDictionaryReader::ReadContentAsBase64()
extern void XmlDictionaryReader_ReadContentAsBase64_mB826AA83D5FEACA76F97AC02F7CB9F6EA3A36DEF (void);
// 0x00000260 System.Byte[] System.Xml.XmlDictionaryReader::ReadContentAsBase64(System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadContentAsBase64_m76CB8C0BD3E7440F2C0780408A2C1ED7BFF869F3 (void);
// 0x00000261 System.String System.Xml.XmlDictionaryReader::ReadContentAsString()
extern void XmlDictionaryReader_ReadContentAsString_m5A57F1860E316B1EA3022C1FD93DA37C24AE9662 (void);
// 0x00000262 System.String System.Xml.XmlDictionaryReader::ReadContentAsString(System.Int32)
extern void XmlDictionaryReader_ReadContentAsString_m9BD42A62FEEA01EDD63BCBB0015B7A7D28BA23F1 (void);
// 0x00000263 System.String System.Xml.XmlDictionaryReader::ReadString()
extern void XmlDictionaryReader_ReadString_mDD6D9F48D9A012C8049D9ADB41698B3105F781B8 (void);
// 0x00000264 System.String System.Xml.XmlDictionaryReader::ReadString(System.Int32)
extern void XmlDictionaryReader_ReadString_mCFB26BCF0F3D078D7F4559D5A93ABBB1612CEF74 (void);
// 0x00000265 System.Byte[] System.Xml.XmlDictionaryReader::ReadContentAsBytes(System.Boolean,System.Int32)
extern void XmlDictionaryReader_ReadContentAsBytes_mDC409214ABC50F5B554484BE7807AED9FCF1E1D6 (void);
// 0x00000266 System.Boolean System.Xml.XmlDictionaryReader::IsTextNode(System.Xml.XmlNodeType)
extern void XmlDictionaryReader_IsTextNode_mC900A41B66DAA05511B42C4E4DBC47501B3D1259 (void);
// 0x00000267 System.Int32 System.Xml.XmlDictionaryReader::ReadContentAsChars(System.Char[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadContentAsChars_m92793BC3BC8FF1C5EB9DF44F1CFE46A28BEEC917 (void);
// 0x00000268 System.Object System.Xml.XmlDictionaryReader::ReadContentAs(System.Type,System.Xml.IXmlNamespaceResolver)
extern void XmlDictionaryReader_ReadContentAs_mDB7C8F4CFE9C54E28A1564B83526340B70937464 (void);
// 0x00000269 System.Decimal System.Xml.XmlDictionaryReader::ReadContentAsDecimal()
extern void XmlDictionaryReader_ReadContentAsDecimal_m2C6C847FC5CDE03C1744E3961D912A32E18DCFAF (void);
// 0x0000026A System.Single System.Xml.XmlDictionaryReader::ReadContentAsFloat()
extern void XmlDictionaryReader_ReadContentAsFloat_mCB6509556CE695CD8CB0CC1498ECDC4150295EE8 (void);
// 0x0000026B System.Xml.UniqueId System.Xml.XmlDictionaryReader::ReadContentAsUniqueId()
extern void XmlDictionaryReader_ReadContentAsUniqueId_m77943D8FC8ACA74896C661FD07D4DCFD5874A22F (void);
// 0x0000026C System.Guid System.Xml.XmlDictionaryReader::ReadContentAsGuid()
extern void XmlDictionaryReader_ReadContentAsGuid_mD52396E11083A38D9C90091D6D15BFBFC5E05694 (void);
// 0x0000026D System.TimeSpan System.Xml.XmlDictionaryReader::ReadContentAsTimeSpan()
extern void XmlDictionaryReader_ReadContentAsTimeSpan_mEECFDF6A42D2368DFAFD7535FCFB986FFA3D6D1C (void);
// 0x0000026E System.String System.Xml.XmlDictionaryReader::ReadElementContentAsString()
extern void XmlDictionaryReader_ReadElementContentAsString_m336A15CB6D25D168335954B2DAA4841730F8B048 (void);
// 0x0000026F System.Boolean System.Xml.XmlDictionaryReader::ReadElementContentAsBoolean()
extern void XmlDictionaryReader_ReadElementContentAsBoolean_mC63E427F53007FB9FC6F87987559B35328C1442C (void);
// 0x00000270 System.Int32 System.Xml.XmlDictionaryReader::ReadElementContentAsInt()
extern void XmlDictionaryReader_ReadElementContentAsInt_mE64366A2C946C4A041DD81A21E20AFEC7572E40E (void);
// 0x00000271 System.Int64 System.Xml.XmlDictionaryReader::ReadElementContentAsLong()
extern void XmlDictionaryReader_ReadElementContentAsLong_mD852C05EB64BD138EDF373878E839EEB791C8A25 (void);
// 0x00000272 System.Single System.Xml.XmlDictionaryReader::ReadElementContentAsFloat()
extern void XmlDictionaryReader_ReadElementContentAsFloat_mA99ED0F682D8C733A34FF7B20578775F8BF3191B (void);
// 0x00000273 System.Double System.Xml.XmlDictionaryReader::ReadElementContentAsDouble()
extern void XmlDictionaryReader_ReadElementContentAsDouble_m06310EB05BFC23D72AEBE2AD1D5D19441CE50539 (void);
// 0x00000274 System.Decimal System.Xml.XmlDictionaryReader::ReadElementContentAsDecimal()
extern void XmlDictionaryReader_ReadElementContentAsDecimal_mD0F3C22C02170A68029EDAE88E68F7E1631B6F8E (void);
// 0x00000275 System.DateTime System.Xml.XmlDictionaryReader::ReadElementContentAsDateTime()
extern void XmlDictionaryReader_ReadElementContentAsDateTime_mF44DD3DC831EA0ACA5BF0A047007B74B68946E09 (void);
// 0x00000276 System.Byte[] System.Xml.XmlDictionaryReader::ReadElementContentAsBase64()
extern void XmlDictionaryReader_ReadElementContentAsBase64_mA3AFE3A9C8C71D6DC8375D266CE36EAC1B0242FF (void);
// 0x00000277 System.Void System.Xml.XmlDictionaryReader::CheckArray(System.Array,System.Int32,System.Int32)
extern void XmlDictionaryReader_CheckArray_mDFC28EBD1BB8AA6E579E033E1E51F70A5E2BB4A5 (void);
// 0x00000278 System.Boolean System.Xml.XmlDictionaryReader::TryGetArrayLength(System.Int32&)
extern void XmlDictionaryReader_TryGetArrayLength_m78E054EA0E9ED69616252D6DC9BEB4E68D8A1710 (void);
// 0x00000279 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Boolean[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mD3F3E4546CA84FFC9666925F0961D9548B6BE68A (void);
// 0x0000027A System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Boolean[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m1A3295AF0760C38C76AD123E40B1F5A1746CC523 (void);
// 0x0000027B System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Int32[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mA83F324B90B48FD1FB96AA3E3790C49CD544FBAA (void);
// 0x0000027C System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m091987050897F2B6383CFAA5347AFA5525943DFC (void);
// 0x0000027D System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Int64[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mB0DF87F3054175D9DE9A91CB1F881A339B9036AD (void);
// 0x0000027E System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int64[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mE0A1F132B6B391AD31FB3BE518CB55D7A53CD349 (void);
// 0x0000027F System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Single[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m6419A17439562C08FCB7528BCE30DF54290E9EDC (void);
// 0x00000280 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Single[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m46B7E8BF473E17A0D515F08CC0E069404ED0B6B4 (void);
// 0x00000281 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Double[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m949BA82143F47A7E4FCCE5234C8ED8EB1DC06074 (void);
// 0x00000282 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Double[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m0CD907A3CDCEA03D9AC58EB6C16C479FDC6FC95A (void);
// 0x00000283 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.Decimal[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m49857CC4CB579401F6A7B339F6B8D1F01395E98D (void);
// 0x00000284 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Decimal[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_m59973D723EBAA7DC80CB3D398EC320947137E9E7 (void);
// 0x00000285 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.String,System.String,System.DateTime[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mC57A4DB8DC14425495603E6E3D0BFCF015EF2F79 (void);
// 0x00000286 System.Int32 System.Xml.XmlDictionaryReader::ReadArray(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.DateTime[],System.Int32,System.Int32)
extern void XmlDictionaryReader_ReadArray_mA55687A3F05B147D472831256E233933A9FE2D0D (void);
// 0x00000287 System.Void System.Xml.XmlDictionaryReader::.ctor()
extern void XmlDictionaryReader__ctor_m062FF9ED1A2156A5933A8DFDB47518D48C4F2AF6 (void);
// 0x00000288 System.Void System.Xml.XmlDictionaryReader/XmlWrappedReader::.ctor(System.Xml.XmlReader,System.Xml.XmlNamespaceManager)
extern void XmlWrappedReader__ctor_m55981EA6C792042818060F41F38954A21D0F2E61 (void);
// 0x00000289 System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::get_AttributeCount()
extern void XmlWrappedReader_get_AttributeCount_m0F8A360B85D1633D927C91812B3BA4FD1EA8ED42 (void);
// 0x0000028A System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_BaseURI()
extern void XmlWrappedReader_get_BaseURI_mC26BD71133EC092CADDD09B8C18922C9F81F63CF (void);
// 0x0000028B System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::get_CanReadValueChunk()
extern void XmlWrappedReader_get_CanReadValueChunk_mAB35F8DB9F156297C3E3A7E04BDEA11B59DF0FC8 (void);
// 0x0000028C System.Void System.Xml.XmlDictionaryReader/XmlWrappedReader::Close()
extern void XmlWrappedReader_Close_mB3E9EA5D2AF60A33E1459C7D4D5EE0B1D6656A26 (void);
// 0x0000028D System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::get_Depth()
extern void XmlWrappedReader_get_Depth_mD02B78BD3F4F7135B038BBFE79B791943A422ABE (void);
// 0x0000028E System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::get_EOF()
extern void XmlWrappedReader_get_EOF_mC84F994547754EA226EB97C568B2538C844AEB3F (void);
// 0x0000028F System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::GetAttribute(System.Int32)
extern void XmlWrappedReader_GetAttribute_mE138EEE5BCFB9EB194BCFA198BA43EE2C94D8277 (void);
// 0x00000290 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::GetAttribute(System.String)
extern void XmlWrappedReader_GetAttribute_m222009A1443583D6229430ABBC3292687F6A94C7 (void);
// 0x00000291 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::GetAttribute(System.String,System.String)
extern void XmlWrappedReader_GetAttribute_mE6D36BEDD37E1FC5F7B960626E2BF34687B69620 (void);
// 0x00000292 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::get_IsDefault()
extern void XmlWrappedReader_get_IsDefault_m197C75D6849C49B363F213289D1B67D66709FA30 (void);
// 0x00000293 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::get_IsEmptyElement()
extern void XmlWrappedReader_get_IsEmptyElement_m4063EC5736776FA1348FF7EBC22C58B92BF4FF5A (void);
// 0x00000294 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::IsStartElement(System.String,System.String)
extern void XmlWrappedReader_IsStartElement_m559C390C06BB66BCDD70936456725B5F46C98C72 (void);
// 0x00000295 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_LocalName()
extern void XmlWrappedReader_get_LocalName_m43B0F047B989F2B3C9EDD7A7AFA03807CAE6F2D5 (void);
// 0x00000296 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::LookupNamespace(System.String)
extern void XmlWrappedReader_LookupNamespace_m00BCA75DF9806EFA725D046363E53150964E69FE (void);
// 0x00000297 System.Void System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToAttribute(System.Int32)
extern void XmlWrappedReader_MoveToAttribute_m6317BB2F643149331E47600F3834E726F2C0C218 (void);
// 0x00000298 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToAttribute(System.String)
extern void XmlWrappedReader_MoveToAttribute_m91FA49E60C7D42853746E6F3066B1ECFCEAF16CB (void);
// 0x00000299 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToAttribute(System.String,System.String)
extern void XmlWrappedReader_MoveToAttribute_mBC9336CEFC77807D9173B006461E2640DD43CEBF (void);
// 0x0000029A System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToElement()
extern void XmlWrappedReader_MoveToElement_m5FE7E50F908B823F43907D76DC6F41AEE6B880F8 (void);
// 0x0000029B System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToFirstAttribute()
extern void XmlWrappedReader_MoveToFirstAttribute_m37885D7DD73E7769DA2B02D316FDFE5F7BFB770E (void);
// 0x0000029C System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::MoveToNextAttribute()
extern void XmlWrappedReader_MoveToNextAttribute_mE4A9F8E2C19DA6CB2417A7462CE6943BE04EC68E (void);
// 0x0000029D System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_Name()
extern void XmlWrappedReader_get_Name_m5F6F64AEF09EFA948CE83031805102CC0EF3FE5A (void);
// 0x0000029E System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_NamespaceURI()
extern void XmlWrappedReader_get_NamespaceURI_mA0F81025D3CD14833B9215FE760E6F19B1895C02 (void);
// 0x0000029F System.Xml.XmlNameTable System.Xml.XmlDictionaryReader/XmlWrappedReader::get_NameTable()
extern void XmlWrappedReader_get_NameTable_m1269F2E40BD350B06D6B05B56B43DFF5A8E25E79 (void);
// 0x000002A0 System.Xml.XmlNodeType System.Xml.XmlDictionaryReader/XmlWrappedReader::get_NodeType()
extern void XmlWrappedReader_get_NodeType_mBBD7DDC5CA9AD84C490C7F2488158493EEF44504 (void);
// 0x000002A1 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_Prefix()
extern void XmlWrappedReader_get_Prefix_m6890FC9A0F821312F2E45FE40D9933D6AF61B1E5 (void);
// 0x000002A2 System.Char System.Xml.XmlDictionaryReader/XmlWrappedReader::get_QuoteChar()
extern void XmlWrappedReader_get_QuoteChar_mC8FB1BBCF4AAE11DF300A0A7EA15E8D483888044 (void);
// 0x000002A3 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::Read()
extern void XmlWrappedReader_Read_mAE5CFDEC88AD7D7828A70A7EBB0D9E105C2B8C3C (void);
// 0x000002A4 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadAttributeValue()
extern void XmlWrappedReader_ReadAttributeValue_mF8204B6A12359D29BEC23DE6509F6731514CD1DB (void);
// 0x000002A5 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadInnerXml()
extern void XmlWrappedReader_ReadInnerXml_m65EA725A2E086E9AB4EE551761358BDB5769BFD2 (void);
// 0x000002A6 System.Void System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadEndElement()
extern void XmlWrappedReader_ReadEndElement_m9FE20C2722308D3D7B0C02F1663B17DEDBBEB968 (void);
// 0x000002A7 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadString()
extern void XmlWrappedReader_ReadString_m422E134043F5929D18F0D7053E792B5F6793DC91 (void);
// 0x000002A8 System.Xml.ReadState System.Xml.XmlDictionaryReader/XmlWrappedReader::get_ReadState()
extern void XmlWrappedReader_get_ReadState_m199D8ED3CE55A7574DBBE61DF77FC2A24FD4CDC4 (void);
// 0x000002A9 System.Void System.Xml.XmlDictionaryReader/XmlWrappedReader::ResolveEntity()
extern void XmlWrappedReader_ResolveEntity_m66216A1B2619544A7A90F65C1E23829F5924266F (void);
// 0x000002AA System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_Value()
extern void XmlWrappedReader_get_Value_m3A61AB5998BAEA042C001B54A175C8FD79DB79A0 (void);
// 0x000002AB System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::get_XmlLang()
extern void XmlWrappedReader_get_XmlLang_m9F752B1593988E839B08527C6FC7BFF568D0F977 (void);
// 0x000002AC System.Xml.XmlSpace System.Xml.XmlDictionaryReader/XmlWrappedReader::get_XmlSpace()
extern void XmlWrappedReader_get_XmlSpace_m02C31E1C409EB78F6B668081853BFF28061BB3C7 (void);
// 0x000002AD System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsBase64(System.Byte[],System.Int32,System.Int32)
extern void XmlWrappedReader_ReadContentAsBase64_m26F240E22D457146683F1B17CB4360D4F3F48E99 (void);
// 0x000002AE System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsBinHex(System.Byte[],System.Int32,System.Int32)
extern void XmlWrappedReader_ReadContentAsBinHex_m192754CFF404AAEDD2AB8BC25E85C28DA97FE9E2 (void);
// 0x000002AF System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadValueChunk(System.Char[],System.Int32,System.Int32)
extern void XmlWrappedReader_ReadValueChunk_mFE5CEE6552AA5CFAB9FFD0F65FB0E50B28A67BF3 (void);
// 0x000002B0 System.Type System.Xml.XmlDictionaryReader/XmlWrappedReader::get_ValueType()
extern void XmlWrappedReader_get_ValueType_mFB4FEDC1B70B98CD33CC8E4231C8BE6995016AB0 (void);
// 0x000002B1 System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsBoolean()
extern void XmlWrappedReader_ReadContentAsBoolean_m44D70FD7902FC2190EADFD4506F3AFA297C564B2 (void);
// 0x000002B2 System.DateTime System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsDateTime()
extern void XmlWrappedReader_ReadContentAsDateTime_m34FE91C985B6412B36D192C624DD8C8E8BABBB01 (void);
// 0x000002B3 System.Decimal System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsDecimal()
extern void XmlWrappedReader_ReadContentAsDecimal_mBE525950884903883B9ABAAEB7816AB0226E3670 (void);
// 0x000002B4 System.Double System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsDouble()
extern void XmlWrappedReader_ReadContentAsDouble_mC49C64BE4F83F7310A94504DE088950965664B68 (void);
// 0x000002B5 System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsInt()
extern void XmlWrappedReader_ReadContentAsInt_mB77F9C85B2D7B0D0A4D35B58FCAB471DAFFC5F8E (void);
// 0x000002B6 System.Int64 System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsLong()
extern void XmlWrappedReader_ReadContentAsLong_mB95B286BA872D3BA1F25D2BE8A2CB1F1FE06C1AB (void);
// 0x000002B7 System.Single System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsFloat()
extern void XmlWrappedReader_ReadContentAsFloat_m0D994FC4E7CBB55CE2305F1F8A8EB47791A8FC52 (void);
// 0x000002B8 System.String System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAsString()
extern void XmlWrappedReader_ReadContentAsString_mC62B4098881C4BC1291C1E6D30FD59A655421FD6 (void);
// 0x000002B9 System.Object System.Xml.XmlDictionaryReader/XmlWrappedReader::ReadContentAs(System.Type,System.Xml.IXmlNamespaceResolver)
extern void XmlWrappedReader_ReadContentAs_mB6364B2970FE525A2EB9CBFE9B566CB473D2CB9E (void);
// 0x000002BA System.Boolean System.Xml.XmlDictionaryReader/XmlWrappedReader::HasLineInfo()
extern void XmlWrappedReader_HasLineInfo_m2A50D6908C08681844AFC27D2D0A7E3F3C601730 (void);
// 0x000002BB System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::get_LineNumber()
extern void XmlWrappedReader_get_LineNumber_mC72C34C555F11AD151AFB4ECCAFB3BC5CCE22996 (void);
// 0x000002BC System.Int32 System.Xml.XmlDictionaryReader/XmlWrappedReader::get_LinePosition()
extern void XmlWrappedReader_get_LinePosition_m58E824774568D30D624A21697EDA53D7DC0D5591 (void);
// 0x000002BD System.Void System.Xml.XmlDictionaryReaderQuotas::.ctor()
extern void XmlDictionaryReaderQuotas__ctor_mA21CAF208B4C76F493A3728860ED36A88D635E79 (void);
// 0x000002BE System.Void System.Xml.XmlDictionaryReaderQuotas::.ctor(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Xml.XmlDictionaryReaderQuotaTypes)
extern void XmlDictionaryReaderQuotas__ctor_m7016CAF17938A0F0DACF82A8A2CBFBEBCBC29D84 (void);
// 0x000002BF System.Xml.XmlDictionaryReaderQuotas System.Xml.XmlDictionaryReaderQuotas::get_Max()
extern void XmlDictionaryReaderQuotas_get_Max_m484BBCE075849747D34B2E53D8FA636B1B53E05A (void);
// 0x000002C0 System.Void System.Xml.XmlDictionaryReaderQuotas::CopyTo(System.Xml.XmlDictionaryReaderQuotas)
extern void XmlDictionaryReaderQuotas_CopyTo_m43426A5E7C91A8F959EAB3658EB3BC5050BF966D (void);
// 0x000002C1 System.Void System.Xml.XmlDictionaryReaderQuotas::InternalCopyTo(System.Xml.XmlDictionaryReaderQuotas)
extern void XmlDictionaryReaderQuotas_InternalCopyTo_m752609DBD59B02A2AC2F1D6CEA68732BA44DE01C (void);
// 0x000002C2 System.Int32 System.Xml.XmlDictionaryReaderQuotas::get_MaxStringContentLength()
extern void XmlDictionaryReaderQuotas_get_MaxStringContentLength_mB4796F5018372D78B0F3BEE79699F400656C5A0B (void);
// 0x000002C3 System.Int32 System.Xml.XmlDictionaryReaderQuotas::get_MaxArrayLength()
extern void XmlDictionaryReaderQuotas_get_MaxArrayLength_m41A819E163B35557AAABA09B02D3DD10CB498575 (void);
// 0x000002C4 System.Int32 System.Xml.XmlDictionaryReaderQuotas::get_MaxBytesPerRead()
extern void XmlDictionaryReaderQuotas_get_MaxBytesPerRead_m999A4BC8A5BBB01757180B88F7902AC1637BAF4E (void);
// 0x000002C5 System.Int32 System.Xml.XmlDictionaryReaderQuotas::get_MaxDepth()
extern void XmlDictionaryReaderQuotas_get_MaxDepth_mCE20B87DB0ED756DD6B79ABA7A625ABFA7B794A4 (void);
// 0x000002C6 System.Int32 System.Xml.XmlDictionaryReaderQuotas::get_MaxNameTableCharCount()
extern void XmlDictionaryReaderQuotas_get_MaxNameTableCharCount_mC24ED7B957C87884986C2FDC250C790F3576E59C (void);
// 0x000002C7 System.Void System.Xml.XmlDictionaryReaderQuotas::MakeReadOnly()
extern void XmlDictionaryReaderQuotas_MakeReadOnly_m3E6E37DC6075A3C3CFBD21606328AECED70E9B72 (void);
// 0x000002C8 System.Void System.Xml.XmlDictionaryReaderQuotas::.cctor()
extern void XmlDictionaryReaderQuotas__cctor_m06B6A24320F4B778ED23A76086DF7FE0EDEFD613 (void);
// 0x000002C9 System.Void System.Xml.XmlDictionaryString::.ctor(System.Xml.IXmlDictionary,System.String,System.Int32)
extern void XmlDictionaryString__ctor_m269BA79FE70EBBA2C5FCBD0B0FE3FB69E802CB0B (void);
// 0x000002CA System.String System.Xml.XmlDictionaryString::GetString(System.Xml.XmlDictionaryString)
extern void XmlDictionaryString_GetString_mD837436BDE4F576F650DEADD1AA492ABB3D3FF6E (void);
// 0x000002CB System.Xml.XmlDictionaryString System.Xml.XmlDictionaryString::get_Empty()
extern void XmlDictionaryString_get_Empty_m8A0AA908A06EED85F0058E4617CB0411154FE85A (void);
// 0x000002CC System.Xml.IXmlDictionary System.Xml.XmlDictionaryString::get_Dictionary()
extern void XmlDictionaryString_get_Dictionary_m233D200A59470470191AB39BFE27B731B7FBF710 (void);
// 0x000002CD System.Int32 System.Xml.XmlDictionaryString::get_Key()
extern void XmlDictionaryString_get_Key_m681F82FDDFCD6F976122A6A0D39675B0ED7FDC48 (void);
// 0x000002CE System.String System.Xml.XmlDictionaryString::get_Value()
extern void XmlDictionaryString_get_Value_m193A6C5E88D06CDFDA1FC7AE98FECCA4EF49538B (void);
// 0x000002CF System.Byte[] System.Xml.XmlDictionaryString::ToUTF8()
extern void XmlDictionaryString_ToUTF8_mDF4D7D163A6D954AE30A8A18BBBA1B64F0C34D5F (void);
// 0x000002D0 System.String System.Xml.XmlDictionaryString::ToString()
extern void XmlDictionaryString_ToString_m1A56D65E3EE75A12A3080EC8E94DD1349AF6890C (void);
// 0x000002D1 System.Void System.Xml.XmlDictionaryString::.cctor()
extern void XmlDictionaryString__cctor_m0CDA16203D5C4015813F618C8749AD55BE334B1E (void);
// 0x000002D2 System.Void System.Xml.XmlDictionaryString/EmptyStringDictionary::.ctor()
extern void EmptyStringDictionary__ctor_mFAFB66785724EA019768B44A9F5AE1B0643601E0 (void);
// 0x000002D3 System.Xml.XmlDictionaryString System.Xml.XmlDictionaryString/EmptyStringDictionary::get_EmptyString()
extern void EmptyStringDictionary_get_EmptyString_m96A56F06EC8A1A8415FF132730CC50BF9EDF6B93 (void);
// 0x000002D4 System.Boolean System.Xml.XmlDictionaryString/EmptyStringDictionary::TryLookup(System.Int32,System.Xml.XmlDictionaryString&)
extern void EmptyStringDictionary_TryLookup_m22EB86EC447F0F806C2F38798837FA3664FD1868 (void);
// 0x000002D5 System.Void System.Xml.XmlNodeWriter::Flush()
// 0x000002D6 System.Void System.Xml.XmlNodeWriter::Close()
// 0x000002D7 System.Void System.Xml.XmlNodeWriter::WriteDeclaration()
// 0x000002D8 System.Void System.Xml.XmlNodeWriter::WriteComment(System.String)
// 0x000002D9 System.Void System.Xml.XmlNodeWriter::WriteStartElement(System.String,System.String)
// 0x000002DA System.Void System.Xml.XmlNodeWriter::WriteStartElement(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlNodeWriter_WriteStartElement_m295A1D3B7AE38E06316A3E42796016B53EA4C0F3 (void);
// 0x000002DB System.Void System.Xml.XmlNodeWriter::WriteEndStartElement(System.Boolean)
// 0x000002DC System.Void System.Xml.XmlNodeWriter::WriteEndElement(System.String,System.String)
// 0x000002DD System.Void System.Xml.XmlNodeWriter::WriteEndElement(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlNodeWriter_WriteEndElement_m4EA7DA992828B0D1B8C0BA87EECFD822863D6A41 (void);
// 0x000002DE System.Void System.Xml.XmlNodeWriter::WriteXmlnsAttribute(System.String,System.String)
// 0x000002DF System.Void System.Xml.XmlNodeWriter::WriteXmlnsAttribute(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlNodeWriter_WriteXmlnsAttribute_m9067BEC55FB07960455784D686795C4A26D74ECE (void);
// 0x000002E0 System.Void System.Xml.XmlNodeWriter::WriteStartAttribute(System.String,System.String)
// 0x000002E1 System.Void System.Xml.XmlNodeWriter::WriteStartAttribute(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlNodeWriter_WriteStartAttribute_m3C20D28E0B00A93D119985DE0B90DF53BB7858FF (void);
// 0x000002E2 System.Void System.Xml.XmlNodeWriter::WriteEndAttribute()
// 0x000002E3 System.Void System.Xml.XmlNodeWriter::WriteCharEntity(System.Int32)
// 0x000002E4 System.Void System.Xml.XmlNodeWriter::WriteEscapedText(System.String)
// 0x000002E5 System.Void System.Xml.XmlNodeWriter::WriteEscapedText(System.Char[],System.Int32,System.Int32)
// 0x000002E6 System.Void System.Xml.XmlNodeWriter::WriteEscapedText(System.Byte[],System.Int32,System.Int32)
// 0x000002E7 System.Void System.Xml.XmlNodeWriter::WriteText(System.String)
// 0x000002E8 System.Void System.Xml.XmlNodeWriter::WriteText(System.Char[],System.Int32,System.Int32)
// 0x000002E9 System.Void System.Xml.XmlNodeWriter::WriteText(System.Byte[],System.Int32,System.Int32)
// 0x000002EA System.Void System.Xml.XmlNodeWriter::WriteInt32Text(System.Int32)
// 0x000002EB System.Void System.Xml.XmlNodeWriter::WriteInt64Text(System.Int64)
// 0x000002EC System.Void System.Xml.XmlNodeWriter::WriteUInt64Text(System.UInt64)
// 0x000002ED System.Void System.Xml.XmlNodeWriter::WriteFloatText(System.Single)
// 0x000002EE System.Void System.Xml.XmlNodeWriter::WriteDoubleText(System.Double)
// 0x000002EF System.Void System.Xml.XmlNodeWriter::WriteDecimalText(System.Decimal)
// 0x000002F0 System.Void System.Xml.XmlNodeWriter::WriteDateTimeText(System.DateTime)
// 0x000002F1 System.Void System.Xml.XmlNodeWriter::WriteUniqueIdText(System.Xml.UniqueId)
// 0x000002F2 System.Void System.Xml.XmlNodeWriter::WriteTimeSpanText(System.TimeSpan)
// 0x000002F3 System.Void System.Xml.XmlNodeWriter::WriteGuidText(System.Guid)
// 0x000002F4 System.Void System.Xml.XmlNodeWriter::WriteBase64Text(System.Byte[],System.Int32,System.Byte[],System.Int32,System.Int32)
// 0x000002F5 System.Void System.Xml.XmlSigningNodeWriter::Flush()
extern void XmlSigningNodeWriter_Flush_mFC5E17616E4E822A9B3E63105CF6E89EC385DD5C (void);
// 0x000002F6 System.Void System.Xml.XmlSigningNodeWriter::Close()
extern void XmlSigningNodeWriter_Close_mD3AF86544467FA007FE24FB9F3B1950A804DF42C (void);
// 0x000002F7 System.Void System.Xml.XmlSigningNodeWriter::WriteDeclaration()
extern void XmlSigningNodeWriter_WriteDeclaration_m55F3958DCC8968559D4C3B993748DCE19D224831 (void);
// 0x000002F8 System.Void System.Xml.XmlSigningNodeWriter::WriteComment(System.String)
extern void XmlSigningNodeWriter_WriteComment_m800FE991C5D3B5507E56E16DB15047A84DE06001 (void);
// 0x000002F9 System.Void System.Xml.XmlSigningNodeWriter::WriteStartElement(System.String,System.String)
extern void XmlSigningNodeWriter_WriteStartElement_m782ADCA21DD25B7B10F8DF0D7C15FC5B3EB097B2 (void);
// 0x000002FA System.Void System.Xml.XmlSigningNodeWriter::WriteEndStartElement(System.Boolean)
extern void XmlSigningNodeWriter_WriteEndStartElement_mB6C7227C40BA2C70168A31981D634D03640744C6 (void);
// 0x000002FB System.Void System.Xml.XmlSigningNodeWriter::WriteEndElement(System.String,System.String)
extern void XmlSigningNodeWriter_WriteEndElement_m3CF1413973ED72799E2B6091C185777E8931B273 (void);
// 0x000002FC System.Void System.Xml.XmlSigningNodeWriter::WriteXmlnsAttribute(System.String,System.String)
extern void XmlSigningNodeWriter_WriteXmlnsAttribute_mBF1B07DB694671D06527E9ADE0794D1953C41A99 (void);
// 0x000002FD System.Void System.Xml.XmlSigningNodeWriter::WriteStartAttribute(System.String,System.String)
extern void XmlSigningNodeWriter_WriteStartAttribute_m819C4959E4C6D7A0431EBBF3E5C20F55A23FCEC4 (void);
// 0x000002FE System.Void System.Xml.XmlSigningNodeWriter::WriteEndAttribute()
extern void XmlSigningNodeWriter_WriteEndAttribute_mC8F2D35A3478B2463A7D089B9A84D072496A6699 (void);
// 0x000002FF System.Void System.Xml.XmlSigningNodeWriter::WriteCharEntity(System.Int32)
extern void XmlSigningNodeWriter_WriteCharEntity_m93EF9634C08D9CF0C12859760A7A216A55940846 (void);
// 0x00000300 System.Void System.Xml.XmlSigningNodeWriter::WriteEscapedText(System.String)
extern void XmlSigningNodeWriter_WriteEscapedText_mE5E7CBA9B9AC06701A6FF6B3460FC601C31F979E (void);
// 0x00000301 System.Void System.Xml.XmlSigningNodeWriter::WriteEscapedText(System.Char[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteEscapedText_mBCB287DC7E2D6DE4AD54A7665DF5F1CF19F15478 (void);
// 0x00000302 System.Void System.Xml.XmlSigningNodeWriter::WriteEscapedText(System.Byte[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteEscapedText_m50B13618B56FABB7EC39DB93563106CDFE001558 (void);
// 0x00000303 System.Void System.Xml.XmlSigningNodeWriter::WriteText(System.String)
extern void XmlSigningNodeWriter_WriteText_m23B56CFC8840F8CD7C6983BC12CD3E6267F99B8D (void);
// 0x00000304 System.Void System.Xml.XmlSigningNodeWriter::WriteText(System.Char[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteText_m934F821AD12C7FC0EF1865D6554DF8AF1D4074CF (void);
// 0x00000305 System.Void System.Xml.XmlSigningNodeWriter::WriteText(System.Byte[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteText_mAD56C89CAB1DCA52DE2F07AD5D008CFB01B7ADD7 (void);
// 0x00000306 System.Void System.Xml.XmlSigningNodeWriter::WriteInt32Text(System.Int32)
extern void XmlSigningNodeWriter_WriteInt32Text_m10CC3E4532513268C09263F84C7EABDA5C806AA4 (void);
// 0x00000307 System.Void System.Xml.XmlSigningNodeWriter::WriteInt64Text(System.Int64)
extern void XmlSigningNodeWriter_WriteInt64Text_m01EAAEAA5B62DBE96F0E4D923DAF7DF6E3CEEDBA (void);
// 0x00000308 System.Void System.Xml.XmlSigningNodeWriter::WriteUInt64Text(System.UInt64)
extern void XmlSigningNodeWriter_WriteUInt64Text_m8F78DECBDA562448C64D0893C72EEBFD96AC3627 (void);
// 0x00000309 System.Void System.Xml.XmlSigningNodeWriter::WriteFloatText(System.Single)
extern void XmlSigningNodeWriter_WriteFloatText_mD884484ABD7D08442DAC360B4B4FF5B6EBB74565 (void);
// 0x0000030A System.Void System.Xml.XmlSigningNodeWriter::WriteDoubleText(System.Double)
extern void XmlSigningNodeWriter_WriteDoubleText_m27A4A6243FF946B20DDE6C822906E129F4F9A349 (void);
// 0x0000030B System.Void System.Xml.XmlSigningNodeWriter::WriteDecimalText(System.Decimal)
extern void XmlSigningNodeWriter_WriteDecimalText_m4E6FCA8E7B4A4E5E2E8B6A9B94B6FDC76B546B81 (void);
// 0x0000030C System.Void System.Xml.XmlSigningNodeWriter::WriteDateTimeText(System.DateTime)
extern void XmlSigningNodeWriter_WriteDateTimeText_m34D94AD32FBC8F59510F9DF6406CB2A525E75FE2 (void);
// 0x0000030D System.Void System.Xml.XmlSigningNodeWriter::WriteUniqueIdText(System.Xml.UniqueId)
extern void XmlSigningNodeWriter_WriteUniqueIdText_mB055B278B51B5F9590D30500A47B84FF7FE0783B (void);
// 0x0000030E System.Void System.Xml.XmlSigningNodeWriter::WriteTimeSpanText(System.TimeSpan)
extern void XmlSigningNodeWriter_WriteTimeSpanText_m63822F96F82ACD529C2C974F8399D0EF90BC7979 (void);
// 0x0000030F System.Void System.Xml.XmlSigningNodeWriter::WriteGuidText(System.Guid)
extern void XmlSigningNodeWriter_WriteGuidText_m08D1F63E10088DF860D021D61CD413D923C0A36C (void);
// 0x00000310 System.Void System.Xml.XmlSigningNodeWriter::WriteBase64Text(System.Byte[],System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteBase64Text_mFBDD0C216AF7586B209DA82799F4DAE6D18F6025 (void);
// 0x00000311 System.Void System.Xml.XmlSigningNodeWriter::WriteBase64Text(System.Byte[],System.Int32,System.Int32)
extern void XmlSigningNodeWriter_WriteBase64Text_m8ECD05F804E83D5BC8BA7FCCE67B3DD6D3838F15 (void);
// 0x00000312 System.Int32 System.Xml.XmlStreamNodeWriter::get_Position()
extern void XmlStreamNodeWriter_get_Position_m8A75F46C4A513BB5BE2A3D12D591E206CF65C66C (void);
// 0x00000313 System.Byte[] System.Xml.XmlStreamNodeWriter::GetBuffer(System.Int32,System.Int32&)
extern void XmlStreamNodeWriter_GetBuffer_m326E398FD0FE2C526EAEE3A938304BA3AD22653D (void);
// 0x00000314 System.Void System.Xml.XmlStreamNodeWriter::Advance(System.Int32)
extern void XmlStreamNodeWriter_Advance_m0DDFC2F7D13ED56DBA191DBC220810EC7A3A78B8 (void);
// 0x00000315 System.Void System.Xml.XmlStreamNodeWriter::EnsureByte()
extern void XmlStreamNodeWriter_EnsureByte_m0B06C1FA11B098050A26C1C78B8D25014F30B1B5 (void);
// 0x00000316 System.Void System.Xml.XmlStreamNodeWriter::WriteByte(System.Byte)
extern void XmlStreamNodeWriter_WriteByte_m7B1FE9B99669AE1D4BA00EAE2CD13686F6DECF49 (void);
// 0x00000317 System.Void System.Xml.XmlStreamNodeWriter::WriteByte(System.Char)
extern void XmlStreamNodeWriter_WriteByte_m25A407DA1CD0DE052B011D9D735914EA147D82DB (void);
// 0x00000318 System.Void System.Xml.XmlStreamNodeWriter::WriteBytes(System.Byte,System.Byte)
extern void XmlStreamNodeWriter_WriteBytes_m47FF6C042E7D67DDE5EAC75AA1DFA49FE3887191 (void);
// 0x00000319 System.Void System.Xml.XmlStreamNodeWriter::WriteBytes(System.Char,System.Char)
extern void XmlStreamNodeWriter_WriteBytes_mF473C1A3605F9DD93ABD9FB4AB9C108CA7FE1AC8 (void);
// 0x0000031A System.Void System.Xml.XmlStreamNodeWriter::WriteUTF8Char(System.Int32)
extern void XmlStreamNodeWriter_WriteUTF8Char_m8F7338B64EE9D902306ED4D8D9A796661F5040C6 (void);
// 0x0000031B System.Void System.Xml.XmlStreamNodeWriter::WriteUTF8Chars(System.Byte[],System.Int32,System.Int32)
extern void XmlStreamNodeWriter_WriteUTF8Chars_m31A03CAC6CEAB42A6BC2015B22FE663F0435FE78 (void);
// 0x0000031C System.Void System.Xml.XmlStreamNodeWriter::WriteUTF8Chars(System.String)
extern void XmlStreamNodeWriter_WriteUTF8Chars_mFC3FCDAD554AF8CAA040F3EB1A34714663FDD12A (void);
// 0x0000031D System.Void System.Xml.XmlStreamNodeWriter::UnsafeWriteUTF8Chars(System.Char*,System.Int32)
extern void XmlStreamNodeWriter_UnsafeWriteUTF8Chars_m06EFFE3C0A33684DA90E1B13B94AA8B0947BCAB1 (void);
// 0x0000031E System.Int32 System.Xml.XmlStreamNodeWriter::UnsafeGetUTF8Chars(System.Char*,System.Int32,System.Byte[],System.Int32)
extern void XmlStreamNodeWriter_UnsafeGetUTF8Chars_m86B7E49E83B34C753798BCD41EDA3696F469ED4D (void);
// 0x0000031F System.Void System.Xml.XmlStreamNodeWriter::FlushBuffer()
extern void XmlStreamNodeWriter_FlushBuffer_m4D5B21D9B54FF7CE13989E73282F65177AFA71F6 (void);
// 0x00000320 System.Void System.Xml.XmlStreamNodeWriter::Flush()
extern void XmlStreamNodeWriter_Flush_mD0F5EC4B2124D4072680ED2BB8AFD86014DC98F0 (void);
// 0x00000321 System.Void System.Xml.XmlStreamNodeWriter::Close()
extern void XmlStreamNodeWriter_Close_mB85A5C09F3512EED0E3C43B3A81E398F0812DF42 (void);
// 0x00000322 System.Void System.Xml.XmlStreamNodeWriter::.cctor()
extern void XmlStreamNodeWriter__cctor_m148DE9C4790757977E811173DF7660913262E178 (void);
// 0x00000323 System.Void System.Xml.XmlUTF8TextReader::.ctor()
extern void XmlUTF8TextReader__ctor_m24E37A9DED8D3D08E9A0899E7AC0513ABFD64A63 (void);
// 0x00000324 System.Void System.Xml.XmlUTF8TextReader::SetInput(System.IO.Stream,System.Text.Encoding,System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void XmlUTF8TextReader_SetInput_m628039266E0F8C899E01FABB655B9843801773DA (void);
// 0x00000325 System.Void System.Xml.XmlUTF8TextReader::MoveToInitial(System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void XmlUTF8TextReader_MoveToInitial_m51BD28E6B8FB38F5B11E4AE8E3FFE7657A28228A (void);
// 0x00000326 System.Void System.Xml.XmlUTF8TextReader::Close()
extern void XmlUTF8TextReader_Close_m5124EB0D653DEAD00F3B0742DF2A18AF28A05306 (void);
// 0x00000327 System.Void System.Xml.XmlUTF8TextReader::SkipWhitespace()
extern void XmlUTF8TextReader_SkipWhitespace_m79622A38D768861BBE8367FEA700023EE73C74C1 (void);
// 0x00000328 System.Void System.Xml.XmlUTF8TextReader::ReadDeclaration()
extern void XmlUTF8TextReader_ReadDeclaration_mC831B6028F0FDEEF517CF526026D8E16B2424D01 (void);
// 0x00000329 System.Void System.Xml.XmlUTF8TextReader::VerifyNCName(System.String)
extern void XmlUTF8TextReader_VerifyNCName_m57D13824CD1D24A6C21327C2E59194F1FB7B9E80 (void);
// 0x0000032A System.Void System.Xml.XmlUTF8TextReader::ReadQualifiedName(System.Xml.PrefixHandle,System.Xml.StringHandle)
extern void XmlUTF8TextReader_ReadQualifiedName_m25FF838814001C44B00D9C4C3939D13BBDDF7246 (void);
// 0x0000032B System.Int32 System.Xml.XmlUTF8TextReader::ReadAttributeText(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8TextReader_ReadAttributeText_mBDF9F756A2D27198B50502722953F17BFA0619C2 (void);
// 0x0000032C System.Void System.Xml.XmlUTF8TextReader::ReadAttributes()
extern void XmlUTF8TextReader_ReadAttributes_m3CA3ED42958AAA9D27BBFAC857561634C928924B (void);
// 0x0000032D System.Void System.Xml.XmlUTF8TextReader::ReadNonFFFE()
extern void XmlUTF8TextReader_ReadNonFFFE_mB860C6ABF2284D077A5B1F0F757D18B1040230F8 (void);
// 0x0000032E System.Boolean System.Xml.XmlUTF8TextReader::IsNextCharacterNonFFFE(System.Byte[],System.Int32)
extern void XmlUTF8TextReader_IsNextCharacterNonFFFE_m470ED7C212632CC7EF9C7FE796631E328F37D5E2 (void);
// 0x0000032F System.Void System.Xml.XmlUTF8TextReader::BufferElement()
extern void XmlUTF8TextReader_BufferElement_m30BB745AB762C671BFFD38E82C515FECD13EEC7A (void);
// 0x00000330 System.Void System.Xml.XmlUTF8TextReader::ReadStartElement()
extern void XmlUTF8TextReader_ReadStartElement_m1E5DC6D616EEAB45C5F0F50A78C6A69685EAB263 (void);
// 0x00000331 System.Void System.Xml.XmlUTF8TextReader::ReadEndElement()
extern void XmlUTF8TextReader_ReadEndElement_mA3ED56A65EC2B6815676BEE11C6BC1EDD500F617 (void);
// 0x00000332 System.Void System.Xml.XmlUTF8TextReader::ReadComment()
extern void XmlUTF8TextReader_ReadComment_m58FDA4C66B6BC7CEF298189660CF6048CD41701B (void);
// 0x00000333 System.Void System.Xml.XmlUTF8TextReader::ReadCData()
extern void XmlUTF8TextReader_ReadCData_m9CE5B0AF40FEFE039EF279CDA17A399DBB538EBB (void);
// 0x00000334 System.Int32 System.Xml.XmlUTF8TextReader::ReadCharRef()
extern void XmlUTF8TextReader_ReadCharRef_m3334575F050D4FB42BD4C627649F49B49062102D (void);
// 0x00000335 System.Void System.Xml.XmlUTF8TextReader::ReadWhitespace()
extern void XmlUTF8TextReader_ReadWhitespace_m1890CB354248770131B03D5C386AD33BDFB650F0 (void);
// 0x00000336 System.Int32 System.Xml.XmlUTF8TextReader::ReadWhitespace(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8TextReader_ReadWhitespace_mC5A34A4BE203C061D6782B0E3CC316877E1F395D (void);
// 0x00000337 System.Int32 System.Xml.XmlUTF8TextReader::ReadText(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8TextReader_ReadText_m2C13FEFB234A3C025B95971E207D1FA4F74FCD15 (void);
// 0x00000338 System.Int32 System.Xml.XmlUTF8TextReader::ReadTextAndWatchForInvalidCharacters(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8TextReader_ReadTextAndWatchForInvalidCharacters_m2B8BA60D891F5686CA9DA84BE167FCDC872F98E0 (void);
// 0x00000339 System.Int32 System.Xml.XmlUTF8TextReader::BreakText(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8TextReader_BreakText_m48D625746F367B5928D2494E57D0CFA6B707FECD (void);
// 0x0000033A System.Void System.Xml.XmlUTF8TextReader::ReadText(System.Boolean)
extern void XmlUTF8TextReader_ReadText_mBF1133DFDC23CB5A8264EF4659B78CA520645346 (void);
// 0x0000033B System.Void System.Xml.XmlUTF8TextReader::ReadEscapedText()
extern void XmlUTF8TextReader_ReadEscapedText_mF4428DD71BA49841F61F7DDAC79335812F863BBE (void);
// 0x0000033C System.Boolean System.Xml.XmlUTF8TextReader::Read()
extern void XmlUTF8TextReader_Read_mA858A9AD1130019EE6E958917CB63BE3C1554D50 (void);
// 0x0000033D System.Boolean System.Xml.XmlUTF8TextReader::HasLineInfo()
extern void XmlUTF8TextReader_HasLineInfo_mE3B1380B4F7DB5F7DA9DCED5598183A16BAC9CCC (void);
// 0x0000033E System.Int32 System.Xml.XmlUTF8TextReader::get_LineNumber()
extern void XmlUTF8TextReader_get_LineNumber_m4AACCD46715FEAF1A88CC5AC094C503E2BEE5879 (void);
// 0x0000033F System.Int32 System.Xml.XmlUTF8TextReader::get_LinePosition()
extern void XmlUTF8TextReader_get_LinePosition_m0BDFD0DE14B2AB0FA1DB066146BB7404742FA85A (void);
// 0x00000340 System.Void System.Xml.XmlUTF8TextReader::GetPosition(System.Int32&,System.Int32&)
extern void XmlUTF8TextReader_GetPosition_m36D6D03EE014CF31642B6EC4DE2C2B09789BA12F (void);
// 0x00000341 System.Void System.Xml.XmlUTF8TextReader::.cctor()
extern void XmlUTF8TextReader__cctor_m8EB968BA1D402157995DF4E67A88E8BE2CA8AB00 (void);
// 0x00000342 System.Byte[] System.Xml.XmlUTF8NodeWriter::GetCharEntityBuffer()
extern void XmlUTF8NodeWriter_GetCharEntityBuffer_mB2A5717A751FA15321E2D43B168195FE4F3DCC5E (void);
// 0x00000343 System.Char[] System.Xml.XmlUTF8NodeWriter::GetCharBuffer(System.Int32)
extern void XmlUTF8NodeWriter_GetCharBuffer_mA4B9E1511D09CE6B5EE34F9C08076A2FE2795029 (void);
// 0x00000344 System.Void System.Xml.XmlUTF8NodeWriter::WriteDeclaration()
extern void XmlUTF8NodeWriter_WriteDeclaration_m4F4D99B093DD268986CDEF9046BDBA35C2D89B68 (void);
// 0x00000345 System.Void System.Xml.XmlUTF8NodeWriter::WriteStartComment()
extern void XmlUTF8NodeWriter_WriteStartComment_m558F2B3378AAE16F66BF06D249BDAFB223A71449 (void);
// 0x00000346 System.Void System.Xml.XmlUTF8NodeWriter::WriteEndComment()
extern void XmlUTF8NodeWriter_WriteEndComment_m559FD20BA234BD5D5F0FB5067A78A8682B94F623 (void);
// 0x00000347 System.Void System.Xml.XmlUTF8NodeWriter::WriteComment(System.String)
extern void XmlUTF8NodeWriter_WriteComment_m26D03F890E9521DAF871EA1E25141D72302CD2E5 (void);
// 0x00000348 System.Void System.Xml.XmlUTF8NodeWriter::WriteStartElement(System.String,System.String)
extern void XmlUTF8NodeWriter_WriteStartElement_m4620D7B75CB3B260F69F0034B034B22E7B1A227A (void);
// 0x00000349 System.Void System.Xml.XmlUTF8NodeWriter::WriteEndStartElement(System.Boolean)
extern void XmlUTF8NodeWriter_WriteEndStartElement_m0716905A9BB896FC84E799CC83C60CFFE7E609DD (void);
// 0x0000034A System.Void System.Xml.XmlUTF8NodeWriter::WriteEndElement(System.String,System.String)
extern void XmlUTF8NodeWriter_WriteEndElement_m098B0E86DA2DCC8E07976A823213DE2F22E2C7B1 (void);
// 0x0000034B System.Void System.Xml.XmlUTF8NodeWriter::WriteStartXmlnsAttribute()
extern void XmlUTF8NodeWriter_WriteStartXmlnsAttribute_m648A206A6B972186E6A17CF9BE98F7E5721D77BE (void);
// 0x0000034C System.Void System.Xml.XmlUTF8NodeWriter::WriteXmlnsAttribute(System.String,System.String)
extern void XmlUTF8NodeWriter_WriteXmlnsAttribute_m1808DFD28206C7A0FEFC660CE8FEA227E59F3ADE (void);
// 0x0000034D System.Void System.Xml.XmlUTF8NodeWriter::WriteStartAttribute(System.String,System.String)
extern void XmlUTF8NodeWriter_WriteStartAttribute_m17B9C5E365746275454BDAFEF839D6D1BA8A76DE (void);
// 0x0000034E System.Void System.Xml.XmlUTF8NodeWriter::WriteEndAttribute()
extern void XmlUTF8NodeWriter_WriteEndAttribute_m395780ABB5DB14155208F3FDA2481AB1A2B5AE93 (void);
// 0x0000034F System.Void System.Xml.XmlUTF8NodeWriter::WritePrefix(System.String)
extern void XmlUTF8NodeWriter_WritePrefix_m27DABE170E1EBA07CE92439C901DA156330DD6AB (void);
// 0x00000350 System.Void System.Xml.XmlUTF8NodeWriter::WriteLocalName(System.String)
extern void XmlUTF8NodeWriter_WriteLocalName_m46F15EDCF17464FF03664248CB942A068FA8B1FD (void);
// 0x00000351 System.Void System.Xml.XmlUTF8NodeWriter::WriteEscapedText(System.String)
extern void XmlUTF8NodeWriter_WriteEscapedText_m8FF4C38BCD3D8938752F7996FC03C7360FC9516F (void);
// 0x00000352 System.Void System.Xml.XmlUTF8NodeWriter::WriteEscapedText(System.Char[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_WriteEscapedText_mADE01614A1692E3302539AE6E6061D2237869F9B (void);
// 0x00000353 System.Void System.Xml.XmlUTF8NodeWriter::UnsafeWriteEscapedText(System.Char*,System.Int32)
extern void XmlUTF8NodeWriter_UnsafeWriteEscapedText_mEABA506B8B2A13A7557153CCF123D4CE886C9F78 (void);
// 0x00000354 System.Void System.Xml.XmlUTF8NodeWriter::WriteEscapedText(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_WriteEscapedText_mD51B04BAADE4225B27A222BFBDA9E9F6C659EFAD (void);
// 0x00000355 System.Void System.Xml.XmlUTF8NodeWriter::WriteText(System.Int32)
extern void XmlUTF8NodeWriter_WriteText_m5B3E9DC3E647769EAB81CE22768728B350DB180C (void);
// 0x00000356 System.Void System.Xml.XmlUTF8NodeWriter::WriteText(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_WriteText_mB23C6693B7F74CF79A15204E9F2A1D561AD15F75 (void);
// 0x00000357 System.Void System.Xml.XmlUTF8NodeWriter::WriteText(System.Char[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_WriteText_mE169416D4D2128C3A4C353C24526CBF1331BE69E (void);
// 0x00000358 System.Void System.Xml.XmlUTF8NodeWriter::WriteText(System.String)
extern void XmlUTF8NodeWriter_WriteText_m0AC61EA6ADB6D49924D015CD3425C4D1A7AE5C2B (void);
// 0x00000359 System.Void System.Xml.XmlUTF8NodeWriter::WriteLessThanCharEntity()
extern void XmlUTF8NodeWriter_WriteLessThanCharEntity_m78B63F77A6A9FD708A916FA7E271F25E080FE52F (void);
// 0x0000035A System.Void System.Xml.XmlUTF8NodeWriter::WriteGreaterThanCharEntity()
extern void XmlUTF8NodeWriter_WriteGreaterThanCharEntity_mAFAD16F4525654055EA3E1145307963A8422955A (void);
// 0x0000035B System.Void System.Xml.XmlUTF8NodeWriter::WriteAmpersandCharEntity()
extern void XmlUTF8NodeWriter_WriteAmpersandCharEntity_m2052A0341DD309502D55D7C356F8A5C7FC2D65FB (void);
// 0x0000035C System.Void System.Xml.XmlUTF8NodeWriter::WriteApostropheCharEntity()
extern void XmlUTF8NodeWriter_WriteApostropheCharEntity_m06520B44097058B10CCA7306729B902E97EF71EB (void);
// 0x0000035D System.Void System.Xml.XmlUTF8NodeWriter::WriteQuoteCharEntity()
extern void XmlUTF8NodeWriter_WriteQuoteCharEntity_m17C1BFEA5C1F72CFD4C93B682DC1E3B23B3642B7 (void);
// 0x0000035E System.Void System.Xml.XmlUTF8NodeWriter::WriteHexCharEntity(System.Int32)
extern void XmlUTF8NodeWriter_WriteHexCharEntity_mDD1CCA0248F01539F39CD2E8D1B7ED143499DDE9 (void);
// 0x0000035F System.Void System.Xml.XmlUTF8NodeWriter::WriteCharEntity(System.Int32)
extern void XmlUTF8NodeWriter_WriteCharEntity_mB31C40C8130EA4FABAACD4A5D42BB369EA28547E (void);
// 0x00000360 System.Int32 System.Xml.XmlUTF8NodeWriter::ToBase16(System.Byte[],System.Int32,System.UInt32)
extern void XmlUTF8NodeWriter_ToBase16_m4FA3B62D33191CD91EF982B0BEC79FD0BEFA89B6 (void);
// 0x00000361 System.Void System.Xml.XmlUTF8NodeWriter::WriteDecimalText(System.Decimal)
extern void XmlUTF8NodeWriter_WriteDecimalText_m8971282F0F158A2F40DADA5FCC8AAC2AC2AD5353 (void);
// 0x00000362 System.Void System.Xml.XmlUTF8NodeWriter::WriteDoubleText(System.Double)
extern void XmlUTF8NodeWriter_WriteDoubleText_m5B05FC80CE9FB534D9994EFFF17DA05606CD25B1 (void);
// 0x00000363 System.Void System.Xml.XmlUTF8NodeWriter::WriteFloatText(System.Single)
extern void XmlUTF8NodeWriter_WriteFloatText_m3934342548A39E88ED41A85581DDAD5105CA4153 (void);
// 0x00000364 System.Void System.Xml.XmlUTF8NodeWriter::WriteDateTimeText(System.DateTime)
extern void XmlUTF8NodeWriter_WriteDateTimeText_m6CB99EF963CABF144ECABEE98E5AB921A2C5C4F6 (void);
// 0x00000365 System.Void System.Xml.XmlUTF8NodeWriter::WriteUniqueIdText(System.Xml.UniqueId)
extern void XmlUTF8NodeWriter_WriteUniqueIdText_m3C494B84873007BFB47558198CD27BC6F4555AE0 (void);
// 0x00000366 System.Void System.Xml.XmlUTF8NodeWriter::WriteInt32Text(System.Int32)
extern void XmlUTF8NodeWriter_WriteInt32Text_mCB87DC533493088F562B68FAC8372A62693F479E (void);
// 0x00000367 System.Void System.Xml.XmlUTF8NodeWriter::WriteInt64Text(System.Int64)
extern void XmlUTF8NodeWriter_WriteInt64Text_m671D1DA84AF29EAA738BFE2D31981D09539A59B7 (void);
// 0x00000368 System.Void System.Xml.XmlUTF8NodeWriter::WriteUInt64Text(System.UInt64)
extern void XmlUTF8NodeWriter_WriteUInt64Text_m453CDF0ADF4968FB5B2023F97D78A883A099E709 (void);
// 0x00000369 System.Void System.Xml.XmlUTF8NodeWriter::WriteGuidText(System.Guid)
extern void XmlUTF8NodeWriter_WriteGuidText_mC29137470190836FBC132C9A200DE0918EA5DA14 (void);
// 0x0000036A System.Void System.Xml.XmlUTF8NodeWriter::WriteBase64Text(System.Byte[],System.Int32,System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_WriteBase64Text_m7BC174F8852B9618E3594A9CEA0EA4E4058C7E04 (void);
// 0x0000036B System.Void System.Xml.XmlUTF8NodeWriter::InternalWriteBase64Text(System.Byte[],System.Int32,System.Int32)
extern void XmlUTF8NodeWriter_InternalWriteBase64Text_m0E173F1D8A301C7FA02B1DAFE961036B0D8BA71E (void);
// 0x0000036C System.Void System.Xml.XmlUTF8NodeWriter::WriteTimeSpanText(System.TimeSpan)
extern void XmlUTF8NodeWriter_WriteTimeSpanText_mB86D96EF5AC05C78CD8101CDC58D902B20BF990D (void);
// 0x0000036D System.Void System.Xml.XmlUTF8NodeWriter::.cctor()
extern void XmlUTF8NodeWriter__cctor_mF9C5EC8E57CD2A590E05550E771736D6F2A54F0C (void);
// 0x0000036E System.Void System.Xml.XmlExceptionHelper::ThrowXmlException(System.Xml.XmlDictionaryReader,System.String)
extern void XmlExceptionHelper_ThrowXmlException_m9CAE837E532956B71A045E068C32D576E0210647 (void);
// 0x0000036F System.Void System.Xml.XmlExceptionHelper::ThrowXmlException(System.Xml.XmlDictionaryReader,System.String,System.String)
extern void XmlExceptionHelper_ThrowXmlException_m51FA892F8FE973F87CFD72FB4EE1F225A270BA3A (void);
// 0x00000370 System.Void System.Xml.XmlExceptionHelper::ThrowXmlException(System.Xml.XmlDictionaryReader,System.String,System.String,System.String)
extern void XmlExceptionHelper_ThrowXmlException_mCAC8B944542C8B240E1BDD1C782EC9CCF8A0528F (void);
// 0x00000371 System.Void System.Xml.XmlExceptionHelper::ThrowXmlException(System.Xml.XmlDictionaryReader,System.String,System.String,System.String,System.String)
extern void XmlExceptionHelper_ThrowXmlException_m54C8B0AE5F3D1B9637DAE7C51249AE4AFEE74991 (void);
// 0x00000372 System.Void System.Xml.XmlExceptionHelper::ThrowXmlException(System.Xml.XmlDictionaryReader,System.Xml.XmlException)
extern void XmlExceptionHelper_ThrowXmlException_mEB4619E7E893211CB9486DE9A0FEDFB0A9943DBC (void);
// 0x00000373 System.String System.Xml.XmlExceptionHelper::GetName(System.String,System.String)
extern void XmlExceptionHelper_GetName_m6DA69A2E5B90FC8B101252C17ACD452AED65E746 (void);
// 0x00000374 System.String System.Xml.XmlExceptionHelper::GetWhatWasFound(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_GetWhatWasFound_m181A4BDBD95C74A19DB5AF3362E7AE89998725E1 (void);
// 0x00000375 System.Void System.Xml.XmlExceptionHelper::ThrowStartElementExpected(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowStartElementExpected_m8D7DC58E8FCC246981733C52E7F9FD18C3E9DC92 (void);
// 0x00000376 System.Void System.Xml.XmlExceptionHelper::ThrowEndElementExpected(System.Xml.XmlDictionaryReader,System.String,System.String)
extern void XmlExceptionHelper_ThrowEndElementExpected_mB7B44BEE122859BD8F08008C1D4602360717DDA2 (void);
// 0x00000377 System.Void System.Xml.XmlExceptionHelper::ThrowMaxStringContentLengthExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxStringContentLengthExceeded_mB5A4A675F73F149C01DF355BA601D00E13A0B264 (void);
// 0x00000378 System.Void System.Xml.XmlExceptionHelper::ThrowMaxArrayLengthExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxArrayLengthExceeded_mDE31F18D5F2A78DF4D666B2B929280A260673A7D (void);
// 0x00000379 System.Void System.Xml.XmlExceptionHelper::ThrowMaxArrayLengthOrMaxItemsQuotaExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxArrayLengthOrMaxItemsQuotaExceeded_m3DE6227A4CBA7F38C4FB24D6D826299BB8295966 (void);
// 0x0000037A System.Void System.Xml.XmlExceptionHelper::ThrowMaxDepthExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxDepthExceeded_m98FCAAB451F07B7DEC230EFCBD47DD9348D90EA4 (void);
// 0x0000037B System.Void System.Xml.XmlExceptionHelper::ThrowMaxBytesPerReadExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxBytesPerReadExceeded_m00F4653331C6F7120292CA9F65C08ED578FAF9B4 (void);
// 0x0000037C System.Void System.Xml.XmlExceptionHelper::ThrowMaxNameTableCharCountExceeded(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowMaxNameTableCharCountExceeded_mC86AAE44E4436DC102ADA7BCE12A3F9BB08E4B44 (void);
// 0x0000037D System.Void System.Xml.XmlExceptionHelper::ThrowBase64DataExpected(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowBase64DataExpected_m346A44349879059878180790C9A87C7EC1FD7D21 (void);
// 0x0000037E System.Void System.Xml.XmlExceptionHelper::ThrowUndefinedPrefix(System.Xml.XmlDictionaryReader,System.String)
extern void XmlExceptionHelper_ThrowUndefinedPrefix_m9A5D3AA34F7C20BB7CD8BAEF5233CE9C7345ACEA (void);
// 0x0000037F System.Void System.Xml.XmlExceptionHelper::ThrowProcessingInstructionNotSupported(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowProcessingInstructionNotSupported_m30E0C1E97C3FC693F75CC767E7ABA3F554F5FC32 (void);
// 0x00000380 System.Void System.Xml.XmlExceptionHelper::ThrowInvalidXml(System.Xml.XmlDictionaryReader,System.Byte)
extern void XmlExceptionHelper_ThrowInvalidXml_m310012A268BDF71C94FC4F4C605D3DCB5CD6DF3B (void);
// 0x00000381 System.Void System.Xml.XmlExceptionHelper::ThrowUnexpectedEndOfFile(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowUnexpectedEndOfFile_m7C9A4D5469020BB917B4C4DFE5B408E67CD532D6 (void);
// 0x00000382 System.Void System.Xml.XmlExceptionHelper::ThrowUnexpectedEndElement(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowUnexpectedEndElement_m880D12A0C24692A7E82FEF7283A1AF87D54851F4 (void);
// 0x00000383 System.Void System.Xml.XmlExceptionHelper::ThrowTokenExpected(System.Xml.XmlDictionaryReader,System.String,System.Char)
extern void XmlExceptionHelper_ThrowTokenExpected_m218288535053C1390B223240085B1A46004DC808 (void);
// 0x00000384 System.Void System.Xml.XmlExceptionHelper::ThrowTokenExpected(System.Xml.XmlDictionaryReader,System.String,System.String)
extern void XmlExceptionHelper_ThrowTokenExpected_mAD3DE4313365889AD55CDE51A9D103229494ECD1 (void);
// 0x00000385 System.Void System.Xml.XmlExceptionHelper::ThrowInvalidCharRef(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowInvalidCharRef_mC48AC7C8FAB32BA288C434BB4B0414D9475B8A21 (void);
// 0x00000386 System.Void System.Xml.XmlExceptionHelper::ThrowTagMismatch(System.Xml.XmlDictionaryReader,System.String,System.String,System.String,System.String)
extern void XmlExceptionHelper_ThrowTagMismatch_m18881234B90DED671F7DA63B38379289C01E2A49 (void);
// 0x00000387 System.Void System.Xml.XmlExceptionHelper::ThrowDuplicateXmlnsAttribute(System.Xml.XmlDictionaryReader,System.String,System.String)
extern void XmlExceptionHelper_ThrowDuplicateXmlnsAttribute_m3C41CDEC7EC76ED3EE32BDFFDEE70049C910C53F (void);
// 0x00000388 System.Void System.Xml.XmlExceptionHelper::ThrowDuplicateAttribute(System.Xml.XmlDictionaryReader,System.String,System.String,System.String,System.String)
extern void XmlExceptionHelper_ThrowDuplicateAttribute_m42FEEDA58E6AC5390E13CA8826373622329CF1EA (void);
// 0x00000389 System.Void System.Xml.XmlExceptionHelper::ThrowInvalidBinaryFormat(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowInvalidBinaryFormat_mEF561549A3C8B62895E5A3F8CF95A1DD309AD490 (void);
// 0x0000038A System.Void System.Xml.XmlExceptionHelper::ThrowInvalidRootData(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowInvalidRootData_m0BFE3805A6AC2FD63B2BB9B00992A162367EEB1C (void);
// 0x0000038B System.Void System.Xml.XmlExceptionHelper::ThrowMultipleRootElements(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowMultipleRootElements_mD71E549C0C77B8808C45300F6A448EC9C8893215 (void);
// 0x0000038C System.Void System.Xml.XmlExceptionHelper::ThrowDeclarationNotFirst(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowDeclarationNotFirst_mBB7EA50EFE7BB6553B73691B05A4C0BFB77B58E9 (void);
// 0x0000038D System.Void System.Xml.XmlExceptionHelper::ThrowXmlDictionaryStringIDOutOfRange(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowXmlDictionaryStringIDOutOfRange_mBCAE826DAF4B325EF10662C8865E0D9B1A6B9B76 (void);
// 0x0000038E System.Void System.Xml.XmlExceptionHelper::ThrowXmlDictionaryStringIDUndefinedStatic(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowXmlDictionaryStringIDUndefinedStatic_mA290F11778A6B966919B58C8E1D21ED1AC978BA3 (void);
// 0x0000038F System.Void System.Xml.XmlExceptionHelper::ThrowXmlDictionaryStringIDUndefinedSession(System.Xml.XmlDictionaryReader,System.Int32)
extern void XmlExceptionHelper_ThrowXmlDictionaryStringIDUndefinedSession_mD995F78A96E6A5FDB3CD506528643D002A12A452 (void);
// 0x00000390 System.Void System.Xml.XmlExceptionHelper::ThrowEmptyNamespace(System.Xml.XmlDictionaryReader)
extern void XmlExceptionHelper_ThrowEmptyNamespace_m67BF85D1A5442D6602CD0169196D631E4A8C7F4F (void);
// 0x00000391 System.Xml.XmlException System.Xml.XmlExceptionHelper::CreateConversionException(System.String,System.String,System.Exception)
extern void XmlExceptionHelper_CreateConversionException_m8F81F4E882F53D9E2AA56D8F01E1A5EBB9D9B1B0 (void);
// 0x00000392 System.Xml.XmlException System.Xml.XmlExceptionHelper::CreateEncodingException(System.Byte[],System.Int32,System.Int32,System.Exception)
extern void XmlExceptionHelper_CreateEncodingException_m392ABD430CCFF9B44633D413347397947387942F (void);
// 0x00000393 System.Xml.XmlException System.Xml.XmlExceptionHelper::CreateEncodingException(System.String,System.Exception)
extern void XmlExceptionHelper_CreateEncodingException_m7B15262DE30FA7B28043F1BF2EE232549F53F8FE (void);
// 0x00000394 System.Int32 System.Text.Base64Encoding::GetMaxByteCount(System.Int32)
extern void Base64Encoding_GetMaxByteCount_m51B6111DA1895ED388A964D5D6A0BF20ED413117 (void);
// 0x00000395 System.Boolean System.Text.Base64Encoding::IsValidLeadBytes(System.Int32,System.Int32,System.Int32,System.Int32)
extern void Base64Encoding_IsValidLeadBytes_mED0B21CB66C2806EB8A548CE99E1713048A3A07F (void);
// 0x00000396 System.Boolean System.Text.Base64Encoding::IsValidTailBytes(System.Int32,System.Int32)
extern void Base64Encoding_IsValidTailBytes_mDDBBC54B947A85FFC7C6D5C265A6233FD1F5FEBF (void);
// 0x00000397 System.Int32 System.Text.Base64Encoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void Base64Encoding_GetByteCount_m971AC92CE18B71923A2444AF18D534DF50682017 (void);
// 0x00000398 System.Int32 System.Text.Base64Encoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void Base64Encoding_GetBytes_mD79082D9A60E02FECAAD4CC49F06631DB32C1A85 (void);
// 0x00000399 System.Int32 System.Text.Base64Encoding::GetBytes(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void Base64Encoding_GetBytes_mADDA35590622208F0630FA9893BCC63C0ED288D5 (void);
// 0x0000039A System.Int32 System.Text.Base64Encoding::GetMaxCharCount(System.Int32)
extern void Base64Encoding_GetMaxCharCount_m0EB4F3BD40230F4B870646D784A5BC9D827C82DF (void);
// 0x0000039B System.Int32 System.Text.Base64Encoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void Base64Encoding_GetCharCount_m34C143F8A498EA2A5AEEB5CC104D1D4DCACA4868 (void);
// 0x0000039C System.Int32 System.Text.Base64Encoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void Base64Encoding_GetChars_mC515857CD720B9CB76EA42E02644C987CE205AF1 (void);
// 0x0000039D System.Int32 System.Text.Base64Encoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void Base64Encoding_GetChars_m20E968D66ACF5FC19175B2E48C6FBEDC218D9590 (void);
// 0x0000039E System.Void System.Text.Base64Encoding::.ctor()
extern void Base64Encoding__ctor_m9C21C2C9843ED10B6E8C349B53DE92C8FE875567 (void);
// 0x0000039F System.Void System.Text.Base64Encoding::.cctor()
extern void Base64Encoding__cctor_m7A2524C6758B4B37F396E753BD2EAAA23DB5478D (void);
// 0x000003A0 System.Int32 System.Text.BinHexEncoding::GetMaxByteCount(System.Int32)
extern void BinHexEncoding_GetMaxByteCount_mE79A3E229196187097236E31ECD8CE287A421893 (void);
// 0x000003A1 System.Int32 System.Text.BinHexEncoding::GetByteCount(System.Char[],System.Int32,System.Int32)
extern void BinHexEncoding_GetByteCount_m4B8FD64FB85DCB7209135138C913C64955BDAB94 (void);
// 0x000003A2 System.Int32 System.Text.BinHexEncoding::GetBytes(System.Char[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void BinHexEncoding_GetBytes_m267604CFC36D45F53C60235E3975EFA9BC327CFA (void);
// 0x000003A3 System.Int32 System.Text.BinHexEncoding::GetMaxCharCount(System.Int32)
extern void BinHexEncoding_GetMaxCharCount_m88E770D2D9517B44316D8E3359E6B4C39DE7CA17 (void);
// 0x000003A4 System.Int32 System.Text.BinHexEncoding::GetCharCount(System.Byte[],System.Int32,System.Int32)
extern void BinHexEncoding_GetCharCount_m92846F47362E91144110B8014CABBBC13CB75BA0 (void);
// 0x000003A5 System.Int32 System.Text.BinHexEncoding::GetChars(System.Byte[],System.Int32,System.Int32,System.Char[],System.Int32)
extern void BinHexEncoding_GetChars_m247DC4AB7B98C97D5C9507725B98AC8C63776AB4 (void);
// 0x000003A6 System.Void System.Text.BinHexEncoding::.ctor()
extern void BinHexEncoding__ctor_m762C3ED54232358E05C353DE539B0B9F21721190 (void);
// 0x000003A7 System.Void System.Text.BinHexEncoding::.cctor()
extern void BinHexEncoding__cctor_m5FC2F94EBC61279968A4043B1FA687EEC680A5B4 (void);
// 0x000003A8 System.Void System.Text.SurrogateChar::.ctor(System.Int32)
extern void SurrogateChar__ctor_m0244C7438DA2C0EA0BCD7FC8280D78AEC54765E4 (void);
// 0x000003A9 System.Void System.Text.SurrogateChar::.ctor(System.Char,System.Char)
extern void SurrogateChar__ctor_mD97B515A1E75EBB7BF68D9ABE65EF556C66B683C (void);
// 0x000003AA System.Char System.Text.SurrogateChar::get_LowChar()
extern void SurrogateChar_get_LowChar_m93E0E738D16C16370CC7D14EE2FBC90869AA7007 (void);
// 0x000003AB System.Char System.Text.SurrogateChar::get_HighChar()
extern void SurrogateChar_get_HighChar_m2B1C01150EE9A470BF95D0F279A07DF8265CFF79 (void);
// 0x000003AC System.Int32 System.Text.SurrogateChar::get_Char()
extern void SurrogateChar_get_Char_mA8EF3784B38A8E24125A65F753E2BD110212E794 (void);
// 0x000003AD System.Void System.Runtime.Serialization.Attributes::.cctor()
extern void Attributes__cctor_m095FE3C97646DFCA1C184CBA01D803BE25E32A45 (void);
// 0x000003AE System.Void System.Runtime.Serialization.Attributes::Read(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_Read_m34E0BCA5F58372E4233F5125616C6F32472D3B94 (void);
// 0x000003AF System.Void System.Runtime.Serialization.Attributes::Reset()
extern void Attributes_Reset_mBF35F2C4464D14E3968D90FBA809ED6BA51A42F4 (void);
// 0x000003B0 System.Void System.Runtime.Serialization.Attributes::ReadId(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadId_m9DBD839B9C2F8C4883F5E375FB30D22D17876FB9 (void);
// 0x000003B1 System.Void System.Runtime.Serialization.Attributes::ReadRef(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadRef_mB23806DA6B509ED49401B3C05684DC8A8B4B4565 (void);
// 0x000003B2 System.Void System.Runtime.Serialization.Attributes::ReadXsiNil(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadXsiNil_mB3BBFB007134BCD5BDA03EB9F521E322814E9DEA (void);
// 0x000003B3 System.Void System.Runtime.Serialization.Attributes::ReadArraySize(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadArraySize_m99B21F0084AF07C5FDA209BEE30DD110FC3FD142 (void);
// 0x000003B4 System.Void System.Runtime.Serialization.Attributes::ReadXsiType(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadXsiType_m440D33BF09A7B4546114CE66359D85240A1D4A7A (void);
// 0x000003B5 System.Void System.Runtime.Serialization.Attributes::ReadFactoryType(System.Runtime.Serialization.XmlReaderDelegator)
extern void Attributes_ReadFactoryType_mD7878D4BF28559D2BB6EA190C723796AF5784A27 (void);
// 0x000003B6 System.Void System.Runtime.Serialization.Attributes::.ctor()
extern void Attributes__ctor_m39FA7DE4B2EB04C811FE47743887AB59AB35332E (void);
// 0x000003B7 System.Void System.Runtime.Serialization.ClassDataContract::.ctor(System.Type)
extern void ClassDataContract__ctor_m3E50BE215740931FCCAE7D635807765788ABDF9F (void);
// 0x000003B8 System.Void System.Runtime.Serialization.ClassDataContract::.ctor(System.Type,System.Xml.XmlDictionaryString,System.String[])
extern void ClassDataContract__ctor_mB2FC0D3831C2F22B4970E3F4F1B43725BC8F57E5 (void);
// 0x000003B9 System.Void System.Runtime.Serialization.ClassDataContract::InitClassDataContract()
extern void ClassDataContract_InitClassDataContract_m644CB667EED23B8BDDB318A28F89F08EFD33202C (void);
// 0x000003BA System.Runtime.Serialization.ClassDataContract System.Runtime.Serialization.ClassDataContract::get_BaseContract()
extern void ClassDataContract_get_BaseContract_m529E63AF1BBD922EFDE2B8C4DA658A84C6FFB4FB (void);
// 0x000003BB System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember> System.Runtime.Serialization.ClassDataContract::get_Members()
extern void ClassDataContract_get_Members_mCE63D5B7BC677C5DFFF987A2BC9ED58B2496A133 (void);
// 0x000003BC System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract::get_OnDeserializing()
extern void ClassDataContract_get_OnDeserializing_m8BBE2E906E203429847FFD9C8284942D2BF777F6 (void);
// 0x000003BD System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract::get_OnDeserialized()
extern void ClassDataContract_get_OnDeserialized_m638A30CDA2187CF748D8D68A544291645EC2BAA9 (void);
// 0x000003BE System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract::get_ExtensionDataSetMethod()
extern void ClassDataContract_get_ExtensionDataSetMethod_m2EAAE1FD37F47C37C3C9CAAD93D2EE653564772B (void);
// 0x000003BF System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.ClassDataContract::get_KnownDataContracts()
extern void ClassDataContract_get_KnownDataContracts_m50F67B3BDEE462E73A16F3FBF0693C8C726C8BDC (void);
// 0x000003C0 System.Boolean System.Runtime.Serialization.ClassDataContract::get_IsISerializable()
extern void ClassDataContract_get_IsISerializable_mE43B80C3AB340B96B03F590CC9C2E6BB5776F5A9 (void);
// 0x000003C1 System.Boolean System.Runtime.Serialization.ClassDataContract::get_IsNonAttributedType()
extern void ClassDataContract_get_IsNonAttributedType_mDD7E45DF027FFB545A657AE8E8E2074F9A49EBC6 (void);
// 0x000003C2 System.Boolean System.Runtime.Serialization.ClassDataContract::get_HasExtensionData()
extern void ClassDataContract_get_HasExtensionData_m818AF75DD113A22E06911F7A90CB6C30747FC17C (void);
// 0x000003C3 System.String System.Runtime.Serialization.ClassDataContract::get_SerializationExceptionMessage()
extern void ClassDataContract_get_SerializationExceptionMessage_m3F54FB2D95EBFE9E3937A6B504F49ED7FF29C016 (void);
// 0x000003C4 System.String System.Runtime.Serialization.ClassDataContract::get_DeserializationExceptionMessage()
extern void ClassDataContract_get_DeserializationExceptionMessage_m591E76B280F7313EF709519850E9518A9CEB600E (void);
// 0x000003C5 System.Boolean System.Runtime.Serialization.ClassDataContract::get_IsReadOnlyContract()
extern void ClassDataContract_get_IsReadOnlyContract_m148D29A5CAFB30D5D2F2139AA64452499FABD320 (void);
// 0x000003C6 System.Reflection.ConstructorInfo System.Runtime.Serialization.ClassDataContract::GetISerializableConstructor()
extern void ClassDataContract_GetISerializableConstructor_m5F0437F7DA13B6677BA427726780A3BBA50A951E (void);
// 0x000003C7 System.Reflection.ConstructorInfo System.Runtime.Serialization.ClassDataContract::GetNonAttributedTypeConstructor()
extern void ClassDataContract_GetNonAttributedTypeConstructor_m7C68EA3DEFB4BEF1DA8505B9B724CAF30F517B8A (void);
// 0x000003C8 System.Runtime.Serialization.XmlFormatClassReaderDelegate System.Runtime.Serialization.ClassDataContract::get_XmlFormatReaderDelegate()
extern void ClassDataContract_get_XmlFormatReaderDelegate_m8399DC772FDE5678C8C50FD5B49AF7929ED6F351 (void);
// 0x000003C9 System.Runtime.Serialization.ClassDataContract System.Runtime.Serialization.ClassDataContract::CreateClassDataContractForKeyValue(System.Type,System.Xml.XmlDictionaryString,System.String[])
extern void ClassDataContract_CreateClassDataContractForKeyValue_m7E53BA161AA7CC12A220B583F55DD0E134CFD06D (void);
// 0x000003CA System.Void System.Runtime.Serialization.ClassDataContract::CheckAndAddMember(System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember>,System.Runtime.Serialization.DataMember,System.Collections.Generic.Dictionary`2<System.String,System.Runtime.Serialization.DataMember>)
extern void ClassDataContract_CheckAndAddMember_m983623BBFCD0423695AF9ECF21C524C38FEFA58D (void);
// 0x000003CB System.Boolean System.Runtime.Serialization.ClassDataContract::IsNonAttributedTypeValidForSerialization(System.Type)
extern void ClassDataContract_IsNonAttributedTypeValidForSerialization_m9CF012F366D51DD7A23F7321850A418D8AA6DE5D (void);
// 0x000003CC System.Object System.Runtime.Serialization.ClassDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void ClassDataContract_ReadXmlValue_m2E6F19C473D3FCFA9F4E3683B263CF8502A48D16 (void);
// 0x000003CD System.Boolean System.Runtime.Serialization.ClassDataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void ClassDataContract_Equals_m87142745BAA43FBA3D4F2F0DB15F3CB697C5E069 (void);
// 0x000003CE System.Boolean System.Runtime.Serialization.ClassDataContract::IsEveryDataMemberOptional(System.Collections.Generic.IEnumerable`1<System.Runtime.Serialization.DataMember>)
extern void ClassDataContract_IsEveryDataMemberOptional_mEC90654333E338B895D8B1975FB86F16F4F43E1C (void);
// 0x000003CF System.Int32 System.Runtime.Serialization.ClassDataContract::GetHashCode()
extern void ClassDataContract_GetHashCode_m8FE32F33059E761578B7A4CC4C7D3A52DB8BAAD1 (void);
// 0x000003D0 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::.ctor(System.Type)
extern void ClassDataContractCriticalHelper__ctor_mBA4BAD32BF3CC7948FE88E6D31AEA7ABE53B896E (void);
// 0x000003D1 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::.ctor(System.Type,System.Xml.XmlDictionaryString,System.String[])
extern void ClassDataContractCriticalHelper__ctor_mD92C276A6E441A4613B8246D456DFBDA119C94B8 (void);
// 0x000003D2 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::EnsureIsReferenceImported(System.Type)
extern void ClassDataContractCriticalHelper_EnsureIsReferenceImported_mCDF1BCF4B65B4FF2EB71C22EBFFB264BDDAA0BEA (void);
// 0x000003D3 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::ImportDataMembers()
extern void ClassDataContractCriticalHelper_ImportDataMembers_m997865C92DE5FEA27C470E41FBD0990AE14DD8FC (void);
// 0x000003D4 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::SetIfGetOnlyCollection(System.Runtime.Serialization.DataMember,System.Boolean)
extern void ClassDataContractCriticalHelper_SetIfGetOnlyCollection_mEA35FF045B3A9DDF6F363624B104F8BE9FDCFF07 (void);
// 0x000003D5 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::SetIfMembersHaveConflict(System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember>)
extern void ClassDataContractCriticalHelper_SetIfMembersHaveConflict_m63B59D4DD12B3D5B506A8E05333E67E9E0C95ACA (void);
// 0x000003D6 System.Xml.XmlQualifiedName System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::GetStableNameAndSetHasDataContract(System.Type)
extern void ClassDataContractCriticalHelper_GetStableNameAndSetHasDataContract_mB89BBB0AC10D8273AAE4575ED783907FA4690AA3 (void);
// 0x000003D7 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::SetIsNonAttributedType(System.Type)
extern void ClassDataContractCriticalHelper_SetIsNonAttributedType_m1B3DC2C8DB9B7292A7B77D3EE4556444CEEBA378 (void);
// 0x000003D8 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::IsMethodOverriding(System.Reflection.MethodInfo)
extern void ClassDataContractCriticalHelper_IsMethodOverriding_m62A99A43C504008BF5553D6F09E95559F1623AF0 (void);
// 0x000003D9 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::EnsureMethodsImported()
extern void ClassDataContractCriticalHelper_EnsureMethodsImported_mF26295ABB0B3BA7CAA99226CBA31F3724364925B (void);
// 0x000003DA System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::IsValidExtensionDataSetMethod(System.Reflection.MethodInfo,System.Reflection.ParameterInfo[])
extern void ClassDataContractCriticalHelper_IsValidExtensionDataSetMethod_m5F463177CF4AD755E9C326118AC7C89FBB7AF518 (void);
// 0x000003DB System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::IsValidCallback(System.Reflection.MethodInfo,System.Reflection.ParameterInfo[],System.Type,System.Reflection.MethodInfo,System.Type&)
extern void ClassDataContractCriticalHelper_IsValidCallback_m13FFF720DEDACD6B024FBB359F8FABD76CCAEB21 (void);
// 0x000003DC System.Runtime.Serialization.ClassDataContract System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_BaseContract()
extern void ClassDataContractCriticalHelper_get_BaseContract_m9F236D272CCF39FA47996EBB7A9050BFD824007F (void);
// 0x000003DD System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::set_BaseContract(System.Runtime.Serialization.ClassDataContract)
extern void ClassDataContractCriticalHelper_set_BaseContract_m1F97E9BBCC8BF99F77170B7123A626E0BE454F8D (void);
// 0x000003DE System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember> System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_Members()
extern void ClassDataContractCriticalHelper_get_Members_m27872BAA0EBA2906AC2B765FDB130BD119B2FCEF (void);
// 0x000003DF System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_OnDeserializing()
extern void ClassDataContractCriticalHelper_get_OnDeserializing_m74B99882A8A8D3588FD723DDDBA30F2F198F007B (void);
// 0x000003E0 System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_OnDeserialized()
extern void ClassDataContractCriticalHelper_get_OnDeserialized_mF57FBAF780804258954F617A4C17AAF9112FF744 (void);
// 0x000003E1 System.Reflection.MethodInfo System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_ExtensionDataSetMethod()
extern void ClassDataContractCriticalHelper_get_ExtensionDataSetMethod_m18533F14A5D759BC4D43E3C6AC0EB3DADEAA94E1 (void);
// 0x000003E2 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_KnownDataContracts()
extern void ClassDataContractCriticalHelper_get_KnownDataContracts_m4E305E351D80366E6A2936FE79E99D062A378FE5 (void);
// 0x000003E3 System.String System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_SerializationExceptionMessage()
extern void ClassDataContractCriticalHelper_get_SerializationExceptionMessage_m50C38A04A92543BF18A007C8655832E0CA926062 (void);
// 0x000003E4 System.String System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_DeserializationExceptionMessage()
extern void ClassDataContractCriticalHelper_get_DeserializationExceptionMessage_m853DF06DBB4ACB82605A0AFBB9A8F4EA76C8EF8E (void);
// 0x000003E5 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_IsISerializable()
extern void ClassDataContractCriticalHelper_get_IsISerializable_m1C4181C96C7FC420486CA9AB1652981C2A478421 (void);
// 0x000003E6 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_HasDataContract()
extern void ClassDataContractCriticalHelper_get_HasDataContract_mE9799CB546EA4DE723F22EFA994BC0D87241AC40 (void);
// 0x000003E7 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_HasExtensionData()
extern void ClassDataContractCriticalHelper_get_HasExtensionData_m5570A5B7648C70D0C06B7A595C7E7649FD37EF12 (void);
// 0x000003E8 System.Boolean System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_IsNonAttributedType()
extern void ClassDataContractCriticalHelper_get_IsNonAttributedType_m9E1FBFE1E468684B7408B457FBB28C695E0E5E39 (void);
// 0x000003E9 System.Reflection.ConstructorInfo System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::GetISerializableConstructor()
extern void ClassDataContractCriticalHelper_GetISerializableConstructor_mA69653DE141FC276838DD101DA388834DA08F079 (void);
// 0x000003EA System.Reflection.ConstructorInfo System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::GetNonAttributedTypeConstructor()
extern void ClassDataContractCriticalHelper_GetNonAttributedTypeConstructor_m60E180482D78008C413E22D17C368028872B45A0 (void);
// 0x000003EB System.Runtime.Serialization.XmlFormatClassReaderDelegate System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_XmlFormatReaderDelegate()
extern void ClassDataContractCriticalHelper_get_XmlFormatReaderDelegate_mAD59C296EBC2473A492A2F9FF32F72518842B232 (void);
// 0x000003EC System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::set_XmlFormatReaderDelegate(System.Runtime.Serialization.XmlFormatClassReaderDelegate)
extern void ClassDataContractCriticalHelper_set_XmlFormatReaderDelegate_mBF6AF7D84E8F9F89665A34E616427DC460D4210C (void);
// 0x000003ED System.Type[] System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper::get_SerInfoCtorArgs()
extern void ClassDataContractCriticalHelper_get_SerInfoCtorArgs_mC4C84565A175F382DAC2CBB68673E50326E4E468 (void);
// 0x000003EE System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/Member::.ctor(System.Runtime.Serialization.DataMember,System.String,System.Int32)
extern void Member__ctor_mC61ED1E34A077EA1C8086CA839925EC6178F9A07 (void);
// 0x000003EF System.Int32 System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/DataMemberConflictComparer::Compare(System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/Member,System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/Member)
extern void DataMemberConflictComparer_Compare_mC4692ECB8CA1D5B09A9E95616EFB1FF7A43DB2CD (void);
// 0x000003F0 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/DataMemberConflictComparer::.ctor()
extern void DataMemberConflictComparer__ctor_m855262218ADBC28A3E49B9A1F689397086349152 (void);
// 0x000003F1 System.Void System.Runtime.Serialization.ClassDataContract/ClassDataContractCriticalHelper/DataMemberConflictComparer::.cctor()
extern void DataMemberConflictComparer__cctor_m1B480C12704B7D6AAA8DA3761E324D5ED45CC52C (void);
// 0x000003F2 System.Int32 System.Runtime.Serialization.ClassDataContract/DataMemberComparer::Compare(System.Runtime.Serialization.DataMember,System.Runtime.Serialization.DataMember)
extern void DataMemberComparer_Compare_m1FF6D7284E3BC4AC00BA9A12819A73C4E2758D94 (void);
// 0x000003F3 System.Void System.Runtime.Serialization.ClassDataContract/DataMemberComparer::.ctor()
extern void DataMemberComparer__ctor_mFF31DAF0E3C22A17CEB4B6484B1F547ED3C54834 (void);
// 0x000003F4 System.Void System.Runtime.Serialization.ClassDataContract/DataMemberComparer::.cctor()
extern void DataMemberComparer__cctor_m5BFDDF49CF8E68B5AD6FA08EF616A68A790BB781 (void);
// 0x000003F5 System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type)
extern void CollectionDataContract__ctor_m6777638B7743BA7D2B7540414442EEA2FD1EBD31 (void);
// 0x000003F6 System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type,System.Runtime.Serialization.DataContract)
extern void CollectionDataContract__ctor_mC1CB6D7117B396C7FD3848D433A5CC3E8F20C7C3 (void);
// 0x000003F7 System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.String,System.String)
extern void CollectionDataContract__ctor_m87B331D673AF72BEED811A98B391523C49DC2030 (void);
// 0x000003F8 System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Reflection.ConstructorInfo)
extern void CollectionDataContract__ctor_mDCAA85232069A07BDC2541132ECB5795E213F992 (void);
// 0x000003F9 System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Reflection.ConstructorInfo,System.Boolean)
extern void CollectionDataContract__ctor_mDBE931D1E4C29101058A49571C71ACCE62DE06D5 (void);
// 0x000003FA System.Void System.Runtime.Serialization.CollectionDataContract::.ctor(System.Type,System.String)
extern void CollectionDataContract__ctor_m7EBB9F62F194975B1686E16FFFF56EC9B88628CB (void);
// 0x000003FB System.Void System.Runtime.Serialization.CollectionDataContract::InitCollectionDataContract(System.Runtime.Serialization.DataContract)
extern void CollectionDataContract_InitCollectionDataContract_mF0611E7628FD039669A7033978C89EEF5067597D (void);
// 0x000003FC System.Type[] System.Runtime.Serialization.CollectionDataContract::get_KnownInterfaces()
extern void CollectionDataContract_get_KnownInterfaces_m60E4F0FA10A25164A5D230F9E2E4F566B1524F71 (void);
// 0x000003FD System.Runtime.Serialization.CollectionKind System.Runtime.Serialization.CollectionDataContract::get_Kind()
extern void CollectionDataContract_get_Kind_m329F001A45936109A6EDC0EFB145DF99D2F22C97 (void);
// 0x000003FE System.Type System.Runtime.Serialization.CollectionDataContract::get_ItemType()
extern void CollectionDataContract_get_ItemType_mFB4F5A43869308FF5CC6DF11F1024E1C54080BD7 (void);
// 0x000003FF System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract::get_ItemContract()
extern void CollectionDataContract_get_ItemContract_mCDACD847FA90C3D14430C2D3A44AB31947B03DD6 (void);
// 0x00000400 System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract::get_SharedTypeContract()
extern void CollectionDataContract_get_SharedTypeContract_m378BE3843E0429DBBF040A07D4C6EE8F76E53AC5 (void);
// 0x00000401 System.String System.Runtime.Serialization.CollectionDataContract::get_ItemName()
extern void CollectionDataContract_get_ItemName_m83AF5EFBAD6C9DB5675614DF56F9AEFEF4BEB523 (void);
// 0x00000402 System.Xml.XmlDictionaryString System.Runtime.Serialization.CollectionDataContract::get_CollectionItemName()
extern void CollectionDataContract_get_CollectionItemName_m33DD883B834F5F99BC7931ED4DFC0FC96F1FE4B5 (void);
// 0x00000403 System.Boolean System.Runtime.Serialization.CollectionDataContract::get_IsItemTypeNullable()
extern void CollectionDataContract_get_IsItemTypeNullable_m4B10F8B8D2F8F367B923F1D24BCDAC0B6A76A11A (void);
// 0x00000404 System.Boolean System.Runtime.Serialization.CollectionDataContract::get_IsConstructorCheckRequired()
extern void CollectionDataContract_get_IsConstructorCheckRequired_mF73FDF687A9C4730A8E0593ACDA65498DCCA582D (void);
// 0x00000405 System.Void System.Runtime.Serialization.CollectionDataContract::set_IsConstructorCheckRequired(System.Boolean)
extern void CollectionDataContract_set_IsConstructorCheckRequired_m679D74A4C1E94405F471D251B6D4BF0FD6605BCB (void);
// 0x00000406 System.Reflection.MethodInfo System.Runtime.Serialization.CollectionDataContract::get_AddMethod()
extern void CollectionDataContract_get_AddMethod_m174AB03E4E6BB82D51B5469837E3C37F49F1FA6F (void);
// 0x00000407 System.Reflection.ConstructorInfo System.Runtime.Serialization.CollectionDataContract::get_Constructor()
extern void CollectionDataContract_get_Constructor_mAAFB6CA27FF2689A337A0E18DFB5CAC054A1FCB0 (void);
// 0x00000408 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.CollectionDataContract::get_KnownDataContracts()
extern void CollectionDataContract_get_KnownDataContracts_m5093238DC6D2AEF376D8D4AF40D4CA5A2001CD04 (void);
// 0x00000409 System.String System.Runtime.Serialization.CollectionDataContract::get_InvalidCollectionInSharedContractMessage()
extern void CollectionDataContract_get_InvalidCollectionInSharedContractMessage_mEFA91099925A2DCE41AE2A9C9B7F2535B6921144 (void);
// 0x0000040A System.String System.Runtime.Serialization.CollectionDataContract::get_DeserializationExceptionMessage()
extern void CollectionDataContract_get_DeserializationExceptionMessage_m81CAC71617C1134C5409F5998CDB3CB7F66C3937 (void);
// 0x0000040B System.Boolean System.Runtime.Serialization.CollectionDataContract::get_IsReadOnlyContract()
extern void CollectionDataContract_get_IsReadOnlyContract_m62D148FE07D9526899BBB42B6F13F7D929377AA5 (void);
// 0x0000040C System.Runtime.Serialization.XmlFormatCollectionReaderDelegate System.Runtime.Serialization.CollectionDataContract::get_XmlFormatReaderDelegate()
extern void CollectionDataContract_get_XmlFormatReaderDelegate_mAFA49752954061EA2165122F118519D19729F1DF (void);
// 0x0000040D System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.CollectionDataContract::get_XmlFormatGetOnlyCollectionReaderDelegate()
extern void CollectionDataContract_get_XmlFormatGetOnlyCollectionReaderDelegate_mB73649F5A766564EA0D0917488DA387404AD0593 (void);
// 0x0000040E System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract::GetSharedTypeContract(System.Type)
extern void CollectionDataContract_GetSharedTypeContract_m97D12C8A1A052D9EC17F0553C29523DFC1251A7D (void);
// 0x0000040F System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollectionInterface(System.Type)
extern void CollectionDataContract_IsCollectionInterface_mFB04330CC719FFF02255E6BB4ECAC823A8F1A118 (void);
// 0x00000410 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollection(System.Type)
extern void CollectionDataContract_IsCollection_m76E168BFC4BE4A69568D4803E23EA45710E4382D (void);
// 0x00000411 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollection(System.Type,System.Type&)
extern void CollectionDataContract_IsCollection_m2115E35A417F7A95C8F7D775AF907D8CCE739749 (void);
// 0x00000412 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollection(System.Type,System.Boolean,System.Boolean)
extern void CollectionDataContract_IsCollection_m460F87F46D3F318593F9DEF78B9CE4242CF82404 (void);
// 0x00000413 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollectionHelper(System.Type,System.Type&,System.Boolean,System.Boolean)
extern void CollectionDataContract_IsCollectionHelper_mCE2EBCA06C72F6DEE3B194F705FA50DBD431458C (void);
// 0x00000414 System.Boolean System.Runtime.Serialization.CollectionDataContract::TryCreate(System.Type,System.Runtime.Serialization.DataContract&)
extern void CollectionDataContract_TryCreate_mFAFCC53DCCAED37F5AE01D3C4ED77E7EDCE40B8C (void);
// 0x00000415 System.Boolean System.Runtime.Serialization.CollectionDataContract::TryCreateGetOnlyCollectionDataContract(System.Type,System.Runtime.Serialization.DataContract&)
extern void CollectionDataContract_TryCreateGetOnlyCollectionDataContract_mE6063288A48271D1DCE8308338D053E3AD42EF1C (void);
// 0x00000416 System.Reflection.MethodInfo System.Runtime.Serialization.CollectionDataContract::GetTargetMethodWithName(System.String,System.Type,System.Type)
extern void CollectionDataContract_GetTargetMethodWithName_mCFD22BDA22D3DDBA387EC05E047B2838F9FAEFA3 (void);
// 0x00000417 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsArraySegment(System.Type)
extern void CollectionDataContract_IsArraySegment_m31E86998A3B7FE2531C35309C4F078265C815195 (void);
// 0x00000418 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollectionOrTryCreate(System.Type,System.Boolean,System.Runtime.Serialization.DataContract&,System.Type&,System.Boolean,System.Boolean)
extern void CollectionDataContract_IsCollectionOrTryCreate_mC5D5DB2BE67DBE34B7FDFAB2FAAB127D923521AE (void);
// 0x00000419 System.Boolean System.Runtime.Serialization.CollectionDataContract::IsCollectionDataContract(System.Type)
extern void CollectionDataContract_IsCollectionDataContract_mD414A3A90FCAB243B6C46BCE0720BD780CED28AF (void);
// 0x0000041A System.Boolean System.Runtime.Serialization.CollectionDataContract::HandleIfInvalidCollection(System.Type,System.Boolean,System.Boolean,System.Boolean,System.String,System.String,System.Runtime.Serialization.DataContract&)
extern void CollectionDataContract_HandleIfInvalidCollection_mA1335BFFDF4253DB73F6CC5A64135F64127AF7BD (void);
// 0x0000041B System.Void System.Runtime.Serialization.CollectionDataContract::GetReadOnlyCollectionExceptionMessages(System.Type,System.Boolean,System.String,System.String,System.String&,System.String&)
extern void CollectionDataContract_GetReadOnlyCollectionExceptionMessages_mAB64CC8E0C98B8551F873F6A40622288094B14D3 (void);
// 0x0000041C System.String System.Runtime.Serialization.CollectionDataContract::GetInvalidCollectionMessage(System.String,System.String,System.String)
extern void CollectionDataContract_GetInvalidCollectionMessage_m533ECA9D1644BB10184B9566584260D52BE69BA7 (void);
// 0x0000041D System.Void System.Runtime.Serialization.CollectionDataContract::FindCollectionMethodsOnInterface(System.Type,System.Type,System.Reflection.MethodInfo&,System.Reflection.MethodInfo&)
extern void CollectionDataContract_FindCollectionMethodsOnInterface_m3F1B9C4F112FB696B64A1F8A0F505E5D81AF73DF (void);
// 0x0000041E System.Void System.Runtime.Serialization.CollectionDataContract::GetCollectionMethods(System.Type,System.Type,System.Type[],System.Boolean,System.Reflection.MethodInfo&,System.Reflection.MethodInfo&)
extern void CollectionDataContract_GetCollectionMethods_m09BBF28F2549768FF7FB72AF24EC3916BEA311FD (void);
// 0x0000041F System.Boolean System.Runtime.Serialization.CollectionDataContract::IsKnownInterface(System.Type)
extern void CollectionDataContract_IsKnownInterface_mB26E3C02747E4FF0E0C5230CC7A9897F2F6C796C (void);
// 0x00000420 System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract::GetValidContract(System.Runtime.Serialization.SerializationMode)
extern void CollectionDataContract_GetValidContract_mC547E309F037ECD1E6A010344E40DEDEAF610DCD (void);
// 0x00000421 System.Void System.Runtime.Serialization.CollectionDataContract::ThrowIfInvalid()
extern void CollectionDataContract_ThrowIfInvalid_m20490FDC7C6B4F316FDA8F199891C3CA86408BD7 (void);
// 0x00000422 System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract::GetValidContract()
extern void CollectionDataContract_GetValidContract_m2B29D132D45D731FAFFA940A8FC9D65A52928043 (void);
// 0x00000423 System.Void System.Runtime.Serialization.CollectionDataContract::CheckConstructor()
extern void CollectionDataContract_CheckConstructor_m015995FD208FA3C48220DFC81DECB4CEBD80507A (void);
// 0x00000424 System.Boolean System.Runtime.Serialization.CollectionDataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void CollectionDataContract_Equals_m40243712A6696A8A7A7C9C5D941527372D5C7166 (void);
// 0x00000425 System.Int32 System.Runtime.Serialization.CollectionDataContract::GetHashCode()
extern void CollectionDataContract_GetHashCode_m7385FAD8D3FAE229E9E43F7470FD35C74113490F (void);
// 0x00000426 System.Object System.Runtime.Serialization.CollectionDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void CollectionDataContract_ReadXmlValue_m34F0B58FBC8D09E0A20DE869F0256AAE6657CDD5 (void);
// 0x00000427 System.Type[] System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_KnownInterfaces()
extern void CollectionDataContractCriticalHelper_get_KnownInterfaces_m1D9EE5FE1199A88867C688742674D7429C1FCA98 (void);
// 0x00000428 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::Init(System.Runtime.Serialization.CollectionKind,System.Type,System.Runtime.Serialization.CollectionDataContractAttribute)
extern void CollectionDataContractCriticalHelper_Init_m811BEC57B063FAEE6E0A0D7D072AA836DB1A5278 (void);
// 0x00000429 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type)
extern void CollectionDataContractCriticalHelper__ctor_m9F45111A7F3CFE02E29EE48932AD900F66D71DBF (void);
// 0x0000042A System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type,System.Runtime.Serialization.DataContract)
extern void CollectionDataContractCriticalHelper__ctor_m4BD884B606D6A433ECE0D6B2C53EA07849B831F1 (void);
// 0x0000042B System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.String,System.String)
extern void CollectionDataContractCriticalHelper__ctor_m3FD48AC7828EB8600DA49EABD8034CBD7F99229E (void);
// 0x0000042C System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Reflection.ConstructorInfo)
extern void CollectionDataContractCriticalHelper__ctor_mAB125428EF92E6C4A0F457B923F4BCDF32A45CD9 (void);
// 0x0000042D System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type,System.Runtime.Serialization.CollectionKind,System.Type,System.Reflection.MethodInfo,System.Reflection.MethodInfo,System.Reflection.ConstructorInfo,System.Boolean)
extern void CollectionDataContractCriticalHelper__ctor_m96B3BEF50A419971A951B80F4C8C0EAA1D64E7E8 (void);
// 0x0000042E System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::.ctor(System.Type,System.String)
extern void CollectionDataContractCriticalHelper__ctor_m2CA4DFE284F23E03F1F5C2E78ABE9BEF90822B03 (void);
// 0x0000042F System.Runtime.Serialization.CollectionKind System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_Kind()
extern void CollectionDataContractCriticalHelper_get_Kind_m1C7543A0E819CD0FEAC864D83C809931D7D8C47C (void);
// 0x00000430 System.Type System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_ItemType()
extern void CollectionDataContractCriticalHelper_get_ItemType_mA693E723E297CDD2B54C4C845EE578D31987881D (void);
// 0x00000431 System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_ItemContract()
extern void CollectionDataContractCriticalHelper_get_ItemContract_m05904E161F21B43F9E61E83AB1A338656CC06770 (void);
// 0x00000432 System.Runtime.Serialization.DataContract System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_SharedTypeContract()
extern void CollectionDataContractCriticalHelper_get_SharedTypeContract_m09257778C6CC3AE25C78296E6AFAD88B736A45DF (void);
// 0x00000433 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::set_SharedTypeContract(System.Runtime.Serialization.DataContract)
extern void CollectionDataContractCriticalHelper_set_SharedTypeContract_m30A8A7878D6B1322A37FC5785917AC14BC2B588A (void);
// 0x00000434 System.String System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_ItemName()
extern void CollectionDataContractCriticalHelper_get_ItemName_m3791FAF7E72319D11E8B3380FF51F78D15C32E96 (void);
// 0x00000435 System.Boolean System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_IsConstructorCheckRequired()
extern void CollectionDataContractCriticalHelper_get_IsConstructorCheckRequired_mE40470BF7CCFD35DDA99372430E8B2E473761BAA (void);
// 0x00000436 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::set_IsConstructorCheckRequired(System.Boolean)
extern void CollectionDataContractCriticalHelper_set_IsConstructorCheckRequired_m57D7BE3258E50F94C26F0937A237102C651C79CC (void);
// 0x00000437 System.Xml.XmlDictionaryString System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_CollectionItemName()
extern void CollectionDataContractCriticalHelper_get_CollectionItemName_mE9EC1481B41C3D13429B9FA3D9466188D5A4C938 (void);
// 0x00000438 System.String System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_KeyName()
extern void CollectionDataContractCriticalHelper_get_KeyName_mBC7F8ADBD7303F504C45B1478B0A7B00B99F647A (void);
// 0x00000439 System.String System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_ValueName()
extern void CollectionDataContractCriticalHelper_get_ValueName_m7368CFD1EE1C340D273E598B6721FD8A72281FDE (void);
// 0x0000043A System.Boolean System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_IsDictionary()
extern void CollectionDataContractCriticalHelper_get_IsDictionary_m7AC42B2E41FAF17E4A93A52D20E0A2F4E06D375B (void);
// 0x0000043B System.String System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_DeserializationExceptionMessage()
extern void CollectionDataContractCriticalHelper_get_DeserializationExceptionMessage_mCBBA5CC38F50B0A0630C886E51E0C3B3964C5310 (void);
// 0x0000043C System.Boolean System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_IsItemTypeNullable()
extern void CollectionDataContractCriticalHelper_get_IsItemTypeNullable_mCA5100F0F95F48A23CA8C526AB4F1F814776D7CD (void);
// 0x0000043D System.Reflection.MethodInfo System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_AddMethod()
extern void CollectionDataContractCriticalHelper_get_AddMethod_mB7C47A1D9021C5AEBD364B5A213F318EF7CCF225 (void);
// 0x0000043E System.Reflection.ConstructorInfo System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_Constructor()
extern void CollectionDataContractCriticalHelper_get_Constructor_m101B584DCB84497D277CDE5B7FD64EFFC2FC60E8 (void);
// 0x0000043F System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_KnownDataContracts()
extern void CollectionDataContractCriticalHelper_get_KnownDataContracts_mBFB905AEA00196A36769470CF6A9C98A4854EC60 (void);
// 0x00000440 System.String System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_InvalidCollectionInSharedContractMessage()
extern void CollectionDataContractCriticalHelper_get_InvalidCollectionInSharedContractMessage_mF9A210924CDB16539F8FFB9509B9925D75AD447B (void);
// 0x00000441 System.Runtime.Serialization.XmlFormatCollectionReaderDelegate System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_XmlFormatReaderDelegate()
extern void CollectionDataContractCriticalHelper_get_XmlFormatReaderDelegate_m495916F6F0FCF18D4C40928EB5453D1C5DFD43F1 (void);
// 0x00000442 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::set_XmlFormatReaderDelegate(System.Runtime.Serialization.XmlFormatCollectionReaderDelegate)
extern void CollectionDataContractCriticalHelper_set_XmlFormatReaderDelegate_m9993F514F3341CE0EE4CC6EF529016F094AA3C89 (void);
// 0x00000443 System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::get_XmlFormatGetOnlyCollectionReaderDelegate()
extern void CollectionDataContractCriticalHelper_get_XmlFormatGetOnlyCollectionReaderDelegate_mB0D49D4FFF8626D30E4D92769F21C873B732E3E3 (void);
// 0x00000444 System.Void System.Runtime.Serialization.CollectionDataContract/CollectionDataContractCriticalHelper::set_XmlFormatGetOnlyCollectionReaderDelegate(System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate)
extern void CollectionDataContractCriticalHelper_set_XmlFormatGetOnlyCollectionReaderDelegate_mD828DC3B7030CDE6D3575B83A9E8D533F1749350 (void);
// 0x00000445 System.String System.Runtime.Serialization.CollectionDataContractAttribute::get_Namespace()
extern void CollectionDataContractAttribute_get_Namespace_m574780DB3D5DC453A8CF5559E2643352B14E0519 (void);
// 0x00000446 System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsNamespaceSetExplicitly()
extern void CollectionDataContractAttribute_get_IsNamespaceSetExplicitly_m8CE70683AF7896394FA66C7104E988FADCA67DD2 (void);
// 0x00000447 System.String System.Runtime.Serialization.CollectionDataContractAttribute::get_Name()
extern void CollectionDataContractAttribute_get_Name_m26FD6BEF03EF3CA9D6A53C47508844D33D959A22 (void);
// 0x00000448 System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsNameSetExplicitly()
extern void CollectionDataContractAttribute_get_IsNameSetExplicitly_m6A375802223F3CED08B290FB1B48794863A590F8 (void);
// 0x00000449 System.String System.Runtime.Serialization.CollectionDataContractAttribute::get_ItemName()
extern void CollectionDataContractAttribute_get_ItemName_m883F4E83A02BCD9937AB904A2D1A780FC784EBE4 (void);
// 0x0000044A System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsItemNameSetExplicitly()
extern void CollectionDataContractAttribute_get_IsItemNameSetExplicitly_m5DBB018F345BF338E40ACDEC66312EBAD0DAD733 (void);
// 0x0000044B System.String System.Runtime.Serialization.CollectionDataContractAttribute::get_KeyName()
extern void CollectionDataContractAttribute_get_KeyName_m29EE583DE400478C734939AAB7AD962D615DC495 (void);
// 0x0000044C System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsReference()
extern void CollectionDataContractAttribute_get_IsReference_m549BF93C18D6FCA7337F83F12FF4B719A413199E (void);
// 0x0000044D System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsKeyNameSetExplicitly()
extern void CollectionDataContractAttribute_get_IsKeyNameSetExplicitly_mE0F6E83BE97F7688D810B4A4A2707AFE85E5642D (void);
// 0x0000044E System.String System.Runtime.Serialization.CollectionDataContractAttribute::get_ValueName()
extern void CollectionDataContractAttribute_get_ValueName_m42453A62E67DBC7C9153E88FF48FFA1B952DE4D4 (void);
// 0x0000044F System.Boolean System.Runtime.Serialization.CollectionDataContractAttribute::get_IsValueNameSetExplicitly()
extern void CollectionDataContractAttribute_get_IsValueNameSetExplicitly_mEED9A20B0E41A78141A3888A2918ADF66F0B24BF (void);
// 0x00000450 System.String System.Runtime.Serialization.ContractNamespaceAttribute::get_ClrNamespace()
extern void ContractNamespaceAttribute_get_ClrNamespace_mA5D336E6D99C126F0C7F63CC6557A7AD4DDB06ED (void);
// 0x00000451 System.String System.Runtime.Serialization.ContractNamespaceAttribute::get_ContractNamespace()
extern void ContractNamespaceAttribute_get_ContractNamespace_m5848D6C950635298259FFB1FA579A35975DEE2B3 (void);
// 0x00000452 System.Void System.Runtime.Serialization.DataContract::.ctor(System.Runtime.Serialization.DataContract/DataContractCriticalHelper)
extern void DataContract__ctor_m1E2C82B57AA621451458646C4318E646A786A7BB (void);
// 0x00000453 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetDataContract(System.Type)
extern void DataContract_GetDataContract_mBA770B937ED8D702264AB313FA59CAF5EA59E7A6 (void);
// 0x00000454 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetDataContract(System.RuntimeTypeHandle,System.Type,System.Runtime.Serialization.SerializationMode)
extern void DataContract_GetDataContract_m3CE3DD2750DE7B8D898E4660BB3336F8F8B5A98D (void);
// 0x00000455 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetDataContract(System.Int32,System.RuntimeTypeHandle,System.Runtime.Serialization.SerializationMode)
extern void DataContract_GetDataContract_mED052453E1B3BFD5D6D81AACB94C3322957080B4 (void);
// 0x00000456 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetDataContractSkipValidation(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContract_GetDataContractSkipValidation_m5F004DEDD09C2035A7BDD53E4913B061246B4F77 (void);
// 0x00000457 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetGetOnlyCollectionDataContract(System.Int32,System.RuntimeTypeHandle,System.Type,System.Runtime.Serialization.SerializationMode)
extern void DataContract_GetGetOnlyCollectionDataContract_m6BE48AB9653085A43CCEE6FCD3E1B637737E3DFD (void);
// 0x00000458 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetGetOnlyCollectionDataContractSkipValidation(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContract_GetGetOnlyCollectionDataContractSkipValidation_mBC257F1D3F65D884E1912834C6FCAF4870488418 (void);
// 0x00000459 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetDataContractForInitialization(System.Int32)
extern void DataContract_GetDataContractForInitialization_mFA1B08F22D93EC11FADBBCC88A383F581B586B0D (void);
// 0x0000045A System.Int32 System.Runtime.Serialization.DataContract::GetIdForInitialization(System.Runtime.Serialization.ClassDataContract)
extern void DataContract_GetIdForInitialization_m715CBCF1C0537A2B3A53D9A2AEF4B3888EE6C23B (void);
// 0x0000045B System.Int32 System.Runtime.Serialization.DataContract::GetId(System.RuntimeTypeHandle)
extern void DataContract_GetId_mED958E8391E92EDC169F887686083D41FF46E870 (void);
// 0x0000045C System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetBuiltInDataContract(System.Type)
extern void DataContract_GetBuiltInDataContract_mE628548EDE2AFFF85667B936484FDCC0A8552589 (void);
// 0x0000045D System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetBuiltInDataContract(System.String,System.String)
extern void DataContract_GetBuiltInDataContract_m9359391AE416A48E248AC95289BE25194E1DE63D (void);
// 0x0000045E System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetBuiltInDataContract(System.String)
extern void DataContract_GetBuiltInDataContract_m00FAD7760C718B85D38B46877D2EFF2E5AEB404D (void);
// 0x0000045F System.String System.Runtime.Serialization.DataContract::GetNamespace(System.String)
extern void DataContract_GetNamespace_m7518FB977A5E09D395CF8156326F4C9EC404F1C9 (void);
// 0x00000460 System.Void System.Runtime.Serialization.DataContract::ThrowInvalidDataContractException(System.String,System.Type)
extern void DataContract_ThrowInvalidDataContractException_mB8F8BF369DAF3D8CBDE538489172129D6D4DC8C5 (void);
// 0x00000461 System.Runtime.Serialization.DataContract/DataContractCriticalHelper System.Runtime.Serialization.DataContract::get_Helper()
extern void DataContract_get_Helper_m72DB07C7CA1851449E4D7BA1F3D0144C453AD194 (void);
// 0x00000462 System.Type System.Runtime.Serialization.DataContract::get_UnderlyingType()
extern void DataContract_get_UnderlyingType_mA80B8DE82D5132DD89B918C53F8BF73090FF67AA (void);
// 0x00000463 System.Type System.Runtime.Serialization.DataContract::get_OriginalUnderlyingType()
extern void DataContract_get_OriginalUnderlyingType_mC109835A1947C23F8DA094E2D3D2F17E7E703FC9 (void);
// 0x00000464 System.Boolean System.Runtime.Serialization.DataContract::get_IsBuiltInDataContract()
extern void DataContract_get_IsBuiltInDataContract_m36A615061FA563D2D3C5BAB1F3949F9DD723861D (void);
// 0x00000465 System.Type System.Runtime.Serialization.DataContract::get_TypeForInitialization()
extern void DataContract_get_TypeForInitialization_mAD0F05E2AE47652CB5F2DDE0D1F097544CA7EA54 (void);
// 0x00000466 System.Object System.Runtime.Serialization.DataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void DataContract_ReadXmlValue_m5501D4F81CA64E9CE07AB3B987D5AB4DAABC4E44 (void);
// 0x00000467 System.Boolean System.Runtime.Serialization.DataContract::get_IsValueType()
extern void DataContract_get_IsValueType_mE90FCD576A3C0D04985564FAA9E48E1F080B0EEF (void);
// 0x00000468 System.Boolean System.Runtime.Serialization.DataContract::get_IsReference()
extern void DataContract_get_IsReference_mF6F507AEB818C2D27548E0108C5FE32447A59224 (void);
// 0x00000469 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::get_StableName()
extern void DataContract_get_StableName_mE4BCC3ABA5EC3BB0BEF5D5CBA3166E33B6947BD5 (void);
// 0x0000046A System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.DataContract::get_KnownDataContracts()
extern void DataContract_get_KnownDataContracts_m320599888965FDD65763B468D18720B7E1E56EF8 (void);
// 0x0000046B System.Boolean System.Runtime.Serialization.DataContract::get_IsISerializable()
extern void DataContract_get_IsISerializable_mDC22E299561062AB1B835641384EA3FB10394AD9 (void);
// 0x0000046C System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract::get_Name()
extern void DataContract_get_Name_m93AB090AD25A025DADE77B3AE9B4EB0B5B1F3DD6 (void);
// 0x0000046D System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract::get_Namespace()
extern void DataContract_get_Namespace_mB5F6E1B32E31BCE96D039F093F4858C1C0A467FB (void);
// 0x0000046E System.Boolean System.Runtime.Serialization.DataContract::get_HasRoot()
extern void DataContract_get_HasRoot_m386C7A4356A2377CA46FCF9B9537D4066A7C5A04 (void);
// 0x0000046F System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract::get_TopLevelElementName()
extern void DataContract_get_TopLevelElementName_mE31D463F3A76968E57EA84AB5AEE4D987EE85CDC (void);
// 0x00000470 System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract::get_TopLevelElementNamespace()
extern void DataContract_get_TopLevelElementNamespace_m1CD514067BACECEC4511006CBE67431A6D79BFD8 (void);
// 0x00000471 System.Boolean System.Runtime.Serialization.DataContract::get_CanContainReferences()
extern void DataContract_get_CanContainReferences_mE874CFC8BAAED96E50A54E0976B7EECB5001E341 (void);
// 0x00000472 System.Boolean System.Runtime.Serialization.DataContract::get_IsPrimitive()
extern void DataContract_get_IsPrimitive_m3188C185506896283A3F1C52466CDCDBA0064686 (void);
// 0x00000473 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetValidContract(System.Runtime.Serialization.SerializationMode)
extern void DataContract_GetValidContract_m63D0284C2274CE47A8E9C249C9B6E40379EA5CA4 (void);
// 0x00000474 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract::GetValidContract()
extern void DataContract_GetValidContract_m7190DAC4CC35869BBCF0FA46CE3E8300DB2C4058 (void);
// 0x00000475 System.Reflection.MethodInfo System.Runtime.Serialization.DataContract::get_ParseMethod()
extern void DataContract_get_ParseMethod_mB620839F3FFB5E80CE71EC85452CAD3C5781627F (void);
// 0x00000476 System.Boolean System.Runtime.Serialization.DataContract::IsTypeSerializable(System.Type)
extern void DataContract_IsTypeSerializable_m821A4B66734DAF991F01AF9DD255BE7C4465A2E7 (void);
// 0x00000477 System.Boolean System.Runtime.Serialization.DataContract::IsTypeSerializable(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>)
extern void DataContract_IsTypeSerializable_m821675DD3DBE699B93B313C746E00A41F317DA3C (void);
// 0x00000478 System.Void System.Runtime.Serialization.DataContract::ValidatePreviousCollectionTypes(System.Type,System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>)
extern void DataContract_ValidatePreviousCollectionTypes_m1D9425006F5B2CD4081EC65963C9D4B2FC1C7F64 (void);
// 0x00000479 System.Type System.Runtime.Serialization.DataContract::UnwrapRedundantNullableType(System.Type)
extern void DataContract_UnwrapRedundantNullableType_m03C79ACF6392E3CF16A317BEDDC6FA2382A616A5 (void);
// 0x0000047A System.Type System.Runtime.Serialization.DataContract::UnwrapNullableType(System.Type)
extern void DataContract_UnwrapNullableType_m54576AB328942170F973DFADF67C0C22DC89CAAB (void);
// 0x0000047B System.Boolean System.Runtime.Serialization.DataContract::IsAlpha(System.Char)
extern void DataContract_IsAlpha_mD48A2E78E05CADDA07AFAB04D76C16DD1E302016 (void);
// 0x0000047C System.Boolean System.Runtime.Serialization.DataContract::IsDigit(System.Char)
extern void DataContract_IsDigit_mB5DCC80DEE3D40F8B6E68E74B79EA38239F1AD41 (void);
// 0x0000047D System.Boolean System.Runtime.Serialization.DataContract::IsAsciiLocalName(System.String)
extern void DataContract_IsAsciiLocalName_mA06C0F6F11665A6DD7C2C94D2BC647179DB6E5BA (void);
// 0x0000047E System.String System.Runtime.Serialization.DataContract::EncodeLocalName(System.String)
extern void DataContract_EncodeLocalName_m100844AB708E541ED1E482B0AB5C62711928DFAF (void);
// 0x0000047F System.Boolean System.Runtime.Serialization.DataContract::IsValidNCName(System.String)
extern void DataContract_IsValidNCName_mEF6B640C7D66A857E6BFC4FDF94121328B7F76C3 (void);
// 0x00000480 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetStableName(System.Type)
extern void DataContract_GetStableName_m78696CB03C56EDE4FBD2E4AF834369734182CB1A (void);
// 0x00000481 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetStableName(System.Type,System.Boolean&)
extern void DataContract_GetStableName_mF44BEEC6C410CF7B81FA15778115E6D0F6B93E04 (void);
// 0x00000482 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetStableName(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>,System.Boolean&)
extern void DataContract_GetStableName_m77F85CF5241B341FA89CC3F3BC17100C3685FB0B (void);
// 0x00000483 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetDCTypeStableName(System.Type,System.Runtime.Serialization.DataContractAttribute)
extern void DataContract_GetDCTypeStableName_m10153826A4B4F9A969D5D786E51EA4F49E3F965E (void);
// 0x00000484 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetNonDCTypeStableName(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>)
extern void DataContract_GetNonDCTypeStableName_mDD657ACCE09421AFC4626AD5891B2736C1B930F8 (void);
// 0x00000485 System.Boolean System.Runtime.Serialization.DataContract::TryGetBuiltInXmlAndArrayTypeStableName(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>,System.Xml.XmlQualifiedName&)
extern void DataContract_TryGetBuiltInXmlAndArrayTypeStableName_mD25BC23C07D08283DAC0C1818429B15A335A2D7F (void);
// 0x00000486 System.Boolean System.Runtime.Serialization.DataContract::TryGetDCAttribute(System.Type,System.Runtime.Serialization.DataContractAttribute&)
extern void DataContract_TryGetDCAttribute_mC97C86794EA71CF38FF43F33E3B33B94383EEDE9 (void);
// 0x00000487 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetCollectionStableName(System.Type,System.Type,System.Runtime.Serialization.CollectionDataContractAttribute&)
extern void DataContract_GetCollectionStableName_m405DAC16C532F652651AFDE0D8FA8C80E66AD6AA (void);
// 0x00000488 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetCollectionStableName(System.Type,System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Object>,System.Runtime.Serialization.CollectionDataContractAttribute&)
extern void DataContract_GetCollectionStableName_m0B59EDD0BAF6D2E37D5EAAA509B348650F782277 (void);
// 0x00000489 System.String System.Runtime.Serialization.DataContract::GetArrayPrefix(System.Type&)
extern void DataContract_GetArrayPrefix_mCA93D66234D15B8F57EBC42EE87F6E41C072E932 (void);
// 0x0000048A System.String System.Runtime.Serialization.DataContract::GetCollectionNamespace(System.String)
extern void DataContract_GetCollectionNamespace_m5C7DF725CCF526283E510F24F4BAEEFF7BEEA07D (void);
// 0x0000048B System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::GetDefaultStableName(System.Type)
extern void DataContract_GetDefaultStableName_m4480CF3DB8B9BBFBE9C17D12837351DD16E21E09 (void);
// 0x0000048C System.String System.Runtime.Serialization.DataContract::GetDefaultStableLocalName(System.Type)
extern void DataContract_GetDefaultStableLocalName_m24A5669B39829529D08FD26AD53F2BB54BA72D7F (void);
// 0x0000048D System.String System.Runtime.Serialization.DataContract::GetDefaultDataContractNamespace(System.Type)
extern void DataContract_GetDefaultDataContractNamespace_m9B9134D3DD5FABE803133444898766DA01AE07B7 (void);
// 0x0000048E System.Collections.Generic.IList`1<System.Int32> System.Runtime.Serialization.DataContract::GetDataContractNameForGenericName(System.String,System.Text.StringBuilder)
extern void DataContract_GetDataContractNameForGenericName_mE83D996F8532E605743525FAEDF1DBE84A410242 (void);
// 0x0000048F System.Boolean System.Runtime.Serialization.DataContract::IsBuiltInNamespace(System.String)
extern void DataContract_IsBuiltInNamespace_m467535334A5835E9E83B736E278E8CF5537A8765 (void);
// 0x00000490 System.String System.Runtime.Serialization.DataContract::GetDefaultStableNamespace(System.Type)
extern void DataContract_GetDefaultStableNamespace_mF8A056971CBBC8E9C089B57697217072E93650C2 (void);
// 0x00000491 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract::CreateQualifiedName(System.String,System.String)
extern void DataContract_CreateQualifiedName_mC99D649978B8EB8069DB1DE17D5C664BE746F0CA (void);
// 0x00000492 System.String System.Runtime.Serialization.DataContract::GetDefaultStableNamespace(System.String)
extern void DataContract_GetDefaultStableNamespace_m6365ABDC0B89B7DCA933D04C454053B24907516F (void);
// 0x00000493 System.Void System.Runtime.Serialization.DataContract::CheckExplicitDataContractNamespaceUri(System.String,System.Type)
extern void DataContract_CheckExplicitDataContractNamespaceUri_m76D26F1487B1CC46525B466872EB7AC6EAD40E36 (void);
// 0x00000494 System.String System.Runtime.Serialization.DataContract::GetClrTypeFullName(System.Type)
extern void DataContract_GetClrTypeFullName_m1DD7F24A5238F620D71A4B65BE8389637FA3E42D (void);
// 0x00000495 System.Void System.Runtime.Serialization.DataContract::GetClrNameAndNamespace(System.String,System.String&,System.String&)
extern void DataContract_GetClrNameAndNamespace_mADC018571399B9D453E7ED6C7DAB7036CF100C57 (void);
// 0x00000496 System.Void System.Runtime.Serialization.DataContract::GetDefaultStableName(System.String,System.String&,System.String&)
extern void DataContract_GetDefaultStableName_m616C5878A297A0EFA4D53F8DCA29371DD15CA3C7 (void);
// 0x00000497 System.Void System.Runtime.Serialization.DataContract::GetDefaultStableName(System.Runtime.Serialization.CodeTypeReference,System.String&,System.String&)
extern void DataContract_GetDefaultStableName_mF1007D156B0F2CA4252E09CB383CE8075F89AD64 (void);
// 0x00000498 System.String System.Runtime.Serialization.DataContract::GetGlobalDataContractNamespace(System.String,System.Reflection.ICustomAttributeProvider)
extern void DataContract_GetGlobalDataContractNamespace_m81BBF1211BAD23A9DFE4C9ACF83AF8AB595A466E (void);
// 0x00000499 System.String System.Runtime.Serialization.DataContract::GetNamespacesDigest(System.String)
extern void DataContract_GetNamespacesDigest_mE24791F8F0D932411B6155DB1F20CF24B34B0512 (void);
// 0x0000049A System.String System.Runtime.Serialization.DataContract::ExpandGenericParameters(System.String,System.Type)
extern void DataContract_ExpandGenericParameters_mD87910479151C802A20DC9BF7B9FD6F538C91714 (void);
// 0x0000049B System.String System.Runtime.Serialization.DataContract::ExpandGenericParameters(System.String,System.Runtime.Serialization.IGenericNameProvider)
extern void DataContract_ExpandGenericParameters_mDDD71BD2A9D2CA09ABDEFAC189990E5DFCFCB2EF (void);
// 0x0000049C System.Boolean System.Runtime.Serialization.DataContract::IsTypeNullable(System.Type)
extern void DataContract_IsTypeNullable_m9FC1E41DCD2A1320BD83CD26BBBF6044E9869C83 (void);
// 0x0000049D System.Void System.Runtime.Serialization.DataContract::ThrowTypeNotSerializable(System.Type)
extern void DataContract_ThrowTypeNotSerializable_m6BF62F8C9E8FB59C42ACF5509BD5616BBE908A07 (void);
// 0x0000049E System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.DataContract::ImportKnownTypeAttributes(System.Type)
extern void DataContract_ImportKnownTypeAttributes_m9A0721650C6A80E689C6F01B744EF2FB156BF00B (void);
// 0x0000049F System.Void System.Runtime.Serialization.DataContract::ImportKnownTypeAttributes(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Type>,System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract>&)
extern void DataContract_ImportKnownTypeAttributes_mD655F55EE5D9A4BE23B2FAD865ADA9F9FEAFA75A (void);
// 0x000004A0 System.Void System.Runtime.Serialization.DataContract::LoadKnownTypesFromConfig(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Type>,System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract>&)
extern void DataContract_LoadKnownTypesFromConfig_m1C951D8CB61D4C462D82014135E4EF1AC205EA55 (void);
// 0x000004A1 System.Void System.Runtime.Serialization.DataContract::CheckAndAdd(System.Type,System.Collections.Generic.Dictionary`2<System.Type,System.Type>,System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract>&)
extern void DataContract_CheckAndAdd_m6A20F091575F4D0075A71360F3DCEC2DAA32F75E (void);
// 0x000004A2 System.Boolean System.Runtime.Serialization.DataContract::Equals(System.Object)
extern void DataContract_Equals_m7F0B789CB328574F880142419E723DCE9FBD58B8 (void);
// 0x000004A3 System.Boolean System.Runtime.Serialization.DataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void DataContract_Equals_m5D50D881BDD8FE0140D7E992A98C9098FF1138BE (void);
// 0x000004A4 System.Boolean System.Runtime.Serialization.DataContract::IsEqualOrChecked(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void DataContract_IsEqualOrChecked_m5581DB93F379F8135AA35D9DF81C9F7B3A114A9A (void);
// 0x000004A5 System.Int32 System.Runtime.Serialization.DataContract::GetHashCode()
extern void DataContract_GetHashCode_m5A826FD58BE49EA2D312BF39009389D5C08B3C9B (void);
// 0x000004A6 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::.cctor()
extern void DataContractCriticalHelper__cctor_m49BF509877916FAFB83730A518D1209E875DE752 (void);
// 0x000004A7 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetDataContractSkipValidation(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContractCriticalHelper_GetDataContractSkipValidation_m2098609B6B36EC0D43615312A63AADDC2FF0F99C (void);
// 0x000004A8 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetGetOnlyCollectionDataContractSkipValidation(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContractCriticalHelper_GetGetOnlyCollectionDataContractSkipValidation_m7132039EE32555B1D3E3B08812AA492DB388565B (void);
// 0x000004A9 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetDataContractForInitialization(System.Int32)
extern void DataContractCriticalHelper_GetDataContractForInitialization_m09DE96D3EF9A25656EBC4347379817AC31637867 (void);
// 0x000004AA System.Int32 System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetIdForInitialization(System.Runtime.Serialization.ClassDataContract)
extern void DataContractCriticalHelper_GetIdForInitialization_m8A54EC49713DFFBEEFF26C16CEDED04CE5D1ED0E (void);
// 0x000004AB System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::ContractMatches(System.Runtime.Serialization.DataContract,System.Runtime.Serialization.DataContract)
extern void DataContractCriticalHelper_ContractMatches_m3734F8594C72177E428F89F7C2FC4799A8F6A47F (void);
// 0x000004AC System.Int32 System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetId(System.RuntimeTypeHandle)
extern void DataContractCriticalHelper_GetId_mE557F9BB20095FCCAF8AB33F2C69D9112057C3AF (void);
// 0x000004AD System.Runtime.Serialization.IntRef System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetNextId()
extern void DataContractCriticalHelper_GetNextId_m618E943FB47D7E4723F6FAE3B913E733A8B12448 (void);
// 0x000004AE System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::CreateDataContract(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContractCriticalHelper_CreateDataContract_m9169313221A6BA316B0AB0FB7C9A8E3DB61025E3 (void);
// 0x000004AF System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::AssignDataContractToId(System.Runtime.Serialization.DataContract,System.Int32)
extern void DataContractCriticalHelper_AssignDataContractToId_m6D84141D5502CA6C90DFA7A5853F50B9EB5917AD (void);
// 0x000004B0 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::CreateGetOnlyCollectionDataContract(System.Int32,System.RuntimeTypeHandle,System.Type)
extern void DataContractCriticalHelper_CreateGetOnlyCollectionDataContract_mFBD638600403066A46A3238A3EAB52DFFB1BFDCB (void);
// 0x000004B1 System.Type System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetDataContractAdapterType(System.Type)
extern void DataContractCriticalHelper_GetDataContractAdapterType_m316915A8B3A9B74E8A4CEDCFC4A1CB674FC5A8EB (void);
// 0x000004B2 System.Type System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetDataContractOriginalType(System.Type)
extern void DataContractCriticalHelper_GetDataContractOriginalType_m9D0E003124A8941323B15568705E0A27708F7A00 (void);
// 0x000004B3 System.RuntimeTypeHandle System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetDataContractAdapterTypeHandle(System.RuntimeTypeHandle)
extern void DataContractCriticalHelper_GetDataContractAdapterTypeHandle_m66B60923D77B9C6D238A91722DF07F79E8B805D2 (void);
// 0x000004B4 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetBuiltInDataContract(System.Type)
extern void DataContractCriticalHelper_GetBuiltInDataContract_m6A43FBF7DEB3056A3F0BDB7A995D3F2B0A8CBB7E (void);
// 0x000004B5 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetBuiltInDataContract(System.String,System.String)
extern void DataContractCriticalHelper_GetBuiltInDataContract_m6ADB02F5B006C9C85BDD9C914C7D4FAA19AD4CA1 (void);
// 0x000004B6 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetBuiltInDataContract(System.String)
extern void DataContractCriticalHelper_GetBuiltInDataContract_m2A577375EBFF61AA192C54A6FF854BB010C484E7 (void);
// 0x000004B7 System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::TryCreateBuiltInDataContract(System.Type,System.Runtime.Serialization.DataContract&)
extern void DataContractCriticalHelper_TryCreateBuiltInDataContract_m4FF96FEE283F4C96E5797E68DC67028C06F79F4E (void);
// 0x000004B8 System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::TryCreateBuiltInDataContract(System.String,System.String,System.Runtime.Serialization.DataContract&)
extern void DataContractCriticalHelper_TryCreateBuiltInDataContract_m6A2853E2EB93F043BAA85CD2012DCC92B6B94F3A (void);
// 0x000004B9 System.String System.Runtime.Serialization.DataContract/DataContractCriticalHelper::GetNamespace(System.String)
extern void DataContractCriticalHelper_GetNamespace_mB11BA44DF4B3E1F0D33B8182F2E5DDD0D3DB0725 (void);
// 0x000004BA System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::ThrowInvalidDataContractException(System.String,System.Type)
extern void DataContractCriticalHelper_ThrowInvalidDataContractException_m803A635A1B0176D1C677928738164CD2F78CCE96 (void);
// 0x000004BB System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::.ctor(System.Type)
extern void DataContractCriticalHelper__ctor_m8E03F6B13D9CB84CE55AF0F547A2804EE754E5F9 (void);
// 0x000004BC System.Type System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_UnderlyingType()
extern void DataContractCriticalHelper_get_UnderlyingType_mAD9098BC59866C4C135E4B17ED83D169579735F0 (void);
// 0x000004BD System.Type System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_OriginalUnderlyingType()
extern void DataContractCriticalHelper_get_OriginalUnderlyingType_m454A53FF65A804BCEBB97C657F201F9E15370F58 (void);
// 0x000004BE System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_IsBuiltInDataContract()
extern void DataContractCriticalHelper_get_IsBuiltInDataContract_mD3DD3C02A90A7BDF07BAC19A6EB8ADDF6B8F61F2 (void);
// 0x000004BF System.Type System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_TypeForInitialization()
extern void DataContractCriticalHelper_get_TypeForInitialization_m273616DEC6D4063D72574F557F8109E05065F7A6 (void);
// 0x000004C0 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::SetTypeForInitialization(System.Type)
extern void DataContractCriticalHelper_SetTypeForInitialization_m14D27CC95003B730AACBC0798912B0751381E550 (void);
// 0x000004C1 System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_IsReference()
extern void DataContractCriticalHelper_get_IsReference_m97A9D03F97467697B377B5E5F70D7E37D7170DD1 (void);
// 0x000004C2 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_IsReference(System.Boolean)
extern void DataContractCriticalHelper_set_IsReference_m8F7DFDA662E3F963F2F45BC6EC25671DEE0CD243 (void);
// 0x000004C3 System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_IsValueType()
extern void DataContractCriticalHelper_get_IsValueType_m59E332C964F68DE5D9E64E30C26CDC3A47C4B5D2 (void);
// 0x000004C4 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_IsValueType(System.Boolean)
extern void DataContractCriticalHelper_set_IsValueType_m499B65D3C5F4C27DCF597DAA8912CDF9E2AB4BF0 (void);
// 0x000004C5 System.Xml.XmlQualifiedName System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_StableName()
extern void DataContractCriticalHelper_get_StableName_m8D61D5C10EC9BCD0F4915F0F30BA373153695E8E (void);
// 0x000004C6 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_StableName(System.Xml.XmlQualifiedName)
extern void DataContractCriticalHelper_set_StableName_m7521E5449AF8127C7AD791D6049F4658AB30076D (void);
// 0x000004C7 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_KnownDataContracts()
extern void DataContractCriticalHelper_get_KnownDataContracts_mDD316C6E86B694D08A2C23AE1234E1C28D047301 (void);
// 0x000004C8 System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_IsISerializable()
extern void DataContractCriticalHelper_get_IsISerializable_mFDE1E6C2581613D0E8F26C4854B6AC5EFDFF0AE4 (void);
// 0x000004C9 System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_Name()
extern void DataContractCriticalHelper_get_Name_m43393164C029E0E5CFC0984C4CAA3F1C795717FE (void);
// 0x000004CA System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_Name(System.Xml.XmlDictionaryString)
extern void DataContractCriticalHelper_set_Name_mACDA2CAC7ACDFA3BDE0EBCF1DB50AD1A25C40E19 (void);
// 0x000004CB System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_Namespace()
extern void DataContractCriticalHelper_get_Namespace_m8C77F20DA16BA600B89CA931F343D1DD85DE68B0 (void);
// 0x000004CC System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_Namespace(System.Xml.XmlDictionaryString)
extern void DataContractCriticalHelper_set_Namespace_mA86F62FED23ACF152B7C541BF7C5A3F94CA8AA47 (void);
// 0x000004CD System.Boolean System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_HasRoot()
extern void DataContractCriticalHelper_get_HasRoot_mEA4D0DE6B9EB54A1E1E7DBB803C90AA6BD69B9FF (void);
// 0x000004CE System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::set_HasRoot(System.Boolean)
extern void DataContractCriticalHelper_set_HasRoot_mF82A90FF9E214F51AFE31017AA1926153E8BB761 (void);
// 0x000004CF System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_TopLevelElementName()
extern void DataContractCriticalHelper_get_TopLevelElementName_m7D80CDE41BDEE879B421A4305F53078E72A43699 (void);
// 0x000004D0 System.Xml.XmlDictionaryString System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_TopLevelElementNamespace()
extern void DataContractCriticalHelper_get_TopLevelElementNamespace_m2DDB324326F391448C66F620808D1004E400157F (void);
// 0x000004D1 System.Reflection.MethodInfo System.Runtime.Serialization.DataContract/DataContractCriticalHelper::get_ParseMethod()
extern void DataContractCriticalHelper_get_ParseMethod_mE05A477F83994D6FDF7082CD72D7DA8E2A23FF83 (void);
// 0x000004D2 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::SetDataContractName(System.Xml.XmlQualifiedName)
extern void DataContractCriticalHelper_SetDataContractName_m943E8C3CA5F156F84B9B1C78CEFAB630372EEAF6 (void);
// 0x000004D3 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::SetDataContractName(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void DataContractCriticalHelper_SetDataContractName_m05A1906F78DCE63B3E565F7C940D64525B999DC3 (void);
// 0x000004D4 System.Void System.Runtime.Serialization.DataContract/DataContractCriticalHelper::ThrowInvalidDataContractException(System.String)
extern void DataContractCriticalHelper_ThrowInvalidDataContractException_m504C17AA06D1870F6F47543EE3032F457269908E (void);
// 0x000004D5 System.Int32 System.Runtime.Serialization.IGenericNameProvider::GetParameterCount()
// 0x000004D6 System.Collections.Generic.IList`1<System.Int32> System.Runtime.Serialization.IGenericNameProvider::GetNestedParameterCounts()
// 0x000004D7 System.String System.Runtime.Serialization.IGenericNameProvider::GetParameterName(System.Int32)
// 0x000004D8 System.String System.Runtime.Serialization.IGenericNameProvider::GetNamespaces()
// 0x000004D9 System.String System.Runtime.Serialization.IGenericNameProvider::GetGenericTypeName()
// 0x000004DA System.Boolean System.Runtime.Serialization.IGenericNameProvider::get_ParametersFromBuiltInNamespaces()
// 0x000004DB System.Void System.Runtime.Serialization.GenericNameProvider::.ctor(System.Type)
extern void GenericNameProvider__ctor_mED6E4D4774764E36A400A32EE47BA32A435A4D61 (void);
// 0x000004DC System.Void System.Runtime.Serialization.GenericNameProvider::.ctor(System.String,System.Object[])
extern void GenericNameProvider__ctor_m56ACEB4F73A3D42917EFFEC32E519CC33044FBC9 (void);
// 0x000004DD System.Int32 System.Runtime.Serialization.GenericNameProvider::GetParameterCount()
extern void GenericNameProvider_GetParameterCount_m0A80CEBA537B9773370CBF0F8EAA924ECEEE794C (void);
// 0x000004DE System.Collections.Generic.IList`1<System.Int32> System.Runtime.Serialization.GenericNameProvider::GetNestedParameterCounts()
extern void GenericNameProvider_GetNestedParameterCounts_m584B38E5831E755D4B63B14D52787B6C42F48ED5 (void);
// 0x000004DF System.String System.Runtime.Serialization.GenericNameProvider::GetParameterName(System.Int32)
extern void GenericNameProvider_GetParameterName_mF82356AA0CD6CE8453495A012EDABD834359C3BE (void);
// 0x000004E0 System.String System.Runtime.Serialization.GenericNameProvider::GetNamespaces()
extern void GenericNameProvider_GetNamespaces_mDA2DFA5221354CE07D3EA930E72D71FBA88A5BCB (void);
// 0x000004E1 System.String System.Runtime.Serialization.GenericNameProvider::GetGenericTypeName()
extern void GenericNameProvider_GetGenericTypeName_m3D97B1EADAEBB5FD06B4B4390B3B36BF03427A3C (void);
// 0x000004E2 System.Boolean System.Runtime.Serialization.GenericNameProvider::get_ParametersFromBuiltInNamespaces()
extern void GenericNameProvider_get_ParametersFromBuiltInNamespaces_mDB90051E26BA9ADE57B760C27E6FFD92526BD39F (void);
// 0x000004E3 System.Xml.XmlQualifiedName System.Runtime.Serialization.GenericNameProvider::GetStableName(System.Int32)
extern void GenericNameProvider_GetStableName_m7CABB6AAEA86E44CA6AB28B0F03CB70C7490DC2D (void);
// 0x000004E4 System.Void System.Runtime.Serialization.DataContractPairKey::.ctor(System.Object,System.Object)
extern void DataContractPairKey__ctor_mD6FEB36BB4C3FB5A43C092025F26221D5A17B6FB (void);
// 0x000004E5 System.Boolean System.Runtime.Serialization.DataContractPairKey::Equals(System.Object)
extern void DataContractPairKey_Equals_mBBC3442B372277340CAC451DC94D47FBD47A734C (void);
// 0x000004E6 System.Int32 System.Runtime.Serialization.DataContractPairKey::GetHashCode()
extern void DataContractPairKey_GetHashCode_mCFFAE318061322C1CFBCD7F154F77A4CE7D886A9 (void);
// 0x000004E7 System.Boolean System.Runtime.Serialization.TypeHandleRefEqualityComparer::Equals(System.Runtime.Serialization.TypeHandleRef,System.Runtime.Serialization.TypeHandleRef)
extern void TypeHandleRefEqualityComparer_Equals_mCE837830517115C50890E92595A8D1D1F7E511F6 (void);
// 0x000004E8 System.Int32 System.Runtime.Serialization.TypeHandleRefEqualityComparer::GetHashCode(System.Runtime.Serialization.TypeHandleRef)
extern void TypeHandleRefEqualityComparer_GetHashCode_m6A413F34A230B39EF437801AE85A340D907DC565 (void);
// 0x000004E9 System.Void System.Runtime.Serialization.TypeHandleRefEqualityComparer::.ctor()
extern void TypeHandleRefEqualityComparer__ctor_m261B2E6494BF0BF860627AA82082D25C8CBF9D73 (void);
// 0x000004EA System.Void System.Runtime.Serialization.TypeHandleRef::.ctor()
extern void TypeHandleRef__ctor_m0531D980804EDA2984BDA3CB5774529759625C8A (void);
// 0x000004EB System.Void System.Runtime.Serialization.TypeHandleRef::.ctor(System.RuntimeTypeHandle)
extern void TypeHandleRef__ctor_mB5831268BC56493191CED6CCC45A977E5F29B2F2 (void);
// 0x000004EC System.RuntimeTypeHandle System.Runtime.Serialization.TypeHandleRef::get_Value()
extern void TypeHandleRef_get_Value_m460E97A65BC7A790BFE6BADDD43A35C7EA461E1A (void);
// 0x000004ED System.Void System.Runtime.Serialization.TypeHandleRef::set_Value(System.RuntimeTypeHandle)
extern void TypeHandleRef_set_Value_m903EE76F200BDA6885C6C7E91E01DEA1BDADFB58 (void);
// 0x000004EE System.Void System.Runtime.Serialization.IntRef::.ctor(System.Int32)
extern void IntRef__ctor_m10C215137E3118CCD8817803409C3EB9C62B1A5B (void);
// 0x000004EF System.Int32 System.Runtime.Serialization.IntRef::get_Value()
extern void IntRef_get_Value_m8756811C1EC9AEA5E938B1425056D31947BF41E6 (void);
// 0x000004F0 System.Void System.Runtime.Serialization.DataContractAttribute::.ctor()
extern void DataContractAttribute__ctor_mAFB75FDCDDBB5925CCE916496408E843E9DDB6BC (void);
// 0x000004F1 System.Boolean System.Runtime.Serialization.DataContractAttribute::get_IsReference()
extern void DataContractAttribute_get_IsReference_mEC2FFE0351B0DD896E7805670D6A614B1AE4C101 (void);
// 0x000004F2 System.Boolean System.Runtime.Serialization.DataContractAttribute::get_IsReferenceSetExplicitly()
extern void DataContractAttribute_get_IsReferenceSetExplicitly_m0469F760DCFA622F24F1298F4C9ABE7A053B8624 (void);
// 0x000004F3 System.String System.Runtime.Serialization.DataContractAttribute::get_Namespace()
extern void DataContractAttribute_get_Namespace_mA94B4E2DB961605035E012B22E09648236CE8DEA (void);
// 0x000004F4 System.Void System.Runtime.Serialization.DataContractAttribute::set_Namespace(System.String)
extern void DataContractAttribute_set_Namespace_m98C63DE53771DF8A1A1FD4C33BC508FE1A5B81D2 (void);
// 0x000004F5 System.Boolean System.Runtime.Serialization.DataContractAttribute::get_IsNamespaceSetExplicitly()
extern void DataContractAttribute_get_IsNamespaceSetExplicitly_m8361D413268F79E5EB798255273710A4335D23EF (void);
// 0x000004F6 System.String System.Runtime.Serialization.DataContractAttribute::get_Name()
extern void DataContractAttribute_get_Name_mF5B74CDE4B1F1031F2E53D93C97DC2A9136009C6 (void);
// 0x000004F7 System.Void System.Runtime.Serialization.DataContractAttribute::set_Name(System.String)
extern void DataContractAttribute_set_Name_mD6136EF537543C289BE7F68B31EFAE0F0AAC75B2 (void);
// 0x000004F8 System.Boolean System.Runtime.Serialization.DataContractAttribute::get_IsNameSetExplicitly()
extern void DataContractAttribute_get_IsNameSetExplicitly_m19BA338BCE7ECD3DF5159DF5057E1BB4B8FBF748 (void);
// 0x000004F9 System.Type System.Runtime.Serialization.DataContractResolver::ResolveName(System.String,System.String,System.Type,System.Runtime.Serialization.DataContractResolver)
// 0x000004FA System.Void System.Runtime.Serialization.DataContractResolver::.ctor()
extern void DataContractResolver__ctor_m6C6DB5E1A3B929FFC671C8CA1562BA9A2920AADD (void);
// 0x000004FB System.Void System.Runtime.Serialization.DataContractSerializer::.ctor(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>,System.Int32,System.Boolean,System.Boolean,System.Runtime.Serialization.IDataContractSurrogate)
extern void DataContractSerializer__ctor_mDDDA99C695BDBA2039E83662405D89CEE9412ED6 (void);
// 0x000004FC System.Void System.Runtime.Serialization.DataContractSerializer::.ctor(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>,System.Int32,System.Boolean,System.Boolean,System.Runtime.Serialization.IDataContractSurrogate,System.Runtime.Serialization.DataContractResolver)
extern void DataContractSerializer__ctor_m2FEBF7CC0DB3FF82C40CC16D7ED800FA76248218 (void);
// 0x000004FD System.Void System.Runtime.Serialization.DataContractSerializer::Initialize(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>,System.Int32,System.Boolean,System.Boolean,System.Runtime.Serialization.IDataContractSurrogate,System.Runtime.Serialization.DataContractResolver,System.Boolean)
extern void DataContractSerializer_Initialize_m37C156B79BBAB8F69EC539735DF8292FFBC8F2C5 (void);
// 0x000004FE System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.DataContractSerializer::get_KnownDataContracts()
extern void DataContractSerializer_get_KnownDataContracts_mD9B05083CBD12752F5ADD058627D70AFEC8F8CC2 (void);
// 0x000004FF System.Int32 System.Runtime.Serialization.DataContractSerializer::get_MaxItemsInObjectGraph()
extern void DataContractSerializer_get_MaxItemsInObjectGraph_mE82DE78DBA485CCF2418CAF816EC9E06850172CD (void);
// 0x00000500 System.Runtime.Serialization.IDataContractSurrogate System.Runtime.Serialization.DataContractSerializer::get_DataContractSurrogate()
extern void DataContractSerializer_get_DataContractSurrogate_mDDA9011DE0DBE186A0380F60EC367EFFADE56F94 (void);
// 0x00000501 System.Boolean System.Runtime.Serialization.DataContractSerializer::get_PreserveObjectReferences()
extern void DataContractSerializer_get_PreserveObjectReferences_m9E55A6805D9660F8AE1377DB56160CB1EEA611C0 (void);
// 0x00000502 System.Boolean System.Runtime.Serialization.DataContractSerializer::get_IgnoreExtensionDataObject()
extern void DataContractSerializer_get_IgnoreExtensionDataObject_m4A3062BF5E09D4C45AC7944998C97220B81B5094 (void);
// 0x00000503 System.Runtime.Serialization.DataContractResolver System.Runtime.Serialization.DataContractSerializer::get_DataContractResolver()
extern void DataContractSerializer_get_DataContractResolver_mD1F8B01596FFE7202C494BF25AF40C816A3919AF (void);
// 0x00000504 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataContractSerializer::get_RootContract()
extern void DataContractSerializer_get_RootContract_m9EC579981B3216A1004F58E2C570C4F272D6F89D (void);
// 0x00000505 System.Object System.Runtime.Serialization.DataContractSerializer::ReadObject(System.Xml.XmlReader,System.Boolean)
extern void DataContractSerializer_ReadObject_m348EE7350B992C5BCBB8DFB6F4E3641C5A8960B7 (void);
// 0x00000506 System.Object System.Runtime.Serialization.DataContractSerializer::ReadObject(System.Xml.XmlDictionaryReader,System.Boolean)
extern void DataContractSerializer_ReadObject_mF7649AB7019939ADAF8098F1196AD3F7449E9AD7 (void);
// 0x00000507 System.Object System.Runtime.Serialization.DataContractSerializer::InternalReadObject(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean)
extern void DataContractSerializer_InternalReadObject_m682E7E4787BC241E6A1F441F31BD501C362286BE (void);
// 0x00000508 System.Object System.Runtime.Serialization.DataContractSerializer::InternalReadObject(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean,System.Runtime.Serialization.DataContractResolver)
extern void DataContractSerializer_InternalReadObject_mBF5428E06638B59C3652652CB5CB3BF034770E51 (void);
// 0x00000509 System.Boolean System.Runtime.Serialization.DataContractSerializer::InternalIsStartObject(System.Runtime.Serialization.XmlReaderDelegator)
extern void DataContractSerializer_InternalIsStartObject_mCB41CA01C2597086E6A52219426D87C5EDEC269D (void);
// 0x0000050A System.Type System.Runtime.Serialization.DataContractSerializer::GetDeserializeType()
extern void DataContractSerializer_GetDeserializeType_mD7F8FD75C34D7AF820C69064813C11301AE43A85 (void);
// 0x0000050B System.Type System.Runtime.Serialization.DataContractSerializer::GetSurrogatedType(System.Runtime.Serialization.IDataContractSurrogate,System.Type)
extern void DataContractSerializer_GetSurrogatedType_m59609D54A16D71713C507B27F547571DD30CAF31 (void);
// 0x0000050C System.Void System.Runtime.Serialization.DataMember::.ctor(System.Reflection.MemberInfo)
extern void DataMember__ctor_mEAC19AE8D3C610B431DE12016BC6190F689F981F (void);
// 0x0000050D System.Reflection.MemberInfo System.Runtime.Serialization.DataMember::get_MemberInfo()
extern void DataMember_get_MemberInfo_m2D00DC6FA5407668B519576FFEB0ACADD3B11860 (void);
// 0x0000050E System.String System.Runtime.Serialization.DataMember::get_Name()
extern void DataMember_get_Name_mBC18DFBF135F56356D8D9FCDF400E0B0943742A5 (void);
// 0x0000050F System.Void System.Runtime.Serialization.DataMember::set_Name(System.String)
extern void DataMember_set_Name_m60C8535A3682967CBB879F4950A60ED78AFFBDC9 (void);
// 0x00000510 System.Int32 System.Runtime.Serialization.DataMember::get_Order()
extern void DataMember_get_Order_m08A84853E2AC3B36434D229BC9CCD2FE95C7D7E8 (void);
// 0x00000511 System.Void System.Runtime.Serialization.DataMember::set_Order(System.Int32)
extern void DataMember_set_Order_m34AFA7CB7E4424E034FD230240F033DACD1EB27D (void);
// 0x00000512 System.Boolean System.Runtime.Serialization.DataMember::get_IsRequired()
extern void DataMember_get_IsRequired_m09F670A4F84861B869C6461A9143C2C5D4147BDA (void);
// 0x00000513 System.Void System.Runtime.Serialization.DataMember::set_IsRequired(System.Boolean)
extern void DataMember_set_IsRequired_mA18592F2C87740745380BD69DC9C8018A4F0CCA1 (void);
// 0x00000514 System.Boolean System.Runtime.Serialization.DataMember::get_EmitDefaultValue()
extern void DataMember_get_EmitDefaultValue_m5A0B7B7885E875F90FAE5536ABB04FAA146A8CC7 (void);
// 0x00000515 System.Void System.Runtime.Serialization.DataMember::set_EmitDefaultValue(System.Boolean)
extern void DataMember_set_EmitDefaultValue_m17625CA1EEE12698CCD1DF86546D760EDD834103 (void);
// 0x00000516 System.Boolean System.Runtime.Serialization.DataMember::get_IsNullable()
extern void DataMember_get_IsNullable_mB58E9B51E5ABC88B76072FF92A9FE8E7413AE221 (void);
// 0x00000517 System.Void System.Runtime.Serialization.DataMember::set_IsNullable(System.Boolean)
extern void DataMember_set_IsNullable_m8FB9E9344616BC5EA0334C6B1834B6500AB9CB83 (void);
// 0x00000518 System.Boolean System.Runtime.Serialization.DataMember::get_IsGetOnlyCollection()
extern void DataMember_get_IsGetOnlyCollection_mC1E55FD7D4F064490F8FAD558AC19D10B5A303AE (void);
// 0x00000519 System.Void System.Runtime.Serialization.DataMember::set_IsGetOnlyCollection(System.Boolean)
extern void DataMember_set_IsGetOnlyCollection_m71FBD15C44290B6CD193172316304F844C2D2B23 (void);
// 0x0000051A System.Type System.Runtime.Serialization.DataMember::get_MemberType()
extern void DataMember_get_MemberType_mBD523A251037D594AC4B804FC7DC2EB3F4C059C2 (void);
// 0x0000051B System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataMember::get_MemberTypeContract()
extern void DataMember_get_MemberTypeContract_m359A925E8C24546B367B28FB7F682997965FB29E (void);
// 0x0000051C System.Boolean System.Runtime.Serialization.DataMember::get_HasConflictingNameAndType()
extern void DataMember_get_HasConflictingNameAndType_m9C4702C5DD4B50AC86E06FF0F343D1C1A1B8431F (void);
// 0x0000051D System.Void System.Runtime.Serialization.DataMember::set_HasConflictingNameAndType(System.Boolean)
extern void DataMember_set_HasConflictingNameAndType_mE50807865FA12770A89F6D4A113C2F958FFF8E37 (void);
// 0x0000051E System.Void System.Runtime.Serialization.DataMember::set_ConflictingMember(System.Runtime.Serialization.DataMember)
extern void DataMember_set_ConflictingMember_m618AA80151D69F18A9EAF3E82578BBA9D0D0956C (void);
// 0x0000051F System.Boolean System.Runtime.Serialization.DataMember::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void DataMember_Equals_mBDE715AFA065D8ABFFD55A7B0DEFB37C90F65A31 (void);
// 0x00000520 System.Int32 System.Runtime.Serialization.DataMember::GetHashCode()
extern void DataMember_GetHashCode_mDF33BC8C960DE7F4EEB5963EBE56F84053C4C3FC (void);
// 0x00000521 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::.ctor(System.Reflection.MemberInfo)
extern void CriticalHelper__ctor_m56D4FD316C9F32FB04C3035983683F462A7DE81B (void);
// 0x00000522 System.Reflection.MemberInfo System.Runtime.Serialization.DataMember/CriticalHelper::get_MemberInfo()
extern void CriticalHelper_get_MemberInfo_mBFF4A8E489ECF504D4C2307DF197EBFD070F2958 (void);
// 0x00000523 System.String System.Runtime.Serialization.DataMember/CriticalHelper::get_Name()
extern void CriticalHelper_get_Name_m07182ED6F48E985F8A1DACDBFB5A56EA5FCF202D (void);
// 0x00000524 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_Name(System.String)
extern void CriticalHelper_set_Name_mD30834A46D36D37D2D48BA2133631DF8D295A374 (void);
// 0x00000525 System.Int32 System.Runtime.Serialization.DataMember/CriticalHelper::get_Order()
extern void CriticalHelper_get_Order_m14460CF7BB726B88E3167A7A6D655F8D81A3DB3E (void);
// 0x00000526 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_Order(System.Int32)
extern void CriticalHelper_set_Order_m4D8D4556E9A30FE21739E52E4C5CFE02F0A84625 (void);
// 0x00000527 System.Boolean System.Runtime.Serialization.DataMember/CriticalHelper::get_IsRequired()
extern void CriticalHelper_get_IsRequired_m4D5FCFE49E81CF399CE7EF8794DD14E1F66DD870 (void);
// 0x00000528 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_IsRequired(System.Boolean)
extern void CriticalHelper_set_IsRequired_m193C96DFA95764FED87B6C12DCD59AF0830FD2CA (void);
// 0x00000529 System.Boolean System.Runtime.Serialization.DataMember/CriticalHelper::get_EmitDefaultValue()
extern void CriticalHelper_get_EmitDefaultValue_m30CFD7B0FF1C67DC4D9F31CAF296616F8DFE8934 (void);
// 0x0000052A System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_EmitDefaultValue(System.Boolean)
extern void CriticalHelper_set_EmitDefaultValue_m9362B6F9928CE0706422D985F5A4D8DF21132BE6 (void);
// 0x0000052B System.Boolean System.Runtime.Serialization.DataMember/CriticalHelper::get_IsNullable()
extern void CriticalHelper_get_IsNullable_mADB88A5C0FB9720D17BC0A16C3147A2309334F7F (void);
// 0x0000052C System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_IsNullable(System.Boolean)
extern void CriticalHelper_set_IsNullable_m8ABE78265D7EF2CDEF2DE7FB0531691728062370 (void);
// 0x0000052D System.Boolean System.Runtime.Serialization.DataMember/CriticalHelper::get_IsGetOnlyCollection()
extern void CriticalHelper_get_IsGetOnlyCollection_m8A6FBDDCCC79D46FF6231D73A3BE361B7E1F8DAD (void);
// 0x0000052E System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_IsGetOnlyCollection(System.Boolean)
extern void CriticalHelper_set_IsGetOnlyCollection_m967066E7EDE35AB7BF89F530C26AD31D2A44473E (void);
// 0x0000052F System.Type System.Runtime.Serialization.DataMember/CriticalHelper::get_MemberType()
extern void CriticalHelper_get_MemberType_m1E958DA4016FF0D8E0C5D9EB995EB10B9AAF7904 (void);
// 0x00000530 System.Runtime.Serialization.DataContract System.Runtime.Serialization.DataMember/CriticalHelper::get_MemberTypeContract()
extern void CriticalHelper_get_MemberTypeContract_m9C3BE50045944B5487E6DF872DE68489027F3324 (void);
// 0x00000531 System.Boolean System.Runtime.Serialization.DataMember/CriticalHelper::get_HasConflictingNameAndType()
extern void CriticalHelper_get_HasConflictingNameAndType_m3C539480D1D2C0A38DF68EDA97C13D7C4717BA66 (void);
// 0x00000532 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_HasConflictingNameAndType(System.Boolean)
extern void CriticalHelper_set_HasConflictingNameAndType_m603F0D858137881A458ABED7CAC0D32B9AE5D228 (void);
// 0x00000533 System.Void System.Runtime.Serialization.DataMember/CriticalHelper::set_ConflictingMember(System.Runtime.Serialization.DataMember)
extern void CriticalHelper_set_ConflictingMember_m609F51CDF9B1F1C8F21F538D033ED3213A651864 (void);
// 0x00000534 System.Void System.Runtime.Serialization.DataMemberAttribute::.ctor()
extern void DataMemberAttribute__ctor_m077F867534BAD9865D6DD156A8FBBB4068283A42 (void);
// 0x00000535 System.String System.Runtime.Serialization.DataMemberAttribute::get_Name()
extern void DataMemberAttribute_get_Name_m8C4BF39A517D901076BAFF6FF89DD53C5F4B2B3E (void);
// 0x00000536 System.Void System.Runtime.Serialization.DataMemberAttribute::set_Name(System.String)
extern void DataMemberAttribute_set_Name_mCF9CB9ED10BD17E99D79CC5CA33431F2135971DF (void);
// 0x00000537 System.Boolean System.Runtime.Serialization.DataMemberAttribute::get_IsNameSetExplicitly()
extern void DataMemberAttribute_get_IsNameSetExplicitly_m8B86CDF8508757C42320626F5A1F39E558F32EDE (void);
// 0x00000538 System.Int32 System.Runtime.Serialization.DataMemberAttribute::get_Order()
extern void DataMemberAttribute_get_Order_m34D8C756AE07BD345011D887546DF54D71898956 (void);
// 0x00000539 System.Boolean System.Runtime.Serialization.DataMemberAttribute::get_IsRequired()
extern void DataMemberAttribute_get_IsRequired_m318C586E28E349EA87096FE6FE473B4C4FD58C73 (void);
// 0x0000053A System.Void System.Runtime.Serialization.DataMemberAttribute::set_IsRequired(System.Boolean)
extern void DataMemberAttribute_set_IsRequired_m660325F5E5D02CE9563D6E28CBC725A90ED63078 (void);
// 0x0000053B System.Boolean System.Runtime.Serialization.DataMemberAttribute::get_EmitDefaultValue()
extern void DataMemberAttribute_get_EmitDefaultValue_m430708B4CFB34DD522B6D01A66CE8FDEDCC088E8 (void);
// 0x0000053C System.String System.Runtime.Serialization.DateTimeFormat::get_FormatString()
extern void DateTimeFormat_get_FormatString_m82144F58064C23C043221BC3DABE5C310428E450 (void);
// 0x0000053D System.IFormatProvider System.Runtime.Serialization.DateTimeFormat::get_FormatProvider()
extern void DateTimeFormat_get_FormatProvider_m80F01972A865D14871A399F1CEC6051C60BE9B33 (void);
// 0x0000053E System.Globalization.DateTimeStyles System.Runtime.Serialization.DateTimeFormat::get_DateTimeStyles()
extern void DateTimeFormat_get_DateTimeStyles_m676E25C0170328EBD595B9BE207179D7CB451F28 (void);
// 0x0000053F System.DateTime System.Runtime.Serialization.DateTimeOffsetAdapter::get_UtcDateTime()
extern void DateTimeOffsetAdapter_get_UtcDateTime_m39D5B6ED19930CBEB27FEA343255E90F2622D942 (void);
// 0x00000540 System.Int16 System.Runtime.Serialization.DateTimeOffsetAdapter::get_OffsetMinutes()
extern void DateTimeOffsetAdapter_get_OffsetMinutes_m1ACFACA778391AA85C1C2F52337183E56B276F03 (void);
// 0x00000541 System.DateTimeOffset System.Runtime.Serialization.DateTimeOffsetAdapter::GetDateTimeOffset(System.Runtime.Serialization.DateTimeOffsetAdapter)
extern void DateTimeOffsetAdapter_GetDateTimeOffset_mD78CF5AF0C81E1C755C772282C5424EE22F4AAC6 (void);
// 0x00000542 System.String System.Runtime.Serialization.DateTimeOffsetAdapter::ToString(System.IFormatProvider)
extern void DateTimeOffsetAdapter_ToString_m7E7AC194BF52459160D5B64DC0C61D3F62896F6C (void);
// 0x00000543 System.Void System.Runtime.Serialization.DictionaryGlobals::.cctor()
extern void DictionaryGlobals__cctor_mB9FA129BAAE651E3F3175B59B659E3C3E7D839F2 (void);
// 0x00000544 System.Void System.Runtime.Serialization.EnumDataContract::.ctor(System.Type)
extern void EnumDataContract__ctor_m204F1FAAC423DA8A07AD3AD4E929F796150191EB (void);
// 0x00000545 System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember> System.Runtime.Serialization.EnumDataContract::get_Members()
extern void EnumDataContract_get_Members_m93BDD805F0F4D4FD6B8F555FF2ABC024801056B8 (void);
// 0x00000546 System.Collections.Generic.List`1<System.Int64> System.Runtime.Serialization.EnumDataContract::get_Values()
extern void EnumDataContract_get_Values_m7EB6E78D871D792ED97B4BF7D6E0282AFA9079D1 (void);
// 0x00000547 System.Boolean System.Runtime.Serialization.EnumDataContract::get_IsFlags()
extern void EnumDataContract_get_IsFlags_m87131872D459F74F40974802B8EECD62125D16C0 (void);
// 0x00000548 System.Boolean System.Runtime.Serialization.EnumDataContract::get_IsULong()
extern void EnumDataContract_get_IsULong_m35455CE4C71BDE2D4C8D4ECC05801BDE3E927650 (void);
// 0x00000549 System.Boolean System.Runtime.Serialization.EnumDataContract::get_CanContainReferences()
extern void EnumDataContract_get_CanContainReferences_m7C519397D3C6F8B299D94668FF0AF07AE61B17D5 (void);
// 0x0000054A System.Object System.Runtime.Serialization.EnumDataContract::ReadEnumValue(System.Runtime.Serialization.XmlReaderDelegator)
extern void EnumDataContract_ReadEnumValue_m305B3E194C620D02DF8739FA4ED0D5B1C316B545 (void);
// 0x0000054B System.Int64 System.Runtime.Serialization.EnumDataContract::ReadEnumValue(System.String,System.Int32,System.Int32)
extern void EnumDataContract_ReadEnumValue_mC4243AF8CC8681AB2AA1571727E306B49FCFD06B (void);
// 0x0000054C System.Boolean System.Runtime.Serialization.EnumDataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void EnumDataContract_Equals_m7AB4B182AFE64DEA57AD4F34D9D7DF9E9D7F3318 (void);
// 0x0000054D System.Int32 System.Runtime.Serialization.EnumDataContract::GetHashCode()
extern void EnumDataContract_GetHashCode_mCD18D46B195BD3B1CD78A3F459119B2B88AD8A8B (void);
// 0x0000054E System.Object System.Runtime.Serialization.EnumDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void EnumDataContract_ReadXmlValue_m665D893DB8042FCD0CFDC124BDF088C3D7992B14 (void);
// 0x0000054F System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::.cctor()
extern void EnumDataContractCriticalHelper__cctor_mB876E15592C2D7F899FEAB82E894A1E0E63B9135 (void);
// 0x00000550 System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::Add(System.Type,System.String)
extern void EnumDataContractCriticalHelper_Add_m388921BAB3A6752D22E01FEE44BF286C4EF0AFD8 (void);
// 0x00000551 System.Xml.XmlQualifiedName System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::GetBaseContractName(System.Type)
extern void EnumDataContractCriticalHelper_GetBaseContractName_m60D5DC53CC701C5CC3DED1D92E33F59F84C24836 (void);
// 0x00000552 System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::.ctor(System.Type)
extern void EnumDataContractCriticalHelper__ctor_m7023C0597BFB9DDACDFE46369458440738885ADE (void);
// 0x00000553 System.Collections.Generic.List`1<System.Runtime.Serialization.DataMember> System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::get_Members()
extern void EnumDataContractCriticalHelper_get_Members_mA4864717BD92770470397464BCE8D4325BB19BB4 (void);
// 0x00000554 System.Collections.Generic.List`1<System.Int64> System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::get_Values()
extern void EnumDataContractCriticalHelper_get_Values_m70F4A0E90A6A09997E2B3F47188F0D44257FE45D (void);
// 0x00000555 System.Boolean System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::get_IsFlags()
extern void EnumDataContractCriticalHelper_get_IsFlags_m388F95377CFA6E11726A5CD23FCD82FBF1201F30 (void);
// 0x00000556 System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::set_IsFlags(System.Boolean)
extern void EnumDataContractCriticalHelper_set_IsFlags_mAC919BF7D3E5D378EF2A908CBA026F0E702E3A06 (void);
// 0x00000557 System.Boolean System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::get_IsULong()
extern void EnumDataContractCriticalHelper_get_IsULong_mDB91038EA68BB668F11E6DF92A9E1C1FAAA5FDF9 (void);
// 0x00000558 System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::ImportBaseType(System.Type)
extern void EnumDataContractCriticalHelper_ImportBaseType_mBBEA31C00A932FA6968318492ECB559AD24F096F (void);
// 0x00000559 System.Void System.Runtime.Serialization.EnumDataContract/EnumDataContractCriticalHelper::ImportDataMembers()
extern void EnumDataContractCriticalHelper_ImportDataMembers_m5413CA1B3095C3C6A353C610C80988F6A4FE6918 (void);
// 0x0000055A System.String System.Runtime.Serialization.EnumMemberAttribute::get_Value()
extern void EnumMemberAttribute_get_Value_mB41126B613B9FD1CD8A05D08FCEC4B6663864BE9 (void);
// 0x0000055B System.Boolean System.Runtime.Serialization.EnumMemberAttribute::get_IsValueSetExplicitly()
extern void EnumMemberAttribute_get_IsValueSetExplicitly_m76EB4379A96CAF01562D8665018EA9D144DB69FA (void);
// 0x0000055C System.Void System.Runtime.Serialization.ExtensionDataObject::.ctor()
extern void ExtensionDataObject__ctor_mF097D712BD9FFEACB8D2F6F7C6F6DEC5AE31B2D9 (void);
// 0x0000055D System.Collections.Generic.IList`1<System.Runtime.Serialization.ExtensionDataMember> System.Runtime.Serialization.ExtensionDataObject::get_Members()
extern void ExtensionDataObject_get_Members_mBE275C0D5CDB974BFB0FBCE8BCF56800C6D85ED5 (void);
// 0x0000055E System.Void System.Runtime.Serialization.ExtensionDataObject::set_Members(System.Collections.Generic.IList`1<System.Runtime.Serialization.ExtensionDataMember>)
extern void ExtensionDataObject_set_Members_m5730F07D4A09E1985C603EA406259479207EE250 (void);
// 0x0000055F System.String System.Runtime.Serialization.ExtensionDataMember::get_Name()
extern void ExtensionDataMember_get_Name_mA3D59F779C4D6B8125F6167A9261DD3DAEFCADAD (void);
// 0x00000560 System.Void System.Runtime.Serialization.ExtensionDataMember::set_Name(System.String)
extern void ExtensionDataMember_set_Name_mCE9A935CF0A0728BB09805B01C1D0BE59155E156 (void);
// 0x00000561 System.String System.Runtime.Serialization.ExtensionDataMember::get_Namespace()
extern void ExtensionDataMember_get_Namespace_m6E730ADD37BAF0B76BE7C69CAF5AE81E16720F86 (void);
// 0x00000562 System.Void System.Runtime.Serialization.ExtensionDataMember::set_Namespace(System.String)
extern void ExtensionDataMember_set_Namespace_mBCB58D1AB6994DD5E28CD8BD0C15248B6DDB2366 (void);
// 0x00000563 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.ExtensionDataMember::get_Value()
extern void ExtensionDataMember_get_Value_m53DBE8139C4178688183D4128C49A0F77816A06B (void);
// 0x00000564 System.Void System.Runtime.Serialization.ExtensionDataMember::set_Value(System.Runtime.Serialization.IDataNode)
extern void ExtensionDataMember_set_Value_mBDADBE9990D392656C61EE2126B95E39660CC7C3 (void);
// 0x00000565 System.Void System.Runtime.Serialization.ExtensionDataMember::set_MemberIndex(System.Int32)
extern void ExtensionDataMember_set_MemberIndex_m959A643C72BDF915E03559B3DAF4958D382D9B91 (void);
// 0x00000566 System.Void System.Runtime.Serialization.ExtensionDataMember::.ctor()
extern void ExtensionDataMember__ctor_m62922A523662394B3FBEA773617926492DD55A0E (void);
// 0x00000567 System.Type System.Runtime.Serialization.IDataNode::get_DataType()
// 0x00000568 System.Object System.Runtime.Serialization.IDataNode::get_Value()
// 0x00000569 System.Void System.Runtime.Serialization.IDataNode::set_Value(System.Object)
// 0x0000056A System.Void System.Runtime.Serialization.IDataNode::set_DataContractName(System.String)
// 0x0000056B System.Void System.Runtime.Serialization.IDataNode::set_DataContractNamespace(System.String)
// 0x0000056C System.Void System.Runtime.Serialization.IDataNode::set_ClrTypeName(System.String)
// 0x0000056D System.Void System.Runtime.Serialization.IDataNode::set_ClrAssemblyName(System.String)
// 0x0000056E System.String System.Runtime.Serialization.IDataNode::get_Id()
// 0x0000056F System.Void System.Runtime.Serialization.IDataNode::set_Id(System.String)
// 0x00000570 System.Void System.Runtime.Serialization.IDataNode::GetData(System.Runtime.Serialization.ElementData)
// 0x00000571 System.Boolean System.Runtime.Serialization.IDataNode::get_IsFinalValue()
// 0x00000572 System.Void System.Runtime.Serialization.IDataNode::set_IsFinalValue(System.Boolean)
// 0x00000573 System.Void System.Runtime.Serialization.IDataNode::Clear()
// 0x00000574 System.Void System.Runtime.Serialization.DataNode`1::.ctor()
// 0x00000575 System.Void System.Runtime.Serialization.DataNode`1::.ctor(T)
// 0x00000576 System.Type System.Runtime.Serialization.DataNode`1::get_DataType()
// 0x00000577 System.Object System.Runtime.Serialization.DataNode`1::get_Value()
// 0x00000578 System.Void System.Runtime.Serialization.DataNode`1::set_Value(System.Object)
// 0x00000579 System.Boolean System.Runtime.Serialization.DataNode`1::System.Runtime.Serialization.IDataNode.get_IsFinalValue()
// 0x0000057A System.Void System.Runtime.Serialization.DataNode`1::System.Runtime.Serialization.IDataNode.set_IsFinalValue(System.Boolean)
// 0x0000057B T System.Runtime.Serialization.DataNode`1::GetValue()
// 0x0000057C System.String System.Runtime.Serialization.DataNode`1::get_DataContractName()
// 0x0000057D System.Void System.Runtime.Serialization.DataNode`1::set_DataContractName(System.String)
// 0x0000057E System.String System.Runtime.Serialization.DataNode`1::get_DataContractNamespace()
// 0x0000057F System.Void System.Runtime.Serialization.DataNode`1::set_DataContractNamespace(System.String)
// 0x00000580 System.String System.Runtime.Serialization.DataNode`1::get_ClrTypeName()
// 0x00000581 System.Void System.Runtime.Serialization.DataNode`1::set_ClrTypeName(System.String)
// 0x00000582 System.String System.Runtime.Serialization.DataNode`1::get_ClrAssemblyName()
// 0x00000583 System.Void System.Runtime.Serialization.DataNode`1::set_ClrAssemblyName(System.String)
// 0x00000584 System.String System.Runtime.Serialization.DataNode`1::get_Id()
// 0x00000585 System.Void System.Runtime.Serialization.DataNode`1::set_Id(System.String)
// 0x00000586 System.Void System.Runtime.Serialization.DataNode`1::GetData(System.Runtime.Serialization.ElementData)
// 0x00000587 System.Void System.Runtime.Serialization.DataNode`1::Clear()
// 0x00000588 System.Void System.Runtime.Serialization.DataNode`1::AddQualifiedNameAttribute(System.Runtime.Serialization.ElementData,System.String,System.String,System.String,System.String,System.String)
// 0x00000589 System.Void System.Runtime.Serialization.ClassDataNode::.ctor()
extern void ClassDataNode__ctor_m282D5CCB65E7DF23D7F0640EF66E988A54958B69 (void);
// 0x0000058A System.Collections.Generic.IList`1<System.Runtime.Serialization.ExtensionDataMember> System.Runtime.Serialization.ClassDataNode::get_Members()
extern void ClassDataNode_get_Members_m8D5DA6B2D8C7F5A9DE79B5697007AC2B32D3FED2 (void);
// 0x0000058B System.Void System.Runtime.Serialization.ClassDataNode::set_Members(System.Collections.Generic.IList`1<System.Runtime.Serialization.ExtensionDataMember>)
extern void ClassDataNode_set_Members_mA1137CAA3CFB9D7052E8A6608CE02E5E63AF45F3 (void);
// 0x0000058C System.Void System.Runtime.Serialization.ClassDataNode::Clear()
extern void ClassDataNode_Clear_m1E7685E25755F5A1F6348DB4FCD524CF74537327 (void);
// 0x0000058D System.Void System.Runtime.Serialization.CollectionDataNode::.ctor()
extern void CollectionDataNode__ctor_m8437996FF88778A13F7CAEC30445AFBF32DF527F (void);
// 0x0000058E System.Collections.Generic.IList`1<System.Runtime.Serialization.IDataNode> System.Runtime.Serialization.CollectionDataNode::get_Items()
extern void CollectionDataNode_get_Items_m461D938C7315F6ECFB5D3E1844577699A10B7ECF (void);
// 0x0000058F System.Void System.Runtime.Serialization.CollectionDataNode::set_Items(System.Collections.Generic.IList`1<System.Runtime.Serialization.IDataNode>)
extern void CollectionDataNode_set_Items_mBB0957B4C26EF2CD3D0D846F999465AA92FA3869 (void);
// 0x00000590 System.String System.Runtime.Serialization.CollectionDataNode::get_ItemName()
extern void CollectionDataNode_get_ItemName_m7A50DCFBDD5A2FBAE593B1031C698D0A6F89F16A (void);
// 0x00000591 System.Void System.Runtime.Serialization.CollectionDataNode::set_ItemName(System.String)
extern void CollectionDataNode_set_ItemName_mB65D8BEEDDE3B53CA459700ECDA74DED92AEC82E (void);
// 0x00000592 System.String System.Runtime.Serialization.CollectionDataNode::get_ItemNamespace()
extern void CollectionDataNode_get_ItemNamespace_mA359CC1A70E02276129F05EF1E86C17FE4897237 (void);
// 0x00000593 System.Void System.Runtime.Serialization.CollectionDataNode::set_ItemNamespace(System.String)
extern void CollectionDataNode_set_ItemNamespace_m9AF00F0FB66B99DBB3C1AA4F56FAB0C1A0A24C9E (void);
// 0x00000594 System.Int32 System.Runtime.Serialization.CollectionDataNode::get_Size()
extern void CollectionDataNode_get_Size_m00B1B83F57D9E43C0193373713CD103BEA191A6D (void);
// 0x00000595 System.Void System.Runtime.Serialization.CollectionDataNode::set_Size(System.Int32)
extern void CollectionDataNode_set_Size_m5231C354852EF9A115EE88167AF83FA94ACF7B19 (void);
// 0x00000596 System.Void System.Runtime.Serialization.CollectionDataNode::GetData(System.Runtime.Serialization.ElementData)
extern void CollectionDataNode_GetData_mF13B16A1773C02298B8571A1AB8A2A0B83A6D54F (void);
// 0x00000597 System.Void System.Runtime.Serialization.CollectionDataNode::Clear()
extern void CollectionDataNode_Clear_m9E13D55649207AAA0C8F6911A43A8791E5995895 (void);
// 0x00000598 System.Void System.Runtime.Serialization.XmlDataNode::.ctor()
extern void XmlDataNode__ctor_m1FCD0F1409C622D7B0B6F5D7B224256F91FD185E (void);
// 0x00000599 System.Collections.Generic.IList`1<System.Xml.XmlAttribute> System.Runtime.Serialization.XmlDataNode::get_XmlAttributes()
extern void XmlDataNode_get_XmlAttributes_m56377CB7E8C4EBAB87DA279DB6B9564C1B4DAD57 (void);
// 0x0000059A System.Void System.Runtime.Serialization.XmlDataNode::set_XmlAttributes(System.Collections.Generic.IList`1<System.Xml.XmlAttribute>)
extern void XmlDataNode_set_XmlAttributes_mC2F00E7514659A5887D5C62BEBA0CE8D12119487 (void);
// 0x0000059B System.Collections.Generic.IList`1<System.Xml.XmlNode> System.Runtime.Serialization.XmlDataNode::get_XmlChildNodes()
extern void XmlDataNode_get_XmlChildNodes_m778F074CFFAC5DED6B546E101B9339965EF27343 (void);
// 0x0000059C System.Void System.Runtime.Serialization.XmlDataNode::set_XmlChildNodes(System.Collections.Generic.IList`1<System.Xml.XmlNode>)
extern void XmlDataNode_set_XmlChildNodes_m2CFE7AC0F53073358CB046E9D40945660D942EBD (void);
// 0x0000059D System.Xml.XmlDocument System.Runtime.Serialization.XmlDataNode::get_OwnerDocument()
extern void XmlDataNode_get_OwnerDocument_mC1ACC6907BE82F28375B433F5CF61E8DE50BDAD5 (void);
// 0x0000059E System.Void System.Runtime.Serialization.XmlDataNode::set_OwnerDocument(System.Xml.XmlDocument)
extern void XmlDataNode_set_OwnerDocument_m102B2E441084099000B7EE064A812DDEF0497178 (void);
// 0x0000059F System.Void System.Runtime.Serialization.XmlDataNode::Clear()
extern void XmlDataNode_Clear_m5D0CCD8D9D85A0413428D6D5CB6618ACB66E0F04 (void);
// 0x000005A0 System.Void System.Runtime.Serialization.ISerializableDataNode::.ctor()
extern void ISerializableDataNode__ctor_mD939F56613046B2D049511CECB876F7D4C640DD3 (void);
// 0x000005A1 System.String System.Runtime.Serialization.ISerializableDataNode::get_FactoryTypeName()
extern void ISerializableDataNode_get_FactoryTypeName_mE7E348D7FC2BABD38B486669410D03DCB2D33933 (void);
// 0x000005A2 System.Void System.Runtime.Serialization.ISerializableDataNode::set_FactoryTypeName(System.String)
extern void ISerializableDataNode_set_FactoryTypeName_m0947A9067E581122258BC10EB72CA983E0B2C0D7 (void);
// 0x000005A3 System.String System.Runtime.Serialization.ISerializableDataNode::get_FactoryTypeNamespace()
extern void ISerializableDataNode_get_FactoryTypeNamespace_mF98B4F318E1CCDACB25310EA42D0325662609999 (void);
// 0x000005A4 System.Void System.Runtime.Serialization.ISerializableDataNode::set_FactoryTypeNamespace(System.String)
extern void ISerializableDataNode_set_FactoryTypeNamespace_m98BD435742708B6826B4816FE92317E4E1D5708B (void);
// 0x000005A5 System.Collections.Generic.IList`1<System.Runtime.Serialization.ISerializableDataMember> System.Runtime.Serialization.ISerializableDataNode::get_Members()
extern void ISerializableDataNode_get_Members_m3C127992D4B10D67FE24A7CC070CC2368DB907FC (void);
// 0x000005A6 System.Void System.Runtime.Serialization.ISerializableDataNode::set_Members(System.Collections.Generic.IList`1<System.Runtime.Serialization.ISerializableDataMember>)
extern void ISerializableDataNode_set_Members_m4CA2BEEED203EAAB6B77AAA4C6E6E56960BB9ED5 (void);
// 0x000005A7 System.Void System.Runtime.Serialization.ISerializableDataNode::GetData(System.Runtime.Serialization.ElementData)
extern void ISerializableDataNode_GetData_m66A9B93A3C1339A24C0049FA861946BECD033CFB (void);
// 0x000005A8 System.Void System.Runtime.Serialization.ISerializableDataNode::Clear()
extern void ISerializableDataNode_Clear_m8C136DE8FECA8EE38D03B48FE65BA41088597EB3 (void);
// 0x000005A9 System.String System.Runtime.Serialization.ISerializableDataMember::get_Name()
extern void ISerializableDataMember_get_Name_m062A3F0DD1357527E368758D20B4DC0AEDC65819 (void);
// 0x000005AA System.Void System.Runtime.Serialization.ISerializableDataMember::set_Name(System.String)
extern void ISerializableDataMember_set_Name_m9DAADA316AAE0DA467A10F1BDD0C2EE836B8EE39 (void);
// 0x000005AB System.Runtime.Serialization.IDataNode System.Runtime.Serialization.ISerializableDataMember::get_Value()
extern void ISerializableDataMember_get_Value_mBE6B086C95B1F81827A219B2361BAB3850BD7D4C (void);
// 0x000005AC System.Void System.Runtime.Serialization.ISerializableDataMember::set_Value(System.Runtime.Serialization.IDataNode)
extern void ISerializableDataMember_set_Value_mE369EB65A7A829AB5FF8EA245EDD480AC146AABF (void);
// 0x000005AD System.Void System.Runtime.Serialization.ISerializableDataMember::.ctor()
extern void ISerializableDataMember__ctor_mBF9BFA10EB9968DC73E44EAE88E88E05942B4D09 (void);
// 0x000005AE System.Void System.Runtime.Serialization.ExtensionDataReader::.cctor()
extern void ExtensionDataReader__cctor_m839B443444122F98002363C4F4EF4B4C2DBD9054 (void);
// 0x000005AF System.Void System.Runtime.Serialization.ExtensionDataReader::.ctor(System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void ExtensionDataReader__ctor_mB54CFD5A8537EEC255CDFEB0BC2EA971DB39169A (void);
// 0x000005B0 System.Void System.Runtime.Serialization.ExtensionDataReader::SetDeserializedValue(System.Object)
extern void ExtensionDataReader_SetDeserializedValue_m13EAD431D03BC296D301B0253A5E27DB5C483911 (void);
// 0x000005B1 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.ExtensionDataReader::GetCurrentNode()
extern void ExtensionDataReader_GetCurrentNode_m053C86EACB5D1619B4DF2EF5B289972712FADED4 (void);
// 0x000005B2 System.Void System.Runtime.Serialization.ExtensionDataReader::SetDataNode(System.Runtime.Serialization.IDataNode,System.String,System.String)
extern void ExtensionDataReader_SetDataNode_mD8D95D1BBE0D23D45A6FD9ECACC2774A7974ACB0 (void);
// 0x000005B3 System.Void System.Runtime.Serialization.ExtensionDataReader::Reset()
extern void ExtensionDataReader_Reset_mC007BF9DF58DFFA1CB2C6CDEF4580E55F774E5CB (void);
// 0x000005B4 System.Boolean System.Runtime.Serialization.ExtensionDataReader::get_IsXmlDataNode()
extern void ExtensionDataReader_get_IsXmlDataNode_mC37FC2CE390BAF4FE05E7026F988F753EE17E703 (void);
// 0x000005B5 System.Xml.XmlNodeType System.Runtime.Serialization.ExtensionDataReader::get_NodeType()
extern void ExtensionDataReader_get_NodeType_m4B825025BC52970613CC0E704B5FC9AAEEBB6950 (void);
// 0x000005B6 System.String System.Runtime.Serialization.ExtensionDataReader::get_LocalName()
extern void ExtensionDataReader_get_LocalName_mF3CBA7EA4ECFBC4A84A6D8AF9CA1526B9E70768E (void);
// 0x000005B7 System.String System.Runtime.Serialization.ExtensionDataReader::get_NamespaceURI()
extern void ExtensionDataReader_get_NamespaceURI_m5C9AA50DAC27E3B843938530B914F458BA96C36B (void);
// 0x000005B8 System.String System.Runtime.Serialization.ExtensionDataReader::get_Prefix()
extern void ExtensionDataReader_get_Prefix_mDA6006B6B7056E6C9E7E087E94D9F9057CC58FD5 (void);
// 0x000005B9 System.String System.Runtime.Serialization.ExtensionDataReader::get_Value()
extern void ExtensionDataReader_get_Value_mC93F0B9FB9A15D091A47BD08B06E806C1FDC641D (void);
// 0x000005BA System.Int32 System.Runtime.Serialization.ExtensionDataReader::get_Depth()
extern void ExtensionDataReader_get_Depth_mD8A15DA6F74192AD5742F2E89B43D5C674CE22C6 (void);
// 0x000005BB System.Int32 System.Runtime.Serialization.ExtensionDataReader::get_AttributeCount()
extern void ExtensionDataReader_get_AttributeCount_m3184A93E4A6F9C647716DCB674AB6B36CAD199E8 (void);
// 0x000005BC System.Boolean System.Runtime.Serialization.ExtensionDataReader::get_EOF()
extern void ExtensionDataReader_get_EOF_m39CE262A7DED0F5886FE76F19114D62AA9B10F3B (void);
// 0x000005BD System.Xml.ReadState System.Runtime.Serialization.ExtensionDataReader::get_ReadState()
extern void ExtensionDataReader_get_ReadState_mA566186F3645E3B4AB3837721283F525C5D58999 (void);
// 0x000005BE System.Boolean System.Runtime.Serialization.ExtensionDataReader::get_IsEmptyElement()
extern void ExtensionDataReader_get_IsEmptyElement_m75481787492D37B952B64A9B7454A09DF24B8A2C (void);
// 0x000005BF System.Boolean System.Runtime.Serialization.ExtensionDataReader::get_IsDefault()
extern void ExtensionDataReader_get_IsDefault_mDEC07FB38DF3F9C61A8D64D115EE92BDC4659C6F (void);
// 0x000005C0 System.Char System.Runtime.Serialization.ExtensionDataReader::get_QuoteChar()
extern void ExtensionDataReader_get_QuoteChar_m852CB9025D106EAABC41FD265551A18EB619F17B (void);
// 0x000005C1 System.Xml.XmlSpace System.Runtime.Serialization.ExtensionDataReader::get_XmlSpace()
extern void ExtensionDataReader_get_XmlSpace_mEA37C6C4EA3F6776D1953338017BAD773496E90B (void);
// 0x000005C2 System.String System.Runtime.Serialization.ExtensionDataReader::get_XmlLang()
extern void ExtensionDataReader_get_XmlLang_m7B68C165EA5C4EB81751088F118F59347B2EE279 (void);
// 0x000005C3 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToFirstAttribute()
extern void ExtensionDataReader_MoveToFirstAttribute_m5344934D0EA31A423ACDCA23A580D450A5C1B580 (void);
// 0x000005C4 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToNextAttribute()
extern void ExtensionDataReader_MoveToNextAttribute_m9A7B9D794A519B35DD932FCDB80E97F57CA54552 (void);
// 0x000005C5 System.Void System.Runtime.Serialization.ExtensionDataReader::MoveToAttribute(System.Int32)
extern void ExtensionDataReader_MoveToAttribute_m449420456C13DA4F0CA2A94D6E8362DBD733D628 (void);
// 0x000005C6 System.String System.Runtime.Serialization.ExtensionDataReader::GetAttribute(System.String,System.String)
extern void ExtensionDataReader_GetAttribute_m705868F0F7DAEB9CF2198D1B1DA9646954D0653A (void);
// 0x000005C7 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToAttribute(System.String,System.String)
extern void ExtensionDataReader_MoveToAttribute_m808730F93B7AA5C38EAF59214BB91F8A7D137768 (void);
// 0x000005C8 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToElement()
extern void ExtensionDataReader_MoveToElement_mD1D2782C77567A10D3CD00D34A6625B2291E58B6 (void);
// 0x000005C9 System.Void System.Runtime.Serialization.ExtensionDataReader::SetElement()
extern void ExtensionDataReader_SetElement_m23388DD6A1CB8C3A896CB4AA9E7B3942DCE70B8F (void);
// 0x000005CA System.String System.Runtime.Serialization.ExtensionDataReader::LookupNamespace(System.String)
extern void ExtensionDataReader_LookupNamespace_m7307CE855A0B76F411463ABEAC4FCB5A0FFB15EA (void);
// 0x000005CB System.Void System.Runtime.Serialization.ExtensionDataReader::Skip()
extern void ExtensionDataReader_Skip_m9C9C872F2048DF3B20A30B5265F74068E85E0795 (void);
// 0x000005CC System.Boolean System.Runtime.Serialization.ExtensionDataReader::IsElementNode(System.Runtime.Serialization.ExtensionDataReader/ExtensionDataNodeType)
extern void ExtensionDataReader_IsElementNode_mCD7C6030CA6D85D5D6A3C0F7FCCC6655E2FEA49D (void);
// 0x000005CD System.Void System.Runtime.Serialization.ExtensionDataReader::Close()
extern void ExtensionDataReader_Close_m9B79599FCD2CA59D7C65062C4A6A31F7A46F1091 (void);
// 0x000005CE System.Boolean System.Runtime.Serialization.ExtensionDataReader::Read()
extern void ExtensionDataReader_Read_m199A4722C2FC8A4F8863CC64CF168C370AB875F1 (void);
// 0x000005CF System.String System.Runtime.Serialization.ExtensionDataReader::get_Name()
extern void ExtensionDataReader_get_Name_mF9F9AC24656BBD07A29B7BEE7C8C6A39573F9AAF (void);
// 0x000005D0 System.String System.Runtime.Serialization.ExtensionDataReader::get_BaseURI()
extern void ExtensionDataReader_get_BaseURI_mCA539F24B6EA4D5BF5A6F1B202C9ABAE138B60C9 (void);
// 0x000005D1 System.Xml.XmlNameTable System.Runtime.Serialization.ExtensionDataReader::get_NameTable()
extern void ExtensionDataReader_get_NameTable_mBDB125A2AD4F4F146B3F7A568B124618EA991095 (void);
// 0x000005D2 System.String System.Runtime.Serialization.ExtensionDataReader::GetAttribute(System.String)
extern void ExtensionDataReader_GetAttribute_mE7EC9573E5ECB88214FBC640B562B435BE9982B6 (void);
// 0x000005D3 System.String System.Runtime.Serialization.ExtensionDataReader::GetAttribute(System.Int32)
extern void ExtensionDataReader_GetAttribute_m6C990B9C53A6D6DD9A805C84C39D05D2F0F656CD (void);
// 0x000005D4 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToAttribute(System.String)
extern void ExtensionDataReader_MoveToAttribute_m99ED4769ABD3FA56AD3FF6256C58C49AA8987616 (void);
// 0x000005D5 System.Void System.Runtime.Serialization.ExtensionDataReader::ResolveEntity()
extern void ExtensionDataReader_ResolveEntity_m4F9434F7359571C5362A6A37E9DB34EA87D28E10 (void);
// 0x000005D6 System.Boolean System.Runtime.Serialization.ExtensionDataReader::ReadAttributeValue()
extern void ExtensionDataReader_ReadAttributeValue_m15DE12EE7A8F76F4990C03617BA4B6CB2BF3B0D4 (void);
// 0x000005D7 System.Void System.Runtime.Serialization.ExtensionDataReader::MoveNext(System.Runtime.Serialization.IDataNode)
extern void ExtensionDataReader_MoveNext_mE0AF59CB6C105B9166E6506404818DC671810AFE (void);
// 0x000005D8 System.Void System.Runtime.Serialization.ExtensionDataReader::SetNextElement(System.Runtime.Serialization.IDataNode,System.String,System.String,System.String)
extern void ExtensionDataReader_SetNextElement_mB70C2444DDF40B71DE24589EA02DFFD923E6EC27 (void);
// 0x000005D9 System.Void System.Runtime.Serialization.ExtensionDataReader::AddDeserializedDataNode(System.Runtime.Serialization.IDataNode)
extern void ExtensionDataReader_AddDeserializedDataNode_mDD326EB14C39B17CCCA5FCE7A1410E5461042EA6 (void);
// 0x000005DA System.Boolean System.Runtime.Serialization.ExtensionDataReader::CheckIfNodeHandled(System.Runtime.Serialization.IDataNode)
extern void ExtensionDataReader_CheckIfNodeHandled_m12411633BEC1BD42C008A5D08EE28171EEA58410 (void);
// 0x000005DB System.Void System.Runtime.Serialization.ExtensionDataReader::MoveNextInClass(System.Runtime.Serialization.ClassDataNode)
extern void ExtensionDataReader_MoveNextInClass_m528CA888E8650126E9801538743B605D92CC072F (void);
// 0x000005DC System.Void System.Runtime.Serialization.ExtensionDataReader::MoveNextInCollection(System.Runtime.Serialization.CollectionDataNode)
extern void ExtensionDataReader_MoveNextInCollection_mDAC3EEAC85B933B22779FFAC1555AA41BC41C05F (void);
// 0x000005DD System.Void System.Runtime.Serialization.ExtensionDataReader::MoveNextInISerializable(System.Runtime.Serialization.ISerializableDataNode)
extern void ExtensionDataReader_MoveNextInISerializable_mDE56ADEC7BB0EDD1EF5CB598BBB73963FA78F91C (void);
// 0x000005DE System.Void System.Runtime.Serialization.ExtensionDataReader::MoveNextInXml(System.Runtime.Serialization.XmlDataNode)
extern void ExtensionDataReader_MoveNextInXml_m3456B68604C97B7A9FF261255E4BE1D047CD2A72 (void);
// 0x000005DF System.Void System.Runtime.Serialization.ExtensionDataReader::MoveToDeserializedObject(System.Runtime.Serialization.IDataNode)
extern void ExtensionDataReader_MoveToDeserializedObject_mAB97DE1C3965BFD29533FEECEE2074D51AAD71CD (void);
// 0x000005E0 System.Boolean System.Runtime.Serialization.ExtensionDataReader::MoveToText(System.Type,System.Runtime.Serialization.IDataNode,System.Boolean)
extern void ExtensionDataReader_MoveToText_m61169888E45A6F1FC79F5045292BBCD9770023E1 (void);
// 0x000005E1 System.Void System.Runtime.Serialization.ExtensionDataReader::PushElement()
extern void ExtensionDataReader_PushElement_m03A5B348C1AF268BA7EB866379231C3D66533BDB (void);
// 0x000005E2 System.Void System.Runtime.Serialization.ExtensionDataReader::PopElement()
extern void ExtensionDataReader_PopElement_m1C1DEB0F1A06E24D744FD77AA3A550E8E8D16CFC (void);
// 0x000005E3 System.Void System.Runtime.Serialization.ExtensionDataReader::GrowElementsIfNeeded()
extern void ExtensionDataReader_GrowElementsIfNeeded_mF765C63A03410D24F0E91264046FE849B23411C9 (void);
// 0x000005E4 System.Runtime.Serialization.ElementData System.Runtime.Serialization.ExtensionDataReader::GetNextElement()
extern void ExtensionDataReader_GetNextElement_m93E03F7C66043F7D97F16E922715C37CEFDC9467 (void);
// 0x000005E5 System.String System.Runtime.Serialization.ExtensionDataReader::GetPrefix(System.String)
extern void ExtensionDataReader_GetPrefix_mED296B7F49A45A30C9D5BB4758CB0F43857F590F (void);
// 0x000005E6 System.Void System.Runtime.Serialization.ExtensionDataReader::AddPrefix(System.String,System.String)
extern void ExtensionDataReader_AddPrefix_m1320A0FE49ADB77038EE426CBB148B8884830E21 (void);
// 0x000005E7 System.Void System.Runtime.Serialization.AttributeData::.ctor()
extern void AttributeData__ctor_m24890B9610DEEC2193027AA735381FD145608A47 (void);
// 0x000005E8 System.Void System.Runtime.Serialization.ElementData::AddAttribute(System.String,System.String,System.String,System.String)
extern void ElementData_AddAttribute_m24C1277B7F19F8E0F713B12A12D3B3F56F52EF28 (void);
// 0x000005E9 System.Void System.Runtime.Serialization.ElementData::GrowAttributesIfNeeded()
extern void ElementData_GrowAttributesIfNeeded_m5B36DA990563BE4FEB15BF4CB23D00C227B9CB5B (void);
// 0x000005EA System.Void System.Runtime.Serialization.ElementData::.ctor()
extern void ElementData__ctor_m4C5A48B14A41183637767ECAD284579650BC466C (void);
// 0x000005EB System.Void System.Runtime.Serialization.GenericParameterDataContract::.ctor(System.Type)
extern void GenericParameterDataContract__ctor_m62DBE6D257EA97FE782445DF8FB17420B8D62658 (void);
// 0x000005EC System.Boolean System.Runtime.Serialization.GenericParameterDataContract::get_IsBuiltInDataContract()
extern void GenericParameterDataContract_get_IsBuiltInDataContract_m7B2122C972E2F77A289B347DCB55BBAB0775B0CA (void);
// 0x000005ED System.Void System.Runtime.Serialization.GenericParameterDataContract/GenericParameterDataContractCriticalHelper::.ctor(System.Type)
extern void GenericParameterDataContractCriticalHelper__ctor_mBBACB630C3844730B7B71F2FEC50186386EDD0F0 (void);
// 0x000005EE System.Type System.Runtime.Serialization.Globals::get_TypeOfObject()
extern void Globals_get_TypeOfObject_m821DC2E38514A362610C86CC23EE8E672A31DAF7 (void);
// 0x000005EF System.Type System.Runtime.Serialization.Globals::get_TypeOfValueType()
extern void Globals_get_TypeOfValueType_mBBCEE4136A04605CEBB2DD290A58C419145CB969 (void);
// 0x000005F0 System.Type System.Runtime.Serialization.Globals::get_TypeOfArray()
extern void Globals_get_TypeOfArray_m8846ECC7D44EC3E09798769E7335B35610E807E2 (void);
// 0x000005F1 System.Type System.Runtime.Serialization.Globals::get_TypeOfString()
extern void Globals_get_TypeOfString_mDA6D206966E9D0DA7D977E01D6BCD15108CD2083 (void);
// 0x000005F2 System.Type System.Runtime.Serialization.Globals::get_TypeOfInt()
extern void Globals_get_TypeOfInt_m6C80173098F1DA80D11904E43CAC20B4228C310F (void);
// 0x000005F3 System.Type System.Runtime.Serialization.Globals::get_TypeOfULong()
extern void Globals_get_TypeOfULong_m112B4EF74D19C4207CE415A0B53461575409F350 (void);
// 0x000005F4 System.Type System.Runtime.Serialization.Globals::get_TypeOfVoid()
extern void Globals_get_TypeOfVoid_mB3A475FF906780040B4F97BBF0225044D907278F (void);
// 0x000005F5 System.Type System.Runtime.Serialization.Globals::get_TypeOfByteArray()
extern void Globals_get_TypeOfByteArray_mC3DEFACB2C260F2DA1A3F92499F93EA742528B8C (void);
// 0x000005F6 System.Type System.Runtime.Serialization.Globals::get_TypeOfTimeSpan()
extern void Globals_get_TypeOfTimeSpan_m660900ABFD7F46D3FA9A0C918D313AA68CC893FE (void);
// 0x000005F7 System.Type System.Runtime.Serialization.Globals::get_TypeOfGuid()
extern void Globals_get_TypeOfGuid_mF300AE08E67E9B61027794A2EBFE90A4F1FA9139 (void);
// 0x000005F8 System.Type System.Runtime.Serialization.Globals::get_TypeOfDateTimeOffset()
extern void Globals_get_TypeOfDateTimeOffset_mF3C7BFB68C1CB22F5D4B23C503B290DAD00555C6 (void);
// 0x000005F9 System.Type System.Runtime.Serialization.Globals::get_TypeOfDateTimeOffsetAdapter()
extern void Globals_get_TypeOfDateTimeOffsetAdapter_m3B63812849E2F7F2E02707B0B1E2C89E980EF9AA (void);
// 0x000005FA System.Type System.Runtime.Serialization.Globals::get_TypeOfUri()
extern void Globals_get_TypeOfUri_mB863C6FCDB48C6DC281FDADA2B93D140654D0F52 (void);
// 0x000005FB System.Type System.Runtime.Serialization.Globals::get_TypeOfTypeEnumerable()
extern void Globals_get_TypeOfTypeEnumerable_mA2ABDCB60A7DC4DB6DD722CE682D606D215B6F54 (void);
// 0x000005FC System.Type System.Runtime.Serialization.Globals::get_TypeOfStreamingContext()
extern void Globals_get_TypeOfStreamingContext_m83C0D9B4846579A596C7B784367DEC04EA780D2F (void);
// 0x000005FD System.Type System.Runtime.Serialization.Globals::get_TypeOfISerializable()
extern void Globals_get_TypeOfISerializable_mCD2A131F3322C8D4BA63852359597FDF078378DC (void);
// 0x000005FE System.Type System.Runtime.Serialization.Globals::get_TypeOfIDeserializationCallback()
extern void Globals_get_TypeOfIDeserializationCallback_mD1F6CFA8EF959646AA89C4ADF29C76FA40F23806 (void);
// 0x000005FF System.Type System.Runtime.Serialization.Globals::get_TypeOfIObjectReference()
extern void Globals_get_TypeOfIObjectReference_m757245111BFF254967FD5E42655E226335053742 (void);
// 0x00000600 System.Type System.Runtime.Serialization.Globals::get_TypeOfKnownTypeAttribute()
extern void Globals_get_TypeOfKnownTypeAttribute_mF99EF58E93B2A62A57C59ED6732E79A8C5ED7532 (void);
// 0x00000601 System.Type System.Runtime.Serialization.Globals::get_TypeOfDataContractAttribute()
extern void Globals_get_TypeOfDataContractAttribute_m4C6AE42C76F8C38E258C6778460BE19C03FAE770 (void);
// 0x00000602 System.Type System.Runtime.Serialization.Globals::get_TypeOfDataMemberAttribute()
extern void Globals_get_TypeOfDataMemberAttribute_mC09F1DF4F1E08B5C3C0E0A5A5E912E1E94EEDA51 (void);
// 0x00000603 System.Type System.Runtime.Serialization.Globals::get_TypeOfEnumMemberAttribute()
extern void Globals_get_TypeOfEnumMemberAttribute_m9C560E3F90962B3E0E637FEAD994C57DD652F541 (void);
// 0x00000604 System.Type System.Runtime.Serialization.Globals::get_TypeOfCollectionDataContractAttribute()
extern void Globals_get_TypeOfCollectionDataContractAttribute_mDD1AE5FC7181F83B495EA189E501949B4D4D8CEF (void);
// 0x00000605 System.Type System.Runtime.Serialization.Globals::get_TypeOfOptionalFieldAttribute()
extern void Globals_get_TypeOfOptionalFieldAttribute_m78EEA3791B94E671962653900E8467145DB9C2C7 (void);
// 0x00000606 System.Type System.Runtime.Serialization.Globals::get_TypeOfObjectArray()
extern void Globals_get_TypeOfObjectArray_m4A105D00ABE2B8AD57C5628C44BC69201A7DDFCF (void);
// 0x00000607 System.Type System.Runtime.Serialization.Globals::get_TypeOfOnSerializingAttribute()
extern void Globals_get_TypeOfOnSerializingAttribute_mA7D6B606181512E7BF2136A991DB9BB0B74D18E6 (void);
// 0x00000608 System.Type System.Runtime.Serialization.Globals::get_TypeOfOnSerializedAttribute()
extern void Globals_get_TypeOfOnSerializedAttribute_mE7A62B796FA0DF7E5AD0588238627FA00CD97C9D (void);
// 0x00000609 System.Type System.Runtime.Serialization.Globals::get_TypeOfOnDeserializingAttribute()
extern void Globals_get_TypeOfOnDeserializingAttribute_m5FAE50465E9CD964BA7AEE14267A783C11550A7E (void);
// 0x0000060A System.Type System.Runtime.Serialization.Globals::get_TypeOfOnDeserializedAttribute()
extern void Globals_get_TypeOfOnDeserializedAttribute_m3020247F18C0D50EC8C85A36E7D4CA8750B77873 (void);
// 0x0000060B System.Type System.Runtime.Serialization.Globals::get_TypeOfFlagsAttribute()
extern void Globals_get_TypeOfFlagsAttribute_m15B5124E4630FB606188EC938783539BD5BF7BDF (void);
// 0x0000060C System.Type System.Runtime.Serialization.Globals::get_TypeOfIXmlSerializable()
extern void Globals_get_TypeOfIXmlSerializable_mD205166C6082FB26FD4506389A1918F842C26AE0 (void);
// 0x0000060D System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlSchemaProviderAttribute()
extern void Globals_get_TypeOfXmlSchemaProviderAttribute_m6E99D68CF1366F02293DD4AF2621C96496F19C13 (void);
// 0x0000060E System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlRootAttribute()
extern void Globals_get_TypeOfXmlRootAttribute_mD6F94A7B4DBE08BC5D60578B2726DD13D10C72A6 (void);
// 0x0000060F System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlQualifiedName()
extern void Globals_get_TypeOfXmlQualifiedName_mE8F51EDA34542512C71EA7A473A17C064F468606 (void);
// 0x00000610 System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlSchemaType()
extern void Globals_get_TypeOfXmlSchemaType_mD1981EBAB7721B04DAA0CBA70DC554B8F07DD95D (void);
// 0x00000611 System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlNodeArray()
extern void Globals_get_TypeOfXmlNodeArray_m89055C4F845577B4F40D9CC350C69201CA870536 (void);
// 0x00000612 System.Object[] System.Runtime.Serialization.Globals::get_EmptyObjectArray()
extern void Globals_get_EmptyObjectArray_mFC912C4CEA3B19FEE703F1C277857D8EF82AC447 (void);
// 0x00000613 System.Type[] System.Runtime.Serialization.Globals::get_EmptyTypeArray()
extern void Globals_get_EmptyTypeArray_m5E2444A2AD08F138D0D7550BB8E3075FF89E6673 (void);
// 0x00000614 System.Type System.Runtime.Serialization.Globals::get_TypeOfIExtensibleDataObject()
extern void Globals_get_TypeOfIExtensibleDataObject_m26FB4439AA3AE12A3B25E667EC33FD929A35C1EB (void);
// 0x00000615 System.Type System.Runtime.Serialization.Globals::get_TypeOfExtensionDataObject()
extern void Globals_get_TypeOfExtensionDataObject_m2432B9DAA370A6836672468850D626336ADAB851 (void);
// 0x00000616 System.Type System.Runtime.Serialization.Globals::get_TypeOfISerializableDataNode()
extern void Globals_get_TypeOfISerializableDataNode_mC382B873595EC09498D00325F844BE2B92E8737D (void);
// 0x00000617 System.Type System.Runtime.Serialization.Globals::get_TypeOfClassDataNode()
extern void Globals_get_TypeOfClassDataNode_mFC1502378635430225B06C79C781CE3ECA4AFDB2 (void);
// 0x00000618 System.Type System.Runtime.Serialization.Globals::get_TypeOfCollectionDataNode()
extern void Globals_get_TypeOfCollectionDataNode_mCB3CB8D7A2B35A2D17F094F621808BEF250D51C0 (void);
// 0x00000619 System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlDataNode()
extern void Globals_get_TypeOfXmlDataNode_m91F9D1C7F196A5CE6C65DD9B5527187C2E74650B (void);
// 0x0000061A System.Type System.Runtime.Serialization.Globals::get_TypeOfNullable()
extern void Globals_get_TypeOfNullable_m8C368D6B7E3450342ACA2215E63F76C893E9995D (void);
// 0x0000061B System.Type System.Runtime.Serialization.Globals::get_TypeOfReflectionPointer()
extern void Globals_get_TypeOfReflectionPointer_mFC9D4461CC323FD38FBF9B93AEEEB1B90F96DC63 (void);
// 0x0000061C System.Type System.Runtime.Serialization.Globals::get_TypeOfIDictionaryGeneric()
extern void Globals_get_TypeOfIDictionaryGeneric_m270144C1FDD0C11F88AF1BBF8F7F8D981D474A72 (void);
// 0x0000061D System.Type System.Runtime.Serialization.Globals::get_TypeOfIDictionary()
extern void Globals_get_TypeOfIDictionary_m6B39844438359096667CFA03AFEBB5D24E71162E (void);
// 0x0000061E System.Type System.Runtime.Serialization.Globals::get_TypeOfIListGeneric()
extern void Globals_get_TypeOfIListGeneric_m79C32B6A5417AD653FFB65ED6214744A79E4399C (void);
// 0x0000061F System.Type System.Runtime.Serialization.Globals::get_TypeOfIList()
extern void Globals_get_TypeOfIList_m56A41A3FDA376FDB072E64F8A112B550FD749D04 (void);
// 0x00000620 System.Type System.Runtime.Serialization.Globals::get_TypeOfICollectionGeneric()
extern void Globals_get_TypeOfICollectionGeneric_m8E7D618EBCE31FEC94EE1373DEC575CD05AC5CFD (void);
// 0x00000621 System.Type System.Runtime.Serialization.Globals::get_TypeOfICollection()
extern void Globals_get_TypeOfICollection_m1211961FE5E4BB78B3FADA7963823C782094FEC5 (void);
// 0x00000622 System.Type System.Runtime.Serialization.Globals::get_TypeOfIEnumerableGeneric()
extern void Globals_get_TypeOfIEnumerableGeneric_m5D4DCA2C8551F9507AB692EEBA1A9A807BF6A777 (void);
// 0x00000623 System.Type System.Runtime.Serialization.Globals::get_TypeOfIEnumerable()
extern void Globals_get_TypeOfIEnumerable_m8F00F1739B50215C507F1CFF3A0E380AA20CBCB2 (void);
// 0x00000624 System.Type System.Runtime.Serialization.Globals::get_TypeOfIEnumerator()
extern void Globals_get_TypeOfIEnumerator_m30D2EF76635C4A3C34CC6FAD98B347EA645214C7 (void);
// 0x00000625 System.Type System.Runtime.Serialization.Globals::get_TypeOfKeyValuePair()
extern void Globals_get_TypeOfKeyValuePair_m9D7B32E478D122592E7E0230C49B43912107B62C (void);
// 0x00000626 System.Type System.Runtime.Serialization.Globals::get_TypeOfKeyValue()
extern void Globals_get_TypeOfKeyValue_m089699914EF2105352218553C7FFB52BB22D1F1A (void);
// 0x00000627 System.Type System.Runtime.Serialization.Globals::get_TypeOfDictionaryGeneric()
extern void Globals_get_TypeOfDictionaryGeneric_mFBCAC45C3BCAC574B166191934475634B390BE28 (void);
// 0x00000628 System.Type System.Runtime.Serialization.Globals::get_TypeOfHashtable()
extern void Globals_get_TypeOfHashtable_m9687819C4ABF1619960846BFC08803329DD98BF4 (void);
// 0x00000629 System.Type System.Runtime.Serialization.Globals::get_TypeOfXmlElement()
extern void Globals_get_TypeOfXmlElement_m00545F53F686DC8E53C8C2E119AFC8E15CFF1173 (void);
// 0x0000062A System.Type System.Runtime.Serialization.Globals::get_TypeOfDBNull()
extern void Globals_get_TypeOfDBNull_mA106905BF4FA8186420C8EB63A5B3C167EDB97A6 (void);
// 0x0000062B System.Uri System.Runtime.Serialization.Globals::get_DataContractXsdBaseNamespaceUri()
extern void Globals_get_DataContractXsdBaseNamespaceUri_m41DC518CB28E20D3B36E21BCCF8AC6E36334196E (void);
// 0x0000062C System.Void System.Runtime.Serialization.Globals::.cctor()
extern void Globals__cctor_mCD1AC5EEF827EE74F31C37E012156C297766A184 (void);
// 0x0000062D System.Void System.Runtime.Serialization.HybridObjectCache::.ctor()
extern void HybridObjectCache__ctor_mF59F29E84793641F3935AC5FD5427869103C8AED (void);
// 0x0000062E System.Void System.Runtime.Serialization.HybridObjectCache::Add(System.String,System.Object)
extern void HybridObjectCache_Add_mD243DC29A2F1B4D8DD9C33D209366871A8E1C4B7 (void);
// 0x0000062F System.Void System.Runtime.Serialization.HybridObjectCache::Remove(System.String)
extern void HybridObjectCache_Remove_mD4C9581D63168B232F0905CD341727003546E5D9 (void);
// 0x00000630 System.Object System.Runtime.Serialization.HybridObjectCache::GetObject(System.String)
extern void HybridObjectCache_GetObject_m372D40FB61273072D24F6B1C641E9FC1E6213EB5 (void);
// 0x00000631 System.Boolean System.Runtime.Serialization.HybridObjectCache::IsObjectReferenced(System.String)
extern void HybridObjectCache_IsObjectReferenced_mF7EFF705730BC9AD4F33CF9D3E71C31D73594D5B (void);
// 0x00000632 System.Type System.Runtime.Serialization.IDataContractSurrogate::GetDataContractType(System.Type)
// 0x00000633 System.Object System.Runtime.Serialization.IDataContractSurrogate::GetDeserializedObject(System.Object,System.Type)
// 0x00000634 System.Type System.Runtime.Serialization.DataContractSurrogateCaller::GetDataContractType(System.Runtime.Serialization.IDataContractSurrogate,System.Type)
extern void DataContractSurrogateCaller_GetDataContractType_m716190FF34EB41BA2588F9125145A2C1BDA4B2D0 (void);
// 0x00000635 System.Object System.Runtime.Serialization.DataContractSurrogateCaller::GetDeserializedObject(System.Runtime.Serialization.IDataContractSurrogate,System.Object,System.Type,System.Type)
extern void DataContractSurrogateCaller_GetDeserializedObject_m20606E9278D704C3C7D7D4DE8FFFE0DB79CA5E03 (void);
// 0x00000636 System.Void System.Runtime.Serialization.IExtensibleDataObject::set_ExtensionData(System.Runtime.Serialization.ExtensionDataObject)
// 0x00000637 System.Void System.Runtime.Serialization.InvalidDataContractException::.ctor()
extern void InvalidDataContractException__ctor_m1B7907967BE71E252FB194B48A5BAC81EBD7A497 (void);
// 0x00000638 System.Void System.Runtime.Serialization.InvalidDataContractException::.ctor(System.String)
extern void InvalidDataContractException__ctor_m6C50A1259C6FD9C49EA59E0905FBCA103A472559 (void);
// 0x00000639 System.Void System.Runtime.Serialization.InvalidDataContractException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void InvalidDataContractException__ctor_m4B8827EF5D454CB2E44460D237769C1067C198B8 (void);
// 0x0000063A System.Type[] System.Runtime.Serialization.JsonFormatGeneratorStatics::get_SerInfoCtorArgs()
extern void JsonFormatGeneratorStatics_get_SerInfoCtorArgs_m99046D52803F8762D8EF8708CDFEF81C888584DB (void);
// 0x0000063B System.Reflection.MethodInfo System.Runtime.Serialization.JsonFormatGeneratorStatics::get_UnboxPointer()
extern void JsonFormatGeneratorStatics_get_UnboxPointer_m3B478CE0F2273247E882E9E842AF5AB9169B765D (void);
// 0x0000063C System.String System.Runtime.Serialization.KnownTypeAttribute::get_MethodName()
extern void KnownTypeAttribute_get_MethodName_m03E297427311467FB8100421938FDBED0EF636F9 (void);
// 0x0000063D System.Type System.Runtime.Serialization.KnownTypeAttribute::get_Type()
extern void KnownTypeAttribute_get_Type_m5793D02AA0710114CED2E116FE487AD50FD97EB1 (void);
// 0x0000063E System.Void System.Runtime.Serialization.KnownTypeDataContractResolver::.ctor(System.Runtime.Serialization.XmlObjectSerializerContext)
extern void KnownTypeDataContractResolver__ctor_m0390C45BB89B4F852FCF096DE0C839EC73C05CEC (void);
// 0x0000063F System.Type System.Runtime.Serialization.KnownTypeDataContractResolver::ResolveName(System.String,System.String,System.Type,System.Runtime.Serialization.DataContractResolver)
extern void KnownTypeDataContractResolver_ResolveName_m05DF26BB60FF472DAAF911E44888B07BF0A630FC (void);
// 0x00000640 System.Boolean System.Runtime.Serialization.NetDataContractSerializer::get_UnsafeTypeForwardingEnabled()
extern void NetDataContractSerializer_get_UnsafeTypeForwardingEnabled_m64837E5264C34A263EBF0C76ED1F2DBC8BB8FBAA (void);
// 0x00000641 System.Object System.Runtime.Serialization.NetDataContractSerializer::ReadObject(System.Xml.XmlDictionaryReader,System.Boolean)
extern void NetDataContractSerializer_ReadObject_mE38EEE65FDCD7BCC22D197E32B7CE40840C8C555 (void);
// 0x00000642 System.Runtime.Serialization.ISerializationSurrogate System.Runtime.Serialization.NetDataContractSerializer::GetSurrogate(System.Type,System.Runtime.Serialization.ISurrogateSelector,System.Runtime.Serialization.StreamingContext)
extern void NetDataContractSerializer_GetSurrogate_m5BAD3BAFD8F4446E62ECF9FA0F054A42A59A234A (void);
// 0x00000643 System.Runtime.Serialization.DataContract System.Runtime.Serialization.NetDataContractSerializer::GetDataContractFromSurrogateSelector(System.Runtime.Serialization.ISurrogateSelector,System.Runtime.Serialization.StreamingContext,System.RuntimeTypeHandle,System.Type,System.Collections.Hashtable&)
extern void NetDataContractSerializer_GetDataContractFromSurrogateSelector_mF676988FF163F5FE901D107468587324D8BAAF28 (void);
// 0x00000644 System.Void System.Runtime.Serialization.NetDataContractSerializer::.cctor()
extern void NetDataContractSerializer__cctor_mF858EC3A27A0C8956CDB6F1BB0BEA117D17694E7 (void);
// 0x00000645 System.Void System.Runtime.Serialization.PrimitiveDataContract::.ctor(System.Type,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void PrimitiveDataContract__ctor_m146C4E5AB0CAF99F9E39CC48708F6006F05CC192 (void);
// 0x00000646 System.Runtime.Serialization.PrimitiveDataContract System.Runtime.Serialization.PrimitiveDataContract::GetPrimitiveDataContract(System.Type)
extern void PrimitiveDataContract_GetPrimitiveDataContract_m9B979CE9A15C991C6779E3D158BE04EC762AADE9 (void);
// 0x00000647 System.Runtime.Serialization.PrimitiveDataContract System.Runtime.Serialization.PrimitiveDataContract::GetPrimitiveDataContract(System.String,System.String)
extern void PrimitiveDataContract_GetPrimitiveDataContract_mD1EF14FB4CE2468A297C0F3BBBD8E232BC5143A6 (void);
// 0x00000648 System.String System.Runtime.Serialization.PrimitiveDataContract::get_ReadMethodName()
// 0x00000649 System.Xml.XmlDictionaryString System.Runtime.Serialization.PrimitiveDataContract::get_TopLevelElementNamespace()
extern void PrimitiveDataContract_get_TopLevelElementNamespace_m3A41D206646AC6B8364A850B1EC5FAA59A26C4E7 (void);
// 0x0000064A System.Boolean System.Runtime.Serialization.PrimitiveDataContract::get_CanContainReferences()
extern void PrimitiveDataContract_get_CanContainReferences_mEBEF354DD613240A2C90A1F962105E16B9F928C8 (void);
// 0x0000064B System.Boolean System.Runtime.Serialization.PrimitiveDataContract::get_IsPrimitive()
extern void PrimitiveDataContract_get_IsPrimitive_mE1FE00D7006F12F99656CA1299E93DAE50E4AAF4 (void);
// 0x0000064C System.Boolean System.Runtime.Serialization.PrimitiveDataContract::get_IsBuiltInDataContract()
extern void PrimitiveDataContract_get_IsBuiltInDataContract_mD852FBEFE8499A0A44E1BDC44C393B815639BD2C (void);
// 0x0000064D System.Reflection.MethodInfo System.Runtime.Serialization.PrimitiveDataContract::get_XmlFormatReaderMethod()
extern void PrimitiveDataContract_get_XmlFormatReaderMethod_m409918693BD1BD22A0C07F08D41CF1FA72BA8332 (void);
// 0x0000064E System.Object System.Runtime.Serialization.PrimitiveDataContract::HandleReadValue(System.Object,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void PrimitiveDataContract_HandleReadValue_m7B5E7A077F26AA47E35CB5619A5A31D6DB9D89F9 (void);
// 0x0000064F System.Boolean System.Runtime.Serialization.PrimitiveDataContract::TryReadNullAtTopLevel(System.Runtime.Serialization.XmlReaderDelegator)
extern void PrimitiveDataContract_TryReadNullAtTopLevel_m412A9940AA966C6ADCC8F0405ADE05F16B2CE656 (void);
// 0x00000650 System.Boolean System.Runtime.Serialization.PrimitiveDataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void PrimitiveDataContract_Equals_m882A3BEFF9635F1F43FE2EE50FD725CB2FA24FCA (void);
// 0x00000651 System.Void System.Runtime.Serialization.PrimitiveDataContract/PrimitiveDataContractCriticalHelper::.ctor(System.Type,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void PrimitiveDataContractCriticalHelper__ctor_mB64045A030B77F8C5B11C58523B769610593744A (void);
// 0x00000652 System.Reflection.MethodInfo System.Runtime.Serialization.PrimitiveDataContract/PrimitiveDataContractCriticalHelper::get_XmlFormatReaderMethod()
extern void PrimitiveDataContractCriticalHelper_get_XmlFormatReaderMethod_mB0CA0E901BEF0AD753B307AEF0872A6D3ED56F22 (void);
// 0x00000653 System.Void System.Runtime.Serialization.PrimitiveDataContract/PrimitiveDataContractCriticalHelper::set_XmlFormatReaderMethod(System.Reflection.MethodInfo)
extern void PrimitiveDataContractCriticalHelper_set_XmlFormatReaderMethod_m75BB08C3A1CD3F4F1D456D86CEEA31E1DB3715BA (void);
// 0x00000654 System.Void System.Runtime.Serialization.CharDataContract::.ctor()
extern void CharDataContract__ctor_m2B0F1D8C7274D39ABADBC690505814B7668D9AE6 (void);
// 0x00000655 System.Void System.Runtime.Serialization.CharDataContract::.ctor(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void CharDataContract__ctor_m4313EFE361E7C3BBD9DCB417EA2C61EE4EE08F5C (void);
// 0x00000656 System.String System.Runtime.Serialization.CharDataContract::get_ReadMethodName()
extern void CharDataContract_get_ReadMethodName_mF5F3558A682F847D94E860A1FAAF3E32A41EF74F (void);
// 0x00000657 System.Object System.Runtime.Serialization.CharDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void CharDataContract_ReadXmlValue_mE372966086CDCBA43D902A0538F1A2F962CBF20D (void);
// 0x00000658 System.Void System.Runtime.Serialization.AsmxCharDataContract::.ctor()
extern void AsmxCharDataContract__ctor_m287D290FEF66B61B95029EB10B383E208C41E51F (void);
// 0x00000659 System.Void System.Runtime.Serialization.BooleanDataContract::.ctor()
extern void BooleanDataContract__ctor_m1575CED4A6C16F86C3930DDE9CECBEB2DBEE83B1 (void);
// 0x0000065A System.String System.Runtime.Serialization.BooleanDataContract::get_ReadMethodName()
extern void BooleanDataContract_get_ReadMethodName_m5DA8FBFC935A7D571FAF6E7561A96EDA6E9CDECE (void);
// 0x0000065B System.Object System.Runtime.Serialization.BooleanDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void BooleanDataContract_ReadXmlValue_m78400BA87293DB4813B65F0E67E4DCEB91AE58B5 (void);
// 0x0000065C System.Void System.Runtime.Serialization.SignedByteDataContract::.ctor()
extern void SignedByteDataContract__ctor_mC7DE5147DBB698FB077C86DEE323529912584A52 (void);
// 0x0000065D System.String System.Runtime.Serialization.SignedByteDataContract::get_ReadMethodName()
extern void SignedByteDataContract_get_ReadMethodName_m24C57DB181EDCCAD07BFE1B36427EE791F00CB3F (void);
// 0x0000065E System.Object System.Runtime.Serialization.SignedByteDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void SignedByteDataContract_ReadXmlValue_mC7FEA4B2BCD1F7BABC5E2BDFE661615C8DE118F4 (void);
// 0x0000065F System.Void System.Runtime.Serialization.UnsignedByteDataContract::.ctor()
extern void UnsignedByteDataContract__ctor_m5E8DF24C41C19DAA4BD320501EFE5E614FE0516B (void);
// 0x00000660 System.String System.Runtime.Serialization.UnsignedByteDataContract::get_ReadMethodName()
extern void UnsignedByteDataContract_get_ReadMethodName_m9161A3DE99814644C1786710B319F48ABB436837 (void);
// 0x00000661 System.Object System.Runtime.Serialization.UnsignedByteDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void UnsignedByteDataContract_ReadXmlValue_mBB05641F0ED643E61E0876E5DB433B4D3D795761 (void);
// 0x00000662 System.Void System.Runtime.Serialization.ShortDataContract::.ctor()
extern void ShortDataContract__ctor_m7B82F08EF0F673A5533C98F53F3321F813FA55AA (void);
// 0x00000663 System.String System.Runtime.Serialization.ShortDataContract::get_ReadMethodName()
extern void ShortDataContract_get_ReadMethodName_mECBACD49D537AEB52993E5280A89027827306C79 (void);
// 0x00000664 System.Object System.Runtime.Serialization.ShortDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void ShortDataContract_ReadXmlValue_m99DA88FAA4BAB01C9B5F7395707BE012C0EB3878 (void);
// 0x00000665 System.Void System.Runtime.Serialization.UnsignedShortDataContract::.ctor()
extern void UnsignedShortDataContract__ctor_m8B579FABAA54E1F6ECF2EFCEDD51794700DAE856 (void);
// 0x00000666 System.String System.Runtime.Serialization.UnsignedShortDataContract::get_ReadMethodName()
extern void UnsignedShortDataContract_get_ReadMethodName_m517DF5B0DB96D51045F751B0A4B25C7527388204 (void);
// 0x00000667 System.Object System.Runtime.Serialization.UnsignedShortDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void UnsignedShortDataContract_ReadXmlValue_m78D050D634ABB2FE70293EA1EBC5F0388377C7CC (void);
// 0x00000668 System.Void System.Runtime.Serialization.IntDataContract::.ctor()
extern void IntDataContract__ctor_m4227B3E8F879241B92C6BB3E7453E019A244B956 (void);
// 0x00000669 System.String System.Runtime.Serialization.IntDataContract::get_ReadMethodName()
extern void IntDataContract_get_ReadMethodName_mBEEAD3CAAF520763357DF1390377558035AF05B4 (void);
// 0x0000066A System.Object System.Runtime.Serialization.IntDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void IntDataContract_ReadXmlValue_m8492B7D5061C1639E32D3D9753302DB50A15978A (void);
// 0x0000066B System.Void System.Runtime.Serialization.UnsignedIntDataContract::.ctor()
extern void UnsignedIntDataContract__ctor_m8716177EF29CC598555EDB24717D5169FD7E9903 (void);
// 0x0000066C System.String System.Runtime.Serialization.UnsignedIntDataContract::get_ReadMethodName()
extern void UnsignedIntDataContract_get_ReadMethodName_mBC8ADC4FBA21FC8B3BB812D4FC6AB1F463A0576E (void);
// 0x0000066D System.Object System.Runtime.Serialization.UnsignedIntDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void UnsignedIntDataContract_ReadXmlValue_mC4097BB24D8B27DE42CAFC77163C0FB9BE137CC0 (void);
// 0x0000066E System.Void System.Runtime.Serialization.LongDataContract::.ctor()
extern void LongDataContract__ctor_mA6CC865BEE3F8CB9EAA001A7CE2F0AD2F136A5AB (void);
// 0x0000066F System.Void System.Runtime.Serialization.LongDataContract::.ctor(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void LongDataContract__ctor_m9261B2651DA93C33A0AEC30FD379D4611F6825B7 (void);
// 0x00000670 System.String System.Runtime.Serialization.LongDataContract::get_ReadMethodName()
extern void LongDataContract_get_ReadMethodName_m8384B7F402A0CAAA856507BF44394C23659A7DFB (void);
// 0x00000671 System.Object System.Runtime.Serialization.LongDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void LongDataContract_ReadXmlValue_mA31F1D07CD0D1D47065D1284870BE6800BFB45BD (void);
// 0x00000672 System.Void System.Runtime.Serialization.IntegerDataContract::.ctor()
extern void IntegerDataContract__ctor_mDFDE3B1AD72C7EB53169D47720CD557F8A5F1993 (void);
// 0x00000673 System.Void System.Runtime.Serialization.PositiveIntegerDataContract::.ctor()
extern void PositiveIntegerDataContract__ctor_mA1CE70333C73BE0986989721591E160D3ECC143E (void);
// 0x00000674 System.Void System.Runtime.Serialization.NegativeIntegerDataContract::.ctor()
extern void NegativeIntegerDataContract__ctor_mE7753FE60AA2988087072BC9F6ABF0D01E1FD120 (void);
// 0x00000675 System.Void System.Runtime.Serialization.NonPositiveIntegerDataContract::.ctor()
extern void NonPositiveIntegerDataContract__ctor_m8165A54225F99393823396870B6B556F6BFFC639 (void);
// 0x00000676 System.Void System.Runtime.Serialization.NonNegativeIntegerDataContract::.ctor()
extern void NonNegativeIntegerDataContract__ctor_mB5976EAAC2280BA072B14202B2F4E91186BCC2E1 (void);
// 0x00000677 System.Void System.Runtime.Serialization.UnsignedLongDataContract::.ctor()
extern void UnsignedLongDataContract__ctor_m395DA01C4F93D59503800860AAC8DB3F6F4E9545 (void);
// 0x00000678 System.String System.Runtime.Serialization.UnsignedLongDataContract::get_ReadMethodName()
extern void UnsignedLongDataContract_get_ReadMethodName_m8A49C2BA7EB7D4B09EA0B85A071FAB5D3C14B8C7 (void);
// 0x00000679 System.Object System.Runtime.Serialization.UnsignedLongDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void UnsignedLongDataContract_ReadXmlValue_mB0DD0B8A69580AF2A8A288C4121FAF5EB75C310B (void);
// 0x0000067A System.Void System.Runtime.Serialization.FloatDataContract::.ctor()
extern void FloatDataContract__ctor_m5F758CF93725803C2010C17B40400737D901C957 (void);
// 0x0000067B System.String System.Runtime.Serialization.FloatDataContract::get_ReadMethodName()
extern void FloatDataContract_get_ReadMethodName_mBCB4C14564866266213150261DA0581CC0EE02F2 (void);
// 0x0000067C System.Object System.Runtime.Serialization.FloatDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void FloatDataContract_ReadXmlValue_mEA5EAD723784C0275BE4706C8706611DB6F98C85 (void);
// 0x0000067D System.Void System.Runtime.Serialization.DoubleDataContract::.ctor()
extern void DoubleDataContract__ctor_mFB622F6BE2ACD6940BA603B528C912572307412E (void);
// 0x0000067E System.String System.Runtime.Serialization.DoubleDataContract::get_ReadMethodName()
extern void DoubleDataContract_get_ReadMethodName_m53760BC810B2F59E5A739EE09AA061738F47C797 (void);
// 0x0000067F System.Object System.Runtime.Serialization.DoubleDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void DoubleDataContract_ReadXmlValue_m2446B3234F6334B0BFD2DD3389B0321C37C7C177 (void);
// 0x00000680 System.Void System.Runtime.Serialization.DecimalDataContract::.ctor()
extern void DecimalDataContract__ctor_m99BC8FA1329566AC6AC1F5865A85FE5CD3364A3A (void);
// 0x00000681 System.String System.Runtime.Serialization.DecimalDataContract::get_ReadMethodName()
extern void DecimalDataContract_get_ReadMethodName_mD9ACDE1A68C527053AEC346AAF004AF6D35CEAA1 (void);
// 0x00000682 System.Object System.Runtime.Serialization.DecimalDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void DecimalDataContract_ReadXmlValue_mF05F3AA37259ACEF7E1E2C8F1A6D4DEFA5B2DB0E (void);
// 0x00000683 System.Void System.Runtime.Serialization.DateTimeDataContract::.ctor()
extern void DateTimeDataContract__ctor_mE6B755C86A5F1EB0E25166A6A7B6711B3A258989 (void);
// 0x00000684 System.String System.Runtime.Serialization.DateTimeDataContract::get_ReadMethodName()
extern void DateTimeDataContract_get_ReadMethodName_m23145B831CACE8FCF94FC201CCECE9023E13CE86 (void);
// 0x00000685 System.Object System.Runtime.Serialization.DateTimeDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void DateTimeDataContract_ReadXmlValue_m8272BC82AC6767F4632E1DE3824220040C90E364 (void);
// 0x00000686 System.Void System.Runtime.Serialization.StringDataContract::.ctor()
extern void StringDataContract__ctor_mD6FFBDBD190A6663A8DC839242BE4CD7B829EB94 (void);
// 0x00000687 System.Void System.Runtime.Serialization.StringDataContract::.ctor(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void StringDataContract__ctor_m3BF90C66B3E5BD4CFCB83DD4B12AF85F247A3B25 (void);
// 0x00000688 System.String System.Runtime.Serialization.StringDataContract::get_ReadMethodName()
extern void StringDataContract_get_ReadMethodName_mE096888815A5210AEBDADCC195ECB2D83BC021C1 (void);
// 0x00000689 System.Object System.Runtime.Serialization.StringDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void StringDataContract_ReadXmlValue_m6F0037360ABF31CF9537939801A4E854E0293F90 (void);
// 0x0000068A System.Void System.Runtime.Serialization.TimeDataContract::.ctor()
extern void TimeDataContract__ctor_m81971C6320150DB6DB5827DF1D518AEB7D7490CE (void);
// 0x0000068B System.Void System.Runtime.Serialization.DateDataContract::.ctor()
extern void DateDataContract__ctor_m0C5B45835BFE91956FE60BDEE005FF81B0632EFB (void);
// 0x0000068C System.Void System.Runtime.Serialization.HexBinaryDataContract::.ctor()
extern void HexBinaryDataContract__ctor_m283272F87E989B6C645A8E7B709D0692E547A2B7 (void);
// 0x0000068D System.Void System.Runtime.Serialization.GYearMonthDataContract::.ctor()
extern void GYearMonthDataContract__ctor_m8340BC4BE93720C443CD405CEB902638F765A9F0 (void);
// 0x0000068E System.Void System.Runtime.Serialization.GYearDataContract::.ctor()
extern void GYearDataContract__ctor_m1970AC0F99E024A9011DD5885DD0FBA1D4460D55 (void);
// 0x0000068F System.Void System.Runtime.Serialization.GMonthDayDataContract::.ctor()
extern void GMonthDayDataContract__ctor_m0DDE117041BA54A690B12D6C95E3285D952CC603 (void);
// 0x00000690 System.Void System.Runtime.Serialization.GDayDataContract::.ctor()
extern void GDayDataContract__ctor_m01C7F98252D35397C8E1D04C25BD99A17921E588 (void);
// 0x00000691 System.Void System.Runtime.Serialization.GMonthDataContract::.ctor()
extern void GMonthDataContract__ctor_mA1E81297B02D0368A056DAF3DE5BB4F9D73C67C6 (void);
// 0x00000692 System.Void System.Runtime.Serialization.NormalizedStringDataContract::.ctor()
extern void NormalizedStringDataContract__ctor_m11E8D3585B6331F69DBF4701021CEEC3CF3C4A3A (void);
// 0x00000693 System.Void System.Runtime.Serialization.TokenDataContract::.ctor()
extern void TokenDataContract__ctor_m3752CA0B63554D3787BBF2C58D828DBF5C46CBF1 (void);
// 0x00000694 System.Void System.Runtime.Serialization.LanguageDataContract::.ctor()
extern void LanguageDataContract__ctor_m8B180442E8A8DA3790800279ACCABDA696BDC31D (void);
// 0x00000695 System.Void System.Runtime.Serialization.NameDataContract::.ctor()
extern void NameDataContract__ctor_m295CE4452CE55BDE19D7DE6A8F1EF43E3B59A75E (void);
// 0x00000696 System.Void System.Runtime.Serialization.NCNameDataContract::.ctor()
extern void NCNameDataContract__ctor_m57CC5A46E10A382B386D4BB6795A7EB9EE0070CF (void);
// 0x00000697 System.Void System.Runtime.Serialization.IDDataContract::.ctor()
extern void IDDataContract__ctor_m0255E33206C9EB11B03459315F5A24048F90DC58 (void);
// 0x00000698 System.Void System.Runtime.Serialization.IDREFDataContract::.ctor()
extern void IDREFDataContract__ctor_mC890B726FE7046408D87DB03C2ADBA5936004023 (void);
// 0x00000699 System.Void System.Runtime.Serialization.IDREFSDataContract::.ctor()
extern void IDREFSDataContract__ctor_m6F23119E2E993A2793A1DE354D46D101CCA7628A (void);
// 0x0000069A System.Void System.Runtime.Serialization.ENTITYDataContract::.ctor()
extern void ENTITYDataContract__ctor_m315411D454310CEBB5BAEF57B24FFEF41D256A05 (void);
// 0x0000069B System.Void System.Runtime.Serialization.ENTITIESDataContract::.ctor()
extern void ENTITIESDataContract__ctor_m7707A09875003DBBA17051C15EFC4B784D55CEC1 (void);
// 0x0000069C System.Void System.Runtime.Serialization.NMTOKENDataContract::.ctor()
extern void NMTOKENDataContract__ctor_mF4DB7E259DB1CDD0DCE5E8400FAA92BAE23A82B5 (void);
// 0x0000069D System.Void System.Runtime.Serialization.ByteArrayDataContract::.ctor()
extern void ByteArrayDataContract__ctor_mFFFB833CCB945F125EBAD19EC9CF2C8797BAB67B (void);
// 0x0000069E System.String System.Runtime.Serialization.ByteArrayDataContract::get_ReadMethodName()
extern void ByteArrayDataContract_get_ReadMethodName_mCC9515F07DFBAF6F34CFF0A27108D96B3B69FCE8 (void);
// 0x0000069F System.Object System.Runtime.Serialization.ByteArrayDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void ByteArrayDataContract_ReadXmlValue_m693978DEA6E94372E52390B729BB5A3927421BD4 (void);
// 0x000006A0 System.Void System.Runtime.Serialization.ObjectDataContract::.ctor()
extern void ObjectDataContract__ctor_m14C07F5DC455E690AE1585406D6EAB793912C41F (void);
// 0x000006A1 System.String System.Runtime.Serialization.ObjectDataContract::get_ReadMethodName()
extern void ObjectDataContract_get_ReadMethodName_m310BBC31C391FB9E7795F27E2B9588A16440F087 (void);
// 0x000006A2 System.Object System.Runtime.Serialization.ObjectDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void ObjectDataContract_ReadXmlValue_mB91EC4F9C50EDEEBB40EA85BAEA6576661F31F93 (void);
// 0x000006A3 System.Boolean System.Runtime.Serialization.ObjectDataContract::get_CanContainReferences()
extern void ObjectDataContract_get_CanContainReferences_m6C1659842F571CDB878BB75D299B4702A6E54631 (void);
// 0x000006A4 System.Boolean System.Runtime.Serialization.ObjectDataContract::get_IsPrimitive()
extern void ObjectDataContract_get_IsPrimitive_m0A520962DAEAF3747DF278D0F49BF7FE44B50F04 (void);
// 0x000006A5 System.Void System.Runtime.Serialization.TimeSpanDataContract::.ctor()
extern void TimeSpanDataContract__ctor_m55478A7DD3D40035DF7EF192BF70A4F6505F4193 (void);
// 0x000006A6 System.Void System.Runtime.Serialization.TimeSpanDataContract::.ctor(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void TimeSpanDataContract__ctor_m3E3082E93C20173597711405F978F926E035F53F (void);
// 0x000006A7 System.String System.Runtime.Serialization.TimeSpanDataContract::get_ReadMethodName()
extern void TimeSpanDataContract_get_ReadMethodName_mD74FAFCBD606618E81AF3847CAED7909B5B885B8 (void);
// 0x000006A8 System.Object System.Runtime.Serialization.TimeSpanDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void TimeSpanDataContract_ReadXmlValue_m1F4FB9326ECF6DC9FAC7AEE5604C425EADC32EB3 (void);
// 0x000006A9 System.Void System.Runtime.Serialization.XsDurationDataContract::.ctor()
extern void XsDurationDataContract__ctor_m51BAD021BEF550DFD713A93D6687A2345B9A64E1 (void);
// 0x000006AA System.Void System.Runtime.Serialization.GuidDataContract::.ctor()
extern void GuidDataContract__ctor_m4D2670B581E275951F41F4AEC1B9D98814A6D84D (void);
// 0x000006AB System.Void System.Runtime.Serialization.GuidDataContract::.ctor(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void GuidDataContract__ctor_mAB82027B30438103D37BE53C1027D5A8CAF36A4A (void);
// 0x000006AC System.String System.Runtime.Serialization.GuidDataContract::get_ReadMethodName()
extern void GuidDataContract_get_ReadMethodName_m99B8B44FC9D6BC43CF620348BF78F2A0B8223499 (void);
// 0x000006AD System.Object System.Runtime.Serialization.GuidDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void GuidDataContract_ReadXmlValue_mCC24744FEB1C101C27DBF6DDAE4F0AAE66ECCB3F (void);
// 0x000006AE System.Void System.Runtime.Serialization.AsmxGuidDataContract::.ctor()
extern void AsmxGuidDataContract__ctor_m8CF55BCE694762004281B1C671E98A752A52A899 (void);
// 0x000006AF System.Void System.Runtime.Serialization.UriDataContract::.ctor()
extern void UriDataContract__ctor_m9098993B8C8A1C3B08234DE1D2FC6FE860684583 (void);
// 0x000006B0 System.String System.Runtime.Serialization.UriDataContract::get_ReadMethodName()
extern void UriDataContract_get_ReadMethodName_mFCC5B25BD53F00227E2261C719FF37B1579EE980 (void);
// 0x000006B1 System.Object System.Runtime.Serialization.UriDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void UriDataContract_ReadXmlValue_mF248295567373E684CD71CBABEA6D02B1A5C9624 (void);
// 0x000006B2 System.Void System.Runtime.Serialization.QNameDataContract::.ctor()
extern void QNameDataContract__ctor_mB4804387AAF4999093C1742CE2B2E8CDF92EEE29 (void);
// 0x000006B3 System.String System.Runtime.Serialization.QNameDataContract::get_ReadMethodName()
extern void QNameDataContract_get_ReadMethodName_mB07D5400B519159A88D5340F397AFC7EC62581E1 (void);
// 0x000006B4 System.Boolean System.Runtime.Serialization.QNameDataContract::get_IsPrimitive()
extern void QNameDataContract_get_IsPrimitive_m6103ED0FD0292966F373EDE89E256CCA2A60EE38 (void);
// 0x000006B5 System.Object System.Runtime.Serialization.QNameDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void QNameDataContract_ReadXmlValue_mD7BED04A8F412296E9E98D90885D7D848CB7A790 (void);
// 0x000006B6 System.Xml.XmlElement System.Runtime.Serialization.SchemaExporter::ExportActualType(System.Xml.XmlQualifiedName,System.Xml.XmlDocument)
extern void SchemaExporter_ExportActualType_m24942764FFF573A7E0CBCFDAFF451D2E05B5EC9B (void);
// 0x000006B7 System.Void System.Runtime.Serialization.SchemaExporter::GetXmlTypeInfo(System.Type,System.Xml.XmlQualifiedName&,System.Xml.Schema.XmlSchemaType&,System.Boolean&)
extern void SchemaExporter_GetXmlTypeInfo_mE74DB2288D19D909AE9976A07C5F62411F5FDE9F (void);
// 0x000006B8 System.Boolean System.Runtime.Serialization.SchemaExporter::InvokeSchemaProviderMethod(System.Type,System.Xml.Schema.XmlSchemaSet,System.Xml.XmlQualifiedName&,System.Xml.Schema.XmlSchemaType&,System.Boolean&)
extern void SchemaExporter_InvokeSchemaProviderMethod_m2DD9A38668F81280D25873387C5FDBF234758056 (void);
// 0x000006B9 System.Xml.Schema.XmlSchemaComplexType System.Runtime.Serialization.SchemaExporter::CreateAnyType()
extern void SchemaExporter_CreateAnyType_mE2C1EE621F4DEAB55FD792DC9130C66E089FC1CA (void);
// 0x000006BA System.Xml.Schema.XmlSchemaComplexType System.Runtime.Serialization.SchemaExporter::CreateAnyElementType()
extern void SchemaExporter_CreateAnyElementType_m94C90DE0F7A47EBEE2D7A69EFC89F6AA753B019C (void);
// 0x000006BB System.Boolean System.Runtime.Serialization.SchemaExporter::IsSpecialXmlType(System.Type,System.Xml.XmlQualifiedName&,System.Xml.Schema.XmlSchemaType&,System.Boolean&)
extern void SchemaExporter_IsSpecialXmlType_mB12F35AECC497EBB4BC01247CF2924993B3CD770 (void);
// 0x000006BC System.Xml.Schema.XmlSchemaAnnotation System.Runtime.Serialization.SchemaExporter::GetSchemaAnnotation(System.Xml.XmlNode[])
extern void SchemaExporter_GetSchemaAnnotation_mD18B2890E76A130CB1C9DA75DAD0EEF7092E1683 (void);
// 0x000006BD System.Xml.XmlQualifiedName System.Runtime.Serialization.SchemaExporter::get_ActualTypeAnnotationName()
extern void SchemaExporter_get_ActualTypeAnnotationName_mF68C1E1644B1B4AC2CC5B43564B174D7FE53DEBF (void);
// 0x000006BE System.Void System.Runtime.Serialization.ScopedKnownTypes::Push(System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract>)
extern void ScopedKnownTypes_Push_mAEB53E753F4A8C2B043B054ABFA72F707744AB11 (void);
// 0x000006BF System.Void System.Runtime.Serialization.ScopedKnownTypes::Pop()
extern void ScopedKnownTypes_Pop_m60142B3457456EDEF4B1E11D13ACE26CF76C61C5 (void);
// 0x000006C0 System.Runtime.Serialization.DataContract System.Runtime.Serialization.ScopedKnownTypes::GetDataContract(System.Xml.XmlQualifiedName)
extern void ScopedKnownTypes_GetDataContract_m06420837D552E998FDBB5EAE2B2F8E6F8316DF08 (void);
// 0x000006C1 System.Void System.Runtime.Serialization.SpecialTypeDataContract::.ctor(System.Type,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void SpecialTypeDataContract__ctor_m8D04133E04D1DA2B6C5F232F2F0D743BBD3263AB (void);
// 0x000006C2 System.Boolean System.Runtime.Serialization.SpecialTypeDataContract::get_IsBuiltInDataContract()
extern void SpecialTypeDataContract_get_IsBuiltInDataContract_m9BC25F7E2C1AE65C34613C7F42830DC504DC6702 (void);
// 0x000006C3 System.Void System.Runtime.Serialization.SpecialTypeDataContract/SpecialTypeDataContractCriticalHelper::.ctor(System.Type,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void SpecialTypeDataContractCriticalHelper__ctor_m13D41BE9DA2B1E1535CDEC2D66F77964BE5D26E5 (void);
// 0x000006C4 System.Void System.Runtime.Serialization.SurrogateDataContract::.ctor(System.Type,System.Runtime.Serialization.ISerializationSurrogate)
extern void SurrogateDataContract__ctor_m3BAFC01AE91FC2A0862475ED7AE272EFC633DA1F (void);
// 0x000006C5 System.Runtime.Serialization.ISerializationSurrogate System.Runtime.Serialization.SurrogateDataContract::get_SerializationSurrogate()
extern void SurrogateDataContract_get_SerializationSurrogate_mA5E4540AE08A14119D308015F1143E1BA5500AC2 (void);
// 0x000006C6 System.Object System.Runtime.Serialization.SurrogateDataContract::SerializationSurrogateSetObjectData(System.Object,System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void SurrogateDataContract_SerializationSurrogateSetObjectData_m69B61758BF25709F42C36EE834EE9AF69E3DD0D2 (void);
// 0x000006C7 System.Object System.Runtime.Serialization.SurrogateDataContract::GetRealObject(System.Runtime.Serialization.IObjectReference,System.Runtime.Serialization.StreamingContext)
extern void SurrogateDataContract_GetRealObject_m18F438AB3E5445A8E782B4D275551416523197DE (void);
// 0x000006C8 System.Object System.Runtime.Serialization.SurrogateDataContract::GetUninitializedObject(System.Type)
extern void SurrogateDataContract_GetUninitializedObject_m274D6C24878857BF7CB52FE9119F610A0B6AA75F (void);
// 0x000006C9 System.Object System.Runtime.Serialization.SurrogateDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void SurrogateDataContract_ReadXmlValue_m9F0F69B6FAEB434E2FD634E3C505C73764075171 (void);
// 0x000006CA System.Void System.Runtime.Serialization.SurrogateDataContract/SurrogateDataContractCriticalHelper::.ctor(System.Type,System.Runtime.Serialization.ISerializationSurrogate)
extern void SurrogateDataContractCriticalHelper__ctor_m535E26ADC0C27106B3E1AED275B1D9D7362BC3D4 (void);
// 0x000006CB System.Runtime.Serialization.ISerializationSurrogate System.Runtime.Serialization.SurrogateDataContract/SurrogateDataContractCriticalHelper::get_SerializationSurrogate()
extern void SurrogateDataContractCriticalHelper_get_SerializationSurrogate_m1547D3B8C6142774E5962193913D680CC801A84A (void);
// 0x000006CC System.Void System.Runtime.Serialization.CreateXmlSerializableDelegate::.ctor(System.Object,System.IntPtr)
extern void CreateXmlSerializableDelegate__ctor_mE688BE59A7E4D7E47AC334794B4574BF27A13CB9 (void);
// 0x000006CD System.Xml.Serialization.IXmlSerializable System.Runtime.Serialization.CreateXmlSerializableDelegate::Invoke()
extern void CreateXmlSerializableDelegate_Invoke_mBD36C23967C8C63DA2F94EC08AC35E6D337AB240 (void);
// 0x000006CE System.Void System.Runtime.Serialization.XmlDataContract::.ctor(System.Type)
extern void XmlDataContract__ctor_m290446C87F724C33DD9BE84767AC3C3892A19D09 (void);
// 0x000006CF System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.XmlDataContract::get_KnownDataContracts()
extern void XmlDataContract_get_KnownDataContracts_mA028687927ED95AB2DC4F16C733907907320D8DC (void);
// 0x000006D0 System.Boolean System.Runtime.Serialization.XmlDataContract::get_IsAnonymous()
extern void XmlDataContract_get_IsAnonymous_m134AD7B1215E89268A2902337B9EADDCBC9EE567 (void);
// 0x000006D1 System.Boolean System.Runtime.Serialization.XmlDataContract::get_HasRoot()
extern void XmlDataContract_get_HasRoot_m7EFB591A1715D3F070D61EDE1931DA3DAA3C8E2F (void);
// 0x000006D2 System.Xml.XmlDictionaryString System.Runtime.Serialization.XmlDataContract::get_TopLevelElementName()
extern void XmlDataContract_get_TopLevelElementName_mAE8A979D8C1E09D78283A4BCE6D2806D20193507 (void);
// 0x000006D3 System.Xml.XmlDictionaryString System.Runtime.Serialization.XmlDataContract::get_TopLevelElementNamespace()
extern void XmlDataContract_get_TopLevelElementNamespace_m96A8A089E0A3F803995E7F99918E5A0C458AF2D0 (void);
// 0x000006D4 System.Runtime.Serialization.CreateXmlSerializableDelegate System.Runtime.Serialization.XmlDataContract::get_CreateXmlSerializableDelegate()
extern void XmlDataContract_get_CreateXmlSerializableDelegate_m1F3590D2022C619BF11BF47A57328BB2318EE98B (void);
// 0x000006D5 System.Boolean System.Runtime.Serialization.XmlDataContract::get_CanContainReferences()
extern void XmlDataContract_get_CanContainReferences_m71FC9ED3199802950272363302C24B21A7BC67B6 (void);
// 0x000006D6 System.Boolean System.Runtime.Serialization.XmlDataContract::get_IsBuiltInDataContract()
extern void XmlDataContract_get_IsBuiltInDataContract_mA67778BB22B27F99759BB79F54B057B92A373BAB (void);
// 0x000006D7 System.Boolean System.Runtime.Serialization.XmlDataContract::Equals(System.Object,System.Collections.Generic.Dictionary`2<System.Runtime.Serialization.DataContractPairKey,System.Object>)
extern void XmlDataContract_Equals_m2375AAFA4A26543BE136779A62DA8DD0840800A5 (void);
// 0x000006D8 System.Int32 System.Runtime.Serialization.XmlDataContract::GetHashCode()
extern void XmlDataContract_GetHashCode_mBA62D57C73EE7B30A3EBDE71549F0F75E69ACCB1 (void);
// 0x000006D9 System.Object System.Runtime.Serialization.XmlDataContract::ReadXmlValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void XmlDataContract_ReadXmlValue_mD0076749BAAB80238BF3E86E2AAC835DD159C098 (void);
// 0x000006DA System.Runtime.Serialization.CreateXmlSerializableDelegate System.Runtime.Serialization.XmlDataContract::GenerateCreateXmlSerializableDelegate()
extern void XmlDataContract_GenerateCreateXmlSerializableDelegate_m0534D6215C8853AA0719393E6935215E552045BA (void);
// 0x000006DB System.Xml.Serialization.IXmlSerializable System.Runtime.Serialization.XmlDataContract::<GenerateCreateXmlSerializableDelegate>b__39_0()
extern void XmlDataContract_U3CGenerateCreateXmlSerializableDelegateU3Eb__39_0_m2D950E71AE290A3A3286F0C04C4A4B222E2B0427 (void);
// 0x000006DC System.Void System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::.ctor(System.Type)
extern void XmlDataContractCriticalHelper__ctor_m2CE02607B9C2888B4DC2852B59F3FD0097A215FB (void);
// 0x000006DD System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_KnownDataContracts()
extern void XmlDataContractCriticalHelper_get_KnownDataContracts_mC4A96EDB700B22A808D622E335A4786AB601562D (void);
// 0x000006DE System.Void System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::set_XsdType(System.Xml.Schema.XmlSchemaType)
extern void XmlDataContractCriticalHelper_set_XsdType_m440C97C00F49C9C2609C937577C18BB2B84D53DB (void);
// 0x000006DF System.Boolean System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_IsAnonymous()
extern void XmlDataContractCriticalHelper_get_IsAnonymous_mDA58533D04B379BF048D5F47C317E0920292AF73 (void);
// 0x000006E0 System.Boolean System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_HasRoot()
extern void XmlDataContractCriticalHelper_get_HasRoot_m5D8A3F11110868154103966B5494049A0F75D1FE (void);
// 0x000006E1 System.Void System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::set_HasRoot(System.Boolean)
extern void XmlDataContractCriticalHelper_set_HasRoot_m1FC216372797FFAB5FB7E40E655A4C526BB7BEFE (void);
// 0x000006E2 System.Xml.XmlDictionaryString System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_TopLevelElementName()
extern void XmlDataContractCriticalHelper_get_TopLevelElementName_m5A778AADA9E8A5A5D13D90139782B1246C35E151 (void);
// 0x000006E3 System.Xml.XmlDictionaryString System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_TopLevelElementNamespace()
extern void XmlDataContractCriticalHelper_get_TopLevelElementNamespace_m98E6C3A209D5408EA756415FA100002412A1DDDC (void);
// 0x000006E4 System.Runtime.Serialization.CreateXmlSerializableDelegate System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::get_CreateXmlSerializableDelegate()
extern void XmlDataContractCriticalHelper_get_CreateXmlSerializableDelegate_m92E5716D5C6DFC4DBD71604E34F1C403E113F501 (void);
// 0x000006E5 System.Void System.Runtime.Serialization.XmlDataContract/XmlDataContractCriticalHelper::set_CreateXmlSerializableDelegate(System.Runtime.Serialization.CreateXmlSerializableDelegate)
extern void XmlDataContractCriticalHelper_set_CreateXmlSerializableDelegate_mA29E864DFE7F1B500469825F21C7089CD6B58F19 (void);
// 0x000006E6 System.Reflection.MethodInfo System.Runtime.Serialization.XmlFormatGeneratorStatics::get_UnboxPointer()
extern void XmlFormatGeneratorStatics_get_UnboxPointer_m36CD58F307FE72D573ED31B7ADB15A6021FE5DD3 (void);
// 0x000006E7 System.Reflection.ConstructorInfo System.Runtime.Serialization.XmlFormatGeneratorStatics::get_HashtableCtor()
extern void XmlFormatGeneratorStatics_get_HashtableCtor_m00FACE3C3F2EA8F572B4724B57F03F5196C20009 (void);
// 0x000006E8 System.Reflection.MethodInfo System.Runtime.Serialization.XmlFormatGeneratorStatics::get_EnsureArraySizeMethod()
extern void XmlFormatGeneratorStatics_get_EnsureArraySizeMethod_mD3E94D40B2C7B1119FCEA71FBF25C770ABC67530 (void);
// 0x000006E9 System.Reflection.MethodInfo System.Runtime.Serialization.XmlFormatGeneratorStatics::get_TrimArraySizeMethod()
extern void XmlFormatGeneratorStatics_get_TrimArraySizeMethod_mE7864C8DD86DE1784A5D825A2392296C61752DB1 (void);
// 0x000006EA System.Reflection.MethodInfo System.Runtime.Serialization.XmlFormatGeneratorStatics::get_ExtensionDataSetExplicitMethodInfo()
extern void XmlFormatGeneratorStatics_get_ExtensionDataSetExplicitMethodInfo_mB258964B2B65D771AB8B92DE76526AAB7147EF54 (void);
// 0x000006EB System.Void System.Runtime.Serialization.XmlFormatClassReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void XmlFormatClassReaderDelegate__ctor_m7540999C406A36A3D83FC80FA98CE265EB0876AB (void);
// 0x000006EC System.Object System.Runtime.Serialization.XmlFormatClassReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString[])
extern void XmlFormatClassReaderDelegate_Invoke_m2CD64C4BE88211C13EC30DB40D47878B265540E5 (void);
// 0x000006ED System.Void System.Runtime.Serialization.XmlFormatCollectionReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void XmlFormatCollectionReaderDelegate__ctor_m1075FA08015455E5060AA15BA7F8B99F9F3B4FAA (void);
// 0x000006EE System.Object System.Runtime.Serialization.XmlFormatCollectionReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatCollectionReaderDelegate_Invoke_m2689513FBB8E1C025CE23BABBFCAB97DEF709269 (void);
// 0x000006EF System.Void System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void XmlFormatGetOnlyCollectionReaderDelegate__ctor_m194D27CBCEBA0B47B75B848AE13D9BFFCA87B029 (void);
// 0x000006F0 System.Void System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatGetOnlyCollectionReaderDelegate_Invoke_m85C0D24CF14F622C320519F548D5A3CC8F6159D4 (void);
// 0x000006F1 System.Void System.Runtime.Serialization.XmlFormatReaderGenerator::.ctor()
extern void XmlFormatReaderGenerator__ctor_m1DAC2E3BB8A0396AEB95BBC4909A97D224F4102E (void);
// 0x000006F2 System.Runtime.Serialization.XmlFormatClassReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator::GenerateClassReader(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderGenerator_GenerateClassReader_mE348E481A99A53B1BE739CF53DD6CBD4591166FD (void);
// 0x000006F3 System.Runtime.Serialization.XmlFormatCollectionReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator::GenerateCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderGenerator_GenerateCollectionReader_mC262B1D1C90CF5C85FAC756EA38FE4272119B6DB (void);
// 0x000006F4 System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator::GenerateGetOnlyCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderGenerator_GenerateGetOnlyCollectionReader_m8A9D67F09A51940ECB853638F58D9CC056187C3A (void);
// 0x000006F5 System.Object System.Runtime.Serialization.XmlFormatReaderGenerator::UnsafeGetUninitializedObject(System.Int32)
extern void XmlFormatReaderGenerator_UnsafeGetUninitializedObject_mD6B698A20D7C110B75E75068E1966F72445EA8CA (void);
// 0x000006F6 System.Runtime.Serialization.XmlFormatClassReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper::GenerateClassReader(System.Runtime.Serialization.ClassDataContract)
extern void CriticalHelper_GenerateClassReader_m7D1701168B78CF1601BD9C986C233CABBACC7963 (void);
// 0x000006F7 System.Runtime.Serialization.XmlFormatCollectionReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper::GenerateCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void CriticalHelper_GenerateCollectionReader_mAA05B8B0EB88EB9C118CFD32617270E93594C92E (void);
// 0x000006F8 System.Runtime.Serialization.XmlFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper::GenerateGetOnlyCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void CriticalHelper_GenerateGetOnlyCollectionReader_m1EEC05751B3C0321D9A792C93805115A3184FC14 (void);
// 0x000006F9 System.Void System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper::.ctor()
extern void CriticalHelper__ctor_mED0BCF24551006D1D8E8BC27C2AEC359D2D76716 (void);
// 0x000006FA System.Void System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m9ECC8FC647C8BAD12AC0BB6D676220E33987B7FA (void);
// 0x000006FB System.Object System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass0_0::<GenerateClassReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString[])
extern void U3CU3Ec__DisplayClass0_0_U3CGenerateClassReaderU3Eb__0_mEFFB53B59C1028F145CAF0E8C1468B06C4AA86FE (void);
// 0x000006FC System.Void System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mC1B7F5262D06CE6FA38BF3748E77DD06BB69A7D0 (void);
// 0x000006FD System.Object System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass1_0::<GenerateCollectionReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void U3CU3Ec__DisplayClass1_0_U3CGenerateCollectionReaderU3Eb__0_mECA16C44D9C3C5EB20D40ADA15A352B02D7680EA (void);
// 0x000006FE System.Void System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m2E91805CA87AE98901DCDDD8A23A6FE3F4E97EA7 (void);
// 0x000006FF System.Void System.Runtime.Serialization.XmlFormatReaderGenerator/CriticalHelper/<>c__DisplayClass2_0::<GenerateGetOnlyCollectionReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void U3CU3Ec__DisplayClass2_0_U3CGenerateGetOnlyCollectionReaderU3Eb__0_m8727C046F7DABC40385590F32FAF56FCF41B945E (void);
// 0x00000700 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.XmlObjectSerializer::get_KnownDataContracts()
extern void XmlObjectSerializer_get_KnownDataContracts_m4AB99E62A9A3D5E06F286D5E8A195ED251188F67 (void);
// 0x00000701 System.Boolean System.Runtime.Serialization.XmlObjectSerializer::CheckIfNeedsContractNsAtRoot(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializer_CheckIfNeedsContractNsAtRoot_m851A33F9FFAB9ECE096D6F01DD3037100E91F6C5 (void);
// 0x00000702 System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObject(System.IO.Stream)
extern void XmlObjectSerializer_ReadObject_mA02AD3264C2E15EDA66BF1B421186875171E843F (void);
// 0x00000703 System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObject(System.Xml.XmlDictionaryReader)
extern void XmlObjectSerializer_ReadObject_m2254F2A960C12CE85203ED7B209C96596D84C64A (void);
// 0x00000704 System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObject(System.Xml.XmlReader,System.Boolean)
extern void XmlObjectSerializer_ReadObject_m666D95CAEA63C04C2B96B8CADE697FB65535B6DF (void);
// 0x00000705 System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObject(System.Xml.XmlDictionaryReader,System.Boolean)
// 0x00000706 System.Object System.Runtime.Serialization.XmlObjectSerializer::InternalReadObject(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean)
extern void XmlObjectSerializer_InternalReadObject_m24E4FD046FEEDA3CA30A94E0C2B5881C7D3A79E1 (void);
// 0x00000707 System.Object System.Runtime.Serialization.XmlObjectSerializer::InternalReadObject(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializer_InternalReadObject_m86E071E707539594FF90B58E1C9E73111DBBE85B (void);
// 0x00000708 System.Boolean System.Runtime.Serialization.XmlObjectSerializer::InternalIsStartObject(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializer_InternalIsStartObject_mFCF9E17599A6E362ED7AF11AE6A5CA19B633C9E2 (void);
// 0x00000709 System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObjectHandleExceptions(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean)
extern void XmlObjectSerializer_ReadObjectHandleExceptions_m1B315518C4090A3549166BFB1E2077D597603B89 (void);
// 0x0000070A System.Object System.Runtime.Serialization.XmlObjectSerializer::ReadObjectHandleExceptions(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializer_ReadObjectHandleExceptions_mA8D4369517F08DB469E801AFE08F51A74CD72084 (void);
// 0x0000070B System.Boolean System.Runtime.Serialization.XmlObjectSerializer::IsRootXmlAny(System.Xml.XmlDictionaryString,System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializer_IsRootXmlAny_mCAF2B30ABD9CC93199BA6DFE25050B876948E909 (void);
// 0x0000070C System.Boolean System.Runtime.Serialization.XmlObjectSerializer::IsStartElement(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializer_IsStartElement_mD594142280638E6470FE8229F24059C76497A6C7 (void);
// 0x0000070D System.Boolean System.Runtime.Serialization.XmlObjectSerializer::IsRootElement(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.DataContract,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlObjectSerializer_IsRootElement_m103207A51F8FA4045B48CC13CECCE39660C10094 (void);
// 0x0000070E System.Void System.Runtime.Serialization.XmlObjectSerializer::CheckNull(System.Object,System.String)
extern void XmlObjectSerializer_CheckNull_m36CB6C134A83A15B866E83876F6C045F8F288659 (void);
// 0x0000070F System.String System.Runtime.Serialization.XmlObjectSerializer::TryAddLineInfo(System.Runtime.Serialization.XmlReaderDelegator,System.String)
extern void XmlObjectSerializer_TryAddLineInfo_mF60B818D3CD897C6AA938049FD3B46315898CEF6 (void);
// 0x00000710 System.Exception System.Runtime.Serialization.XmlObjectSerializer::CreateSerializationExceptionWithReaderDetails(System.String,System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializer_CreateSerializationExceptionWithReaderDetails_m14080F0D052B10942003B969DD648A6110CE3B18 (void);
// 0x00000711 System.Runtime.Serialization.SerializationException System.Runtime.Serialization.XmlObjectSerializer::CreateSerializationException(System.String)
extern void XmlObjectSerializer_CreateSerializationException_m14581C5D9FE35E14E819276C06E69548661ED683 (void);
// 0x00000712 System.Runtime.Serialization.SerializationException System.Runtime.Serialization.XmlObjectSerializer::CreateSerializationException(System.String,System.Exception)
extern void XmlObjectSerializer_CreateSerializationException_m89D67E6172D4C9EAE21AD46BC7F1A51FD699AC67 (void);
// 0x00000713 System.String System.Runtime.Serialization.XmlObjectSerializer::GetTypeInfo(System.Type)
extern void XmlObjectSerializer_GetTypeInfo_mEF2C337869A33349B0137C8831D3199C1B7387A7 (void);
// 0x00000714 System.String System.Runtime.Serialization.XmlObjectSerializer::GetTypeInfoError(System.String,System.Type,System.Exception)
extern void XmlObjectSerializer_GetTypeInfoError_mAA19E974B1D87E706ACA54240E9671919D8E5D91 (void);
// 0x00000715 System.Type System.Runtime.Serialization.XmlObjectSerializer::GetDeserializeType()
extern void XmlObjectSerializer_GetDeserializeType_m8175483C7CF73CF85B5893AA51E9C568C6E324E2 (void);
// 0x00000716 System.Runtime.Serialization.IFormatterConverter System.Runtime.Serialization.XmlObjectSerializer::get_FormatterConverter()
extern void XmlObjectSerializer_get_FormatterConverter_mEEB240C964EACEFFA8BB599349C5514E570B6F50 (void);
// 0x00000717 System.Void System.Runtime.Serialization.XmlObjectSerializer::.ctor()
extern void XmlObjectSerializer__ctor_mD9F7398F63320021BC20A375FBC88A25ABB49B8E (void);
// 0x00000718 System.Void System.Runtime.Serialization.XmlObjectSerializerContext::.ctor(System.Runtime.Serialization.XmlObjectSerializer,System.Int32,System.Runtime.Serialization.StreamingContext,System.Boolean,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializerContext__ctor_m7F7FF6016E06319A448E8D8A39D82824D4811184 (void);
// 0x00000719 System.Void System.Runtime.Serialization.XmlObjectSerializerContext::.ctor(System.Runtime.Serialization.XmlObjectSerializer,System.Int32,System.Runtime.Serialization.StreamingContext,System.Boolean)
extern void XmlObjectSerializerContext__ctor_mEF0A0207FF9DF5CDB412BD61B1F65832E5625E4C (void);
// 0x0000071A System.Void System.Runtime.Serialization.XmlObjectSerializerContext::.ctor(System.Runtime.Serialization.DataContractSerializer,System.Runtime.Serialization.DataContract,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializerContext__ctor_m8789317F5CAC1B3563ED4EF4343A017419A2D2F5 (void);
// 0x0000071B System.Runtime.Serialization.SerializationMode System.Runtime.Serialization.XmlObjectSerializerContext::get_Mode()
extern void XmlObjectSerializerContext_get_Mode_mA76A9A0204EBAB9751092FAEB6D6D46A904D6EC7 (void);
// 0x0000071C System.Boolean System.Runtime.Serialization.XmlObjectSerializerContext::get_IsGetOnlyCollection()
extern void XmlObjectSerializerContext_get_IsGetOnlyCollection_m061C960C5E1EFF48CFDAEFE9A0CEEE1F2F9A91C2 (void);
// 0x0000071D System.Void System.Runtime.Serialization.XmlObjectSerializerContext::set_IsGetOnlyCollection(System.Boolean)
extern void XmlObjectSerializerContext_set_IsGetOnlyCollection_mCC176D028E701336FAEF33B1937766413064F506 (void);
// 0x0000071E System.Runtime.Serialization.StreamingContext System.Runtime.Serialization.XmlObjectSerializerContext::GetStreamingContext()
extern void XmlObjectSerializerContext_GetStreamingContext_m0CDE8264CA73B597CEB88C321B428C996409189A (void);
// 0x0000071F System.Void System.Runtime.Serialization.XmlObjectSerializerContext::IncrementItemCount(System.Int32)
extern void XmlObjectSerializerContext_IncrementItemCount_mDADAD621EED6E96EA12DAD9EC3CF3A5F74A21113 (void);
// 0x00000720 System.Int32 System.Runtime.Serialization.XmlObjectSerializerContext::get_RemainingItemCount()
extern void XmlObjectSerializerContext_get_RemainingItemCount_m958D1AECB35E28A9B81F54CDE7D8D95B83F39149 (void);
// 0x00000721 System.Boolean System.Runtime.Serialization.XmlObjectSerializerContext::get_IgnoreExtensionDataObject()
extern void XmlObjectSerializerContext_get_IgnoreExtensionDataObject_mCE077D7936D9819979BFF252D5B0DBF5A640A465 (void);
// 0x00000722 System.Runtime.Serialization.DataContractResolver System.Runtime.Serialization.XmlObjectSerializerContext::get_DataContractResolver()
extern void XmlObjectSerializerContext_get_DataContractResolver_mC95624015ACF30E8886958E0D86A9E993AEBAF5F (void);
// 0x00000723 System.Runtime.Serialization.KnownTypeDataContractResolver System.Runtime.Serialization.XmlObjectSerializerContext::get_KnownTypeResolver()
extern void XmlObjectSerializerContext_get_KnownTypeResolver_m90F7FE87E820247DA9EB2AAD29EC632E4D31B7EE (void);
// 0x00000724 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::GetDataContract(System.Type)
extern void XmlObjectSerializerContext_GetDataContract_m89BD7838153BFE29919053F7882C1343954480BC (void);
// 0x00000725 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::GetDataContract(System.RuntimeTypeHandle,System.Type)
extern void XmlObjectSerializerContext_GetDataContract_m3E68834FFFCC2E3E665A7EE70720F7AA9BE5B4A0 (void);
// 0x00000726 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::GetDataContract(System.Int32,System.RuntimeTypeHandle)
extern void XmlObjectSerializerContext_GetDataContract_mBD1259B5AC635FAED1D8FA516BCDE3993A399816 (void);
// 0x00000727 System.Void System.Runtime.Serialization.XmlObjectSerializerContext::CheckIfTypeSerializable(System.Type,System.Boolean)
extern void XmlObjectSerializerContext_CheckIfTypeSerializable_m35D8AC9DBC193F8701F7B98D3140024DBFE609B6 (void);
// 0x00000728 System.Type System.Runtime.Serialization.XmlObjectSerializerContext::GetSurrogatedType(System.Type)
extern void XmlObjectSerializerContext_GetSurrogatedType_mC3A2A3A15C7C87D3F5BA4D2304C61DFAA0630B22 (void);
// 0x00000729 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.XmlObjectSerializerContext::get_SerializerKnownDataContracts()
extern void XmlObjectSerializerContext_get_SerializerKnownDataContracts_m6BD78E52500AEE2BC8F14ED36C7BE19EC3683B30 (void);
// 0x0000072A System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::GetDataContractFromSerializerKnownTypes(System.Xml.XmlQualifiedName)
extern void XmlObjectSerializerContext_GetDataContractFromSerializerKnownTypes_mAE6DE0F22C4E2DA2B7FA3CA3228A46F62332E86F (void);
// 0x0000072B System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.XmlObjectSerializerContext::GetDataContractsForKnownTypes(System.Collections.Generic.IList`1<System.Type>)
extern void XmlObjectSerializerContext_GetDataContractsForKnownTypes_m69728BA7FCC48DB3E8A98990B79CC65DADF2DDE4 (void);
// 0x0000072C System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::ResolveDataContractFromKnownTypes(System.Xml.XmlQualifiedName)
extern void XmlObjectSerializerContext_ResolveDataContractFromKnownTypes_m86965A0EC92F932058FB4DB12AD20D0DF5470CFC (void);
// 0x0000072D System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::ResolveDataContractFromDataContractResolver(System.Xml.XmlQualifiedName,System.Type)
extern void XmlObjectSerializerContext_ResolveDataContractFromDataContractResolver_m40B4DBEA2C289DB6B1C677733F2B195F94B88BF4 (void);
// 0x0000072E System.Type System.Runtime.Serialization.XmlObjectSerializerContext::ResolveNameFromKnownTypes(System.Xml.XmlQualifiedName)
extern void XmlObjectSerializerContext_ResolveNameFromKnownTypes_m56854743EDCB03418893A0933E8E547E46216ECA (void);
// 0x0000072F System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::ResolveDataContractFromKnownTypes(System.String,System.String,System.Runtime.Serialization.DataContract,System.Type)
extern void XmlObjectSerializerContext_ResolveDataContractFromKnownTypes_mCFC92773A7FC04B4D85946E1B424E2AE36DBF0FF (void);
// 0x00000730 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerContext::ResolveDataContractFromRootDataContract(System.Xml.XmlQualifiedName)
extern void XmlObjectSerializerContext_ResolveDataContractFromRootDataContract_m2BBFC7C7384B8F15045D4A052C6BA551C23DAD5D (void);
// 0x00000731 System.Runtime.Serialization.HybridObjectCache System.Runtime.Serialization.XmlObjectSerializerReadContext::get_DeserializedObjects()
extern void XmlObjectSerializerReadContext_get_DeserializedObjects_m1135E7CAF7F7ED782DB9C48D0D15A48CF6269F22 (void);
// 0x00000732 System.Xml.XmlDocument System.Runtime.Serialization.XmlObjectSerializerReadContext::get_Document()
extern void XmlObjectSerializerReadContext_get_Document_m4C73E864B791B29E38B8E876AC67B466015861E0 (void);
// 0x00000733 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::get_IsGetOnlyCollection()
extern void XmlObjectSerializerReadContext_get_IsGetOnlyCollection_m7EDC6A09C1DCD7B4D810D358FB5A95AB17854EEF (void);
// 0x00000734 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::set_IsGetOnlyCollection(System.Boolean)
extern void XmlObjectSerializerReadContext_set_IsGetOnlyCollection_m9A0B06C07042C9EDC8DABBCD86A9807BB6F8820D (void);
// 0x00000735 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::GetCollectionMember()
extern void XmlObjectSerializerReadContext_GetCollectionMember_m318167A04E79B7C332391EDFF15BBDE6CF1FF8D2 (void);
// 0x00000736 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::StoreCollectionMemberInfo(System.Object)
extern void XmlObjectSerializerReadContext_StoreCollectionMemberInfo_mB15388D0739B55311B259BA368430D4D9F581E3E (void);
// 0x00000737 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ThrowNullValueReturnedForGetOnlyCollectionException(System.Type)
extern void XmlObjectSerializerReadContext_ThrowNullValueReturnedForGetOnlyCollectionException_m2487B962B1B98AD9370B7FDE8B32C0E3257D73ED (void);
// 0x00000738 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ThrowArrayExceededSizeException(System.Int32,System.Type)
extern void XmlObjectSerializerReadContext_ThrowArrayExceededSizeException_m2164AE3669BABBC863F6C59B9B5950A32A54E506 (void);
// 0x00000739 System.Runtime.Serialization.XmlObjectSerializerReadContext System.Runtime.Serialization.XmlObjectSerializerReadContext::CreateContext(System.Runtime.Serialization.DataContractSerializer,System.Runtime.Serialization.DataContract,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializerReadContext_CreateContext_m7CDAC27D66E7DF8DE7C6499FF484CB6B108D72A5 (void);
// 0x0000073A System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::.ctor(System.Runtime.Serialization.XmlObjectSerializer,System.Int32,System.Runtime.Serialization.StreamingContext,System.Boolean)
extern void XmlObjectSerializerReadContext__ctor_mD0C1321D113FD28FDC91525AD5845A683E264EAA (void);
// 0x0000073B System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::.ctor(System.Runtime.Serialization.DataContractSerializer,System.Runtime.Serialization.DataContract,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializerReadContext__ctor_m91703A76AC64EC5E3D549B46BEF5F753FB263EEB (void);
// 0x0000073C System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Int32,System.RuntimeTypeHandle,System.String,System.String)
extern void XmlObjectSerializerReadContext_InternalDeserialize_mFE4D3E3F7AC21C4FDF54B9DD0ECAE204887E94FF (void);
// 0x0000073D System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContext_InternalDeserialize_m3833C14A08C93A875AC5AD0B43AF9FA01A12F12C (void);
// 0x0000073E System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.Runtime.Serialization.DataContract,System.String,System.String)
extern void XmlObjectSerializerReadContext_InternalDeserialize_m15D26A6E1684D9A26C49C570E4D8F466EF426B35 (void);
// 0x0000073F System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::TryHandleNullOrRef(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.String,System.String,System.Object&)
extern void XmlObjectSerializerReadContext_TryHandleNullOrRef_m9367AAD76C139453DE2A4D39B79235D1B47170BC (void);
// 0x00000740 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String,System.Type,System.Runtime.Serialization.DataContract&)
extern void XmlObjectSerializerReadContext_InternalDeserialize_m59AB5DF5675EBF635551B0AD83FE554C44451B12 (void);
// 0x00000741 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::ReplaceScopedKnownTypesTop(System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract>,System.Boolean)
extern void XmlObjectSerializerReadContext_ReplaceScopedKnownTypesTop_mFEBF7A7947ECCCC68A3661B57E9DEDB84131B46F (void);
// 0x00000742 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::MoveToNextElement(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_MoveToNextElement_m3FE7D91B83F11C1C125DCD11058CCA8425D1FCD3 (void);
// 0x00000743 System.Int32 System.Runtime.Serialization.XmlObjectSerializerReadContext::GetMemberIndex(System.Runtime.Serialization.XmlReaderDelegator,System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString[],System.Int32,System.Runtime.Serialization.ExtensionDataObject)
extern void XmlObjectSerializerReadContext_GetMemberIndex_mEDE68AC0F431A4390330B403AF8863157980E1E8 (void);
// 0x00000744 System.Int32 System.Runtime.Serialization.XmlObjectSerializerReadContext::GetMemberIndexWithRequiredMembers(System.Runtime.Serialization.XmlReaderDelegator,System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString[],System.Int32,System.Int32,System.Runtime.Serialization.ExtensionDataObject)
extern void XmlObjectSerializerReadContext_GetMemberIndexWithRequiredMembers_m9DD5C1C0E8B71EC59B4384917F30F440F09999CF (void);
// 0x00000745 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ThrowRequiredMemberMissingException(System.Runtime.Serialization.XmlReaderDelegator,System.Int32,System.Int32,System.Xml.XmlDictionaryString[])
extern void XmlObjectSerializerReadContext_ThrowRequiredMemberMissingException_m37272374BE65C5E4A94BE5CFA8EB648287A1BE81 (void);
// 0x00000746 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::HandleMemberNotFound(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.ExtensionDataObject,System.Int32)
extern void XmlObjectSerializerReadContext_HandleMemberNotFound_mE592CF9FB5D991DB7A680FA52CF189EF6B2E2E83 (void);
// 0x00000747 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::HandleUnknownElement(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.ExtensionDataObject,System.Int32)
extern void XmlObjectSerializerReadContext_HandleUnknownElement_m84D5094C407AE36361009DFE51FC15D27EF4F92F (void);
// 0x00000748 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::SkipUnknownElement(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_SkipUnknownElement_m09DC13E40D04E3A3E5772C96B2675F35579845DD (void);
// 0x00000749 System.String System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadIfNullOrRef(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.Boolean)
extern void XmlObjectSerializerReadContext_ReadIfNullOrRef_m37AF4C79C0A9666A067D09BFD1D614641A2735E2 (void);
// 0x0000074A System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadAttributes(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_ReadAttributes_m376561B9161938A5AFBA18EC36309066151EC3FB (void);
// 0x0000074B System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ResetAttributes()
extern void XmlObjectSerializerReadContext_ResetAttributes_m9D9479017D0678452FBAC19051F25DEDC3EC59FC (void);
// 0x0000074C System.String System.Runtime.Serialization.XmlObjectSerializerReadContext::GetObjectId()
extern void XmlObjectSerializerReadContext_GetObjectId_mA8DDBFE7E4CF3181E53A71CC80B338AED3E1FF3B (void);
// 0x0000074D System.Int32 System.Runtime.Serialization.XmlObjectSerializerReadContext::GetArraySize()
extern void XmlObjectSerializerReadContext_GetArraySize_mDF5FA348F26E632DC923F768FE50E552657B6B59 (void);
// 0x0000074E System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::AddNewObject(System.Object)
extern void XmlObjectSerializerReadContext_AddNewObject_mAF67A9375CCB014DA9229B30D8FB73800FED3E4F (void);
// 0x0000074F System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::AddNewObjectWithId(System.String,System.Object)
extern void XmlObjectSerializerReadContext_AddNewObjectWithId_mA025D37DE842CC7FBFA296623365B60B0E8C4D61 (void);
// 0x00000750 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ReplaceDeserializedObject(System.String,System.Object,System.Object)
extern void XmlObjectSerializerReadContext_ReplaceDeserializedObject_m6DFB72A236EABA37FB18DCA12B97E82D78C71B58 (void);
// 0x00000751 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::GetExistingObject(System.String,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContext_GetExistingObject_m2F6E47B776BAC1123105CCF2C6E2F03AA631AABF (void);
// 0x00000752 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::GetExistingObjectOrExtensionData(System.String)
extern void XmlObjectSerializerReadContext_GetExistingObjectOrExtensionData_mECD9E949454AB3A47C50AA5D61BCE33BF33D994E (void);
// 0x00000753 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::GetRealObject(System.Runtime.Serialization.IObjectReference,System.String)
extern void XmlObjectSerializerReadContext_GetRealObject_m5ABF9F7B2C71F9B0E7829B8AD935A6EDEC9E6311 (void);
// 0x00000754 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::DeserializeFromExtensionData(System.Runtime.Serialization.IDataNode,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContext_DeserializeFromExtensionData_m84BB24DC28F9E873250F3FA4D74E1614D7D49CDF (void);
// 0x00000755 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::Read(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_Read_mF95A19F2DA6548034AE42E2A20E0AEB441286542 (void);
// 0x00000756 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::ParseQualifiedName(System.String,System.Runtime.Serialization.XmlReaderDelegator,System.String&,System.String&,System.String&)
extern void XmlObjectSerializerReadContext_ParseQualifiedName_m9FE0EE3917A6654C05D8105F7EC290629D381D67 (void);
// 0x00000757 T[] System.Runtime.Serialization.XmlObjectSerializerReadContext::EnsureArraySize(T[],System.Int32)
// 0x00000758 T[] System.Runtime.Serialization.XmlObjectSerializerReadContext::TrimArraySize(T[],System.Int32)
// 0x00000759 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::CheckEndOfArray(System.Runtime.Serialization.XmlReaderDelegator,System.Int32,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlObjectSerializerReadContext_CheckEndOfArray_m3C446EDF2BA75B22B98A61E587F6333A3CE0EA28 (void);
// 0x0000075A System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadIXmlSerializable(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlDataContract,System.Boolean)
extern void XmlObjectSerializerReadContext_ReadIXmlSerializable_mC90B09F03FADC07568F73162B9E5DF0A71053759 (void);
// 0x0000075B System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadRootIXmlSerializable(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlDataContract,System.Boolean)
extern void XmlObjectSerializerReadContext_ReadRootIXmlSerializable_mCE2EBBFF0B62120B535F0177580B43C2C0B16A56 (void);
// 0x0000075C System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadIXmlSerializable(System.Runtime.Serialization.XmlSerializableReader,System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlDataContract,System.Boolean)
extern void XmlObjectSerializerReadContext_ReadIXmlSerializable_m566CB1998DC64A1F59155EA65CC169A09F2C9686 (void);
// 0x0000075D System.Runtime.Serialization.SerializationInfo System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadSerializationInfo(System.Runtime.Serialization.XmlReaderDelegator,System.Type)
extern void XmlObjectSerializerReadContext_ReadSerializationInfo_mCDDBC0788E6F1B7C790ECB32813470C9A4FB83F8 (void);
// 0x0000075E System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerReadContext::ResolveDataContractFromTypeName()
extern void XmlObjectSerializerReadContext_ResolveDataContractFromTypeName_m93C9E7BE15CAF9C3BC4D071802788E1AE2D84F21 (void);
// 0x0000075F System.Runtime.Serialization.ExtensionDataMember System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadExtensionDataMember(System.Runtime.Serialization.XmlReaderDelegator,System.Int32)
extern void XmlObjectSerializerReadContext_ReadExtensionDataMember_mC93DDF7CAB5B8A41D261FBD157E838A193158AF2 (void);
// 0x00000760 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_ReadExtensionDataValue_mBB94399C4AC9D6BD1939BB64311FB662AC3E31CC (void);
// 0x00000761 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::StartReadExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_StartReadExtensionDataValue_mA4E5924F8529211767F7199794A56AAACCE04440 (void);
// 0x00000762 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadExtensionDataValue_m7DDEFDDE9050147E6655BD6D3448E9256E5AE222 (void);
// 0x00000763 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadPrimitiveExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadPrimitiveExtensionDataValue_mCEC49106E93B9FC63CF3BF15A52A361AD1B14C8E (void);
// 0x00000764 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContext::InitializeExtensionDataNode(System.Runtime.Serialization.IDataNode,System.String,System.String)
extern void XmlObjectSerializerReadContext_InitializeExtensionDataNode_mE878A22871D7179FE4C2FCFDD9A341D2A9DF5088 (void);
// 0x00000765 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadUnknownPrimitiveData(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadUnknownPrimitiveData_mCDC97BBCD8344F4AF81364C62369EB1E82F5FECF (void);
// 0x00000766 System.Runtime.Serialization.ClassDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadUnknownClassData(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadUnknownClassData_mB0FC1D56B883A0B34587ECFC9802E30B4A10B362 (void);
// 0x00000767 System.Runtime.Serialization.CollectionDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadUnknownCollectionData(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadUnknownCollectionData_m4209419BE0F52D01E50109954B352C0479A0463C (void);
// 0x00000768 System.Runtime.Serialization.ISerializableDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadUnknownISerializableData(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadUnknownISerializableData_m544DF935E14D84164EC8C4DDBF8E4C26591C8583 (void);
// 0x00000769 System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadUnknownXmlData(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadUnknownXmlData_m60B697E1D88CE2C4173D5B81A4C86BEE58E9E2ED (void);
// 0x0000076A System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadAndResolveUnknownXmlData(System.Runtime.Serialization.XmlReaderDelegator,System.Collections.Generic.IDictionary`2<System.String,System.String>,System.String,System.String)
extern void XmlObjectSerializerReadContext_ReadAndResolveUnknownXmlData_mA97FC9F7E2703BE67AC7E8EEC83205366E0F30F2 (void);
// 0x0000076B System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::IsContentNode(System.Xml.XmlNodeType)
extern void XmlObjectSerializerReadContext_IsContentNode_mB5A6BE0A4CCEF1D094427BC8A6E48386BD0627C1 (void);
// 0x0000076C System.Runtime.Serialization.XmlReaderDelegator System.Runtime.Serialization.XmlObjectSerializerReadContext::CreateReaderOverChildNodes(System.Collections.Generic.IList`1<System.Xml.XmlAttribute>,System.Collections.Generic.IList`1<System.Xml.XmlNode>)
extern void XmlObjectSerializerReadContext_CreateReaderOverChildNodes_m77397BF85CA394E44164484A442FFC17FB42578C (void);
// 0x0000076D System.Xml.XmlNode System.Runtime.Serialization.XmlObjectSerializerReadContext::CreateWrapperXmlElement(System.Xml.XmlDocument,System.Collections.Generic.IList`1<System.Xml.XmlAttribute>,System.Collections.Generic.IList`1<System.Xml.XmlNode>,System.String,System.String,System.String)
extern void XmlObjectSerializerReadContext_CreateWrapperXmlElement_mD94974CFC58F62A99845D39F3A51C8E3E81EABB9 (void);
// 0x0000076E System.Xml.XmlAttribute System.Runtime.Serialization.XmlObjectSerializerReadContext::AddNamespaceDeclaration(System.String,System.String)
extern void XmlObjectSerializerReadContext_AddNamespaceDeclaration_m3AC13188DB1C89566FD12510650D3D526A6875B1 (void);
// 0x0000076F System.Exception System.Runtime.Serialization.XmlObjectSerializerReadContext::CreateUnexpectedStateException(System.Xml.XmlNodeType,System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_CreateUnexpectedStateException_mFCBA863B32D81FE866E5062057FB9ABE335B969E (void);
// 0x00000770 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContext::ReadDataContractValue(System.Runtime.Serialization.DataContract,System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_ReadDataContractValue_m63F058C212D275967C12BC48FC980BDE3A739937 (void);
// 0x00000771 System.Runtime.Serialization.XmlReaderDelegator System.Runtime.Serialization.XmlObjectSerializerReadContext::CreateReaderDelegatorForReader(System.Xml.XmlReader)
extern void XmlObjectSerializerReadContext_CreateReaderDelegatorForReader_m27BCA4A3DD4532E7A25A24C3827AA35907D1D01E (void);
// 0x00000772 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::IsReadingCollectionExtensionData(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_IsReadingCollectionExtensionData_mA86BC09F259869A64F3C90047CF2F79B032B6373 (void);
// 0x00000773 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContext::IsReadingClassExtensionData(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContext_IsReadingClassExtensionData_mACFE1FCE36E11DAAF0F73E9CDC99AB3685C4F417 (void);
// 0x00000774 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::.ctor(System.Runtime.Serialization.DataContractSerializer,System.Runtime.Serialization.DataContract,System.Runtime.Serialization.DataContractResolver)
extern void XmlObjectSerializerReadContextComplex__ctor_mD03833D98556A401FA95FD59CD317AE66D044CB3 (void);
// 0x00000775 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::.ctor(System.Runtime.Serialization.XmlObjectSerializer,System.Int32,System.Runtime.Serialization.StreamingContext,System.Boolean)
extern void XmlObjectSerializerReadContextComplex__ctor_m6AC85976446C15DEE0A6E11244A7AECED10AD311 (void);
// 0x00000776 System.Runtime.Serialization.SerializationMode System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::get_Mode()
extern void XmlObjectSerializerReadContextComplex_get_Mode_m4C718FA2C1BC99E7518384C825DC21BF3E656F7B (void);
// 0x00000777 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::GetDataContract(System.Int32,System.RuntimeTypeHandle)
extern void XmlObjectSerializerReadContextComplex_GetDataContract_m41E205D5E0C161E588A165FE762A110B6A10E3CC (void);
// 0x00000778 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::GetDataContract(System.RuntimeTypeHandle,System.Type)
extern void XmlObjectSerializerReadContextComplex_GetDataContract_mE283D1C21257274BF9E34FD20BD070945485C479 (void);
// 0x00000779 System.Object System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Int32,System.RuntimeTypeHandle,System.String,System.String)
extern void XmlObjectSerializerReadContextComplex_InternalDeserialize_m6C11A2423EAD377112D8B6E6CC59AE4BEAA89D19 (void);
// 0x0000077A System.Object System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContextComplex_InternalDeserialize_mCBF64075D72A021B47C3A75B563618EEC2BC7118 (void);
// 0x0000077B System.Object System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::InternalDeserialize(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.Runtime.Serialization.DataContract,System.String,System.String)
extern void XmlObjectSerializerReadContextComplex_InternalDeserialize_m7359A5865B64347A5B9A0CBE12520A6A8E1A3619 (void);
// 0x0000077C System.Object System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::InternalDeserializeInSharedTypeMode(System.Runtime.Serialization.XmlReaderDelegator,System.Int32,System.Type,System.String,System.String)
extern void XmlObjectSerializerReadContextComplex_InternalDeserializeInSharedTypeMode_m5D4AE7CB90BFA797EC24C0FDC2B7F0DF59CD1AB9 (void);
// 0x0000077D System.Object System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::InternalDeserializeWithSurrogate(System.Runtime.Serialization.XmlReaderDelegator,System.Type,System.Runtime.Serialization.DataContract,System.String,System.String)
extern void XmlObjectSerializerReadContextComplex_InternalDeserializeWithSurrogate_mE0DDDAD0F4BF260FC0865432A321B298454FCDF1 (void);
// 0x0000077E System.Type System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::ResolveDataContractTypeInSharedTypeMode(System.String,System.String,System.Reflection.Assembly&)
extern void XmlObjectSerializerReadContextComplex_ResolveDataContractTypeInSharedTypeMode_m5D624616C89F0B7CC5197E05125B464A21FEBA47 (void);
// 0x0000077F System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::ResolveDataContractInSharedTypeMode(System.String,System.String,System.Reflection.Assembly&,System.Type&)
extern void XmlObjectSerializerReadContextComplex_ResolveDataContractInSharedTypeMode_mC8E73252B455352510F1E3403A57CD144E14635A (void);
// 0x00000780 System.Runtime.Serialization.DataContract System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::ResolveDataContractFromTypeName()
extern void XmlObjectSerializerReadContextComplex_ResolveDataContractFromTypeName_mF9626788898255D6573BA4C3277CA6F087193C8E (void);
// 0x00000781 System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::CheckIfTypeSerializableForSharedTypeMode(System.Type)
extern void XmlObjectSerializerReadContextComplex_CheckIfTypeSerializableForSharedTypeMode_mA241A6844FFE78E06BB63E077200EE9EF5DEAD71 (void);
// 0x00000782 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::CheckIfTypeSerializable(System.Type,System.Boolean)
extern void XmlObjectSerializerReadContextComplex_CheckIfTypeSerializable_m30755D9A3A302F1DA68A2AACB3F89ACF23036414 (void);
// 0x00000783 System.Type System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::GetSurrogatedType(System.Type)
extern void XmlObjectSerializerReadContextComplex_GetSurrogatedType_mBFA4CD50C5ECFB4DB44D47CEA4CBDEB61159A68D (void);
// 0x00000784 System.Int32 System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::GetArraySize()
extern void XmlObjectSerializerReadContextComplex_GetArraySize_m676279CD1E13EA195E94F8203AA2BE7D7F2050AF (void);
// 0x00000785 System.Reflection.Assembly System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::ResolveSimpleAssemblyName(System.Reflection.AssemblyName)
extern void XmlObjectSerializerReadContextComplex_ResolveSimpleAssemblyName_mE29133F8114C234CCF4B0A7E4108DBDE81926BC1 (void);
// 0x00000786 System.Reflection.Assembly System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::ResolveSimpleAssemblyName(System.String)
extern void XmlObjectSerializerReadContextComplex_ResolveSimpleAssemblyName_m2AF5E3BA9F937F2DB3989B0438432A8E4910847C (void);
// 0x00000787 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::CheckTypeForwardedTo(System.Reflection.Assembly,System.Reflection.Assembly,System.Type)
extern void XmlObjectSerializerReadContextComplex_CheckTypeForwardedTo_mBD947AD2394CFDADE4639ED510F2D186A18D117D (void);
// 0x00000788 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex::.cctor()
extern void XmlObjectSerializerReadContextComplex__cctor_m72A87E5CDB277460F60C5BFBAD671C8FF3F2DF8D (void);
// 0x00000789 System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/TopLevelAssemblyTypeResolver::.ctor(System.Reflection.Assembly)
extern void TopLevelAssemblyTypeResolver__ctor_m28B39914F9DE57129656DD64582D1E4B1376C4CF (void);
// 0x0000078A System.Type System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/TopLevelAssemblyTypeResolver::ResolveType(System.Reflection.Assembly,System.String,System.Boolean)
extern void TopLevelAssemblyTypeResolver_ResolveType_m3FC6132EBB2FB8D48EE462735FA1945605F2D777 (void);
// 0x0000078B System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeInfo::.ctor(System.Reflection.Assembly,System.Type)
extern void XmlObjectDataContractTypeInfo__ctor_m98CE7DAC6FBFE09FDE9F41BD6E1C4CE2948CEF37 (void);
// 0x0000078C System.Reflection.Assembly System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeInfo::get_Assembly()
extern void XmlObjectDataContractTypeInfo_get_Assembly_m9A661F828081CE309A5C775571732C42FA44A368 (void);
// 0x0000078D System.Type System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeInfo::get_Type()
extern void XmlObjectDataContractTypeInfo_get_Type_mC38109214EFAF6BE6F7BCC3E7676B1202247D943 (void);
// 0x0000078E System.Void System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeKey::.ctor(System.String,System.String)
extern void XmlObjectDataContractTypeKey__ctor_mA6770F3220D706F2D7ED9748FE20AC5273E0765F (void);
// 0x0000078F System.Boolean System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeKey::Equals(System.Object)
extern void XmlObjectDataContractTypeKey_Equals_mC4C4AE83B8A33FA77BF4F651128E4F82A9B70F5F (void);
// 0x00000790 System.Int32 System.Runtime.Serialization.XmlObjectSerializerReadContextComplex/XmlObjectDataContractTypeKey::GetHashCode()
extern void XmlObjectDataContractTypeKey_GetHashCode_m16159C93712604A06A0CEF2B0811E5169159B74A (void);
// 0x00000791 System.Void System.Runtime.Serialization.XmlReaderDelegator::.ctor(System.Xml.XmlReader)
extern void XmlReaderDelegator__ctor_m86F759055A24BCB7E6B61563FE6EA99A9BBB4ADD (void);
// 0x00000792 System.Xml.XmlReader System.Runtime.Serialization.XmlReaderDelegator::get_UnderlyingReader()
extern void XmlReaderDelegator_get_UnderlyingReader_mA881749D0A82CAA178175411409CB4B09E56B6C2 (void);
// 0x00000793 System.Runtime.Serialization.ExtensionDataReader System.Runtime.Serialization.XmlReaderDelegator::get_UnderlyingExtensionDataReader()
extern void XmlReaderDelegator_get_UnderlyingExtensionDataReader_m4D4FE50A454FC18380938633D58A137CA0745AD7 (void);
// 0x00000794 System.Int32 System.Runtime.Serialization.XmlReaderDelegator::get_AttributeCount()
extern void XmlReaderDelegator_get_AttributeCount_m68635E8A6050ABB50497BD1F8FB36598D2588717 (void);
// 0x00000795 System.String System.Runtime.Serialization.XmlReaderDelegator::GetAttribute(System.String)
extern void XmlReaderDelegator_GetAttribute_mA5E33B6B04C18E07EDF5C4C0049C43A7AB2AAA42 (void);
// 0x00000796 System.String System.Runtime.Serialization.XmlReaderDelegator::GetAttribute(System.String,System.String)
extern void XmlReaderDelegator_GetAttribute_mAF37FD5BACCDF7829047CA9148879A0E21B613AB (void);
// 0x00000797 System.String System.Runtime.Serialization.XmlReaderDelegator::GetAttribute(System.Int32)
extern void XmlReaderDelegator_GetAttribute_mFB87CB78870070EE8465C47323FD42D7BEA70FBC (void);
// 0x00000798 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::get_IsEmptyElement()
extern void XmlReaderDelegator_get_IsEmptyElement_m3AB8D9EAB1BE3ED9EF10ED42498FC779302128EA (void);
// 0x00000799 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsNamespaceURI(System.String)
extern void XmlReaderDelegator_IsNamespaceURI_m7102C183363D95F232B8AB1B7C9D18B0BB9D8691 (void);
// 0x0000079A System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsLocalName(System.String)
extern void XmlReaderDelegator_IsLocalName_m19A26A86B1C125414B73AB11A750BA32468F38A8 (void);
// 0x0000079B System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsNamespaceUri(System.Xml.XmlDictionaryString)
extern void XmlReaderDelegator_IsNamespaceUri_mEF3A30B819D823EF65A09CAD673D473628255A6B (void);
// 0x0000079C System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsLocalName(System.Xml.XmlDictionaryString)
extern void XmlReaderDelegator_IsLocalName_m33854F779A2DA7D902C6FA548A307896CC006B9A (void);
// 0x0000079D System.Int32 System.Runtime.Serialization.XmlReaderDelegator::IndexOfLocalName(System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString)
extern void XmlReaderDelegator_IndexOfLocalName_mE69EAC3EF256F7062FBE7D9AB7AA95FE52F7ED63 (void);
// 0x0000079E System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsStartElement()
extern void XmlReaderDelegator_IsStartElement_mEF1624BAA20BBACB032D65BB32008A2CACC3A835 (void);
// 0x0000079F System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsStartElement(System.String,System.String)
extern void XmlReaderDelegator_IsStartElement_mE7A06394F3F473E5E04258F439763B4F7D46E80F (void);
// 0x000007A0 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::IsStartElement(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlReaderDelegator_IsStartElement_m10E2BA5D745DEA429513E28FFD06BA41B85162D1 (void);
// 0x000007A1 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::MoveToAttribute(System.String)
extern void XmlReaderDelegator_MoveToAttribute_m84B1DB12A2C6FF8F1C7CE98581696666D4F4A411 (void);
// 0x000007A2 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::MoveToAttribute(System.String,System.String)
extern void XmlReaderDelegator_MoveToAttribute_mCCC01D964006036A8721B9685C7E6E14DCDB54B5 (void);
// 0x000007A3 System.Void System.Runtime.Serialization.XmlReaderDelegator::MoveToAttribute(System.Int32)
extern void XmlReaderDelegator_MoveToAttribute_m64161D12742B1AD2614E1F85324B735A725A48A0 (void);
// 0x000007A4 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::MoveToElement()
extern void XmlReaderDelegator_MoveToElement_m3D6BA21BF925B9FEB6C795E5120DC8901289945C (void);
// 0x000007A5 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::MoveToFirstAttribute()
extern void XmlReaderDelegator_MoveToFirstAttribute_m1F65752A23590A550E9F7D045F675092A7FF6B23 (void);
// 0x000007A6 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::MoveToNextAttribute()
extern void XmlReaderDelegator_MoveToNextAttribute_mE546DED2B738D7A87F000CECA5ABC2272291C7C0 (void);
// 0x000007A7 System.Xml.XmlNodeType System.Runtime.Serialization.XmlReaderDelegator::get_NodeType()
extern void XmlReaderDelegator_get_NodeType_mCA3CCC1C3403C8CBFAB9AA5A97133735C913F940 (void);
// 0x000007A8 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::Read()
extern void XmlReaderDelegator_Read_m33D68413FFA1ED6AC36CCE6C216628B11A4D6F03 (void);
// 0x000007A9 System.Xml.XmlNodeType System.Runtime.Serialization.XmlReaderDelegator::MoveToContent()
extern void XmlReaderDelegator_MoveToContent_m945C5E02682DAFC31A13791EC5F79D1731115B85 (void);
// 0x000007AA System.Boolean System.Runtime.Serialization.XmlReaderDelegator::ReadAttributeValue()
extern void XmlReaderDelegator_ReadAttributeValue_m9B1948224E6E8C57D6FC35F266D883DE0B32DF34 (void);
// 0x000007AB System.Void System.Runtime.Serialization.XmlReaderDelegator::ReadEndElement()
extern void XmlReaderDelegator_ReadEndElement_m55090939D60CC18064BB9FDE79A33757615A63A4 (void);
// 0x000007AC System.Exception System.Runtime.Serialization.XmlReaderDelegator::CreateInvalidPrimitiveTypeException(System.Type)
extern void XmlReaderDelegator_CreateInvalidPrimitiveTypeException_mA9FA6E1D5EB6EF70F3EEE0CF37ACE8584AB05829 (void);
// 0x000007AD System.Object System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsAnyType(System.Type)
extern void XmlReaderDelegator_ReadElementContentAsAnyType_m9127162869A572EF18D797A71228D65A0501AE98 (void);
// 0x000007AE System.Object System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsAnyType(System.Type)
extern void XmlReaderDelegator_ReadContentAsAnyType_m6C689E81F1C20F3A23F4C31DBA48A036DF31E9A9 (void);
// 0x000007AF System.Runtime.Serialization.IDataNode System.Runtime.Serialization.XmlReaderDelegator::ReadExtensionData(System.Type)
extern void XmlReaderDelegator_ReadExtensionData_m6C772EC19343083F36C782193F7A309DBD9E5EF6 (void);
// 0x000007B0 System.Void System.Runtime.Serialization.XmlReaderDelegator::ThrowConversionException(System.String,System.String)
extern void XmlReaderDelegator_ThrowConversionException_mA8ED224EFC068123101B7322E9685B364DD9C3D3 (void);
// 0x000007B1 System.Void System.Runtime.Serialization.XmlReaderDelegator::ThrowNotAtElement()
extern void XmlReaderDelegator_ThrowNotAtElement_m2F00424DA34AAE315F2AC95A6D7551902A02E1D4 (void);
// 0x000007B2 System.Char System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsChar()
extern void XmlReaderDelegator_ReadElementContentAsChar_mB3EF316599AC07D07571C6CAB8C0831842192574 (void);
// 0x000007B3 System.Char System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsChar()
extern void XmlReaderDelegator_ReadContentAsChar_mBD50A4C640E5A66237AC26F7372E5359A6337B17 (void);
// 0x000007B4 System.Char System.Runtime.Serialization.XmlReaderDelegator::ToChar(System.Int32)
extern void XmlReaderDelegator_ToChar_m5155FF5D55886CDB618F74CDCE344A129C3DE88E (void);
// 0x000007B5 System.String System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsString()
extern void XmlReaderDelegator_ReadElementContentAsString_mBFB45337BC2DBE04C102D80AD188E1A5AF63C44E (void);
// 0x000007B6 System.String System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsString()
extern void XmlReaderDelegator_ReadContentAsString_mC50E197B7B6AA7A93C51E6DCE92249F325E0773D (void);
// 0x000007B7 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsBoolean()
extern void XmlReaderDelegator_ReadElementContentAsBoolean_m20DBF68E383BEEBADD3934FC1A2595803AA08209 (void);
// 0x000007B8 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsBoolean()
extern void XmlReaderDelegator_ReadContentAsBoolean_mC037E50245F32951DD681D111C4534FFE7BA32A9 (void);
// 0x000007B9 System.Single System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsFloat()
extern void XmlReaderDelegator_ReadElementContentAsFloat_mEC88AFC2DDBD68A2E5563624F696F6FAD5909132 (void);
// 0x000007BA System.Single System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsSingle()
extern void XmlReaderDelegator_ReadContentAsSingle_m8A39697BE57361E244905E5B82363FFC2144AAB0 (void);
// 0x000007BB System.Double System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsDouble()
extern void XmlReaderDelegator_ReadElementContentAsDouble_m34DDF7F6461BF47A77B8210764DF850802A4A83A (void);
// 0x000007BC System.Double System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsDouble()
extern void XmlReaderDelegator_ReadContentAsDouble_m1C3C1D0B1BFD031AC0FF71181F80DFC352E22700 (void);
// 0x000007BD System.Decimal System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsDecimal()
extern void XmlReaderDelegator_ReadElementContentAsDecimal_m349146C56A137CF41FC09AD197F24EE511E45DC3 (void);
// 0x000007BE System.Decimal System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsDecimal()
extern void XmlReaderDelegator_ReadContentAsDecimal_m76095574FC3148D9ADAC8BD72CA99B05952A6239 (void);
// 0x000007BF System.Byte[] System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsBase64()
extern void XmlReaderDelegator_ReadElementContentAsBase64_mC8C926D4F848084CAC7775059C9ABB90824FBBF9 (void);
// 0x000007C0 System.Byte[] System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsBase64()
extern void XmlReaderDelegator_ReadContentAsBase64_mEA43940F9D51F8B0C21ED4B66495F9EF858CFF3D (void);
// 0x000007C1 System.Byte[] System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsBase64(System.String)
extern void XmlReaderDelegator_ReadContentAsBase64_mC0728F7AE436B4CC8B4451AFA7546107A2EB4EDE (void);
// 0x000007C2 System.DateTime System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsDateTime()
extern void XmlReaderDelegator_ReadElementContentAsDateTime_m023316266236EAC41C9FDE1D285709ED8943E3B1 (void);
// 0x000007C3 System.DateTime System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsDateTime()
extern void XmlReaderDelegator_ReadContentAsDateTime_m92BCFE2981C106C248C79676AED1A3114F99BB0C (void);
// 0x000007C4 System.Int32 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsInt()
extern void XmlReaderDelegator_ReadElementContentAsInt_m952438BEAD7601E51C41804CAAF9D4B494D1A1E9 (void);
// 0x000007C5 System.Int32 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsInt()
extern void XmlReaderDelegator_ReadContentAsInt_mBB5756F1602500C8FCACC863B4CA484F99B08969 (void);
// 0x000007C6 System.Int64 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsLong()
extern void XmlReaderDelegator_ReadElementContentAsLong_m1E4FDD3C7FEAA366CAC6CF57F5AA6954CDEF61B6 (void);
// 0x000007C7 System.Int64 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsLong()
extern void XmlReaderDelegator_ReadContentAsLong_mF175251B65D1EF4E9CB17DA6748CF4892BA16479 (void);
// 0x000007C8 System.Int16 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsShort()
extern void XmlReaderDelegator_ReadElementContentAsShort_m774A363660F9ACDC36FCFDA3A8AC188C99390639 (void);
// 0x000007C9 System.Int16 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsShort()
extern void XmlReaderDelegator_ReadContentAsShort_mF103E0096521F007C3D84321990AE16CC73851EE (void);
// 0x000007CA System.Int16 System.Runtime.Serialization.XmlReaderDelegator::ToShort(System.Int32)
extern void XmlReaderDelegator_ToShort_m5A243984E8172AC058A88970C7217752A85C9820 (void);
// 0x000007CB System.Byte System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsUnsignedByte()
extern void XmlReaderDelegator_ReadElementContentAsUnsignedByte_m2847BF385B43F06C553EECE192CEEBFE4B5F4493 (void);
// 0x000007CC System.Byte System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsUnsignedByte()
extern void XmlReaderDelegator_ReadContentAsUnsignedByte_m0E09C9E1BC1818371E78E8608D0D409612B9977F (void);
// 0x000007CD System.Byte System.Runtime.Serialization.XmlReaderDelegator::ToByte(System.Int32)
extern void XmlReaderDelegator_ToByte_m6240E515D0E6F6A8846D0110607C2E1B2C4E75F0 (void);
// 0x000007CE System.SByte System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsSignedByte()
extern void XmlReaderDelegator_ReadElementContentAsSignedByte_mF8505ACC1C110D9D1C5400B28DACF49A6C4AA69E (void);
// 0x000007CF System.SByte System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsSignedByte()
extern void XmlReaderDelegator_ReadContentAsSignedByte_m860191558F53BF5EE84809A9860CFED71CF96DDF (void);
// 0x000007D0 System.SByte System.Runtime.Serialization.XmlReaderDelegator::ToSByte(System.Int32)
extern void XmlReaderDelegator_ToSByte_mB6E251CF0DC59786BF2BCA821DA123AF01DBF1BC (void);
// 0x000007D1 System.UInt32 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsUnsignedInt()
extern void XmlReaderDelegator_ReadElementContentAsUnsignedInt_m0EA5107EC3302847E371FE9D1CC345FAEB663F9D (void);
// 0x000007D2 System.UInt32 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsUnsignedInt()
extern void XmlReaderDelegator_ReadContentAsUnsignedInt_mC1879B95AD6602C122C846C4C495894B790D1A4A (void);
// 0x000007D3 System.UInt32 System.Runtime.Serialization.XmlReaderDelegator::ToUInt32(System.Int64)
extern void XmlReaderDelegator_ToUInt32_m152D33ED394D13A046AB8C50D768EDB041AE3457 (void);
// 0x000007D4 System.UInt64 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsUnsignedLong()
extern void XmlReaderDelegator_ReadElementContentAsUnsignedLong_mC10CF7829EE255DEB0B22E7E32A9B1FC8DDA8A6D (void);
// 0x000007D5 System.UInt64 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsUnsignedLong()
extern void XmlReaderDelegator_ReadContentAsUnsignedLong_m9B47DA4B42D246EC28FAB902A83EFC1819F81471 (void);
// 0x000007D6 System.UInt16 System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsUnsignedShort()
extern void XmlReaderDelegator_ReadElementContentAsUnsignedShort_m61489300D28D0BE3A66BDC5F633DE6DDFDB49605 (void);
// 0x000007D7 System.UInt16 System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsUnsignedShort()
extern void XmlReaderDelegator_ReadContentAsUnsignedShort_mE91DC6BE83107493F115B504139AC9FF12CAA00F (void);
// 0x000007D8 System.UInt16 System.Runtime.Serialization.XmlReaderDelegator::ToUInt16(System.Int32)
extern void XmlReaderDelegator_ToUInt16_mFA46959C9DC564892A80EED68DD7FF139A77646A (void);
// 0x000007D9 System.TimeSpan System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsTimeSpan()
extern void XmlReaderDelegator_ReadElementContentAsTimeSpan_m5AC5537998F72B6C623A30772C9E229EB53B3743 (void);
// 0x000007DA System.TimeSpan System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsTimeSpan()
extern void XmlReaderDelegator_ReadContentAsTimeSpan_m655BEA2FCFB899CE85CC92F1D22ECEC644A10685 (void);
// 0x000007DB System.Guid System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsGuid()
extern void XmlReaderDelegator_ReadElementContentAsGuid_m779466EC0D44FAD7D13A033294F5A5FEA45FBED3 (void);
// 0x000007DC System.Guid System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsGuid()
extern void XmlReaderDelegator_ReadContentAsGuid_m8414FB677536001786501D8FF8AD3B2BD43C6A79 (void);
// 0x000007DD System.Uri System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsUri()
extern void XmlReaderDelegator_ReadElementContentAsUri_m6B0701382202AF06AD02048F2041233C6D08DC66 (void);
// 0x000007DE System.Uri System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsUri()
extern void XmlReaderDelegator_ReadContentAsUri_m69357E242F8A68F36F804E2748C0D25431C34012 (void);
// 0x000007DF System.Xml.XmlQualifiedName System.Runtime.Serialization.XmlReaderDelegator::ReadElementContentAsQName()
extern void XmlReaderDelegator_ReadElementContentAsQName_m439DF2A617C9B53BE3EA4BEF597BA2780C902EF0 (void);
// 0x000007E0 System.Xml.XmlQualifiedName System.Runtime.Serialization.XmlReaderDelegator::ReadContentAsQName()
extern void XmlReaderDelegator_ReadContentAsQName_mC0A56259142D1ED5EBE1383AF1115553CE7ED51F (void);
// 0x000007E1 System.Xml.XmlQualifiedName System.Runtime.Serialization.XmlReaderDelegator::ParseQualifiedName(System.String)
extern void XmlReaderDelegator_ParseQualifiedName_m9320F27AF78F36D713CE8FE574446FEF751DB87F (void);
// 0x000007E2 System.Void System.Runtime.Serialization.XmlReaderDelegator::CheckExpectedArrayLength(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Int32)
extern void XmlReaderDelegator_CheckExpectedArrayLength_m6559D555E79642925361B20C95F29D819F15AA84 (void);
// 0x000007E3 System.Int32 System.Runtime.Serialization.XmlReaderDelegator::GetArrayLengthQuota(System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void XmlReaderDelegator_GetArrayLengthQuota_mD0E4EA9BCAF137D48B457D4ED7E97DC7B09AABA9 (void);
// 0x000007E4 System.Void System.Runtime.Serialization.XmlReaderDelegator::CheckActualArrayLength(System.Int32,System.Int32,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlReaderDelegator_CheckActualArrayLength_m1B3BF699E18FE3D772527AC941F428E8A754A9BC (void);
// 0x000007E5 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadBooleanArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Boolean[]&)
extern void XmlReaderDelegator_TryReadBooleanArray_m804FAC13D5E280810A092EB33072B263254B4CFE (void);
// 0x000007E6 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadDateTimeArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.DateTime[]&)
extern void XmlReaderDelegator_TryReadDateTimeArray_mA792F81DEEA9715D98922C0103A4A94EBDE83FB7 (void);
// 0x000007E7 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadDecimalArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Decimal[]&)
extern void XmlReaderDelegator_TryReadDecimalArray_m8DD03D36FCC0FC9637A05932C6A96CA0E44F3BF6 (void);
// 0x000007E8 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadInt32Array(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Int32[]&)
extern void XmlReaderDelegator_TryReadInt32Array_m165996D3678016407537B23DF5B8CB92C5AFBE31 (void);
// 0x000007E9 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadInt64Array(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Int64[]&)
extern void XmlReaderDelegator_TryReadInt64Array_m93041E905F44F56C7F9D157A4850DB4CE9391324 (void);
// 0x000007EA System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadSingleArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Single[]&)
extern void XmlReaderDelegator_TryReadSingleArray_m8AEDDD9FD7EE4D7ECADE74A39CC41423177A64BF (void);
// 0x000007EB System.Boolean System.Runtime.Serialization.XmlReaderDelegator::TryReadDoubleArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.Double[]&)
extern void XmlReaderDelegator_TryReadDoubleArray_m0B3A95C4A9A7991784D0EB1C5743520EF7766DB6 (void);
// 0x000007EC System.Collections.Generic.IDictionary`2<System.String,System.String> System.Runtime.Serialization.XmlReaderDelegator::GetNamespacesInScope(System.Xml.XmlNamespaceScope)
extern void XmlReaderDelegator_GetNamespacesInScope_mB0D98B1A49EAB2746CCC05AD2BCFC421EFF8D1A4 (void);
// 0x000007ED System.Boolean System.Runtime.Serialization.XmlReaderDelegator::HasLineInfo()
extern void XmlReaderDelegator_HasLineInfo_mFF93DD6C3A0A08EC68639C106325C974DBA2EBA6 (void);
// 0x000007EE System.Int32 System.Runtime.Serialization.XmlReaderDelegator::get_LineNumber()
extern void XmlReaderDelegator_get_LineNumber_mE950CE4951D3B4E932D22B6230BB0F84FB26B594 (void);
// 0x000007EF System.Int32 System.Runtime.Serialization.XmlReaderDelegator::get_LinePosition()
extern void XmlReaderDelegator_get_LinePosition_m5B087F1B1E4393AB11CCF3048AF018621DEC49C7 (void);
// 0x000007F0 System.Boolean System.Runtime.Serialization.XmlReaderDelegator::get_Normalized()
extern void XmlReaderDelegator_get_Normalized_m2436EC5C87364BB48A774972DFD764D7E408CC71 (void);
// 0x000007F1 System.Void System.Runtime.Serialization.XmlReaderDelegator::set_Normalized(System.Boolean)
extern void XmlReaderDelegator_set_Normalized_mBE07713C1E365E9896C09F2768DAB3569E0E488C (void);
// 0x000007F2 System.Xml.WhitespaceHandling System.Runtime.Serialization.XmlReaderDelegator::get_WhitespaceHandling()
extern void XmlReaderDelegator_get_WhitespaceHandling_mEA94484409EE533E2BA15F9575F9C3BE45AD9298 (void);
// 0x000007F3 System.Void System.Runtime.Serialization.XmlReaderDelegator::set_WhitespaceHandling(System.Xml.WhitespaceHandling)
extern void XmlReaderDelegator_set_WhitespaceHandling_mC53C683711FA0502D11D19C675CF6450ECF5E2B1 (void);
// 0x000007F4 System.String System.Runtime.Serialization.XmlReaderDelegator::get_Name()
extern void XmlReaderDelegator_get_Name_m4C26E699D9205D6D4A17AF3A526506FF1A3D9114 (void);
// 0x000007F5 System.String System.Runtime.Serialization.XmlReaderDelegator::get_LocalName()
extern void XmlReaderDelegator_get_LocalName_mA05D1C9F06E1953CEA407863750F1864461CBE93 (void);
// 0x000007F6 System.String System.Runtime.Serialization.XmlReaderDelegator::get_NamespaceURI()
extern void XmlReaderDelegator_get_NamespaceURI_m36271C19CC2C823C8B5C83B0FA0117EDFDF8922C (void);
// 0x000007F7 System.String System.Runtime.Serialization.XmlReaderDelegator::get_Value()
extern void XmlReaderDelegator_get_Value_mEF602439F82848968A21FE32761D85BE665A0AF8 (void);
// 0x000007F8 System.Type System.Runtime.Serialization.XmlReaderDelegator::get_ValueType()
extern void XmlReaderDelegator_get_ValueType_m75C2CDCEA03407C75A4CF41BF4EC0A475E1EC117 (void);
// 0x000007F9 System.Int32 System.Runtime.Serialization.XmlReaderDelegator::get_Depth()
extern void XmlReaderDelegator_get_Depth_mF582B1E54DE7BA9353D51041259EE1D711C99675 (void);
// 0x000007FA System.String System.Runtime.Serialization.XmlReaderDelegator::LookupNamespace(System.String)
extern void XmlReaderDelegator_LookupNamespace_m3D2E880E29F4B53AA1276325099B468529706EF4 (void);
// 0x000007FB System.Boolean System.Runtime.Serialization.XmlReaderDelegator::get_EOF()
extern void XmlReaderDelegator_get_EOF_m6485B110598DB0CFDCF6B4824410ED66C55A94C9 (void);
// 0x000007FC System.Void System.Runtime.Serialization.XmlReaderDelegator::Skip()
extern void XmlReaderDelegator_Skip_m488FCB522CE0787DFEA06AB903883AC13DBE67F3 (void);
// 0x000007FD System.Xml.XmlReader System.Runtime.Serialization.XmlSerializableReader::get_InnerReader()
extern void XmlSerializableReader_get_InnerReader_mEEC93F0EB9C933BAF4A8679DFC8B9CF09B74E63C (void);
// 0x000007FE System.Void System.Runtime.Serialization.XmlSerializableReader::BeginRead(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlSerializableReader_BeginRead_m50F975F62A3B9733AE85898BA4447BF4D5D4C0BF (void);
// 0x000007FF System.Void System.Runtime.Serialization.XmlSerializableReader::EndRead()
extern void XmlSerializableReader_EndRead_m9C11F71877333A0E80D3F523767414177A6790B9 (void);
// 0x00000800 System.Boolean System.Runtime.Serialization.XmlSerializableReader::Read()
extern void XmlSerializableReader_Read_mF90FBB227A053E3A1D25F84B6F89CE15E65EFFD3 (void);
// 0x00000801 System.Void System.Runtime.Serialization.XmlSerializableReader::Close()
extern void XmlSerializableReader_Close_m35B0A44D046BD80D207D4574539900AFC77803D7 (void);
// 0x00000802 System.Xml.XmlReaderSettings System.Runtime.Serialization.XmlSerializableReader::get_Settings()
extern void XmlSerializableReader_get_Settings_mF80753DF678C8CF14323ACF6FD3DCC6FBA9D9D4C (void);
// 0x00000803 System.Xml.XmlNodeType System.Runtime.Serialization.XmlSerializableReader::get_NodeType()
extern void XmlSerializableReader_get_NodeType_mAC4399D6E4EE22A40BDA932DA5BD0B34BC9AF5AF (void);
// 0x00000804 System.String System.Runtime.Serialization.XmlSerializableReader::get_Name()
extern void XmlSerializableReader_get_Name_mC332FDF48E6922E43013E2C14A3B7FF2969E7B5D (void);
// 0x00000805 System.String System.Runtime.Serialization.XmlSerializableReader::get_LocalName()
extern void XmlSerializableReader_get_LocalName_m36120176B392292BD4B3E118E9F5144497614114 (void);
// 0x00000806 System.String System.Runtime.Serialization.XmlSerializableReader::get_NamespaceURI()
extern void XmlSerializableReader_get_NamespaceURI_mD56291F6E819EF9D5FF4989B578F7135D55E248E (void);
// 0x00000807 System.String System.Runtime.Serialization.XmlSerializableReader::get_Prefix()
extern void XmlSerializableReader_get_Prefix_mDA8D157675C91660174E052BB4B78DD94ACB5952 (void);
// 0x00000808 System.String System.Runtime.Serialization.XmlSerializableReader::get_Value()
extern void XmlSerializableReader_get_Value_m83DE1A38461F6E206EFD564AC66454442BC20CB2 (void);
// 0x00000809 System.Int32 System.Runtime.Serialization.XmlSerializableReader::get_Depth()
extern void XmlSerializableReader_get_Depth_m8759B3E419DDBD50F4ADB820A813F87B37AFC9DA (void);
// 0x0000080A System.String System.Runtime.Serialization.XmlSerializableReader::get_BaseURI()
extern void XmlSerializableReader_get_BaseURI_m32A74107A9A9EB4A6E7C7B4CB41CF710F77867ED (void);
// 0x0000080B System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_IsEmptyElement()
extern void XmlSerializableReader_get_IsEmptyElement_m9A451C82BD4C2DA28FF80D3F243A1B453D087AAC (void);
// 0x0000080C System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_IsDefault()
extern void XmlSerializableReader_get_IsDefault_mA3DB0825A08A05FDF7A009F98703CA868FA78F38 (void);
// 0x0000080D System.Char System.Runtime.Serialization.XmlSerializableReader::get_QuoteChar()
extern void XmlSerializableReader_get_QuoteChar_m8859CC64E52311816D0C8876E7DC70DD5FAF606B (void);
// 0x0000080E System.Xml.XmlSpace System.Runtime.Serialization.XmlSerializableReader::get_XmlSpace()
extern void XmlSerializableReader_get_XmlSpace_m6B6BF92B7765F973B96FBBCE3E0BCD98A1FC6E4F (void);
// 0x0000080F System.String System.Runtime.Serialization.XmlSerializableReader::get_XmlLang()
extern void XmlSerializableReader_get_XmlLang_m11C660C7EB7E3FEC6F17D3D27EB40FF8580950A8 (void);
// 0x00000810 System.Xml.Schema.IXmlSchemaInfo System.Runtime.Serialization.XmlSerializableReader::get_SchemaInfo()
extern void XmlSerializableReader_get_SchemaInfo_mA2BF0B7C2B56D8E8EA62302C527753EA9B2AE56C (void);
// 0x00000811 System.Type System.Runtime.Serialization.XmlSerializableReader::get_ValueType()
extern void XmlSerializableReader_get_ValueType_m4BD7D4499DD09BBC0805D819BF609978C93BD5A8 (void);
// 0x00000812 System.Int32 System.Runtime.Serialization.XmlSerializableReader::get_AttributeCount()
extern void XmlSerializableReader_get_AttributeCount_mB25688DCBFC141913F1B51CDAAC70EAD419599A5 (void);
// 0x00000813 System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_EOF()
extern void XmlSerializableReader_get_EOF_mB1D92C6B579B179486419BFB8EB2ADDCB3276559 (void);
// 0x00000814 System.Xml.ReadState System.Runtime.Serialization.XmlSerializableReader::get_ReadState()
extern void XmlSerializableReader_get_ReadState_mB351254052AB5FDA530FE1E77C08FC3208140C9F (void);
// 0x00000815 System.Xml.XmlNameTable System.Runtime.Serialization.XmlSerializableReader::get_NameTable()
extern void XmlSerializableReader_get_NameTable_m9365876DEA928015730D5F4F7EBD57C023AE7E6F (void);
// 0x00000816 System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_CanResolveEntity()
extern void XmlSerializableReader_get_CanResolveEntity_m0666DE1F1AEB3C6F3D3A0CE11671821A79DCA904 (void);
// 0x00000817 System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_CanReadValueChunk()
extern void XmlSerializableReader_get_CanReadValueChunk_mC938231E2506F66836CA0CDBE989CA53655B05C2 (void);
// 0x00000818 System.Boolean System.Runtime.Serialization.XmlSerializableReader::get_HasAttributes()
extern void XmlSerializableReader_get_HasAttributes_m7B1D3E2690E467EE8253E1AB178A89880C158843 (void);
// 0x00000819 System.String System.Runtime.Serialization.XmlSerializableReader::GetAttribute(System.String)
extern void XmlSerializableReader_GetAttribute_m7A16441E87283C4C285E6281D1BFEC2EE7F82B7E (void);
// 0x0000081A System.String System.Runtime.Serialization.XmlSerializableReader::GetAttribute(System.String,System.String)
extern void XmlSerializableReader_GetAttribute_mF1808C2E0DC0B9DFBBBC762ACCFFF27BA812E4BB (void);
// 0x0000081B System.String System.Runtime.Serialization.XmlSerializableReader::GetAttribute(System.Int32)
extern void XmlSerializableReader_GetAttribute_mDA8570E800ACD3DF2EA6C37D259E19A41E86FF39 (void);
// 0x0000081C System.Boolean System.Runtime.Serialization.XmlSerializableReader::MoveToAttribute(System.String)
extern void XmlSerializableReader_MoveToAttribute_mB44332BC4B48CFC00E5F7AE8C2D36439BB01AEAC (void);
// 0x0000081D System.Boolean System.Runtime.Serialization.XmlSerializableReader::MoveToAttribute(System.String,System.String)
extern void XmlSerializableReader_MoveToAttribute_m46F65051760BDCA15CB4FB62FCD746F1D8EC1437 (void);
// 0x0000081E System.Void System.Runtime.Serialization.XmlSerializableReader::MoveToAttribute(System.Int32)
extern void XmlSerializableReader_MoveToAttribute_mAB5586FA653054EEC88C729CF63B8FFFCF30D697 (void);
// 0x0000081F System.Boolean System.Runtime.Serialization.XmlSerializableReader::MoveToFirstAttribute()
extern void XmlSerializableReader_MoveToFirstAttribute_m85E86FE369CD0C118BB8093050A3D9C1BBFD2EAB (void);
// 0x00000820 System.Boolean System.Runtime.Serialization.XmlSerializableReader::MoveToNextAttribute()
extern void XmlSerializableReader_MoveToNextAttribute_m657C1DD81AC33FEE3D726B42DBDF389C1D8560B2 (void);
// 0x00000821 System.Boolean System.Runtime.Serialization.XmlSerializableReader::MoveToElement()
extern void XmlSerializableReader_MoveToElement_m90B4CB16D22AFBBF49D0FE02D9C589AD1941DCF1 (void);
// 0x00000822 System.String System.Runtime.Serialization.XmlSerializableReader::LookupNamespace(System.String)
extern void XmlSerializableReader_LookupNamespace_mBB79CA6D5D89CA7A1647E4CEE3B781F9EDC85F37 (void);
// 0x00000823 System.Boolean System.Runtime.Serialization.XmlSerializableReader::ReadAttributeValue()
extern void XmlSerializableReader_ReadAttributeValue_m3CCEAE702E34053251FCE38C8229A277AD2198A3 (void);
// 0x00000824 System.Void System.Runtime.Serialization.XmlSerializableReader::ResolveEntity()
extern void XmlSerializableReader_ResolveEntity_m8464547F8DB2FF484384F728B4736C927BB89A51 (void);
// 0x00000825 System.Boolean System.Runtime.Serialization.XmlSerializableReader::IsStartElement()
extern void XmlSerializableReader_IsStartElement_m9204015FFFD7DA486FF14D281C06D0035BE2026B (void);
// 0x00000826 System.Boolean System.Runtime.Serialization.XmlSerializableReader::IsStartElement(System.String,System.String)
extern void XmlSerializableReader_IsStartElement_m720F1B14D715A2AD5AE9076FA61523755297C6A1 (void);
// 0x00000827 System.Xml.XmlNodeType System.Runtime.Serialization.XmlSerializableReader::MoveToContent()
extern void XmlSerializableReader_MoveToContent_m93756103292DBD2A92F5FC05CF26FC808D4AC10B (void);
// 0x00000828 System.Object System.Runtime.Serialization.XmlSerializableReader::ReadContentAsObject()
extern void XmlSerializableReader_ReadContentAsObject_m803DDCA894011D3A1B452399BBC5186ED95AFCFF (void);
// 0x00000829 System.Boolean System.Runtime.Serialization.XmlSerializableReader::ReadContentAsBoolean()
extern void XmlSerializableReader_ReadContentAsBoolean_m530E54220EEA2EB7018C4E257FA96C32C7233623 (void);
// 0x0000082A System.DateTime System.Runtime.Serialization.XmlSerializableReader::ReadContentAsDateTime()
extern void XmlSerializableReader_ReadContentAsDateTime_m4DF5312E0B4D47B5589DAD0EB7FF7680E08B2821 (void);
// 0x0000082B System.Double System.Runtime.Serialization.XmlSerializableReader::ReadContentAsDouble()
extern void XmlSerializableReader_ReadContentAsDouble_m011F9CCD2BBE6B4AB6C06C8BF13C1DFF5B9F3958 (void);
// 0x0000082C System.Int32 System.Runtime.Serialization.XmlSerializableReader::ReadContentAsInt()
extern void XmlSerializableReader_ReadContentAsInt_m5635875B3ECE82AA1AE18F1885D451E26B52683D (void);
// 0x0000082D System.Int64 System.Runtime.Serialization.XmlSerializableReader::ReadContentAsLong()
extern void XmlSerializableReader_ReadContentAsLong_mA5AF7ED8C355FF57A939904A7B205010CA6DA46A (void);
// 0x0000082E System.String System.Runtime.Serialization.XmlSerializableReader::ReadContentAsString()
extern void XmlSerializableReader_ReadContentAsString_m47863037B9D9E57A3B36E8F21EDB107D4A2454B8 (void);
// 0x0000082F System.Object System.Runtime.Serialization.XmlSerializableReader::ReadContentAs(System.Type,System.Xml.IXmlNamespaceResolver)
extern void XmlSerializableReader_ReadContentAs_mE0E7454E258FD1BF77A56129828BD4ACA5DD0C04 (void);
// 0x00000830 System.Int32 System.Runtime.Serialization.XmlSerializableReader::ReadContentAsBase64(System.Byte[],System.Int32,System.Int32)
extern void XmlSerializableReader_ReadContentAsBase64_mD378E59686629BC6B66851CC445EDF22373AD63C (void);
// 0x00000831 System.Int32 System.Runtime.Serialization.XmlSerializableReader::ReadContentAsBinHex(System.Byte[],System.Int32,System.Int32)
extern void XmlSerializableReader_ReadContentAsBinHex_m5F43A9B5ABFDD0FBC3AC505A891D1E9E487818DD (void);
// 0x00000832 System.Int32 System.Runtime.Serialization.XmlSerializableReader::ReadValueChunk(System.Char[],System.Int32,System.Int32)
extern void XmlSerializableReader_ReadValueChunk_mEDDF5597444B4549716EDBAC0FAA852B694C2D07 (void);
// 0x00000833 System.String System.Runtime.Serialization.XmlSerializableReader::ReadString()
extern void XmlSerializableReader_ReadString_m3C9C95DA6B1F8236DB5B3CE85414C9751990FB54 (void);
// 0x00000834 System.Boolean System.Runtime.Serialization.XmlSerializableReader::System.Xml.Serialization.IXmlTextParser.get_Normalized()
extern void XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_get_Normalized_mAD0E03710EA89B8C7102D9FA137BA094A8C6227F (void);
// 0x00000835 System.Void System.Runtime.Serialization.XmlSerializableReader::System.Xml.Serialization.IXmlTextParser.set_Normalized(System.Boolean)
extern void XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_set_Normalized_mD23FE8BA4181588F701799150851FEDE53D8262C (void);
// 0x00000836 System.Xml.WhitespaceHandling System.Runtime.Serialization.XmlSerializableReader::System.Xml.Serialization.IXmlTextParser.get_WhitespaceHandling()
extern void XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_get_WhitespaceHandling_mDD7AD8843204CBD378C7F1765ED6C4730D2E9264 (void);
// 0x00000837 System.Void System.Runtime.Serialization.XmlSerializableReader::System.Xml.Serialization.IXmlTextParser.set_WhitespaceHandling(System.Xml.WhitespaceHandling)
extern void XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_set_WhitespaceHandling_mB322D20FD78B463C63CCADAC8B13118042019CEB (void);
// 0x00000838 System.Boolean System.Runtime.Serialization.XmlSerializableReader::System.Xml.IXmlLineInfo.HasLineInfo()
extern void XmlSerializableReader_System_Xml_IXmlLineInfo_HasLineInfo_mBC1882F34A081DA753092CB238EEE83C6030B67F (void);
// 0x00000839 System.Int32 System.Runtime.Serialization.XmlSerializableReader::System.Xml.IXmlLineInfo.get_LineNumber()
extern void XmlSerializableReader_System_Xml_IXmlLineInfo_get_LineNumber_m983064892A7D0C8B81AE735B8FC7D19B6D3D69A9 (void);
// 0x0000083A System.Int32 System.Runtime.Serialization.XmlSerializableReader::System.Xml.IXmlLineInfo.get_LinePosition()
extern void XmlSerializableReader_System_Xml_IXmlLineInfo_get_LinePosition_m5E6B786B256CCAB666701875D59EF5018123F0F9 (void);
// 0x0000083B System.Void System.Runtime.Serialization.XmlSerializableReader::.ctor()
extern void XmlSerializableReader__ctor_mEFF4D9B60FBFAB4DEE33C988138C8435CD6D69E4 (void);
// 0x0000083C System.Xml.XmlNode[] System.Runtime.Serialization.XmlSerializableServices::ReadNodes(System.Xml.XmlReader)
extern void XmlSerializableServices_ReadNodes_m25CED267F2F1FEF95D104A2A389885E6B4BCE256 (void);
// 0x0000083D System.Boolean System.Runtime.Serialization.XmlSerializableServices::IsValidAttribute(System.Xml.XmlReader)
extern void XmlSerializableServices_IsValidAttribute_mBDC9273980421A6E4E769DF0F5956728DDF010CF (void);
// 0x0000083E System.Void System.Runtime.Serialization.XmlSerializableServices::.cctor()
extern void XmlSerializableServices__cctor_m3439B3A0CB3F11DEB556DC552A50C3E595D64419 (void);
// 0x0000083F System.Void System.Runtime.Serialization.BitFlagsGenerator::.ctor(System.Int32)
extern void BitFlagsGenerator__ctor_mBF4444E1B242ABD6ED751FE7362D9431EA0128D7 (void);
// 0x00000840 System.Void System.Runtime.Serialization.BitFlagsGenerator::Store(System.Int32,System.Boolean)
extern void BitFlagsGenerator_Store_mE2EB70CD5B4611E3B66E6E306FC406F5B0B25437 (void);
// 0x00000841 System.Boolean System.Runtime.Serialization.BitFlagsGenerator::Load(System.Int32)
extern void BitFlagsGenerator_Load_mC08357BA2A65F5FBE3974AF2A79DD89A58715368 (void);
// 0x00000842 System.Byte[] System.Runtime.Serialization.BitFlagsGenerator::LoadArray()
extern void BitFlagsGenerator_LoadArray_m8D77D7198390C4896198F147BF195825E7E30AA3 (void);
// 0x00000843 System.Int32 System.Runtime.Serialization.BitFlagsGenerator::GetLocalCount()
extern void BitFlagsGenerator_GetLocalCount_m0DBD381788632CB4C696ABB48970C120CD205DD4 (void);
// 0x00000844 System.Int32 System.Runtime.Serialization.BitFlagsGenerator::GetBitCount()
extern void BitFlagsGenerator_GetBitCount_m9C65E15FF21FAD9F48313F626C6372EB91586CF2 (void);
// 0x00000845 System.Byte System.Runtime.Serialization.BitFlagsGenerator::GetLocal(System.Int32)
extern void BitFlagsGenerator_GetLocal_mC27A703EDB4133C29EBD56405A5DA27DE620DC7D (void);
// 0x00000846 System.Boolean System.Runtime.Serialization.BitFlagsGenerator::IsBitSet(System.Byte[],System.Int32)
extern void BitFlagsGenerator_IsBitSet_m653D1EEA314AC752B63A21ABDC010A3DEEBA407D (void);
// 0x00000847 System.Void System.Runtime.Serialization.BitFlagsGenerator::SetBit(System.Byte[],System.Int32)
extern void BitFlagsGenerator_SetBit_m0C2FCDF279F946381F2092FC8652EB0C6963B0F6 (void);
// 0x00000848 System.Int32 System.Runtime.Serialization.BitFlagsGenerator::GetByteIndex(System.Int32)
extern void BitFlagsGenerator_GetByteIndex_mD2BC56AC9E4FAC3266B3FC1151C3D788F02A4B49 (void);
// 0x00000849 System.Byte System.Runtime.Serialization.BitFlagsGenerator::GetBitValue(System.Int32)
extern void BitFlagsGenerator_GetBitValue_m2D7DE0BB46380E80BE5AE746BAEDC6BA2F44C292 (void);
// 0x0000084A System.Object System.Runtime.Serialization.CodeInterpreter::ConvertValue(System.Object,System.Type,System.Type)
extern void CodeInterpreter_ConvertValue_mE184C0E4C56A45864BEB7E7F81A4C4F24BE53A3D (void);
// 0x0000084B System.Boolean System.Runtime.Serialization.CodeInterpreter::CanConvert(System.TypeCode)
extern void CodeInterpreter_CanConvert_mF09439AA95AB2169D4D9AA0B2F0C62EF6ED9845B (void);
// 0x0000084C System.Object System.Runtime.Serialization.CodeInterpreter::InternalConvert(System.Object,System.Type,System.Type,System.Boolean)
extern void CodeInterpreter_InternalConvert_m3A85D95C28398A1C6BDFAB880E6F8A465D4EC80C (void);
// 0x0000084D System.Object System.Runtime.Serialization.CodeInterpreter::GetMember(System.Reflection.MemberInfo,System.Object)
extern void CodeInterpreter_GetMember_m7DA7EEB040C6D19FFDCD06492A163B8FAF9AB155 (void);
// 0x0000084E System.Void System.Runtime.Serialization.CodeInterpreter::SetMember(System.Reflection.MemberInfo,System.Object,System.Object)
extern void CodeInterpreter_SetMember_m71954618E3A5A1201150D1A591F3D7126ECD8DB8 (void);
// 0x0000084F System.Void System.Runtime.Serialization.DiagnosticUtility::.cctor()
extern void DiagnosticUtility__cctor_m5F64B6C8FE8B54849A165BE67252B32CC1ACED1A (void);
// 0x00000850 System.Void System.Runtime.Serialization.DiagnosticUtility/DiagnosticTrace::TraceEvent(System.Object[])
extern void DiagnosticTrace_TraceEvent_m2AC3A2106A380B47251EC3AC6D48E835EFEE58F4 (void);
// 0x00000851 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelperError(System.Exception)
extern void ExceptionUtility_ThrowHelperError_mB01429D47ABA81955EC561D8286C63E8C74D5FB6 (void);
// 0x00000852 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelperCallback(System.Exception)
extern void ExceptionUtility_ThrowHelperCallback_mC035C0936B0B4DFD780FE9E3B356401880460241 (void);
// 0x00000853 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelper(System.Exception,System.Diagnostics.TraceEventType)
extern void ExceptionUtility_ThrowHelper_mB8572AC383576258341DCD063A8B28ECB635F081 (void);
// 0x00000854 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelperArgument(System.String,System.String)
extern void ExceptionUtility_ThrowHelperArgument_m3742379C7B9235D0A083D5FBE7E528071D86B6CB (void);
// 0x00000855 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelperArgumentNull(System.String)
extern void ExceptionUtility_ThrowHelperArgumentNull_m758514C87C3B905C2DFF60D19630F479958BEE79 (void);
// 0x00000856 System.Exception System.Runtime.Serialization.DiagnosticUtility/ExceptionUtility::ThrowHelperFatal(System.String,System.Exception)
extern void ExceptionUtility_ThrowHelperFatal_mACCEE6A91E32560E8F884432D126992DA1C94700 (void);
// 0x00000857 System.Runtime.Diagnostics.EtwDiagnosticTrace System.Runtime.Serialization.FxTrace::get_Trace()
extern void FxTrace_get_Trace_m5C29850211785937295F00E947CB9855B011C210 (void);
// 0x00000858 System.Boolean System.Runtime.Serialization.FxTrace::IsEventEnabled(System.Int32)
extern void FxTrace_IsEventEnabled_mB5C223ECE3EEC745E2801FD8CCB28A5718CFDD9E (void);
// 0x00000859 System.Void System.Runtime.Serialization.FxTrace::UpdateEventDefinitions(System.Runtime.Diagnostics.EventDescriptor[],System.UInt16[])
extern void FxTrace_UpdateEventDefinitions_mD9D92212E2CEDBC23BAD9907A396BC20866B97DA (void);
// 0x0000085A System.Void System.Runtime.Serialization.FxTrace::.cctor()
extern void FxTrace__cctor_m65A354FD4FEC05CD6917A8CF9276DDF15CB62CF7 (void);
// 0x0000085B System.String System.Runtime.Serialization.SR::GetString(System.String,System.Object[])
extern void SR_GetString_mCB22EBBC246A223CDDA76C1D8F355262069E2DD4 (void);
// 0x0000085C System.String System.Runtime.Serialization.SR::GetString(System.Globalization.CultureInfo,System.String,System.Object[])
extern void SR_GetString_mACA6407683C37D3EF5674BC49C44F3830ED60199 (void);
// 0x0000085D System.String System.Runtime.Serialization.SR::GetString(System.String)
extern void SR_GetString_mBD8F2ECD53B5DF9AADDE7871DB25FCBA4D50025D (void);
// 0x0000085E System.Void System.Runtime.Serialization.CodeTypeReference::.ctor(System.String,System.Runtime.Serialization.CodeTypeReferenceOptions)
extern void CodeTypeReference__ctor_m089E48CB392B602025ACAD901A8804F3A1C037AB (void);
// 0x0000085F System.Void System.Runtime.Serialization.CodeTypeReference::.ctor(System.String)
extern void CodeTypeReference__ctor_m6BBFD6D30604A75C4219A7183CD9C34A52C5641F (void);
// 0x00000860 System.Void System.Runtime.Serialization.CodeTypeReference::Initialize(System.String)
extern void CodeTypeReference_Initialize_mB4459889F5CE3DF18CCA6B13614EAA5902654B34 (void);
// 0x00000861 System.Void System.Runtime.Serialization.CodeTypeReference::Initialize(System.String,System.Runtime.Serialization.CodeTypeReferenceOptions)
extern void CodeTypeReference_Initialize_mEAE97FA187F01B86C4D0FBF22A0DDDE37CBFBB52 (void);
// 0x00000862 System.Void System.Runtime.Serialization.CodeTypeReference::.ctor(System.Runtime.Serialization.CodeTypeReference,System.Int32)
extern void CodeTypeReference__ctor_mDDDD5E8B359269E81F1D15837EDD204FCA868D64 (void);
// 0x00000863 System.String System.Runtime.Serialization.CodeTypeReference::get_BaseType()
extern void CodeTypeReference_get_BaseType_mFEA2E3FCA0AF01F5FB973C46EA737280360932CC (void);
// 0x00000864 System.Runtime.Serialization.CodeTypeReferenceOptions System.Runtime.Serialization.CodeTypeReference::get_Options()
extern void CodeTypeReference_get_Options_m1B59BF301B82B465C621FDA0C7970D8BBB03BF91 (void);
// 0x00000865 System.Void System.Runtime.Serialization.CodeTypeReference::set_Options(System.Runtime.Serialization.CodeTypeReferenceOptions)
extern void CodeTypeReference_set_Options_mE1B0FACDE4A337A61EF593ABAC1B836A0DA92580 (void);
// 0x00000866 System.Collections.Generic.List`1<System.Runtime.Serialization.CodeTypeReference> System.Runtime.Serialization.CodeTypeReference::get_TypeArguments()
extern void CodeTypeReference_get_TypeArguments_mAFE5B459E8EE2B6DF5E51EEC6882E5059990D5F3 (void);
// 0x00000867 System.String System.Runtime.Serialization.CodeTypeReference::RipOffAssemblyInformationFromTypeName(System.String)
extern void CodeTypeReference_RipOffAssemblyInformationFromTypeName_m248C55245E91D1A501ADEA2248A0B6AE5A89F27B (void);
// 0x00000868 System.Void System.Runtime.Serialization.XmlDataContractInterpreter::.ctor(System.Runtime.Serialization.XmlDataContract)
extern void XmlDataContractInterpreter__ctor_mDF0271C5F01EF0302351DD287FD7D760832B32F7 (void);
// 0x00000869 System.Xml.Serialization.IXmlSerializable System.Runtime.Serialization.XmlDataContractInterpreter::CreateXmlSerializable()
extern void XmlDataContractInterpreter_CreateXmlSerializable_mE0C0AD3EBA97A902E1E9678628777E4CF6C942EE (void);
// 0x0000086A System.Reflection.ConstructorInfo System.Runtime.Serialization.XmlDataContractInterpreter::GetConstructor()
extern void XmlDataContractInterpreter_GetConstructor_m2EC6FB905734629ABA9537F417F54C909A2DFDFD (void);
// 0x0000086B System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::.ctor(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter__ctor_mC144D3623656AD6093EA78FAC0F916AF26A5D124 (void);
// 0x0000086C System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::.ctor(System.Runtime.Serialization.CollectionDataContract,System.Boolean)
extern void XmlFormatReaderInterpreter__ctor_m4E4AC9589717FBDC9E05CF4F8E9DA9ADE5F6636A (void);
// 0x0000086D System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadFromXml(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString[],System.Xml.XmlDictionaryString[])
extern void XmlFormatReaderInterpreter_ReadFromXml_mF6B79876541301C2EAE0EFB1C2F4BB53074A3D86 (void);
// 0x0000086E System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadCollectionFromXml(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderInterpreter_ReadCollectionFromXml_m1D442C039CAD333F5BDFDE9EF596A179C58DCC27 (void);
// 0x0000086F System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadGetOnlyCollectionFromXml(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderInterpreter_ReadGetOnlyCollectionFromXml_m63C147876DD578A147C827276263E5CE56594C99 (void);
// 0x00000870 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::CreateObject(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_CreateObject_m068757F2D37ACC691BDD559996B1F2223A5785F3 (void);
// 0x00000871 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::InvokeOnDeserializing(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_InvokeOnDeserializing_m267CB7BA61240CF1967ECDFF8914EA9DB99FA187 (void);
// 0x00000872 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::InvokeOnDeserialized(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_InvokeOnDeserialized_mCC5CBD61D2DC2A3E12CDAD92796ECB67538B6CCC (void);
// 0x00000873 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::HasFactoryMethod(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_HasFactoryMethod_m5542C9CF5C7D24792D5AFF8677528CE9B1842B0C (void);
// 0x00000874 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::InvokeFactoryMethod(System.Runtime.Serialization.ClassDataContract,System.String)
extern void XmlFormatReaderInterpreter_InvokeFactoryMethod_mCBA762FC03426A448BB845F53D99B6DDE3B49B03 (void);
// 0x00000875 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadISerializable(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_ReadISerializable_mD718C6A6375FDF275F647C7EBF30D196666F1C95 (void);
// 0x00000876 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadClass(System.Runtime.Serialization.ClassDataContract)
extern void XmlFormatReaderInterpreter_ReadClass_mB0CC70A813710813D1796884EF61FEBF7A51E863 (void);
// 0x00000877 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadMembers(System.Runtime.Serialization.ClassDataContract,System.Runtime.Serialization.ExtensionDataObject)
extern void XmlFormatReaderInterpreter_ReadMembers_mEFC2959C959ADF9670551916B1311CDEA5BFD4B1 (void);
// 0x00000878 System.Int32 System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadMembers(System.Int32,System.Runtime.Serialization.ClassDataContract,System.Boolean[],System.Int32&,System.Int32&)
extern void XmlFormatReaderInterpreter_ReadMembers_m7CD09378520806270C8E278AC1A6A4F1B4DAC5AC (void);
// 0x00000879 System.Boolean[] System.Runtime.Serialization.XmlFormatReaderInterpreter::GetRequiredMembers(System.Runtime.Serialization.ClassDataContract,System.Int32&)
extern void XmlFormatReaderInterpreter_GetRequiredMembers_m87578C30B2C524269CDF25F7BC80761E20A04A14 (void);
// 0x0000087A System.Int32 System.Runtime.Serialization.XmlFormatReaderInterpreter::GetRequiredMembers(System.Runtime.Serialization.ClassDataContract,System.Boolean[])
extern void XmlFormatReaderInterpreter_GetRequiredMembers_m595218E4E6A0C79546E0D519E248E2751E929DE0 (void);
// 0x0000087B System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadValue(System.Type,System.String,System.String)
extern void XmlFormatReaderInterpreter_ReadValue_m7688CA2B813CEAA403F73A6CCC997334DC1201A6 (void);
// 0x0000087C System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::InternalDeserialize(System.Type,System.String,System.String)
extern void XmlFormatReaderInterpreter_InternalDeserialize_m01E0878754D8DB05105A14AD23ECCE83EE46F1DE (void);
// 0x0000087D System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::WrapNullableObject(System.Type,System.Object,System.Type,System.Int32)
extern void XmlFormatReaderInterpreter_WrapNullableObject_mE377C7E81B6DF0F8EE0B949278CEA7758C2AC182 (void);
// 0x0000087E System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadCollection(System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderInterpreter_ReadCollection_mB396F6AB6407698961EC8DBCBF6A5DF535546E2C (void);
// 0x0000087F System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadGetOnlyCollection(System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderInterpreter_ReadGetOnlyCollection_m74C9DACDEDEA81FA2B680D35D055A99A272E8305 (void);
// 0x00000880 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::TryReadPrimitiveArray(System.Type,System.Type,System.Int32,System.Boolean&)
extern void XmlFormatReaderInterpreter_TryReadPrimitiveArray_mFFE30A1F7E3D85890B0D15EBCF08C9C8E79B0069 (void);
// 0x00000881 System.Object System.Runtime.Serialization.XmlFormatReaderInterpreter::ReadCollectionItem(System.Runtime.Serialization.CollectionDataContract,System.Type,System.String,System.String)
extern void XmlFormatReaderInterpreter_ReadCollectionItem_m71C427064AC568380F49B5E2CF46F0CD2C99FEB7 (void);
// 0x00000882 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::StoreCollectionValue(System.Object,System.Type,System.Object,System.Runtime.Serialization.CollectionDataContract)
extern void XmlFormatReaderInterpreter_StoreCollectionValue_mC1A3CFC655DFE24CB3BEDCBE4C774163F92B8833 (void);
// 0x00000883 System.Void System.Runtime.Serialization.XmlFormatReaderInterpreter::HandleUnexpectedItemInCollection(System.Int32&)
extern void XmlFormatReaderInterpreter_HandleUnexpectedItemInCollection_m6936FB841525F86C45E6B561723F867142084656 (void);
// 0x00000884 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::IsStartElement(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void XmlFormatReaderInterpreter_IsStartElement_m381B0C239284DD41918C37FBDCDDF6E8D31E8384 (void);
// 0x00000885 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::IsStartElement()
extern void XmlFormatReaderInterpreter_IsStartElement_m0D5933794D083CE3E5988E3707AF0009C7255FD6 (void);
// 0x00000886 System.Boolean System.Runtime.Serialization.XmlFormatReaderInterpreter::IsEndElement()
extern void XmlFormatReaderInterpreter_IsEndElement_m1064E2E63279CCACE84B30DED95DD084342AB90C (void);
// 0x00000887 System.Int32 System.Runtime.Serialization.Json.ByteArrayHelperWithString::ReadArray(System.Xml.XmlDictionaryReader,System.String,System.String,System.Byte[],System.Int32,System.Int32)
extern void ByteArrayHelperWithString_ReadArray_mB3AB2BD38AF548098816812EDC5272F5BCA7F21F (void);
// 0x00000888 System.Void System.Runtime.Serialization.Json.ByteArrayHelperWithString::ThrowConversionException(System.String,System.String)
extern void ByteArrayHelperWithString_ThrowConversionException_mB6880A7C7C1E90BF9CBF6567DB09699FD2CA2564 (void);
// 0x00000889 System.Byte System.Runtime.Serialization.Json.ByteArrayHelperWithString::ToByte(System.Int32)
extern void ByteArrayHelperWithString_ToByte_mE6F6A9A860BC193F5BE6257B335A60031C42A225 (void);
// 0x0000088A System.Void System.Runtime.Serialization.Json.ByteArrayHelperWithString::.ctor()
extern void ByteArrayHelperWithString__ctor_m1B794705D1A61D8B399AF85ACDFC02BC6246A987 (void);
// 0x0000088B System.Void System.Runtime.Serialization.Json.ByteArrayHelperWithString::.cctor()
extern void ByteArrayHelperWithString__cctor_mA6E8A5750AEA133F084C055AFA799CBB8B103186 (void);
// 0x0000088C System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::.ctor(System.Type)
extern void DataContractJsonSerializer__ctor_mDBAD2FB5F119218821A9805D8F576DD2FAF7F639 (void);
// 0x0000088D System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::.ctor(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>)
extern void DataContractJsonSerializer__ctor_m558ADAF0B17436D1970D4A62FB63CB4DBA1ED006 (void);
// 0x0000088E System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::.ctor(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>,System.Int32,System.Boolean,System.Runtime.Serialization.IDataContractSurrogate,System.Boolean)
extern void DataContractJsonSerializer__ctor_mA81FB3CB6F4A3F2D769551B5C7177AEFCD3F548B (void);
// 0x0000088F System.Runtime.Serialization.IDataContractSurrogate System.Runtime.Serialization.Json.DataContractJsonSerializer::get_DataContractSurrogate()
extern void DataContractJsonSerializer_get_DataContractSurrogate_m1C64289ADA6874FA4D22DC7DEDCAA942A1E94203 (void);
// 0x00000890 System.Boolean System.Runtime.Serialization.Json.DataContractJsonSerializer::get_IgnoreExtensionDataObject()
extern void DataContractJsonSerializer_get_IgnoreExtensionDataObject_m1FD14E3DA7649A69B4F9799FC739BBC1045DA9B7 (void);
// 0x00000891 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.Json.DataContractJsonSerializer::get_KnownDataContracts()
extern void DataContractJsonSerializer_get_KnownDataContracts_m2094716DA8F4B4911F55108AF6A58C3E1004838D (void);
// 0x00000892 System.Int32 System.Runtime.Serialization.Json.DataContractJsonSerializer::get_MaxItemsInObjectGraph()
extern void DataContractJsonSerializer_get_MaxItemsInObjectGraph_mD7A1F691B986F383033A6F34FBB98A2BD9EDB369 (void);
// 0x00000893 System.Runtime.Serialization.DateTimeFormat System.Runtime.Serialization.Json.DataContractJsonSerializer::get_DateTimeFormat()
extern void DataContractJsonSerializer_get_DateTimeFormat_mDCE3872786BB543FC7A58BE55E661735FBFEBF98 (void);
// 0x00000894 System.Boolean System.Runtime.Serialization.Json.DataContractJsonSerializer::get_UseSimpleDictionaryFormat()
extern void DataContractJsonSerializer_get_UseSimpleDictionaryFormat_mAFA38F1790DD2318B8537D353DA578F4F6C1859C (void);
// 0x00000895 System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.DataContractJsonSerializer::get_RootContract()
extern void DataContractJsonSerializer_get_RootContract_m5AF8FFA664AB905DAB99C4B0CF0E92E1BD9EEF39 (void);
// 0x00000896 System.Xml.XmlDictionaryString System.Runtime.Serialization.Json.DataContractJsonSerializer::get_RootName()
extern void DataContractJsonSerializer_get_RootName_m9A889DAA72098400AA3A2422D80A09D6984FBE24 (void);
// 0x00000897 System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::ReadObject(System.IO.Stream)
extern void DataContractJsonSerializer_ReadObject_mCF613FC3BDF510375E609FE7A7867ADE00F26B6A (void);
// 0x00000898 System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::ReadObject(System.Xml.XmlReader,System.Boolean)
extern void DataContractJsonSerializer_ReadObject_m3511A16A95C047B844E1BA6A8801ACA9777BC031 (void);
// 0x00000899 System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::ReadObject(System.Xml.XmlDictionaryReader)
extern void DataContractJsonSerializer_ReadObject_m8CD7300185045923CBCEDEF5E7085100A171969F (void);
// 0x0000089A System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::ReadObject(System.Xml.XmlDictionaryReader,System.Boolean)
extern void DataContractJsonSerializer_ReadObject_m8482103334C6BBD49D7AE85DE9E6CBBD5ED0C251 (void);
// 0x0000089B System.String System.Runtime.Serialization.Json.DataContractJsonSerializer::ConvertXmlNameToJsonName(System.String)
extern void DataContractJsonSerializer_ConvertXmlNameToJsonName_m50587D1A3791480FF1B67520DED41279C4BDA7B8 (void);
// 0x0000089C System.Xml.XmlDictionaryString System.Runtime.Serialization.Json.DataContractJsonSerializer::ConvertXmlNameToJsonName(System.Xml.XmlDictionaryString)
extern void DataContractJsonSerializer_ConvertXmlNameToJsonName_m296CB32813B04EC4E3FECB16FA3D7748E002A6CA (void);
// 0x0000089D System.Boolean System.Runtime.Serialization.Json.DataContractJsonSerializer::IsJsonLocalName(System.Runtime.Serialization.XmlReaderDelegator,System.String)
extern void DataContractJsonSerializer_IsJsonLocalName_m385B49F0478862BEE7607EF2E61CDE0091E0BFF6 (void);
// 0x0000089E System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::ReadJsonValue(System.Runtime.Serialization.DataContract,System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void DataContractJsonSerializer_ReadJsonValue_m2DD44F490A394660A3A9AC13D10F374054432A67 (void);
// 0x0000089F System.Type System.Runtime.Serialization.Json.DataContractJsonSerializer::GetDeserializeType()
extern void DataContractJsonSerializer_GetDeserializeType_m1F5931EFB44A4EAAE5EB7462E38194B09FC428BC (void);
// 0x000008A0 System.Boolean System.Runtime.Serialization.Json.DataContractJsonSerializer::InternalIsStartObject(System.Runtime.Serialization.XmlReaderDelegator)
extern void DataContractJsonSerializer_InternalIsStartObject_m7D0BAE67C02837E00E240259D75D3D4C0A518B73 (void);
// 0x000008A1 System.Object System.Runtime.Serialization.Json.DataContractJsonSerializer::InternalReadObject(System.Runtime.Serialization.XmlReaderDelegator,System.Boolean)
extern void DataContractJsonSerializer_InternalReadObject_mB750923CEA1B7E8873E72D3BCFEB60D41A13B2A2 (void);
// 0x000008A2 System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::AddCollectionItemTypeToKnownTypes(System.Type)
extern void DataContractJsonSerializer_AddCollectionItemTypeToKnownTypes_m344C0164F99638654ADB9A3540F91CD71058539B (void);
// 0x000008A3 System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::Initialize(System.Type,System.Collections.Generic.IEnumerable`1<System.Type>,System.Int32,System.Boolean,System.Runtime.Serialization.IDataContractSurrogate,System.Runtime.Serialization.EmitTypeInformation,System.Boolean,System.Runtime.Serialization.DateTimeFormat,System.Boolean)
extern void DataContractJsonSerializer_Initialize_m213EB8E92CB41AAC0B39EECC71DF0765BDBA81BD (void);
// 0x000008A4 System.Void System.Runtime.Serialization.Json.DataContractJsonSerializer::CheckIfTypeIsReference(System.Runtime.Serialization.DataContract)
extern void DataContractJsonSerializer_CheckIfTypeIsReference_mB433F59C8FF210AFDDC842CC6FBD08E38B6F6690 (void);
// 0x000008A5 System.Void System.Runtime.Serialization.Json.JsonByteArrayDataContract::.ctor(System.Runtime.Serialization.ByteArrayDataContract)
extern void JsonByteArrayDataContract__ctor_m16A4CDECB6FF9E5135789E9FB0F1E4BEC28156EC (void);
// 0x000008A6 System.Object System.Runtime.Serialization.Json.JsonByteArrayDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonByteArrayDataContract_ReadJsonValueCore_m36425EA858E131FC6D168E6EBEE7668DB9AD8731 (void);
// 0x000008A7 System.Void System.Runtime.Serialization.Json.JsonClassDataContract::.ctor(System.Runtime.Serialization.ClassDataContract)
extern void JsonClassDataContract__ctor_m2DF702BF896653932C9A624A58004FC365948842 (void);
// 0x000008A8 System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate System.Runtime.Serialization.Json.JsonClassDataContract::get_JsonFormatReaderDelegate()
extern void JsonClassDataContract_get_JsonFormatReaderDelegate_m6C1981D88C32ED659BBD26E3D76F5D4E38514E41 (void);
// 0x000008A9 System.Xml.XmlDictionaryString[] System.Runtime.Serialization.Json.JsonClassDataContract::get_MemberNames()
extern void JsonClassDataContract_get_MemberNames_m2325D54594ACAC4201BD59C09E21D1C5E646F1B1 (void);
// 0x000008AA System.Runtime.Serialization.ClassDataContract System.Runtime.Serialization.Json.JsonClassDataContract::get_TraditionalClassDataContract()
extern void JsonClassDataContract_get_TraditionalClassDataContract_mD568B405A14E04823E4842513CC52CD313995C0B (void);
// 0x000008AB System.Object System.Runtime.Serialization.Json.JsonClassDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonClassDataContract_ReadJsonValueCore_m837A00A26EA027552A663B143FEB8967860A481E (void);
// 0x000008AC System.Void System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::.ctor(System.Runtime.Serialization.ClassDataContract)
extern void JsonClassDataContractCriticalHelper__ctor_m20E10E2F719458680951710713D0183FF9E666EE (void);
// 0x000008AD System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::get_JsonFormatReaderDelegate()
extern void JsonClassDataContractCriticalHelper_get_JsonFormatReaderDelegate_mACB761B123592E44B8CB07D06F64DBC2BBD2C7A2 (void);
// 0x000008AE System.Void System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::set_JsonFormatReaderDelegate(System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate)
extern void JsonClassDataContractCriticalHelper_set_JsonFormatReaderDelegate_m04BD3CD2EAEE846F572AEEE6AE3AE33E38A8C90C (void);
// 0x000008AF System.Xml.XmlDictionaryString[] System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::get_MemberNames()
extern void JsonClassDataContractCriticalHelper_get_MemberNames_m019B90803B40FCD141777B8659A70604AFB20552 (void);
// 0x000008B0 System.Runtime.Serialization.ClassDataContract System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::get_TraditionalClassDataContract()
extern void JsonClassDataContractCriticalHelper_get_TraditionalClassDataContract_m4BF70788225F03091B982381EE30141C0AED6C5D (void);
// 0x000008B1 System.Void System.Runtime.Serialization.Json.JsonClassDataContract/JsonClassDataContractCriticalHelper::CopyMembersAndCheckDuplicateNames()
extern void JsonClassDataContractCriticalHelper_CopyMembersAndCheckDuplicateNames_m8055F8B0EC3C4B387DD81FAC8C975AE40912A11A (void);
// 0x000008B2 System.Void System.Runtime.Serialization.Json.JsonCollectionDataContract::.ctor(System.Runtime.Serialization.CollectionDataContract)
extern void JsonCollectionDataContract__ctor_m2E15722B25974EE7F46C3057984E00B4E4ADCBD0 (void);
// 0x000008B3 System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate System.Runtime.Serialization.Json.JsonCollectionDataContract::get_JsonFormatReaderDelegate()
extern void JsonCollectionDataContract_get_JsonFormatReaderDelegate_mF6677082D793464D5429DA8B3702DDF0CC7E3627 (void);
// 0x000008B4 System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.Json.JsonCollectionDataContract::get_JsonFormatGetOnlyReaderDelegate()
extern void JsonCollectionDataContract_get_JsonFormatGetOnlyReaderDelegate_mAAE3A3147EED31EC77F3A056EDD909BB84C573DD (void);
// 0x000008B5 System.Runtime.Serialization.CollectionDataContract System.Runtime.Serialization.Json.JsonCollectionDataContract::get_TraditionalCollectionDataContract()
extern void JsonCollectionDataContract_get_TraditionalCollectionDataContract_m5E5F2AED19B597EFA0B30639A3A07E5B344052CE (void);
// 0x000008B6 System.Object System.Runtime.Serialization.Json.JsonCollectionDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonCollectionDataContract_ReadJsonValueCore_m16F8F7087AAD6CA9701DD02D9C03B15386C69FAE (void);
// 0x000008B7 System.Void System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::.ctor(System.Runtime.Serialization.CollectionDataContract)
extern void JsonCollectionDataContractCriticalHelper__ctor_m0D5F3F29E4FB5A3E874D48C823A47494176146EA (void);
// 0x000008B8 System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::get_JsonFormatReaderDelegate()
extern void JsonCollectionDataContractCriticalHelper_get_JsonFormatReaderDelegate_mE2E4FFF15C80E60EF435A2ECE3E855B4A52C6D39 (void);
// 0x000008B9 System.Void System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::set_JsonFormatReaderDelegate(System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate)
extern void JsonCollectionDataContractCriticalHelper_set_JsonFormatReaderDelegate_m431D30336E761E93489BDF94D80BF4BF8B5CD13A (void);
// 0x000008BA System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::get_JsonFormatGetOnlyReaderDelegate()
extern void JsonCollectionDataContractCriticalHelper_get_JsonFormatGetOnlyReaderDelegate_mBD4A37C895337475A6AD51783B74E9FA19F735B7 (void);
// 0x000008BB System.Void System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::set_JsonFormatGetOnlyReaderDelegate(System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate)
extern void JsonCollectionDataContractCriticalHelper_set_JsonFormatGetOnlyReaderDelegate_m618607EF3DF5B720049767AC4937BBE7C0821336 (void);
// 0x000008BC System.Runtime.Serialization.CollectionDataContract System.Runtime.Serialization.Json.JsonCollectionDataContract/JsonCollectionDataContractCriticalHelper::get_TraditionalCollectionDataContract()
extern void JsonCollectionDataContractCriticalHelper_get_TraditionalCollectionDataContract_m9F8C7EF7BC66B0C54BFF12D73284CE87BBB1FFFF (void);
// 0x000008BD System.Void System.Runtime.Serialization.Json.JsonDataContract::.ctor(System.Runtime.Serialization.DataContract)
extern void JsonDataContract__ctor_m2AE5BA1403129478C92F28B41D8140A6AC3637B9 (void);
// 0x000008BE System.Void System.Runtime.Serialization.Json.JsonDataContract::.ctor(System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper)
extern void JsonDataContract__ctor_mA93F655166D5211899A9E9B29C8B76823C02CA74 (void);
// 0x000008BF System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper System.Runtime.Serialization.Json.JsonDataContract::get_Helper()
extern void JsonDataContract_get_Helper_mDC4D4244B2C7ECDB3BEE95044F7597A6649CACED (void);
// 0x000008C0 System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.JsonDataContract::get_TraditionalDataContract()
extern void JsonDataContract_get_TraditionalDataContract_m236E30BF2485A969D21BC8B0D23767D67BDD2197 (void);
// 0x000008C1 System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.Json.JsonDataContract::get_KnownDataContracts()
extern void JsonDataContract_get_KnownDataContracts_m406233066ADF9442874CF21756C284EE9124AFFE (void);
// 0x000008C2 System.Runtime.Serialization.Json.JsonDataContract System.Runtime.Serialization.Json.JsonDataContract::GetJsonDataContract(System.Runtime.Serialization.DataContract)
extern void JsonDataContract_GetJsonDataContract_m18EE3442A309734B894217D3D52BBA7C7E04FA1F (void);
// 0x000008C3 System.Object System.Runtime.Serialization.Json.JsonDataContract::ReadJsonValue(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonDataContract_ReadJsonValue_mF9898B88487F0E90B879A3026DD13907B761848A (void);
// 0x000008C4 System.Object System.Runtime.Serialization.Json.JsonDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonDataContract_ReadJsonValueCore_m284221E4CB2BA96E3E2AB4DBFFDF85B46FA1A2E6 (void);
// 0x000008C5 System.Object System.Runtime.Serialization.Json.JsonDataContract::HandleReadValue(System.Object,System.Runtime.Serialization.XmlObjectSerializerReadContext)
extern void JsonDataContract_HandleReadValue_mE2CCEA432EE960DEB8CDC04B729C641E8A4BD832 (void);
// 0x000008C6 System.Boolean System.Runtime.Serialization.Json.JsonDataContract::TryReadNullAtTopLevel(System.Runtime.Serialization.XmlReaderDelegator)
extern void JsonDataContract_TryReadNullAtTopLevel_m67448DFCD7C56478EA2E563D7F4F41344D7E2B77 (void);
// 0x000008C7 System.Void System.Runtime.Serialization.Json.JsonDataContract::PopKnownDataContracts(System.Runtime.Serialization.XmlObjectSerializerContext)
extern void JsonDataContract_PopKnownDataContracts_m739AACE9797AC5518EBA40A0F85638C37407F6C7 (void);
// 0x000008C8 System.Void System.Runtime.Serialization.Json.JsonDataContract::PushKnownDataContracts(System.Runtime.Serialization.XmlObjectSerializerContext)
extern void JsonDataContract_PushKnownDataContracts_mCF669588E06B5768C5CD5796B997D9E3D9ECA7E9 (void);
// 0x000008C9 System.Void System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::.ctor(System.Runtime.Serialization.DataContract)
extern void JsonDataContractCriticalHelper__ctor_m8E39F6E4EF1638DDD48DA5983C59646BD24A949D (void);
// 0x000008CA System.Collections.Generic.Dictionary`2<System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract> System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::get_KnownDataContracts()
extern void JsonDataContractCriticalHelper_get_KnownDataContracts_m26F06804EC3C7A4FAE343971B2EEC26807ADC0A3 (void);
// 0x000008CB System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::get_TraditionalDataContract()
extern void JsonDataContractCriticalHelper_get_TraditionalDataContract_mC51A222FB32748EC2F5AFB9B79998A393A13AFAF (void);
// 0x000008CC System.Runtime.Serialization.Json.JsonDataContract System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::GetJsonDataContract(System.Runtime.Serialization.DataContract)
extern void JsonDataContractCriticalHelper_GetJsonDataContract_mD351272C0675E3DBE9FB77432E1413E1344BC68D (void);
// 0x000008CD System.Int32 System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::GetId(System.RuntimeTypeHandle)
extern void JsonDataContractCriticalHelper_GetId_m14A8A3E4621F058CF94DDC8E95EDF8005E2CCE42 (void);
// 0x000008CE System.Runtime.Serialization.Json.JsonDataContract System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::CreateJsonDataContract(System.Int32,System.Runtime.Serialization.DataContract)
extern void JsonDataContractCriticalHelper_CreateJsonDataContract_m0D70DF5BA5D4753D567430BA9831E09E07C5EB41 (void);
// 0x000008CF System.Void System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::AddCollectionItemContractsToKnownDataContracts()
extern void JsonDataContractCriticalHelper_AddCollectionItemContractsToKnownDataContracts_m5ED38536A543F80022532A7274C27DF6ADE7D075 (void);
// 0x000008D0 System.Void System.Runtime.Serialization.Json.JsonDataContract/JsonDataContractCriticalHelper::.cctor()
extern void JsonDataContractCriticalHelper__cctor_m270ACC278080F70187F80AC36BDD25FA5C3EF545 (void);
// 0x000008D1 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::.ctor(System.IO.Stream,System.Text.Encoding,System.Boolean)
extern void JsonEncodingStreamWrapper__ctor_m55881BFCA9AE245054CD741AE643D663E22659D6 (void);
// 0x000008D2 System.Boolean System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_CanRead()
extern void JsonEncodingStreamWrapper_get_CanRead_m92037440463B605B6972287DD5DAE31D0E129ECB (void);
// 0x000008D3 System.Boolean System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_CanSeek()
extern void JsonEncodingStreamWrapper_get_CanSeek_mC32DFA69021433D2851031F41941CCEFA024C479 (void);
// 0x000008D4 System.Boolean System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_CanTimeout()
extern void JsonEncodingStreamWrapper_get_CanTimeout_m97AD5DC5F87318FD7D41C383D76954330A62F7CA (void);
// 0x000008D5 System.Boolean System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_CanWrite()
extern void JsonEncodingStreamWrapper_get_CanWrite_m22EC5145193F1D571AA40F18A3AE2286C3D7D95B (void);
// 0x000008D6 System.Int64 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_Length()
extern void JsonEncodingStreamWrapper_get_Length_m2AD801FFB3C021ACC7F80590D6C909C618069AFC (void);
// 0x000008D7 System.Int64 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_Position()
extern void JsonEncodingStreamWrapper_get_Position_m95CFB106FAB3DF90620FEF9E06DEA115DBB582FC (void);
// 0x000008D8 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::set_Position(System.Int64)
extern void JsonEncodingStreamWrapper_set_Position_m0767A4B0F5B491614A995DCFCCA20085D7DD8684 (void);
// 0x000008D9 System.Int32 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_ReadTimeout()
extern void JsonEncodingStreamWrapper_get_ReadTimeout_mBCA54F9F4F0E998BDDC7BB56E884039F7FACF540 (void);
// 0x000008DA System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::set_ReadTimeout(System.Int32)
extern void JsonEncodingStreamWrapper_set_ReadTimeout_mB1118C8F0E59FA6F75614E5564209B416971B4E2 (void);
// 0x000008DB System.Int32 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::get_WriteTimeout()
extern void JsonEncodingStreamWrapper_get_WriteTimeout_m3363AFD655EBFD9E551E642088BCD69AF8780D4A (void);
// 0x000008DC System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::set_WriteTimeout(System.Int32)
extern void JsonEncodingStreamWrapper_set_WriteTimeout_m2FBF47522B356C12AF3EC3562EE1C0FA0C626BD7 (void);
// 0x000008DD System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::Close()
extern void JsonEncodingStreamWrapper_Close_m3D9E823A4C242CBBB6B7FE895D22B8E2F10307A8 (void);
// 0x000008DE System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::Flush()
extern void JsonEncodingStreamWrapper_Flush_m18137D8FD12C6FA7AD97D0651159807334FFF91B (void);
// 0x000008DF System.Int32 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::Read(System.Byte[],System.Int32,System.Int32)
extern void JsonEncodingStreamWrapper_Read_m5FE4432249CF12DEBA74D176C0B95DE3651B7CEF (void);
// 0x000008E0 System.Int32 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::ReadByte()
extern void JsonEncodingStreamWrapper_ReadByte_m75428C04EC879163A47768212851FC71D3DF1CFA (void);
// 0x000008E1 System.Int64 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::Seek(System.Int64,System.IO.SeekOrigin)
extern void JsonEncodingStreamWrapper_Seek_mDA54187828F3CEEA64F1379C9CBF1A836E0758D5 (void);
// 0x000008E2 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::SetLength(System.Int64)
extern void JsonEncodingStreamWrapper_SetLength_m625E5B4D0DE38C5913507DA92ACED513A047A8BC (void);
// 0x000008E3 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::Write(System.Byte[],System.Int32,System.Int32)
extern void JsonEncodingStreamWrapper_Write_mBA0BE019A09B3D5B2C51650F703732DF08A96358 (void);
// 0x000008E4 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::WriteByte(System.Byte)
extern void JsonEncodingStreamWrapper_WriteByte_m63082DE505B870A7EDC898D2C56002E2BCA2AE75 (void);
// 0x000008E5 System.Text.Encoding System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::GetEncoding(System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding)
extern void JsonEncodingStreamWrapper_GetEncoding_m67C305A05554D08C1A3B9CD5E261C4146ED0CE21 (void);
// 0x000008E6 System.String System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::GetEncodingName(System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding)
extern void JsonEncodingStreamWrapper_GetEncodingName_m6E9E73420497391158E41652A2749A9DB17EC8E9 (void);
// 0x000008E7 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::GetSupportedEncoding(System.Text.Encoding)
extern void JsonEncodingStreamWrapper_GetSupportedEncoding_m843367225D3B2D69B399892809B792E889B521E8 (void);
// 0x000008E8 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::ReadEncoding(System.Byte,System.Byte)
extern void JsonEncodingStreamWrapper_ReadEncoding_mA95F2B3E0AA1C2D2D9AB281B4C44EA2F325DC79D (void);
// 0x000008E9 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::ThrowExpectedEncodingMismatch(System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding,System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding)
extern void JsonEncodingStreamWrapper_ThrowExpectedEncodingMismatch_m4291E6EC42820B67948580D01DF17E6DD406DAE6 (void);
// 0x000008EA System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::CleanupCharBreak()
extern void JsonEncodingStreamWrapper_CleanupCharBreak_mA7C555BCFEFAC40810288A21193974401B914919 (void);
// 0x000008EB System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::EnsureBuffers()
extern void JsonEncodingStreamWrapper_EnsureBuffers_m63DF4630980BA430B69DB2D296FC7C5D7778E1FC (void);
// 0x000008EC System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::EnsureByteBuffer()
extern void JsonEncodingStreamWrapper_EnsureByteBuffer_m628B607930D1E26D3CED7032E9DD7F7B37486050 (void);
// 0x000008ED System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::FillBuffer(System.Int32)
extern void JsonEncodingStreamWrapper_FillBuffer_m543CE1A485A4229839AA5FACB39AF52419C86107 (void);
// 0x000008EE System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::InitForReading(System.IO.Stream,System.Text.Encoding)
extern void JsonEncodingStreamWrapper_InitForReading_mE6CA3CAD8601EA31F0CCBD62371AE695D1DA2C75 (void);
// 0x000008EF System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::InitForWriting(System.IO.Stream,System.Text.Encoding)
extern void JsonEncodingStreamWrapper_InitForWriting_m2EED8243D269538EFCE9C45C73CF708B748912F8 (void);
// 0x000008F0 System.Runtime.Serialization.Json.JsonEncodingStreamWrapper/SupportedEncoding System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::ReadEncoding()
extern void JsonEncodingStreamWrapper_ReadEncoding_mC82C71C0AA3A34698A4F595E4B6F61B5A1C413E3 (void);
// 0x000008F1 System.Void System.Runtime.Serialization.Json.JsonEncodingStreamWrapper::.cctor()
extern void JsonEncodingStreamWrapper__cctor_m3C75D41AC613032B59329315132456374CF03BE4 (void);
// 0x000008F2 System.Void System.Runtime.Serialization.Json.JsonEnumDataContract::.ctor(System.Runtime.Serialization.EnumDataContract)
extern void JsonEnumDataContract__ctor_mE47E7FF170FD7F3C5AE4A3C4D077383D0DC1145E (void);
// 0x000008F3 System.Boolean System.Runtime.Serialization.Json.JsonEnumDataContract::get_IsULong()
extern void JsonEnumDataContract_get_IsULong_m05F0FFE0858D88D8895ED2DD47DF5564BC00A91F (void);
// 0x000008F4 System.Object System.Runtime.Serialization.Json.JsonEnumDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonEnumDataContract_ReadJsonValueCore_m670EDE889054D8762995D924805033A7B8EE26C5 (void);
// 0x000008F5 System.Void System.Runtime.Serialization.Json.JsonEnumDataContract/JsonEnumDataContractCriticalHelper::.ctor(System.Runtime.Serialization.EnumDataContract)
extern void JsonEnumDataContractCriticalHelper__ctor_mBB17A840DC678D491F820D8D7D15F579F6D66E3D (void);
// 0x000008F6 System.Boolean System.Runtime.Serialization.Json.JsonEnumDataContract/JsonEnumDataContractCriticalHelper::get_IsULong()
extern void JsonEnumDataContractCriticalHelper_get_IsULong_m5EAD37449874373EBDACCEB919778B58E34A4162 (void);
// 0x000008F7 System.Void System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void JsonFormatClassReaderDelegate__ctor_m2F4DBCB5849DF53C2AE67EC89AE84E70F8AD8866 (void);
// 0x000008F8 System.Object System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString[])
extern void JsonFormatClassReaderDelegate_Invoke_mAAB83E87D989C5C2E6207E8635AF98DFA726CFEF (void);
// 0x000008F9 System.Void System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void JsonFormatCollectionReaderDelegate__ctor_mB89481ABA75B71FC642551360B8F6F862D086EA9 (void);
// 0x000008FA System.Object System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatCollectionReaderDelegate_Invoke_m04E7661456E088542702A50B37CA9FE32DCC9DF6 (void);
// 0x000008FB System.Void System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate::.ctor(System.Object,System.IntPtr)
extern void JsonFormatGetOnlyCollectionReaderDelegate__ctor_mBC50D36CE7B9F664BDC7ADBBB586C4539C028098 (void);
// 0x000008FC System.Void System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate::Invoke(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatGetOnlyCollectionReaderDelegate_Invoke_mCCFFC3D1894228A4659DA55374DB3225A4A853A9 (void);
// 0x000008FD System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator::.ctor()
extern void JsonFormatReaderGenerator__ctor_mAE40E9556456C29F3B8EED1D6832931DB2CD7EE8 (void);
// 0x000008FE System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator::GenerateClassReader(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderGenerator_GenerateClassReader_m204BAB8CC82A5282AA41E97138D4C034382615CB (void);
// 0x000008FF System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator::GenerateCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderGenerator_GenerateCollectionReader_mFA5464DD44D51CA4845C98BB8F43DEA99366A195 (void);
// 0x00000900 System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator::GenerateGetOnlyCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderGenerator_GenerateGetOnlyCollectionReader_m911990A0E21A319FA0A10BEFFB84DE78A2F158B9 (void);
// 0x00000901 System.Runtime.Serialization.Json.JsonFormatClassReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper::GenerateClassReader(System.Runtime.Serialization.ClassDataContract)
extern void CriticalHelper_GenerateClassReader_m5463698C2D0AFA303C2C3430FE0DF6A77DD016DA (void);
// 0x00000902 System.Runtime.Serialization.Json.JsonFormatCollectionReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper::GenerateCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void CriticalHelper_GenerateCollectionReader_m3E9D3E773C5F5607FBE9CB2E4AFAB7447FEBC957 (void);
// 0x00000903 System.Runtime.Serialization.Json.JsonFormatGetOnlyCollectionReaderDelegate System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper::GenerateGetOnlyCollectionReader(System.Runtime.Serialization.CollectionDataContract)
extern void CriticalHelper_GenerateGetOnlyCollectionReader_mAE9F4B788F6A216B7420ABED5943BE30C178BC00 (void);
// 0x00000904 System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper::.ctor()
extern void CriticalHelper__ctor_m399F61544F67A2F49613EBB21A7C9C9E58FAEEEA (void);
// 0x00000905 System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m8AAF28EEB4B3494013AFF0BEA19D6F1D65CE7B12 (void);
// 0x00000906 System.Object System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass0_0::<GenerateClassReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString[])
extern void U3CU3Ec__DisplayClass0_0_U3CGenerateClassReaderU3Eb__0_m7F635744D426476BF93FD6B2143084707C5643CD (void);
// 0x00000907 System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mFCA0B3FC1151A429C5785BA636443B252AC3E42E (void);
// 0x00000908 System.Object System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass1_0::<GenerateCollectionReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void U3CU3Ec__DisplayClass1_0_U3CGenerateCollectionReaderU3Eb__0_m716BA6A2FE1525BF906C5DB301C81731D16F1549 (void);
// 0x00000909 System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m4B934391FD0EA30137B0E6CA9845B532F09AA1E2 (void);
// 0x0000090A System.Void System.Runtime.Serialization.Json.JsonFormatReaderGenerator/CriticalHelper/<>c__DisplayClass2_0::<GenerateGetOnlyCollectionReader>b__0(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void U3CU3Ec__DisplayClass2_0_U3CGenerateGetOnlyCollectionReaderU3Eb__0_m98B14D1C7978DAD4C7640D927AD079A1EEACA188 (void);
// 0x0000090B System.Void System.Runtime.Serialization.Json.JsonGlobals::.cctor()
extern void JsonGlobals__cctor_m499E735778FC97B03243105D23C173D8552D362E (void);
// 0x0000090C System.Void System.Runtime.Serialization.Json.JsonObjectDataContract::.ctor(System.Runtime.Serialization.DataContract)
extern void JsonObjectDataContract__ctor_m00AB3A171DB0249D0ADCF2E29FFD5FDCB17FC97C (void);
// 0x0000090D System.Object System.Runtime.Serialization.Json.JsonObjectDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonObjectDataContract_ReadJsonValueCore_m78253A21FE0C49CB809C171CAD9DBC8EE145224E (void);
// 0x0000090E System.Object System.Runtime.Serialization.Json.JsonObjectDataContract::ParseJsonNumber(System.String,System.TypeCode&)
extern void JsonObjectDataContract_ParseJsonNumber_m0B56A61CC1D26EAF19649FD6D1C3C4E92ADB137D (void);
// 0x0000090F System.Object System.Runtime.Serialization.Json.JsonObjectDataContract::ParseJsonNumber(System.String)
extern void JsonObjectDataContract_ParseJsonNumber_mD695A7CDF1510F3F0FB9EAEEAABF1F1BB19A07F7 (void);
// 0x00000910 System.Void System.Runtime.Serialization.Json.JsonQNameDataContract::.ctor(System.Runtime.Serialization.QNameDataContract)
extern void JsonQNameDataContract__ctor_m0D45B7573F11C5B5F76AE3C97E0D9750253F6617 (void);
// 0x00000911 System.Object System.Runtime.Serialization.Json.JsonQNameDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonQNameDataContract_ReadJsonValueCore_mF241330C6847FAC9C5E29543F3CC2BA12F92BFF3 (void);
// 0x00000912 System.Void System.Runtime.Serialization.Json.JsonReaderDelegator::.ctor(System.Xml.XmlReader)
extern void JsonReaderDelegator__ctor_mF8A9B93C8461179AE979410D66FFA9A6EA1F5F5F (void);
// 0x00000913 System.Void System.Runtime.Serialization.Json.JsonReaderDelegator::.ctor(System.Xml.XmlReader,System.Runtime.Serialization.DateTimeFormat)
extern void JsonReaderDelegator__ctor_mB6DD03CB22CFE005A1F9A9F37934911788A396E9 (void);
// 0x00000914 System.Xml.XmlDictionaryReaderQuotas System.Runtime.Serialization.Json.JsonReaderDelegator::get_ReaderQuotas()
extern void JsonReaderDelegator_get_ReaderQuotas_mC60FE55589D8A0A209B4C31C7A0490938BC0DFDA (void);
// 0x00000915 System.Runtime.Serialization.Json.JsonReaderDelegator/DateTimeArrayJsonHelperWithString System.Runtime.Serialization.Json.JsonReaderDelegator::get_DateTimeArrayHelper()
extern void JsonReaderDelegator_get_DateTimeArrayHelper_mF83DCAA117D8ED0C177FBC8625C9CF7D251534D9 (void);
// 0x00000916 System.Xml.XmlQualifiedName System.Runtime.Serialization.Json.JsonReaderDelegator::ParseQualifiedName(System.String)
extern void JsonReaderDelegator_ParseQualifiedName_mD6829EAB7DEEF92FFD1D410471797901D5251706 (void);
// 0x00000917 System.Char System.Runtime.Serialization.Json.JsonReaderDelegator::ReadContentAsChar()
extern void JsonReaderDelegator_ReadContentAsChar_mF3E7BDB28C7C94F9DCE5B7565EF5B1FE56434DAE (void);
// 0x00000918 System.Xml.XmlQualifiedName System.Runtime.Serialization.Json.JsonReaderDelegator::ReadContentAsQName()
extern void JsonReaderDelegator_ReadContentAsQName_m4141C9F78047037BB3C0516D4F95FBFB71E731EC (void);
// 0x00000919 System.Char System.Runtime.Serialization.Json.JsonReaderDelegator::ReadElementContentAsChar()
extern void JsonReaderDelegator_ReadElementContentAsChar_mE752F9DB2D01DFAEC5B98EB58B54D9DC49A903AF (void);
// 0x0000091A System.Byte[] System.Runtime.Serialization.Json.JsonReaderDelegator::ReadContentAsBase64()
extern void JsonReaderDelegator_ReadContentAsBase64_m31208E3A55F15F0627637D1BFDC29337ACD7C230 (void);
// 0x0000091B System.Byte[] System.Runtime.Serialization.Json.JsonReaderDelegator::ReadElementContentAsBase64()
extern void JsonReaderDelegator_ReadElementContentAsBase64_m904F764AE29C2D11C42D437EE9A23B5616CF8731 (void);
// 0x0000091C System.DateTime System.Runtime.Serialization.Json.JsonReaderDelegator::ReadContentAsDateTime()
extern void JsonReaderDelegator_ReadContentAsDateTime_mED4039C9CBB951459C92B17F03C71269A5B3096B (void);
// 0x0000091D System.DateTime System.Runtime.Serialization.Json.JsonReaderDelegator::ParseJsonDate(System.String,System.Runtime.Serialization.DateTimeFormat)
extern void JsonReaderDelegator_ParseJsonDate_m629EA10B51432F2DC6F0EF08A0A6165277C7CB92 (void);
// 0x0000091E System.DateTime System.Runtime.Serialization.Json.JsonReaderDelegator::ParseJsonDateInDefaultFormat(System.String)
extern void JsonReaderDelegator_ParseJsonDateInDefaultFormat_m0847D5A4DCCAB0ED2CA4D0F7A158575CE249B0F8 (void);
// 0x0000091F System.DateTime System.Runtime.Serialization.Json.JsonReaderDelegator::ReadElementContentAsDateTime()
extern void JsonReaderDelegator_ReadElementContentAsDateTime_m489BA45397AF1ED781A00AF3AD0D3100FE237C6A (void);
// 0x00000920 System.Boolean System.Runtime.Serialization.Json.JsonReaderDelegator::TryReadJsonDateTimeArray(System.Runtime.Serialization.XmlObjectSerializerReadContext,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Int32,System.DateTime[]&)
extern void JsonReaderDelegator_TryReadJsonDateTimeArray_mBEEF54F15BCDBD2FD68675337EE11EF7D6BFC5A1 (void);
// 0x00000921 System.UInt64 System.Runtime.Serialization.Json.JsonReaderDelegator::ReadContentAsUnsignedLong()
extern void JsonReaderDelegator_ReadContentAsUnsignedLong_m3AF9061BDE3589930DDA726BAEBBF72E96089DFF (void);
// 0x00000922 System.UInt64 System.Runtime.Serialization.Json.JsonReaderDelegator::ReadElementContentAsUnsignedLong()
extern void JsonReaderDelegator_ReadElementContentAsUnsignedLong_mFFE7812B07B7ADC4BA547D0D1823C57801100F4E (void);
// 0x00000923 System.Void System.Runtime.Serialization.Json.JsonReaderDelegator/DateTimeArrayJsonHelperWithString::.ctor(System.Runtime.Serialization.DateTimeFormat)
extern void DateTimeArrayJsonHelperWithString__ctor_m80D81CC6DAB430F7BCD9D714F2D88334F1EE9AE7 (void);
// 0x00000924 System.Int32 System.Runtime.Serialization.Json.JsonReaderDelegator/DateTimeArrayJsonHelperWithString::ReadArray(System.Xml.XmlDictionaryReader,System.String,System.String,System.DateTime[],System.Int32,System.Int32)
extern void DateTimeArrayJsonHelperWithString_ReadArray_mDA4C7CA5FBA3C3829DC7B5CFAB267483A9F82511 (void);
// 0x00000925 System.Xml.XmlDictionaryReader System.Runtime.Serialization.Json.JsonReaderWriterFactory::CreateJsonReader(System.IO.Stream,System.Xml.XmlDictionaryReaderQuotas)
extern void JsonReaderWriterFactory_CreateJsonReader_m662CFCA2554A46B4357A4A1776B6F7029A216820 (void);
// 0x00000926 System.Xml.XmlDictionaryReader System.Runtime.Serialization.Json.JsonReaderWriterFactory::CreateJsonReader(System.IO.Stream,System.Text.Encoding,System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void JsonReaderWriterFactory_CreateJsonReader_m5B490359A2903A9E0E53F5A8866309E343ADB751 (void);
// 0x00000927 System.Void System.Runtime.Serialization.Json.JsonStringDataContract::.ctor(System.Runtime.Serialization.StringDataContract)
extern void JsonStringDataContract__ctor_mC6767265D363AD99D2B30DD6A47CE0EBABED10DC (void);
// 0x00000928 System.Object System.Runtime.Serialization.Json.JsonStringDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonStringDataContract_ReadJsonValueCore_mC1B32A955B9A4D8B7CAD7E2FF1E7B676A768E029 (void);
// 0x00000929 System.Void System.Runtime.Serialization.Json.JsonUriDataContract::.ctor(System.Runtime.Serialization.UriDataContract)
extern void JsonUriDataContract__ctor_mC851DE0D2713F44C8D9B8C45B07042F02A43F5E1 (void);
// 0x0000092A System.Object System.Runtime.Serialization.Json.JsonUriDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonUriDataContract_ReadJsonValueCore_m9790136115B682C01298F54D27B70718F6B5DCED (void);
// 0x0000092B System.Void System.Runtime.Serialization.Json.JsonXmlDataContract::.ctor(System.Runtime.Serialization.XmlDataContract)
extern void JsonXmlDataContract__ctor_m96D8E4ED9FADFB15AD9EB6AFF8E95A266182C31D (void);
// 0x0000092C System.Object System.Runtime.Serialization.Json.JsonXmlDataContract::ReadJsonValueCore(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson)
extern void JsonXmlDataContract_ReadJsonValueCore_m9E3A438D2AD28ABA834260BA88B52698D6E5BA7B (void);
// 0x0000092D System.Collections.Generic.List`1<System.Type> System.Runtime.Serialization.Json.JsonXmlDataContract::GetKnownTypesFromContext(System.Runtime.Serialization.XmlObjectSerializerContext,System.Collections.Generic.IList`1<System.Type>)
extern void JsonXmlDataContract_GetKnownTypesFromContext_m791F316BDEA4A1E656950D85EACC2797F0F64F05 (void);
// 0x0000092E System.String System.Runtime.Serialization.Json.XmlJsonReader::get_Value()
extern void XmlJsonReader_get_Value_mD4BF363350C3D29441F286CDC07BB1D7ACD1CF75 (void);
// 0x0000092F System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::get_IsAttributeValue()
extern void XmlJsonReader_get_IsAttributeValue_m990BCD4E841CC82CE8D9FD1AAC6D62D72D14CDC4 (void);
// 0x00000930 System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::get_IsReadingCollection()
extern void XmlJsonReader_get_IsReadingCollection_mC54F2AAD455D4F32B115877FF26ABEAF7159DBCB (void);
// 0x00000931 System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::get_IsReadingComplexText()
extern void XmlJsonReader_get_IsReadingComplexText_m27B930346FEA477A768156C5A9C5CBB9A410E367 (void);
// 0x00000932 System.Void System.Runtime.Serialization.Json.XmlJsonReader::Close()
extern void XmlJsonReader_Close_m3443826B75CD941D16A1E2D619722A4CF9F8F453 (void);
// 0x00000933 System.String System.Runtime.Serialization.Json.XmlJsonReader::GetAttribute(System.Int32)
extern void XmlJsonReader_GetAttribute_m1122C3CA0CD42F5A574E508B3A6457C6F23FF470 (void);
// 0x00000934 System.String System.Runtime.Serialization.Json.XmlJsonReader::GetAttribute(System.String,System.String)
extern void XmlJsonReader_GetAttribute_mF24B5C7DA226323C36FA8D6BF9B8DD9754A08F13 (void);
// 0x00000935 System.String System.Runtime.Serialization.Json.XmlJsonReader::GetAttribute(System.String)
extern void XmlJsonReader_GetAttribute_m0842A6194C64222D2EE9CC8336E1D1CDBB3E3ECF (void);
// 0x00000936 System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::Read()
extern void XmlJsonReader_Read_m54540A632EDD2A067F481B9C6B0304A8C3BE1BF9 (void);
// 0x00000937 System.Decimal System.Runtime.Serialization.Json.XmlJsonReader::ReadContentAsDecimal()
extern void XmlJsonReader_ReadContentAsDecimal_mBB60C8BDA8062CE587B3868248E521DDDE0992D9 (void);
// 0x00000938 System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ReadContentAsInt()
extern void XmlJsonReader_ReadContentAsInt_mAACC2DF2C9D31C07E61FC82D0013BD39FE0B7579 (void);
// 0x00000939 System.Int64 System.Runtime.Serialization.Json.XmlJsonReader::ReadContentAsLong()
extern void XmlJsonReader_ReadContentAsLong_m0B876F9FE68E02D43ACA903DEFC4070630E7738D (void);
// 0x0000093A System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ReadValueChunk(System.Char[],System.Int32,System.Int32)
extern void XmlJsonReader_ReadValueChunk_m6F2DE5BE6815F23490512C3BBB7A6DC7B62AA0BC (void);
// 0x0000093B System.Void System.Runtime.Serialization.Json.XmlJsonReader::SetInput(System.IO.Stream,System.Text.Encoding,System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void XmlJsonReader_SetInput_mABD3376B5D0FD1D69038083AE5DC064B1705933A (void);
// 0x0000093C System.Void System.Runtime.Serialization.Json.XmlJsonReader::CheckArray(System.Array,System.Int32,System.Int32)
extern void XmlJsonReader_CheckArray_mD74CF6709FD77A398182C97213756C843F5A440B (void);
// 0x0000093D System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::BreakText(System.Byte[],System.Int32,System.Int32)
extern void XmlJsonReader_BreakText_m8B06025EEFB3FD3DE06ABB870D3D1780A2284D83 (void);
// 0x0000093E System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ComputeNumericalTextLength(System.Byte[],System.Int32,System.Int32)
extern void XmlJsonReader_ComputeNumericalTextLength_m8C2977B55F37664CFE41A72B232668139E0EAB0A (void);
// 0x0000093F System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ComputeQuotedTextLengthUntilEndQuote(System.Byte[],System.Int32,System.Int32,System.Boolean&)
extern void XmlJsonReader_ComputeQuotedTextLengthUntilEndQuote_m2D2BEE40C0A43F74F38FE34B57ECD2F424E4DCA8 (void);
// 0x00000940 System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::IsWhitespace(System.Byte)
extern void XmlJsonReader_IsWhitespace_mBCF2E133AE90FCD83F906CC131D20A37BB328EA8 (void);
// 0x00000941 System.Char System.Runtime.Serialization.Json.XmlJsonReader::ParseChar(System.String,System.Globalization.NumberStyles)
extern void XmlJsonReader_ParseChar_mA0A06B22BDDEEB7FC00A2AB917BF8ACB51A6706F (void);
// 0x00000942 System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ParseInt(System.String,System.Globalization.NumberStyles)
extern void XmlJsonReader_ParseInt_m505C732803238B20A0DC8C32AB0970A969856CF2 (void);
// 0x00000943 System.Void System.Runtime.Serialization.Json.XmlJsonReader::BufferElement()
extern void XmlJsonReader_BufferElement_m53721DB9427ED257E7670E60B5217B45D17076D4 (void);
// 0x00000944 System.Void System.Runtime.Serialization.Json.XmlJsonReader::EnterJsonScope(System.Runtime.Serialization.Json.JsonNodeType)
extern void XmlJsonReader_EnterJsonScope_m2E3160962A4EFACE20926EE49A7DFA09913F3522 (void);
// 0x00000945 System.Runtime.Serialization.Json.JsonNodeType System.Runtime.Serialization.Json.XmlJsonReader::ExitJsonScope()
extern void XmlJsonReader_ExitJsonScope_mA4424BAC4A699A14E91C1F0EF7A9597960816BD3 (void);
// 0x00000946 System.Void System.Runtime.Serialization.Json.XmlJsonReader::MoveToEndElement()
extern void XmlJsonReader_MoveToEndElement_m62D3B49AAC273F3DBF202ED6FE1863964C6E6AF8 (void);
// 0x00000947 System.Void System.Runtime.Serialization.Json.XmlJsonReader::MoveToInitial(System.Xml.XmlDictionaryReaderQuotas,System.Xml.OnXmlDictionaryReaderClose)
extern void XmlJsonReader_MoveToInitial_mCBF287D1219E08D1C7FFE45BB22522D5DE0241ED (void);
// 0x00000948 System.Void System.Runtime.Serialization.Json.XmlJsonReader::ParseAndSetLocalName()
extern void XmlJsonReader_ParseAndSetLocalName_m981C74E15BB443197E58177396614B8CD4402F79 (void);
// 0x00000949 System.Void System.Runtime.Serialization.Json.XmlJsonReader::ParseStartElement()
extern void XmlJsonReader_ParseStartElement_mF0412AE34B040155CAEC349BAF7F34DACEFC7742 (void);
// 0x0000094A System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadAttributes()
extern void XmlJsonReader_ReadAttributes_mF653B2BF7C5D844AF1D71FA9BC78C9B8121ED6DA (void);
// 0x0000094B System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadEscapedCharacter(System.Boolean)
extern void XmlJsonReader_ReadEscapedCharacter_m21AAF4DE32B3B517A85B8821B6F3A2AAD65CF70A (void);
// 0x0000094C System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadNonExistentElementName(System.Xml.StringHandleConstStringType)
extern void XmlJsonReader_ReadNonExistentElementName_m2B747B93D4C999CBB4AC34E69F30C6C7BCEF9551 (void);
// 0x0000094D System.Int32 System.Runtime.Serialization.Json.XmlJsonReader::ReadNonFFFE()
extern void XmlJsonReader_ReadNonFFFE_m7320B9CB92794E7A944AAA9B76B6B843E4B83E25 (void);
// 0x0000094E System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadNumericalText()
extern void XmlJsonReader_ReadNumericalText_m94D23C6F281F6EF938E092DF0282FF0C751D8043 (void);
// 0x0000094F System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadQuotedText(System.Boolean)
extern void XmlJsonReader_ReadQuotedText_m9CE9C4FD3229C5C5B56B51A80470EFD003EECDD5 (void);
// 0x00000950 System.Void System.Runtime.Serialization.Json.XmlJsonReader::ReadServerTypeAttribute(System.Boolean)
extern void XmlJsonReader_ReadServerTypeAttribute_m3A306BB46F0E0DB0D46195FD7AAC2969A717FFC0 (void);
// 0x00000951 System.Void System.Runtime.Serialization.Json.XmlJsonReader::ResetState()
extern void XmlJsonReader_ResetState_mF12297948ED759E6FB480716ACD5FA37677F5741 (void);
// 0x00000952 System.Void System.Runtime.Serialization.Json.XmlJsonReader::SetJsonNameWithMapping(System.Xml.XmlBaseReader/XmlElementNode)
extern void XmlJsonReader_SetJsonNameWithMapping_m9606EB7D58A5645563674A269D12ACFED6C08E66 (void);
// 0x00000953 System.Void System.Runtime.Serialization.Json.XmlJsonReader::SkipExpectedByteInBufferReader(System.Byte)
extern void XmlJsonReader_SkipExpectedByteInBufferReader_mB12E9997E348BEA4C3C3B57D4B7A2BF3075095BE (void);
// 0x00000954 System.Void System.Runtime.Serialization.Json.XmlJsonReader::SkipWhitespaceInBufferReader()
extern void XmlJsonReader_SkipWhitespaceInBufferReader_m4BF0995B42B369AF46F66B2F31D570F12FB28181 (void);
// 0x00000955 System.Boolean System.Runtime.Serialization.Json.XmlJsonReader::TryGetByte(System.Byte&)
extern void XmlJsonReader_TryGetByte_mDAE95F5BC57D39A9D3D3D49D051F556A383A85DD (void);
// 0x00000956 System.String System.Runtime.Serialization.Json.XmlJsonReader::UnescapeJsonString(System.String)
extern void XmlJsonReader_UnescapeJsonString_m8CAD0BCC9C4A60733066ADA5BA35CE80717252DD (void);
// 0x00000957 System.Void System.Runtime.Serialization.Json.XmlJsonReader::.ctor()
extern void XmlJsonReader__ctor_m25BAEF29BFBE83CF3477C0C15C8C172A7C0BF489 (void);
// 0x00000958 System.Void System.Runtime.Serialization.Json.XmlJsonReader::.cctor()
extern void XmlJsonReader__cctor_mFA9E339A920E19987B1153CA1F9C688C0FDD3EF6 (void);
// 0x00000959 System.Void System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::.ctor(System.Runtime.Serialization.Json.DataContractJsonSerializer,System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializerReadContextComplexJson__ctor_mA4FB3F666BBE801724B58B84FF092E7DAF41A937 (void);
// 0x0000095A System.Collections.Generic.IList`1<System.Type> System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::get_SerializerKnownTypeList()
extern void XmlObjectSerializerReadContextComplexJson_get_SerializerKnownTypeList_mE5FFF65B9AFA299A5D0E250463A4C646C45A1B8D (void);
// 0x0000095B System.Boolean System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::get_UseSimpleDictionaryFormat()
extern void XmlObjectSerializerReadContextComplexJson_get_UseSimpleDictionaryFormat_m891CEB8E032AD682A4575507FBB8D8FA04E71852 (void);
// 0x0000095C System.Void System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::StartReadExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_StartReadExtensionDataValue_mFFF0340898ABBE6E0326CF724BF13706A669FDC0 (void);
// 0x0000095D System.Runtime.Serialization.IDataNode System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ReadPrimitiveExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator,System.String,System.String)
extern void XmlObjectSerializerReadContextComplexJson_ReadPrimitiveExtensionDataValue_m5BF7CA4A44BBEF33B6E733403BDABD4C7628CC45 (void);
// 0x0000095E System.Runtime.Serialization.IDataNode System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ReadNumericalPrimitiveExtensionDataValue(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_ReadNumericalPrimitiveExtensionDataValue_mF5C6447DE7B7370225C5727B78E47F998CD25749 (void);
// 0x0000095F System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::CreateContext(System.Runtime.Serialization.Json.DataContractJsonSerializer,System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializerReadContextComplexJson_CreateContext_mE4338F45843C78C04364174681FAFD52F524BBA3 (void);
// 0x00000960 System.Int32 System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::GetArraySize()
extern void XmlObjectSerializerReadContextComplexJson_GetArraySize_mA334060CCC3BB1DBFCF554B49E9EF026867C1C31 (void);
// 0x00000961 System.Object System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ReadDataContractValue(System.Runtime.Serialization.DataContract,System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_ReadDataContractValue_mCE8D60BC28F63C4C46064EC666963BF4AE7D9E7F (void);
// 0x00000962 System.Void System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ReadAttributes(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_ReadAttributes_m04D5CBED4C97E4B3738C5782771A759D23AF0B26 (void);
// 0x00000963 System.Int32 System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::GetJsonMemberIndex(System.Runtime.Serialization.XmlReaderDelegator,System.Xml.XmlDictionaryString[],System.Int32,System.Runtime.Serialization.ExtensionDataObject)
extern void XmlObjectSerializerReadContextComplexJson_GetJsonMemberIndex_m05E217B888BD74F6E817B911F742B6773A7FEF26 (void);
// 0x00000964 System.Boolean System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::TryGetJsonLocalName(System.Runtime.Serialization.XmlReaderDelegator,System.String&)
extern void XmlObjectSerializerReadContextComplexJson_TryGetJsonLocalName_mD6EEF559A324ED2EF2D16E4BB14008593E5E98DA (void);
// 0x00000965 System.String System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::GetJsonMemberName(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_GetJsonMemberName_m90D66B9C6054F89339A8CA92AB35F75E6E18F293 (void);
// 0x00000966 System.Void System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ThrowMissingRequiredMembers(System.Object,System.Xml.XmlDictionaryString[],System.Byte[],System.Byte[])
extern void XmlObjectSerializerReadContextComplexJson_ThrowMissingRequiredMembers_m73D747E0208F694CF63CB106922A66C2A7EC95EA (void);
// 0x00000967 System.Void System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ThrowDuplicateMemberException(System.Object,System.Xml.XmlDictionaryString[],System.Int32)
extern void XmlObjectSerializerReadContextComplexJson_ThrowDuplicateMemberException_m08D759732DDA8BFFE4F7A0188E74386D2C6E20FB (void);
// 0x00000968 System.Boolean System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::IsBitSet(System.Byte[],System.Int32)
extern void XmlObjectSerializerReadContextComplexJson_IsBitSet_m72FDAE03639CB312A8CE7ABE89BA7A69B172E8B5 (void);
// 0x00000969 System.Boolean System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::IsReadingCollectionExtensionData(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_IsReadingCollectionExtensionData_m618285C809989EDDEE00B10C6BFCDE6107CF2425 (void);
// 0x0000096A System.Boolean System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::IsReadingClassExtensionData(System.Runtime.Serialization.XmlReaderDelegator)
extern void XmlObjectSerializerReadContextComplexJson_IsReadingClassExtensionData_mF19A27601537471AE424FCBE6A6FF80A5B65478B (void);
// 0x0000096B System.Runtime.Serialization.XmlReaderDelegator System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::CreateReaderDelegatorForReader(System.Xml.XmlReader)
extern void XmlObjectSerializerReadContextComplexJson_CreateReaderDelegatorForReader_m60124A85A0F7C06FDA26374DEA8B8BFBB3C64644 (void);
// 0x0000096C System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::GetDataContract(System.RuntimeTypeHandle,System.Type)
extern void XmlObjectSerializerReadContextComplexJson_GetDataContract_mC8604C73154004708CF3A5826820ECC6F0B9F49F (void);
// 0x0000096D System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::GetDataContract(System.Int32,System.RuntimeTypeHandle)
extern void XmlObjectSerializerReadContextComplexJson_GetDataContract_mAFF74F11AAFC6086E312F612477E3CD133C930C1 (void);
// 0x0000096E System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson::ResolveDataContractFromRootDataContract(System.Xml.XmlQualifiedName)
extern void XmlObjectSerializerReadContextComplexJson_ResolveDataContractFromRootDataContract_mA2B57FDBA3AA01D47633CC08D9387539AD4D714D (void);
// 0x0000096F System.String System.Runtime.Serialization.Json.XmlObjectSerializerWriteContextComplexJson::TruncateDefaultDataContractNamespace(System.String)
extern void XmlObjectSerializerWriteContextComplexJson_TruncateDefaultDataContractNamespace_mC448B0AE4CE3A780355F1B57B98785F2F793200E (void);
// 0x00000970 System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.XmlObjectSerializerWriteContextComplexJson::GetRevisedItemContract(System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializerWriteContextComplexJson_GetRevisedItemContract_m7C14769A8582010E52D3CE588442909DE79B1C8C (void);
// 0x00000971 System.Runtime.Serialization.DataContract System.Runtime.Serialization.Json.XmlObjectSerializerWriteContextComplexJson::ResolveJsonDataContractFromRootDataContract(System.Runtime.Serialization.XmlObjectSerializerContext,System.Xml.XmlQualifiedName,System.Runtime.Serialization.DataContract)
extern void XmlObjectSerializerWriteContextComplexJson_ResolveJsonDataContractFromRootDataContract_m71FD9B77844636CAB242D498644CB924F455641E (void);
// 0x00000972 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::.ctor(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter__ctor_m0222DA24BAF5BD35FA62BB78EE101E512AE69500 (void);
// 0x00000973 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::.ctor(System.Runtime.Serialization.CollectionDataContract,System.Boolean)
extern void JsonFormatReaderInterpreter__ctor_m3B3A5ABDAC42DBE3EE91F7102B9BD9AD8581DB6A (void);
// 0x00000974 System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadFromJson(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString[])
extern void JsonFormatReaderInterpreter_ReadFromJson_mC988F76CE080FC1DE1EAFEBAF095E278B82D0935 (void);
// 0x00000975 System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadCollectionFromJson(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderInterpreter_ReadCollectionFromJson_m225B84746BAD45B221783BB43EF85D1024AB99B1 (void);
// 0x00000976 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadGetOnlyCollectionFromJson(System.Runtime.Serialization.XmlReaderDelegator,System.Runtime.Serialization.Json.XmlObjectSerializerReadContextComplexJson,System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString,System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderInterpreter_ReadGetOnlyCollectionFromJson_m27A25F3DA314BC665EBE3D2527FD530BB4A92DB0 (void);
// 0x00000977 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::CreateObject(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_CreateObject_m2ABDAD5DECAE5779CC9039F17C0D9EC48765DBE4 (void);
// 0x00000978 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::InvokeOnDeserializing(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_InvokeOnDeserializing_m5C6FCB6131B58E75FB81ED55B62AD9FBC81DDD90 (void);
// 0x00000979 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::InvokeOnDeserialized(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_InvokeOnDeserialized_mCA6B72505E3E4BA909BFCE0B79F397AAC19BAA58 (void);
// 0x0000097A System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::HasFactoryMethod(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_HasFactoryMethod_mF122F074F14A2B2513E72BFA213E0E979EFEE9F2 (void);
// 0x0000097B System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::InvokeFactoryMethod(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_InvokeFactoryMethod_m3BC60765CAAF5AF37079AC99A921945570CACEC7 (void);
// 0x0000097C System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadISerializable(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_ReadISerializable_m22B284EE27F0C336927E3F004E0594C12AFABAEC (void);
// 0x0000097D System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadClass(System.Runtime.Serialization.ClassDataContract)
extern void JsonFormatReaderInterpreter_ReadClass_m56B55EECA1DC9ACF0564D06C31E18881A8B381B8 (void);
// 0x0000097E System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadMembers(System.Runtime.Serialization.ClassDataContract,System.Runtime.Serialization.ExtensionDataObject)
extern void JsonFormatReaderInterpreter_ReadMembers_mE3E4DF680B4570AD3736EFCB079421589A04FF4F (void);
// 0x0000097F System.Int32 System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadMembers(System.Int32,System.Runtime.Serialization.ClassDataContract,System.Runtime.Serialization.BitFlagsGenerator,System.Int32&)
extern void JsonFormatReaderInterpreter_ReadMembers_m5A1DBCDDD5689AD66771C6A36B6D1DDB810A6525 (void);
// 0x00000980 System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::CheckRequiredElements(System.Runtime.Serialization.BitFlagsGenerator,System.Byte[])
extern void JsonFormatReaderInterpreter_CheckRequiredElements_mBB35E4F8DADF7338785FFC00C0F5F6220255B772 (void);
// 0x00000981 System.Int32 System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::SetRequiredElements(System.Runtime.Serialization.ClassDataContract,System.Byte[])
extern void JsonFormatReaderInterpreter_SetRequiredElements_mB34D263AA306399EB9CA426AF481150283E381C1 (void);
// 0x00000982 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::SetExpectedElements(System.Runtime.Serialization.BitFlagsGenerator,System.Int32)
extern void JsonFormatReaderInterpreter_SetExpectedElements_m14EFE26AC7D1EEC5F527735D195F3EC9211CCB9F (void);
// 0x00000983 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ResetExpectedElements(System.Runtime.Serialization.BitFlagsGenerator,System.Int32)
extern void JsonFormatReaderInterpreter_ResetExpectedElements_mFEE3803809D942B1827E1EC4C8D67FE1580AC72D (void);
// 0x00000984 System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadValue(System.Type,System.String)
extern void JsonFormatReaderInterpreter_ReadValue_m2E561FFE42D05453B991D5EEECF8A12EBAA509DE (void);
// 0x00000985 System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::InternalDeserialize(System.Type,System.String)
extern void JsonFormatReaderInterpreter_InternalDeserialize_m318E5EE4880EA46E28D7E15B5408653F01785936 (void);
// 0x00000986 System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::WrapNullableObject(System.Type,System.Object,System.Type,System.Int32)
extern void JsonFormatReaderInterpreter_WrapNullableObject_m3C88608667C5AD77090F0C0FB88DC1747D460821 (void);
// 0x00000987 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadCollection(System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderInterpreter_ReadCollection_m7DFFAE4C8C2E0A8349FE915635C414D4EB3E3B7E (void);
// 0x00000988 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadSimpleDictionary(System.Runtime.Serialization.CollectionDataContract,System.Type)
extern void JsonFormatReaderInterpreter_ReadSimpleDictionary_mBBFEEBFADCD6BEDE713B2343F5CF7623DEF56335 (void);
// 0x00000989 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadGetOnlyCollection(System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderInterpreter_ReadGetOnlyCollection_mCEFE032954306DEDF057A4907A73FC17C57DD1D5 (void);
// 0x0000098A System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::TryReadPrimitiveArray(System.Type,System.Boolean&)
extern void JsonFormatReaderInterpreter_TryReadPrimitiveArray_m1393B0618E0EDFE1429C82AD4B03089BB306C3C1 (void);
// 0x0000098B System.Object System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ReadCollectionItem(System.Runtime.Serialization.CollectionDataContract,System.Type)
extern void JsonFormatReaderInterpreter_ReadCollectionItem_mFE6FB737590592AC1A722B6AE0825DAC46B30EF9 (void);
// 0x0000098C System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::StoreCollectionValue(System.Object,System.Type,System.Object,System.Runtime.Serialization.CollectionDataContract)
extern void JsonFormatReaderInterpreter_StoreCollectionValue_m51CA54DEC022BE98FA8D4639D002BF12E893A7BE (void);
// 0x0000098D System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::HandleUnexpectedItemInCollection(System.Int32&)
extern void JsonFormatReaderInterpreter_HandleUnexpectedItemInCollection_mE8FB20C69166FA59B01AEEA6F81765A60E99E65C (void);
// 0x0000098E System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::IsStartElement(System.Xml.XmlDictionaryString,System.Xml.XmlDictionaryString)
extern void JsonFormatReaderInterpreter_IsStartElement_m122BD53034B61503CD9868D09E2B15BBFF730D22 (void);
// 0x0000098F System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::IsStartElement()
extern void JsonFormatReaderInterpreter_IsStartElement_m994C7347CDA77B7AEF20DB4CF9236A569E01C7AF (void);
// 0x00000990 System.Boolean System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::IsEndElement()
extern void JsonFormatReaderInterpreter_IsEndElement_m4ACD48AAC961A211E74E73F1627956F752559528 (void);
// 0x00000991 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ThrowUnexpectedStateException(System.Xml.XmlNodeType)
extern void JsonFormatReaderInterpreter_ThrowUnexpectedStateException_mE3E3518AD4009DDAB0EDB4A0FA2D20E529093ED3 (void);
// 0x00000992 System.Void System.Runtime.Serialization.Json.JsonFormatReaderInterpreter::ThrowSerializationException(System.String,System.Object[])
extern void JsonFormatReaderInterpreter_ThrowSerializationException_mB5CD7A508ED953E2EAE446CE783DDF631CB9F5F0 (void);
// 0x00000993 System.Void System.Runtime.Serialization.Diagnostics.TraceUtility::Trace(System.Diagnostics.TraceEventType,System.Int32,System.String,System.Runtime.Diagnostics.TraceRecord)
extern void TraceUtility_Trace_m6F966E47EE0ECABFDF5B729E49E9F8AD4ACC03F7 (void);
// 0x00000994 System.Void System.Runtime.Serialization.Diagnostics.TraceUtility::Trace(System.Diagnostics.TraceEventType,System.Int32,System.String,System.Runtime.Diagnostics.TraceRecord,System.Exception)
extern void TraceUtility_Trace_m055DDA8CF63451828191C8ADA392A05418952426 (void);
// 0x00000995 System.Void System.Runtime.Serialization.Diagnostics.TraceUtility::.cctor()
extern void TraceUtility__cctor_m05F3720E1020896ED589CFB4D28E776440D14928 (void);
// 0x00000996 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::ReaderQuotaExceededIsEnabled()
extern void TD_ReaderQuotaExceededIsEnabled_m0A8046964C4EC32C05B6D77AF32BF29D0870CBAE (void);
// 0x00000997 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::ReaderQuotaExceeded(System.String)
extern void TD_ReaderQuotaExceeded_m6067AAA1D27BFE5B493EE5420EE1EA6A71497538 (void);
// 0x00000998 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCDeserializeWithSurrogateStartIsEnabled()
extern void TD_DCDeserializeWithSurrogateStartIsEnabled_m082A707D702A00A70A60B11B5E9D060BAEC0F6AA (void);
// 0x00000999 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCDeserializeWithSurrogateStart(System.String)
extern void TD_DCDeserializeWithSurrogateStart_m90A760EAD6B4964EE0D6E1190EC5EDE051F40C3D (void);
// 0x0000099A System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCDeserializeWithSurrogateStopIsEnabled()
extern void TD_DCDeserializeWithSurrogateStopIsEnabled_m46277B8CE26D7CCA516EFCCB872E2CC894B7C6A5 (void);
// 0x0000099B System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCDeserializeWithSurrogateStop()
extern void TD_DCDeserializeWithSurrogateStop_m84C102B4E0745BF6116A4B76C1FA3A7938C56D8A (void);
// 0x0000099C System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::ImportKnownTypesStartIsEnabled()
extern void TD_ImportKnownTypesStartIsEnabled_m7FB8E8E0F5CEAAD415C702632A05972E18DF9A76 (void);
// 0x0000099D System.Void System.Runtime.Serialization.Diagnostics.Application.TD::ImportKnownTypesStart()
extern void TD_ImportKnownTypesStart_m4B9C6F129422BA7C91BA9F9CCD55050F3EBA4205 (void);
// 0x0000099E System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::ImportKnownTypesStopIsEnabled()
extern void TD_ImportKnownTypesStopIsEnabled_m609360DC76351075A9A9A67E120D01363E71D637 (void);
// 0x0000099F System.Void System.Runtime.Serialization.Diagnostics.Application.TD::ImportKnownTypesStop()
extern void TD_ImportKnownTypesStop_m9E457405D857FF249B77C2E82AE055809399566D (void);
// 0x000009A0 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCResolverResolveIsEnabled()
extern void TD_DCResolverResolveIsEnabled_mA594BDA76F874A82CFD7EED8BBDFF57EBE8198DD (void);
// 0x000009A1 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCResolverResolve(System.String)
extern void TD_DCResolverResolve_m1506172A442EF553AEBB8F8B94892B84CA6F4A57 (void);
// 0x000009A2 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCGenReaderStartIsEnabled()
extern void TD_DCGenReaderStartIsEnabled_m4CAA1D5BD10C12CA13A36209687DAE530D068AAE (void);
// 0x000009A3 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCGenReaderStart(System.String,System.String)
extern void TD_DCGenReaderStart_m1206B935E37799C77C96EDB75D86F62439663AA4 (void);
// 0x000009A4 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCGenReaderStopIsEnabled()
extern void TD_DCGenReaderStopIsEnabled_mA6B75A7192D3AF25F80C8466D8137D960C3CABBD (void);
// 0x000009A5 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCGenReaderStop()
extern void TD_DCGenReaderStop_mD2D403F60D15D7F2C3F3E19DC92F1ADB8FD7F8D9 (void);
// 0x000009A6 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCJsonGenReaderStartIsEnabled()
extern void TD_DCJsonGenReaderStartIsEnabled_m4CFA5ABF9CE848E1B7E25372CE80A75C9F37967E (void);
// 0x000009A7 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCJsonGenReaderStart(System.String,System.String)
extern void TD_DCJsonGenReaderStart_mA0B80BAAAE2F97B0E17196F73C16082C1E49DF03 (void);
// 0x000009A8 System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::DCJsonGenReaderStopIsEnabled()
extern void TD_DCJsonGenReaderStopIsEnabled_m6BB34F91C03FCD1EDA3670F1F8429EC2478FB00B (void);
// 0x000009A9 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::DCJsonGenReaderStop()
extern void TD_DCJsonGenReaderStop_m863CE464317D7C2942B048248BCDC2809D78F656 (void);
// 0x000009AA System.Void System.Runtime.Serialization.Diagnostics.Application.TD::CreateEventDescriptors()
extern void TD_CreateEventDescriptors_mF1EDD6DE59A790098718CE7991A5036A2837ED46 (void);
// 0x000009AB System.Void System.Runtime.Serialization.Diagnostics.Application.TD::EnsureEventDescriptors()
extern void TD_EnsureEventDescriptors_mA8856CD6B58C2C7F8935970819D855990AFB41A0 (void);
// 0x000009AC System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::IsEtwEventEnabled(System.Int32)
extern void TD_IsEtwEventEnabled_m91707199E84DB7356D401D935E96AAC943B60BD0 (void);
// 0x000009AD System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::WriteEtwEvent(System.Int32,System.Runtime.Diagnostics.EventTraceActivity,System.String,System.String)
extern void TD_WriteEtwEvent_mE6054960D2BF50ECDCC3550B12E3F5C6DA97534A (void);
// 0x000009AE System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::WriteEtwEvent(System.Int32,System.Runtime.Diagnostics.EventTraceActivity,System.String)
extern void TD_WriteEtwEvent_m5F115E0434F9E0BCDA24EE6CF9683CA462577F56 (void);
// 0x000009AF System.Boolean System.Runtime.Serialization.Diagnostics.Application.TD::WriteEtwEvent(System.Int32,System.Runtime.Diagnostics.EventTraceActivity,System.String,System.String,System.String)
extern void TD_WriteEtwEvent_m4D037EF8CC4D439A6309D957719E2CE125299913 (void);
// 0x000009B0 System.Void System.Runtime.Serialization.Diagnostics.Application.TD::.cctor()
extern void TD__cctor_m2F5A05FD6D70705130B47F11BCD9FD1187B03A80 (void);
static Il2CppMethodPointer s_methodPointers[2480] = 
{
	NULL,
	NULL,
	NULL,
	BooleanArrayHelperWithDictionaryString_ReadArray_m26AC51B1FD9B838F50C7FE3EDE044D95AE9B0DF2,
	BooleanArrayHelperWithDictionaryString__ctor_m33069EE3D60E3B0F39A3840C65EADF7532BF9C37,
	BooleanArrayHelperWithDictionaryString__cctor_mC3F239A037F7127862CADD32B7EFC9B02AD0ACAA,
	Int32ArrayHelperWithDictionaryString_ReadArray_mF61A206C6CDCF3ECB1425E069554E600434B9792,
	Int32ArrayHelperWithDictionaryString__ctor_mAE1001338D5F50D5CB1CEF55DEBBCBCD33015056,
	Int32ArrayHelperWithDictionaryString__cctor_mA223CEE851C08872B47FF9D5134741DDD8B2A766,
	Int64ArrayHelperWithDictionaryString_ReadArray_mD4E56F5CE2C7D05112EB36471A70D36C3A077DD5,
	Int64ArrayHelperWithDictionaryString__ctor_m3F1ADF49433BC0A9101DE81F044B8CA543BE0F15,
	Int64ArrayHelperWithDictionaryString__cctor_mC9A90B5AF35E64DCED886DA4BEF52FBA85415535,
	SingleArrayHelperWithDictionaryString_ReadArray_mE2BDB6B4CD8ACB377C4E60FFFD681A8A506C6A6F,
	SingleArrayHelperWithDictionaryString__ctor_mB535940165C39976B93C1A15CD387BA43E430860,
	SingleArrayHelperWithDictionaryString__cctor_m1DF8B1BBEC0E74EA73FF6FAFBE468A642B5926C9,
	DoubleArrayHelperWithDictionaryString_ReadArray_m4189BD9311A409C4EC2E0D7CC7969A7402B9C166,
	DoubleArrayHelperWithDictionaryString__ctor_m0F7582B2F9C5F1F56450F2D0B74B921695F47912,
	DoubleArrayHelperWithDictionaryString__cctor_m2B448A4F17C277EB892ECD6A8D9A510BD8E6991D,
	DecimalArrayHelperWithDictionaryString_ReadArray_m33DF1C6CBA34B3DCB6E90BCC505E1B077EA81F78,
	DecimalArrayHelperWithDictionaryString__ctor_mD61892DE83B455C4539258D73CEFFEE2BAD18F61,
	DecimalArrayHelperWithDictionaryString__cctor_m14A5E9949B0429826C0F2C3991AFC5562ED792B2,
	DateTimeArrayHelperWithDictionaryString_ReadArray_mB27C8338F8F4E32B5B227699FAC0AC000E5C509D,
	DateTimeArrayHelperWithDictionaryString__ctor_m03F6B0C1D7EF35CEAD694AAB2BE363B4D3270E0E,
	DateTimeArrayHelperWithDictionaryString__cctor_m82273079E650CDB72DBFD2203860C6CB8FD8DBD1,
	EncodingStreamWrapper__ctor_m69BFB0B372D850771D5642F2B28670276F44C7EA,
	EncodingStreamWrapper_SetReadDocumentEncoding_m584A704F25FCEE64E7413C5DB98FF4901139DC6D,
	EncodingStreamWrapper_GetEncoding_m7BC513B52DBAC0D5251E3F0EF8F2FD03C0806C90,
	EncodingStreamWrapper_GetEncodingName_mAA6E4CDD6CC05492407BC82D10E824D079CC6162,
	EncodingStreamWrapper_GetSupportedEncoding_mF62637209A7257DA3EBC1C3DF8E199E992C19425,
	EncodingStreamWrapper_ReadBOMEncoding_mD2CEB2E6763AB4F9B0D9E9CADB5160C6A25A7A50,
	EncodingStreamWrapper_ReadBOMEncoding_m49410D4763F2083048302533D40EE416ADF4BEFA,
	EncodingStreamWrapper_FillBuffer_mB7AC1008BB751163CBF0B3C2E34A084FC65B9126,
	EncodingStreamWrapper_EnsureBuffers_mDCB1AC2EE463756726EBDEF05C8CD1543528F629,
	EncodingStreamWrapper_EnsureByteBuffer_mE8D64EBA62A1301DDF61FE35D138F2D24C6A4264,
	EncodingStreamWrapper_CheckUTF8DeclarationEncoding_mC46BCA9EC98AE81CC45A0E6FE50ED6B6BF29250E,
	EncodingStreamWrapper_CompareCaseInsensitive_mC994883B7ACBB0328A525881837D35DE52BE064E,
	EncodingStreamWrapper_Compare_mA0FDF745579F2443672C452C5AAA05C16628F489,
	EncodingStreamWrapper_IsWhitespace_mBFCC377AA35A50995FFC1BDDC79E6DB8C2A5E74C,
	EncodingStreamWrapper_ThrowExpectedEncodingMismatch_mF09F05586AED86130B7C6DE4C056B81131491CB2,
	EncodingStreamWrapper_ThrowEncodingMismatch_mD660972193FFE64D98233709D2643DF5B9E5D0A7,
	EncodingStreamWrapper_ThrowEncodingMismatch_m5115FCE5BEBCF008B8EBF2ABACE296A5D8E227D8,
	EncodingStreamWrapper_get_CanRead_m40E1D3B9AB5087FBD675D555A61264797E22A4BA,
	EncodingStreamWrapper_get_CanSeek_mDA06B11F044C0C68BF56A456DA9E73D5F9E6E6CB,
	EncodingStreamWrapper_get_CanWrite_mEB548CE93185ACB6501CA22042700AE3736D6507,
	EncodingStreamWrapper_get_Position_mD1CBF1DFDEE1A100C0004751A26B1119A720F8C9,
	EncodingStreamWrapper_set_Position_m2B4CCEA543C4DE9AE47A8BFC496FB2D149397B62,
	EncodingStreamWrapper_Close_m464DCFE28B8279C3E115EB7EB2B164709445AAC3,
	EncodingStreamWrapper_Flush_m4776C25FD540A67A6C928FA3A0477E002942A7DA,
	EncodingStreamWrapper_ReadByte_m974CFBB46709773F176671A73F87E19F0761290F,
	EncodingStreamWrapper_Read_m5CF8D5557299EB4BD6438C43E8545F30A0E94CA4,
	EncodingStreamWrapper_CleanupCharBreak_mF892CB119A1126D94C6826FA1C516FF34B627C47,
	EncodingStreamWrapper_Seek_mD28CA138AEF63E0DB37174402286A20DB78EE6FF,
	EncodingStreamWrapper_WriteByte_m7E594627D586CED07AFE02926DA5BC876107D976,
	EncodingStreamWrapper_Write_mC83D9CB91021E68A8F6FB1C8BCA33E67EF26DE71,
	EncodingStreamWrapper_get_CanTimeout_m11A9C4F9365452949C39F4FD65D355EED2E6EC68,
	EncodingStreamWrapper_get_Length_m1F220847DE8CA657BC776F11D929B7132E8B4112,
	EncodingStreamWrapper_get_ReadTimeout_m54947FEFBD6C5BD7846323CCF702F5963452BF79,
	EncodingStreamWrapper_set_ReadTimeout_m072660233E58B62B7ECD20E5CC753CE25A124941,
	EncodingStreamWrapper_get_WriteTimeout_m4BE2AE6CFD4A572AF056C9A0F5182C6F72839223,
	EncodingStreamWrapper_set_WriteTimeout_m06472100B6546F3464FC269C7D35DF260D50CAAB,
	EncodingStreamWrapper_SetLength_mE1E7F37C79E8E469BB7B5ED0F1C531E76B807066,
	EncodingStreamWrapper__cctor_m4CF63091FD89AE7C24C8AC74943C09804EC00256,
	NULL,
	PrefixHandle__ctor_m9F17653A857DB8100700BD09E1D14742841A6510,
	PrefixHandle_SetValue_m405028A9E53FB2D4E87FDB759D32C4D47C279490,
	PrefixHandle_SetValue_m1D14B2BC5B6FCA2C077D324F363FEB8B67E3C60D,
	PrefixHandle_SetValue_m110EC52337EBF807F854EB6B81C12075D53B47A8,
	PrefixHandle_get_IsEmpty_mB031BAFB2F3FB8A8673A0EC0263CAB99D8EBF2E7,
	PrefixHandle_get_IsXmlns_mFB8174A14A11FCA061185B57E5DC3599F5A932B1,
	PrefixHandle_get_IsXml_mF9676C9F083B30F19C81E7369B0D59622FA3B32A,
	PrefixHandle_TryGetShortPrefix_m1FDF4904A709EC4048F49C77044D5BFE2901B96A,
	PrefixHandle_GetString_m707C5C3842631CAAB16BF2E545F24350504CE51A,
	PrefixHandle_GetAlphaPrefix_mD5B580DAE3F131AD3D6B4DF0048E37153D33B81A,
	PrefixHandle_GetString_mDCD7482FF0176CE85F0E0193E0E708994374E25B,
	PrefixHandle_GetString_m6FF9590CE327ADA02D0F0673705054C66E11A5FB,
	PrefixHandle_GetString_m9072D56B8E44C5A4DE2AA156DA75472B9325FC92,
	PrefixHandle_GetString_m00079CF15D414936E8CE6867F3E6FCEA92AD6D77,
	PrefixHandle_CompareTo_m09521F2E60A338DB056FA4C5F9A7D6B84E4EB7A8,
	PrefixHandle_Equals2_m764A7F64212802BA9A8A5BDEB81428B38872E37A,
	PrefixHandle_Equals2_m0E5E81FE14C81F41C441DEB4F6A2D80E23042994,
	PrefixHandle_Equals2_mE5C13AD9FFDC44FEA1349FD4162EC8B67BD26C31,
	PrefixHandle_op_Equality_mD2969E7287DD678C229CD21D0A552E4478C1EEF9,
	PrefixHandle_op_Equality_mDEE5F0BB72FB13C346665386B832DFCA1C5804E8,
	PrefixHandle_op_Equality_mAA77AEC7710772FDCE7DAE8E96FC9146EE4AE9E0,
	PrefixHandle_Equals_mB931D5BD29A96E827BEF5B9323526DC4CDA0DD0A,
	PrefixHandle_ToString_m4689D517FBF2DB68A41D1A9F25CC1EB442D6CED9,
	PrefixHandle_GetHashCode_mA2D611E7F9C20302C157399FC8137D714A157C79,
	PrefixHandle__cctor_m8DA6CAC4640BC958A5DC844F3070737C7E963FE8,
	StringHandle__ctor_mDE97B7A6217B44FD2573205B644CE9A24E420A84,
	StringHandle_SetValue_mCBA3A46D8DDA5A6CC121DA66D7BD75EA98B316E8,
	StringHandle_SetConstantValue_m454D7BA581FAFAFD3114898D60849D42371DFA85,
	StringHandle_SetValue_m802803727082C68C0C40A8505F699A59238F918B,
	StringHandle_SetValue_mB6E4F034BC09A533CAFFF1C14CB54AA46E953778,
	StringHandle_get_IsEmpty_m553233D784A7125C73260D258182B89709B9EDC9,
	StringHandle_get_IsXmlns_m660949D26AC182877F06D3935C4E9B038481BC5D,
	StringHandle_ToPrefixHandle_mBCBAA2E52225D1E4A438485F16A6546B4731DD0F,
	StringHandle_GetString_m95A2ABA786D3D3EF229B8CB61AA3D0E4EA640299,
	StringHandle_GetString_m4CBF4A1BF6DFA1FA15205E33F7A6FB0CE6D75C34,
	StringHandle_GetString_mFF4D54EBB24E91B7DC236ABA49FC3B4853F5B940,
	StringHandle_ToString_mE850A963374D8C2135AEC5A36C9E47032146727C,
	StringHandle_Equals2_m765636B91010EE6D914EE11E32EE77195DA73FF4,
	StringHandle_Equals2_m07763F818662CDB54F2EFD5E82D2A468A08A63AF,
	StringHandle_Equals2_m8B4A5B0C5DB0DC0DBE983A56A48DCF1BE37A880F,
	StringHandle_Equals2_m5600E177912550762308D4ED3811866E132624DD,
	StringHandle_Equals2_mCDE5597F6C90C1E7224EFA410867379812617EE5,
	StringHandle_op_Equality_m61E3C94F5701D2E2C2A6F68FE34A8240ED8674EC,
	StringHandle_op_Equality_m2024941945F1E2162BF419554F313A63C57748AF,
	StringHandle_op_Inequality_mDF90628E59F219816ED9DA5B6FA7768466EF0447,
	StringHandle_op_Equality_m0D56AFB3EE5BD92D1A91AC4F7B7797B97A40F583,
	StringHandle_CompareTo_mC04397EF0821B364B15C47E12B35B8BFDAC86A17,
	StringHandle_Equals_mE6EBF84A3DF8E9FC34EF142F45EE10AC7539AE2B,
	StringHandle_GetHashCode_mF20795DE3342C0565F05B99D99F7AD9D19F8A5A2,
	StringHandle__cctor_mB834487733CA9285BF7E2748623971236FE03464,
	UniqueId__ctor_m886CA3FD85A18088143B2940819D540A06782622,
	UniqueId__ctor_mBF4FAD5CA8AEB23CE686C1879F2A3B2FB9ACE600,
	UniqueId_get_CharArrayLength_m1E206BF698096EB61058DC4895105A3A20A16187,
	UniqueId_UnsafeDecode_mF61CB8D67C0EC3A2A4B4A5F2C53EF6B326CD6631,
	UniqueId_UnsafeEncode_m3520B6A366F594FC46EF67EF2FC8EB815A82F6CD,
	UniqueId_get_IsGuid_m0FDA658ACB8FBEF9530D588474FBD429AF93A55A,
	UniqueId_UnsafeParse_m055742AD013BB3BE4046942227BC716EE1085B15,
	UniqueId_ToCharArray_mC8665EBAE036B8519D4C55C80AB50415ADF3FE38,
	UniqueId_ToString_mD2ACE4CCB2F55A872D39EA847EC73CBCC0A77274,
	UniqueId_op_Equality_m25F4CBB4DB5FE72A49E727116FF8C95C0425890C,
	UniqueId_Equals_m5B6FA8978449B0996D25075C113612346C8039EC,
	UniqueId_GetHashCode_m84E07067446D9C50DD3312C26C2E70A9DC86D232,
	UniqueId_UnsafeGetInt64_m2DFBDF726D2BB2505B004185EA3A016327591452,
	UniqueId_UnsafeGetInt32_m2E7232530828E965560ED26C62D9CB015C8E1CD5,
	UniqueId_UnsafeSetInt64_mAF2E1188C17D8617AC738CCB8A1D0D1F32DFC232,
	UniqueId_UnsafeSetInt32_m41EBF7129D9345B868912116D840704318B4B5D6,
	UniqueId__cctor_mF512E2CFAD256FF2D0E31A54BF2845DB17B9391E,
	ValueHandle__ctor_mAD8231FAFF5D4DC76A9E0EC09DCB7F23A2AB8159,
	ValueHandle_get_Base64Encoding_m372C49738E26305D63B7C04751FB70F1880E4C3D,
	ValueHandle_SetConstantValue_m96F1A888C46454EFA762FFD1681AD4B6DE828CF8,
	ValueHandle_SetValue_m356A8BDA96D10DABBDEF5D5DB0893CF0DE34FF60,
	ValueHandle_SetDictionaryValue_mACAD6AB51EC46D49571993C792CA009BD6C526F6,
	ValueHandle_SetCharValue_mAA94C0908502C2471C6AE69E99B9DA59ADEB2998,
	ValueHandle_SetQNameValue_mF29FAF7C971F8712F050DCAC764C9291F5BEA123,
	ValueHandle_SetValue_mF2B1AE8F642E915422D2720AE9FE803199B490DC,
	ValueHandle_IsWhitespace_m2A76785471E48705B3E222E55D50054C34BBA4F3,
	ValueHandle_ToType_m1A4E656088980A95D6EC720A786F1656669206FF,
	ValueHandle_ToBoolean_mA990A6A9C114D768D603CEECA71A45DE6079213B,
	ValueHandle_ToInt_m704A8FC5077954C0AAF362F02F2E48CECDCE0494,
	ValueHandle_ToLong_mBD2363E63BC67188A6C834A52C1F31480970B3CE,
	ValueHandle_ToULong_mD71E568F1CD897B8ED8A10E277B6BB35A2EF6E1F,
	ValueHandle_ToSingle_mC22BA59930D584C633D8D5D82D3657CCBFEAE08F,
	ValueHandle_ToDouble_mB259752241D5F61CC399A1C81B1539EFA1DA70CB,
	ValueHandle_ToDecimal_m10C964F454FC9FF4EB27B7976A0A4FB7030259A9,
	ValueHandle_ToDateTime_m2A48FC176F0B4E8608929456BFE54A30768FBFB0,
	ValueHandle_ToUniqueId_m3E004FDEE456D420718B07A659950524B88A8CD1,
	ValueHandle_ToTimeSpan_mF991840664966EDA7D570EF9F8232CF711B5773D,
	ValueHandle_ToGuid_mC32890FEF8418AB07925EF0F945261D69BC590FD,
	ValueHandle_ToString_m0F4CC35B1A7A9FCDF4AC91153556C97C1EF8FE04,
	ValueHandle_ToByteArray_mA469EC9E08C564CAF908E7B5AD6AE0958FD970BB,
	ValueHandle_GetString_mF7091CAFD37C487CCDD77780F4FE18703262CA4F,
	ValueHandle_Equals2_m36B1CBEF9063168019AB827055BF8CB726546443,
	ValueHandle_Sign_m4CF0265044FBCF863B4C3FEE0F81EE35B4512598,
	ValueHandle_ToList_m515BF8A7C1937168F1FAFC06EB47C48E879B50D5,
	ValueHandle_ToObject_m2B291F7278E104EF72AF84052159C0C0496EC43C,
	ValueHandle_TryReadBase64_m521B0B213C6571C1653476F3F21D3106D2818575,
	ValueHandle_TryReadChars_m2ADD2B702FBB2D914B6D12621BC2CC6CF721DBDE,
	ValueHandle_TryReadUnicodeChars_mAF5C09321FD757DB0D06112A90F635037ED2F9F0,
	ValueHandle_TryGetByteArrayLength_mB3D0ACDC3CC15D78E77C80DCF7AAB8924A25330B,
	ValueHandle_GetCharsText_m1A986DB4003EC211AAA7317559FBC9526CFBA623,
	ValueHandle_GetUnicodeCharsText_mA9EAD91EC02802BC6B4A0E252ED877C751242FE7,
	ValueHandle_GetEscapedCharsText_m788CAB2DE923930DB4DAC222A4ACE79121884E79,
	ValueHandle_GetCharText_m45341A1276C01BCBDA3EA984CB34FF25FF78BD61,
	ValueHandle_GetChar_m0C9FB6819351D919AF6BB7569EE30FFFE01DC066,
	ValueHandle_GetInt8_mF08095855C8E7C52039787026E76D82319D05F1B,
	ValueHandle_GetInt16_m7062162DB994E19F82B4E066D32D8E54F22A8ECA,
	ValueHandle_GetInt32_m919F4B53BEAFF48C11FE18021547EED9F0825874,
	ValueHandle_GetInt64_m7ACE2532869A0046298109BEF75F2B8DBD7FCF40,
	ValueHandle_GetUInt64_m58C0F0B93EA26621AE6A3F1853A9D977D312D3D4,
	ValueHandle_GetSingle_m5995EB4362146798FA63BF5134C1E3CB28DAF37C,
	ValueHandle_GetDouble_m695617D79319AE93A566DDE885FB24C956AB3A47,
	ValueHandle_GetDecimal_m77261DD408FE5371267EEBCA80E06F5890D37590,
	ValueHandle_GetUniqueId_m1D6F13C05710AC43A55510980B03D081E0FBFB42,
	ValueHandle_GetGuid_m86D893B84979361977DD1CFBD8265207DF8A957B,
	ValueHandle_GetBase64_m38CCDAA9D4EA7922C432C9C585837864C116B058,
	ValueHandle_GetDictionaryString_m93E8286073B86561A550D91D5D472EC78B5C9E5C,
	ValueHandle_GetQNameDictionaryText_m052B0ABF6008DC43E18A0B271BA40100A89F72A6,
	ValueHandle__cctor_mE40A64F092B3D01F97D9C99AF008C64DA4786EEB,
	XmlBaseReader__ctor_mE29E82F290BFD039B9057F2C57775AD90F309A79,
	XmlBaseReader_get_BinHexEncoding_m620A0A7921E315B69073E23936C5934533237C02,
	XmlBaseReader_get_Base64Encoding_mF917B0BF359D5B7ECBF7EAA97C4C0D66326EAB4D,
	XmlBaseReader_get_BufferReader_m92B09A265A7CB4B97DEE0CAF53D111F488780BFA,
	XmlBaseReader_get_Quotas_m17CB2856E9380A6D928B80B39D4742FE5A6E214D,
	XmlBaseReader_get_Node_mB1796DF90267696B3952E50816728DE9E3B75319,
	XmlBaseReader_MoveToNode_m50C5F7663F9A5CA06FE8E87A60A9575B6384D1D3,
	XmlBaseReader_MoveToInitial_mF7FB58BCC6BAF3BD2DD1C568CEB8159009598839,
	XmlBaseReader_MoveToDeclaration_m5C33F84DF26864C8217152FB86BBE5ECD0CDF9C7,
	XmlBaseReader_CheckStandalone_mF2642E0842737C83167ADDE62AA81BCC8BF4B5BD,
	XmlBaseReader_CheckDeclAttribute_mFB835BAB36BDB55B0F34AB15D45968B5D94BDFCD,
	XmlBaseReader_MoveToComment_m775806AA4C6692EAC8F185FEEBF6BBB17A136AF6,
	XmlBaseReader_MoveToCData_mD9B0493F16E139B83F3D4698CD107ED42D59B8AD,
	XmlBaseReader_MoveToAtomicText_m3DDEAB54FD32B2D2A477DA76159D4EB5E79E8FA7,
	XmlBaseReader_MoveToComplexText_m7CC28853D739C5F20FABDED89F60A94FB945DCFA,
	XmlBaseReader_MoveToWhitespaceText_m61A276025A7344F5C8D5DC80042246B8ED24AB1D,
	XmlBaseReader_get_ElementNode_mAA432C55978B3DD21EF182655559E257528F0BA3,
	XmlBaseReader_MoveToEndElement_m6C8FE7FCFEF032404B5BC13921E274A0ADA7674C,
	XmlBaseReader_MoveToEndOfFile_m7ED872B60EC0D9B314D2E9A91B56317A2B239B61,
	XmlBaseReader_EnterScope_m9896064455A22C212855BEE696095C9EAACF6FE7,
	XmlBaseReader_ExitScope_m4BD40F3305D4ACEAC1554AA34C1421EE472E6E01,
	XmlBaseReader_AddAttribute_mBFDFB2AA7E80B736BC920DE9B4AD66202EE05D9F,
	XmlBaseReader_AddNamespace_mA1B422AFF9D9F857E7547AFEA6CC0D7889A0F639,
	XmlBaseReader_AddAttribute_m920516731EFBF60395C8202C5730751C70CBC646,
	XmlBaseReader_AddXmlAttribute_m2414BEB88038F4AEB32C8E589B475CC2DAED6A5F,
	XmlBaseReader_AddXmlnsAttribute_mB4AE3256F8A17F853A22E25351EC7FDDB5A27048,
	XmlBaseReader_FixXmlAttribute_m19C8C7ACE466C4318C64AFD5C5C75AFD039A1931,
	XmlBaseReader_get_OutsideRootElement_m5B68A6DF2B1E4D46F0E5F5FE2A05EBE4DE4A0C2A,
	XmlBaseReader_get_CanReadValueChunk_mD16BA6D3B6E669ADEE20495DF59863706C141612,
	XmlBaseReader_get_BaseURI_m7FEBBFBC7CA0AB8C9AA8397CAB5FE14AD157ACCD,
	XmlBaseReader_get_IsDefault_mEE181B5B6C4036188239CBC4E5905C6AF6F8812B,
	XmlBaseReader_get_AttributeCount_mFD9FF79D1E0CFDB4E3D0CB4C6AE0A48767CCF1BF,
	XmlBaseReader_Close_mBBEAD1B07A63C2F346C6CDE00CC233C0B57A4056,
	XmlBaseReader_get_Depth_mA8CD78BB8DF3C9282187002121C196EBB8EE5E45,
	XmlBaseReader_get_EOF_mB0208C6123123A6C1F6AAC36BC55663ACBABDA53,
	XmlBaseReader_GetAttributeNode_mBDC181C8DBC6255345051B8163C848D7A390177A,
	XmlBaseReader_GetAttributeNode_m8792CF2B025DAEFD6E222CA76E7C083527F89636,
	XmlBaseReader_GetAttributeNode_m2ED3B85D68FF7920F1D4F617D10F167B56DD3CBC,
	XmlBaseReader_GetAttribute_m82D6D1838383DB930D0C52D01DAEFE2817DFAB7A,
	XmlBaseReader_GetAttribute_m5481F734FEB51B5C67033342D2CBE6B55B3CC8B8,
	XmlBaseReader_GetAttribute_m939E0E67302D54C605A0DDE9CE45431DF03B2C2B,
	XmlBaseReader_get_IsEmptyElement_m649B777553B6CE32F1BB71BBCE9E7DF86D1CCA70,
	XmlBaseReader_get_LocalName_mEBD48190382F41AEA75DA80BB2C64D1D762F948F,
	XmlBaseReader_LookupNamespace_m1945C9B7E0B81B9C23489EBF142F6230B27D6A3C,
	XmlBaseReader_LookupNamespace_mA81AF7919E1CE9138AE69624A5C0CB5FB70D0DF9,
	XmlBaseReader_ProcessAttributes_m6A1F209E7DEBD286F887DC5CEDABF25F57EEB1C8,
	XmlBaseReader_ProcessAttributes_m916535993745D7238F84905B09D6E669349186ED,
	XmlBaseReader_CheckAttributes_m04AFAC1C099FEF5813B1F98C6F9B6FA99F2A2B80,
	XmlBaseReader_MoveToAttribute_mDEF0BFC3B49CD80305990B6C246F9E616AEE474C,
	XmlBaseReader_MoveToAttribute_mCF5E85077C0F22F913A6640958BA6F18D3104941,
	XmlBaseReader_MoveToAttribute_mD6F29CAB8846F078C4DFD50E338554B26BC1BEC5,
	XmlBaseReader_MoveToElement_m02F2A956851F7269DA58B30CD9E821500063FFF9,
	XmlBaseReader_MoveToContent_m01130CAC1EEDB1B71EB70B9158DCEF0F1408E716,
	XmlBaseReader_MoveToFirstAttribute_m688844B9998D75C759FC57663DF1688E8C42A252,
	XmlBaseReader_MoveToNextAttribute_mBF84DB160F107164606A5E118D4461268D1C5EB3,
	XmlBaseReader_get_NamespaceURI_m3F8B00FD7B7C52D3EE5ECFF3541B3728D0ED729F,
	XmlBaseReader_get_NameTable_m934015804D97E6B16F6E39B7329D8B23EB6D286C,
	XmlBaseReader_get_NodeType_mA2AC013A05ADCC16F573E209CB5EB244DEBA5978,
	XmlBaseReader_get_Prefix_mE4BD88D4D4537643009EB63B3D65F7D9AF3EED3E,
	XmlBaseReader_get_QuoteChar_m7D5425CB6B792C3BD2F9E61EC05D1410C69065A7,
	XmlBaseReader_GetLocalName_mEF109F256CF95A98B9F717100F0EBAD1255083D8,
	XmlBaseReader_GetNamespaceUri_m85F9D77458C78D7627941C0BD821F6B8A747D4AF,
	XmlBaseReader_IsLocalName_m67B87169729E211E1DF05CA6CEB38DC1874C59AA,
	XmlBaseReader_IsLocalName_mB7BEB63C067476C1DA734560CF38E67C25A6BA39,
	XmlBaseReader_IsNamespaceUri_mCE4FE8DDFF7D2DAE4845BF24FB912AE2EDC22779,
	XmlBaseReader_IsNamespaceUri_mB9195D13D21C5C56C68C2BE8EB17AB94B91E4D22,
	XmlBaseReader_IsStartElement_m2DEBA2F4B0193C22ABBB2C4CD47D2182CA53FAA8,
	XmlBaseReader_IsStartElement_m6F25CA517E9B5EC5827D304490F8753669731CF7,
	XmlBaseReader_IsStartElement_m4F632D958CB1F72DC5F6CDAC701B62C0EB19B20E,
	XmlBaseReader_IndexOfLocalName_mBE76DB33F2267A99FF5DA7D781609155CF66F9DF,
	XmlBaseReader_ReadValueChunk_m5ACECAE7F6F0AB4E48691083DF17B03536C074D3,
	XmlBaseReader_ReadElementContentAsString_m0C3511D4C5201A98A5279CCA241368B33DB07348,
	XmlBaseReader_ReadElementString_m280B5ADDD913150662B536081ECE78C591DDD52F,
	XmlBaseReader_ReadStartElement_m3717AB44BFA2F5476B63972283F5A4A1DE56039C,
	XmlBaseReader_ReadEndElement_m84E9EE0533BF911BC26A428563E3C0BC594F50AC,
	XmlBaseReader_ReadAttributeValue_m72999AAF833FD92104884309706ACB583D499A3A,
	XmlBaseReader_get_ReadState_mB0087C20D92F30B2C394826CA3D62DCC6D907A06,
	XmlBaseReader_SkipValue_m6664D12DA10C03BDA1DAB1DDA5D6E6620EBCE41D,
	XmlBaseReader_TryGetBase64ContentLength_m7DA7F41E2E7214082369EC6FE5A8B0ED504F8FBF,
	XmlBaseReader_ReadContentAsBase64_mF67C3818025B6F1CBAC790ACC67D0CE5D9B779A0,
	XmlBaseReader_ReadContentAsBase64_m04E8E1ED6D3F9CFEC6A9A83CADC2C9B90506F7E5,
	XmlBaseReader_ReadContentAsBinHex_mC95BE7788121DE7A128667861695E88CDAAB83F3,
	XmlBaseReader_ReadBytes_m7EB745B00749346BFB21AB79988B9101E318D897,
	XmlBaseReader_ReadContentAsString_m332383D98865CF85E580EC37368DB7153DCB3FC4,
	XmlBaseReader_ReadContentAsBoolean_m4140218FD8B9A93E0DE1C026602CF74AE98E5CF7,
	XmlBaseReader_ReadContentAsLong_m903C86BEE4FBE4100B36CFCE0CE5C53F9F7A0F8E,
	XmlBaseReader_ReadContentAsInt_m1417043783FE216EA2760F52BEF564ECDA6D334C,
	XmlBaseReader_ReadContentAsDateTime_m535CE1C81FEAD0D04668D4E617DEE4C9933F0D6A,
	XmlBaseReader_ReadContentAsDouble_mCB089AF200C498A0649706A45327DD37B12DBB63,
	XmlBaseReader_ReadContentAsFloat_m66B042AB1BCED9C98D5F846EB7E1D378772F72AB,
	XmlBaseReader_ReadContentAsDecimal_m6CBE99F887BD3F3B7019985115F507BBD838F057,
	XmlBaseReader_ReadContentAsUniqueId_mF0D066B6547B0712A70CD53DC018F32FA08C3F7A,
	XmlBaseReader_ReadContentAsTimeSpan_m0B777A7DF9D92619955E3E4710566667755AF68F,
	XmlBaseReader_ReadContentAsGuid_m4B28CFD313EFFEACE548EAA43091B32FB4496944,
	XmlBaseReader_ReadContentAsObject_mE0FDD0E6D430ABE6710F1053BC0E911B2317447B,
	XmlBaseReader_ReadContentAs_mECB09CBBB3C353F017C5972445676CBA117C32B9,
	XmlBaseReader_ResolveEntity_m36838D59634511B59F28D6D9A2CAB74E6756ABF3,
	XmlBaseReader_Skip_mE0E025FE83C5B1514551269BA0C54529E8C172B0,
	XmlBaseReader_get_Value_mCFF8D1E75706D3A22330A9B05A9C60CF3B75780D,
	XmlBaseReader_get_ValueType_mE7BB327E97FAD2A6541956B32B48645BE2C32BEA,
	XmlBaseReader_get_XmlLang_mBFFFCC5C91E534E8DB1F4D73221F99A664CA016D,
	XmlBaseReader_get_XmlSpace_m116916C6CF0B9C090308B2583C4027DD606A96F8,
	XmlBaseReader_GetOpenElements_mF6C93E199919490F0C93B2202490BF983DF2289D,
	XmlBaseReader_GetCharBuffer_m6386405D12B00EB50E6C3B6F36D485F43402F180,
	XmlBaseReader_SignStartElement_m894080D504BB32CC4350DCEB4E31FD5B683EC43E,
	XmlBaseReader_SignAttribute_mDC919012695F0AF7E6F3B725520A715A2D735FFF,
	XmlBaseReader_SignEndElement_m8A478C17732BF31A0A747D5CD460459D7E70A1A4,
	XmlBaseReader_SignNode_m51F29EB50D3758506D0BCBA15CA03749940D5594,
	XmlBaseReader_SignNode_m2D742E5E792A4F5E0CAFF35F0C4DA5C631E323A3,
	XmlBaseReader__cctor_m4F35DF6636EBF3C52B238FF27C181D9B636D0A10,
	XmlNode__ctor_m5B8080EEEBD08AB3917C1754DAB9E74251C1E01D,
	XmlNode_get_ReadState_mD71DCD394E57B1415D2F0E98763845884357F5C5,
	XmlNode_get_LocalName_mA4DCB272267C72DD38207BAFC5283855E211E71C,
	XmlNode_get_Prefix_m7067995DD22B79394BCE76D18472D9EE0704554B,
	XmlNode_get_CanGetAttribute_mE26FBB9492E5A0611CDD788BE2121EFD0722C5E7,
	XmlNode_get_CanMoveToElement_m1237E934CA3693C3F876A0E8ADD57D981A1BC834,
	XmlNode_get_AttributeText_mB8780DC3D6C2454D4A2284B8585B8C73B06791EE,
	XmlNode_get_SkipValue_mD05A023477207B91A5F4FC553264C4C55EE5735A,
	XmlNode_get_Value_mBF80142EA81DA543907FFA2F75A4C9BC31D4900B,
	XmlNode_get_DepthDelta_mAD0ADCF996B887C0066484650679002DF5550850,
	XmlNode_get_HasContent_mE7DD57C4D3356FDB57EF92ED4A4AB87E036CAF23,
	XmlNode_get_NodeType_mD8FE4E387A3A852615DBCA96163E2D79F99D5CB5,
	XmlNode_set_NodeType_m71D8A3822934CAE66E1C5F4A8845C3831E868BEB,
	XmlNode_get_QNameType_m9ACF53395F5E64D80FE98155E970A594A538D6C0,
	XmlNode_set_QNameType_m374D456BAE763334D3684E9A8B53E5EFE561FB09,
	XmlNode_get_Namespace_m10F4E4A7A28A8E1437EB943709604C445F1D78A0,
	XmlNode_set_Namespace_m89CD2263936C38E35F7D52CE69E6F0E6DD816CCA,
	XmlNode_get_IsAtomicValue_mD13343EC9B59F53B4693A3E90FDE00831E72AFD5,
	XmlNode_set_IsAtomicValue_m507380030EBBFA9B85D81E9EBFAA905C6D722B9C,
	XmlNode_get_ExitScope_m6F3017359F00BE2FD9F8C568109E5F930BFB495B,
	XmlNode_set_ExitScope_m6BC46F117B5B3AB4E938E2136CD3799659C18DCF,
	XmlNode_get_IsEmptyElement_m5DEF8DF856EA49F368515D14D0E082E765DCAB14,
	XmlNode_set_IsEmptyElement_m1B3C83C3537061144062D1D1D6FED46A695696F3,
	XmlNode_get_QuoteChar_mF43D4EEBD21A69C99F70C72417EB92A1B4F3183E,
	XmlNode_set_QuoteChar_m0FBFB8981AA7E5773FEA15A931D9440C7DCA6DD4,
	XmlNode_IsLocalName_m57ACF68173DF734A4F2648AF383E9559078FFC7A,
	XmlNode_IsLocalName_m20EB45E1F59E5E8018E8DECB90179184B84D2ABB,
	XmlNode_IsNamespaceUri_mB96025A53A83F87683E641422038C08AE84E034D,
	XmlNode_IsNamespaceUri_mB396955ECC7A0EED810FDF5CCE13C38B8FDD7EAD,
	XmlNode_IsLocalNameAndNamespaceUri_m70BBD0F9F2F6EA45C5E89F0D4FB0D735005936E5,
	XmlNode_IsPrefixAndLocalName_m6F691625A6322BEFCAB4DA6795F6138F1362B957,
	XmlNode_get_ValueAsString_mB2C10FF7C67065C0C6AEB8FB4844D28BD3166013,
	XmlElementNode__ctor_mDBEA3CEAE1B973396D0EEACA2E5766ABD2482191,
	XmlElementNode__ctor_m57438F324430B5BF715E8AE9A2F1C7C47E36869B,
	XmlElementNode_get_EndElement_mEE2161A2188D93FD1B83F0A80264C9FA7A479076,
	XmlElementNode_get_BufferOffset_mB2E0525858D5783007F7B00EC2360117AB2B802A,
	XmlElementNode_set_BufferOffset_m08F4D4E76823BD5A1AFF903512105D69516366F7,
	XmlAttributeNode__ctor_m059B03E371BF74D999B6D2BE12A05799EB897720,
	XmlAttributeNode__ctor_m8D8F27B6496DAFC763ED1F3F2895FE699C1FF3BE,
	XmlEndElementNode__ctor_m2796F9CBB127069098CE7EE3695914F00A2D1E86,
	XmlTextNode__ctor_m9CA567587003012D2DDAF081B24FE0442CA58126,
	XmlAtomicTextNode__ctor_m7CA9FA40A5E686ABDE8E02BD35A8B09E542FD86E,
	XmlComplexTextNode__ctor_m70346868068DD5E55FB220A7E6D31CA1AE8DA90A,
	XmlWhitespaceTextNode__ctor_m2892230BE7292A6C371E4E2EB48A52A965FCD1E3,
	XmlCDataNode__ctor_m1B17D0C4EB63BC7611DA023F0F0A8FE8AD315027,
	XmlAttributeTextNode__ctor_m49F1F00673430F4976BCB61426D330DADADE7286,
	XmlInitialNode__ctor_m46E06ECA120CA4133F77494F701E9B82142274FD,
	XmlDeclarationNode__ctor_m5D9D8F84058CD91D3E1DF69928A638CCC961B755,
	XmlCommentNode__ctor_mAC2703EA61639F984DE3B78C94B9860FB5A6951B,
	XmlEndOfFileNode__ctor_m1F92B739E8E1E1BEB6093C2B128971109B52973A,
	XmlClosedNode__ctor_m533542F67BE24F5AAF1C682CD33DE9AAEDEAC436,
	AttributeSorter_Sort_m52A4018C7203468D226AEFB0468D6183D0D31F7A,
	AttributeSorter_GetIndeces_mE8B46583937B6E3BE125DC3AB76CFDC0FF55D95E,
	AttributeSorter_Close_m48ED81CA7277A9A388BF0C09F71A2FB9C9C0CEE8,
	AttributeSorter_Sort_m4F19B0B91AE3A9FD35A16E39B2812E87E28C69CE,
	AttributeSorter_IsSorted_mE6DF0523D320923367C50A1352B0C72141695101,
	AttributeSorter_Compare_mBDF728D2A2706CA2613646E6D785E4E4A119F018,
	AttributeSorter_CompareQNameType_m3C0C5757FAC34F2E6F60CBE57D54E1008B7A17DA,
	AttributeSorter__ctor_m0FD1D080C36CDA78F73ACA559DAE6483EC3BF94E,
	NamespaceManager__ctor_m885C0E7A4BCA3C7286A7BDD9C60B76E0EF43CA1D,
	NamespaceManager_Close_m43231CA35BE81DE59897B95C73D86B93ACA708A0,
	NamespaceManager_get_XmlNamespace_m669A702DDACF3F2E2AEF4DF103865EE7052B4AD5,
	NamespaceManager_get_EmptyNamespace_m9F2767A5C65A92E028C527323770D0ECCDBD088B,
	NamespaceManager_get_XmlLang_mAD664DE74F6B5353FF30A3FA8BA800209C6D6688,
	NamespaceManager_get_XmlSpace_m551110613D13EDEB66E8358287A3D483388B320F,
	NamespaceManager_Clear_m9EDAB3CE4F090806ECF5FB198A518912A2E6EC32,
	NamespaceManager_EnterScope_m6B498EF465485244DBB88C228F534E96454976F6,
	NamespaceManager_ExitScope_mE31F7E76C94EFA1A3BF41CB87723D7055F197926,
	NamespaceManager_AddLangAttribute_m48C1565782F98409BA726EE503C10E7BE4AD0A9E,
	NamespaceManager_AddSpaceAttribute_m1F0D06BF2C83FEE1D4BFCE79711AD54F94A376E3,
	NamespaceManager_AddAttribute_mF431D9DA43BAD677524B87076D279C47E6EA9E86,
	NamespaceManager_Register_m3AD994FEC67ECE39A769D8CFFDB2FCE277A8C353,
	NamespaceManager_AddNamespace_m537ED8B1BA0595C095854BC09D456EDD81663ADB,
	NamespaceManager_LookupNamespace_m613FFBC40C0F82802EF6BFFE92FFC8ACF4B33B9A,
	NamespaceManager_LookupNamespace_m8E4DC5E5707C2D308EF6C2837A6A32CAE09FB6BC,
	NamespaceManager_LookupNamespace_m6C50536B497D395740C94498645705FC3BCCBE9B,
	NamespaceManager_TryGetShortPrefix_m4C3C3923B941C8720AC40EB6C30524392048B4B9,
	NamespaceManager__cctor_m913371041F3D34A0BA4A7F07CCEA35FC1D99FB13,
	XmlAttribute__ctor_mA187A0BBCB2DBE692FABADD0C6D0E2177F5980BB,
	XmlAttribute_get_Depth_m2D7D56BE4E96E7C593A0ED4B81A173F2D4A16D94,
	XmlAttribute_set_Depth_m3F6B97F84CF0ACE2B27A11856A31CC5945D9C9B1,
	XmlAttribute_get_XmlLang_m0F1C77BD62394591A8F5CD30AD14BDDCEC18DB23,
	XmlAttribute_set_XmlLang_m94F3F01A8593EA97CC01430C48BF80B4FCFBD453,
	XmlAttribute_get_XmlSpace_mEE25097FCF1846423533725FFC2A76F38B9062CA,
	XmlAttribute_set_XmlSpace_mF91942C8AF081D8A8E627E58B074806D43E5C82B,
	Namespace__ctor_m9CF67CBD79F889F89F3ED6B7CC943EA3D0F4DEB3,
	Namespace_Clear_mAAB8979F724CDEA3BED5E73553F27FC794E73198,
	Namespace_get_Depth_mB4374D15E2A7D5FA2231ACB77A7D6F1156D7ADE6,
	Namespace_set_Depth_mC619153A63D25C7F404166ADD56C3C1B95DBD5F1,
	Namespace_get_Prefix_mA769918911319F2BE19889DC528575D522CE33EC,
	Namespace_IsUri_m3C46C66F712D44FA402E35B42A2ECB930FA44237,
	Namespace_IsUri_m9BBA94343288B77072F10B8ADC5531FF2C62729D,
	Namespace_get_Uri_m87D0210E40FFE742FA268ABE74BCB7AD15FEEE20,
	Namespace_get_OuterUri_mC501BD8B02DAA5EFF4CBED9151B464B51F4958B2,
	Namespace_set_OuterUri_m43C1655777E0C2C61CDFEE384B1A3B2CFF0B668F,
	QuotaNameTable__ctor_m7D2498054D2F3B564F85748F225C4CEFD08FFA58,
	QuotaNameTable_Get_mE4214160C0918438524699B1DD9AB7157AE84441,
	QuotaNameTable_Get_m12256B09B56E573DAD819B283E9825F2CE46B9C0,
	QuotaNameTable_Add_m4B91F07E98529F31E15092F0A910B8FFAED9E4DE,
	QuotaNameTable_Add_m5B190B7BA1A526EE639F5D4538540E87B5F4CA8E,
	QuotaNameTable_Add_mD7DFE10F9D38B029909B459D23099E87B4955C7F,
	XmlBinaryReaderSession_TryLookup_m787FB2DE6AF6AA471892E86BB1BBB2E67FE6A1A8,
	XmlBufferReader__ctor_m9EB77E390101608C9B477CCCC5FF9C4D6F1A91AC,
	XmlBufferReader__ctor_mE618914A053EE5F3B464D0055FA161816FA964E8,
	XmlBufferReader_get_Empty_m832B2B4E712A7E463109534CD4E989ECDEF7C279,
	XmlBufferReader_get_Buffer_mB32BD829069AF069FDCB0CCB1AD529DAED18E81C,
	XmlBufferReader_get_IsStreamed_m38A1CF2C17CA4893AAEBA524D0B0F5F717C70D3A,
	XmlBufferReader_SetBuffer_m883A22CEA5DFCDD04F2969B0F4A4D4105FE83948,
	XmlBufferReader_SetBuffer_m21DEDF371817426BD60E7F04EB3401401E306117,
	XmlBufferReader_Close_mB88AAEC827180BCBC93743CA1FB7F580EE95D3D6,
	XmlBufferReader_get_EndOfFile_mFD06EEBC10D8FB02379957B55D40FF828225C7F3,
	XmlBufferReader_GetByte_m1ADE8591788E8C7F6DD191710BC6CF52A342395B,
	XmlBufferReader_SkipByte_mBC6BF43391E55A8ACC88D99074E1037468EDB451,
	XmlBufferReader_GetByteHard_mC8D4B64944608B46A7833526788E66CCBE298926,
	XmlBufferReader_GetBuffer_mCB41B785954DFC4BAF050876FFDB7D3734E2D28F,
	XmlBufferReader_GetBuffer_m9596467F2402ED1D68733AC97049AE6441730EA9,
	XmlBufferReader_GetBuffer_m791A75F75E8F164B581E3D8E97A260107822DA8B,
	XmlBufferReader_GetBufferHard_m59C748233C300A4A96A6BA108DAB1553C5BFB402,
	XmlBufferReader_EnsureByte_m57AE11F2C521FA5A84420124CEC7B1950A67C106,
	XmlBufferReader_TryEnsureByte_m3DAAD44BEB6FA875C9E4F3E62E2D165DFEBA6E63,
	XmlBufferReader_EnsureBytes_m7ED528EE62021598F931E85A1A57B24ECAE6E667,
	XmlBufferReader_TryEnsureBytes_mBA2FC98382D52AD353119746F792F695F89FD590,
	XmlBufferReader_Advance_m27717A43FFF12A15277B063938BD527368DA150B,
	XmlBufferReader_SetWindow_m5E622E24BD5C0D2481695072DF936FE2674E6B21,
	XmlBufferReader_get_Offset_m988B3C7EAB8EA101C6F84DF3FA478E5EE5951AA7,
	XmlBufferReader_set_Offset_m51900647465BEEED94F3BC14B9DDBCD6DF8D90F9,
	XmlBufferReader_ReadBytes_m29C550071AF959CD115683A4A292C43A77932379,
	XmlBufferReader_ReadMultiByteUInt31_m6428FD3BC61882415D8509A2980D62B8A2BDDF0D,
	XmlBufferReader_ReadUInt8_mECFF347CB626172CEB0D999323095C6E9C0E8C59,
	XmlBufferReader_ReadUInt16_m1B7ABAB8BFE13E96F5B88EB9BF0930A0DDCB3148,
	XmlBufferReader_ReadInt32_m41DE9DC4208F80173AA909455C97B79807DABAFF,
	XmlBufferReader_ReadUInt31_m4DE8DF14BE15FEDD826473D186E632B4D50CA0DE,
	XmlBufferReader_GetCharBuffer_mDDF51E8D1FFF0E8A3695B5AFB597F06A8CCDA97D,
	XmlBufferReader_GetChars_m902B7AA72D2E9CD9D58CCA459D72083FD3F491CA,
	XmlBufferReader_GetChars_mB06FEEBED01A9882FE43911E8C6BF9B8B3B54F53,
	XmlBufferReader_GetString_m2FC1C286AE1C1EE228462C91DF5FC412A27F2CF4,
	XmlBufferReader_GetUnicodeString_m0FAFBA9D9E696E86B2C6EF3B339B38B8B72A5C02,
	XmlBufferReader_GetString_mB489E7D6E985E870068DF0C95C14EA790FE39693,
	XmlBufferReader_GetEscapedChars_mBAE3C00395FD0FFF24852DA205681DC7648BFFD6,
	XmlBufferReader_IsAttrChar_m10742C6A2ACA77B2B1D44A5A7A8CB9FE7FCEB6CA,
	XmlBufferReader_GetEscapedString_m22395D83CC92B584A9E1D35267F9BBD019B0E0F8,
	XmlBufferReader_GetEscapedString_mC524551F9998A577A8DD51C1429207F58F26AE93,
	XmlBufferReader_GetLessThanCharEntity_m1DE4237A1399EBEE60566682AFD7A020FBB2FF80,
	XmlBufferReader_GetGreaterThanCharEntity_mAE06AA2E77AB2EC88148D2F6B7A578518E39F4CB,
	XmlBufferReader_GetQuoteCharEntity_m3489FC2BF1C247B32A609CCD72B890BE1EABDF3C,
	XmlBufferReader_GetAmpersandCharEntity_m9A8915B60653EE7109AC2BF4DBC1AFEF3B13A68B,
	XmlBufferReader_GetApostropheCharEntity_mBBC2B45E797EC24C22DE8BD094AA2BCE3B813950,
	XmlBufferReader_GetDecimalCharEntity_m1C10BF993708F62C5BB1DFA52FD914ADED3C0B8A,
	XmlBufferReader_GetHexCharEntity_m8B67950E2756FEEA59B6B8959D838C24E34D403D,
	XmlBufferReader_GetCharEntity_m67402A805BE6EF81F6D52395D66DC9EF37693A69,
	XmlBufferReader_IsWhitespaceKey_m93159ACFFA277C2148C51A64402F9C8CD13859FC,
	XmlBufferReader_IsWhitespaceUTF8_m8FF0B9883B0C0C89DF8FAC54BF7BBFEFBAA6244C,
	XmlBufferReader_IsWhitespaceUnicode_m9DF630DB7D9C3299D435DA991148AD10615B8464,
	XmlBufferReader_Equals2_m25877650EBA88DF5F1555E6A31A29CF7B65AEFDC,
	XmlBufferReader_Equals2_m2C69294F1B41D281E5C0ACA1A604F1D30D878F04,
	XmlBufferReader_Equals2_m61E17500C814481A408FE6CDF14FDAF9D6980698,
	XmlBufferReader_Equals2_m1896A0E5E69B566E3C98A3918C1B897D0933D1F0,
	XmlBufferReader_Equals2_m3321637DEEB129F87828A062C1AD71866B35A357,
	XmlBufferReader_Equals2_mC27BF722E298E9E97A11E4BA08CAEFD9EA124846,
	XmlBufferReader_Compare_m2D2EF59FDF1FF2282C53C5712005B420E25A6A07,
	XmlBufferReader_GetByte_m3BA3C199782D75B97C837E6DE3060E9755E45638,
	XmlBufferReader_GetInt8_m393D325AB0437BB3B2A94BAC2B473BF430D55AD3,
	XmlBufferReader_GetInt16_mD59F82C30A9A3143D16A2E370A1C89D8BEBF8FD9,
	XmlBufferReader_GetInt32_mE9849BB1EC22E5E19C134F4E9F065413AB04EF0A,
	XmlBufferReader_GetInt64_m2FDBB9FB699ECBAAED3D7FF8813ABF6F140ECA4C,
	XmlBufferReader_GetUInt64_mF07504843F1D5F41A7B7BF1B518501BA40C0D33A,
	XmlBufferReader_GetSingle_m464D07A40695A242FA14E9B57610D99A44801925,
	XmlBufferReader_GetDouble_mB24556397299E8A07B17DE16A71FD5CB0046D963,
	XmlBufferReader_GetDecimal_mAA7C999EE70293471E177EA368F9C6733A1EE150,
	XmlBufferReader_GetUniqueId_m871269B20107C168092976A2A4AFA8A39F6C7759,
	XmlBufferReader_GetGuid_mCEF297FBD3DAF553732177D676B36BA32BA4C977,
	XmlBufferReader_GetBase64_m54015A054D2F2078D86CA5C704267DCC43B27D46,
	XmlBufferReader_GetNodeType_m433A78BF192D8E43986133A6140D105D11B56AD9,
	XmlBufferReader_SkipNodeType_mA4E6DE90F48D5375762F1311CBD28B4D9D2BD483,
	XmlBufferReader_GetList_m8086C513B3CB8E08FE8853F4737920D54B4BAAB8,
	XmlBufferReader_GetDictionaryString_m186636F2747A6B432AB3289BBFDE3CB6091ECFCE,
	XmlBufferReader_ReadDictionaryKey_mCE90FD66FDCF51C73703B9E3347CB729E321C368,
	XmlBufferReader_ReadValue_mF62B3AF2C72257A9004C50EB0205A8393251D973,
	XmlBufferReader_ReadValue_m8CAD70557F7EA9BB46BC7C91904AA77A69DB5290,
	XmlBufferReader_ReadUnicodeValue_m84456625B652F1BC302968BE4CA875BE94A7F01A,
	XmlBufferReader_ReadList_m7E74F0F45F702FC66382FE481F4516F5A8CBFD2A,
	XmlBufferReader_ReadQName_m7883A52F995F9D219FB748770BA95F2A37BC4BB9,
	XmlBufferReader_GetRows_m220BD73053EF5950062A14F05723E8A93EE79290,
	XmlBufferReader__cctor_m84D169D696E5EEDADCF5C7C287DC9FA680828F4E,
	XmlCanonicalWriter_Flush_mA7DB15FF6D0D7A7C83F34569F4B079B7611170B8,
	XmlCanonicalWriter_Close_m545BBBF4CD870A7FAF540DBDC447A39610094004,
	XmlCanonicalWriter_WriteDeclaration_m611907368C146441D9EC32C591E4843786BEC010,
	XmlCanonicalWriter_WriteComment_m68599B6CC4A86EF54B29B91FFAF8FDA987D9AB68,
	XmlCanonicalWriter_StartElement_mDDFEDE2DFC093EF9A9B0E1DECD6E6C31EF4EB95B,
	XmlCanonicalWriter_EndElement_m0B88A13CD36C345CA332CFD747F085542AA3AF8D,
	XmlCanonicalWriter_WriteStartElement_mCCF807E3BCBDE8B0CB107BDE767E1E43C47ECCD1,
	XmlCanonicalWriter_IsInclusivePrefix_m11EFCD47F0E5EE2AACFC0395908A8394C04DF5A3,
	XmlCanonicalWriter_WriteEndStartElement_m9162FB8A594D8400A2EB240CFC40E6319E778D2A,
	XmlCanonicalWriter_WriteEndElement_mB1A988E12299CEBC0888ECEDF9438F99DF5D4442,
	XmlCanonicalWriter_EnsureXmlnsBuffer_m26DC20981E73199F119CBD175E1A6B1E1A99AD01,
	XmlCanonicalWriter_WriteXmlnsAttribute_m7EC772F1A36376C6A9E82F8FC701133F8E051AC0,
	XmlCanonicalWriter_WriteStartAttribute_m668F3C40EB1FD934BDC49CD71A59E92F6C51D276,
	XmlCanonicalWriter_WriteEndAttribute_m16E55CBC6A14BC715EC5C490B3F3D9A7BCB6B22E,
	XmlCanonicalWriter_WriteCharEntity_m217D2F24591C33B58508073C997E6F250B67CFA1,
	XmlCanonicalWriter_WriteEscapedText_m74BAA54875E657A8E2180E86F3D1B5E172F953E1,
	XmlCanonicalWriter_WriteEscapedText_mDC72396933B0ADA14486EC36670822407BAD1354,
	XmlCanonicalWriter_WriteEscapedText_m0CD88F98FB1D52DFD58F84AD7F98D09F06CE9AD2,
	XmlCanonicalWriter_WriteText_m28BA5D90E6247961179F98E7200778AF44802A2D,
	XmlCanonicalWriter_WriteText_mD2429BDF62A8825D0164D1E6F46E86A151ABC492,
	XmlCanonicalWriter_WriteText_m5F6463E5DC109BDC55BD0FFDC2F217ADF644B670,
	XmlCanonicalWriter_WriteText_mF1AD81765E746842DF1911D19F89956E401274E7,
	XmlCanonicalWriter_ThrowIfClosed_mE96AF3DA68DF57C202185A47FFE816E34E36F433,
	XmlCanonicalWriter_ThrowClosed_m6833597C1B6C41B9BF3434B49AD7AC41819B7708,
	XmlCanonicalWriter_WriteXmlnsAttribute_m67665521973E004745C24DC1360AD16700D7A100,
	XmlCanonicalWriter_SortAttributes_mE4BC62222324086EFBB2688C90B2C603B888818E,
	XmlCanonicalWriter_AddAttribute_m8E4E915220AF7886BCE7BB0B63319DB8F9C2EDF2,
	XmlCanonicalWriter_AddXmlnsAttribute_mE862C0B435A11A3AF79F40FE7C89944061F40BA6,
	XmlCanonicalWriter_ResolvePrefix_m3FB98ECE5D6D8017595DBD5EBEDB9BCFACE7C79C,
	XmlCanonicalWriter_ResolvePrefix_m5D9CCD5EBA30ECACEC817CFB8E04AD01A8945BF7,
	XmlCanonicalWriter_ResolvePrefixes_m5081AB877ED568BF93C130B740AEE6DB56B1F61E,
	XmlCanonicalWriter_Compare_m3F3307E36DCCAC31BB60D49C2EA993DA20571F1F,
	XmlCanonicalWriter_Compare_m22EB7156AD61365EF530801A8427B76F337953D4,
	XmlCanonicalWriter_Compare_m57E74320549D321EBC016B9D6922CAC9AD85BC91,
	XmlCanonicalWriter_Compare_m53622C0208DA0E8063A07305F520100C750F0267,
	XmlCanonicalWriter_Equals_m9320D7340C3736023DC2E926983C9A8653FCD0CA,
	XmlCanonicalWriter__cctor_m2F5B83408EB082378E7B01EA0B667002F1226659,
	AttributeSorter__ctor_mB8587264A3284B3DF5523A6AA0284B8CBA0BE6A0,
	AttributeSorter_Sort_mC8C7CE57FA636C9DA3238696397D2E467C33AA96,
	AttributeSorter_Compare_mA9EA5CEBD7F0BEB64900197995134116DDD32A4B,
	XmlConverter_get_Base64Encoding_mBA0C13FD6E888644CBB27A21459E08F5770F5D4C,
	XmlConverter_get_UTF8Encoding_mF2244DA6C1B4485397B14B49C6E3BB8C135DE5ED,
	XmlConverter_get_UnicodeEncoding_m46209129C86A552F16EDA2D87C344A5062C817BF,
	XmlConverter_ToBoolean_mE9AE6E78428700AF7AC1406003C07B42CA7541A4,
	XmlConverter_ToBoolean_mFCDC25D8E3CF222EFCD19A80B36D0F16FCDBA93F,
	XmlConverter_ToInt32_mFFEEB51B8CFE70EAB2CA85522C1B289FB253AFA8,
	XmlConverter_ToInt32_m12B2B91A0D3727BE883B9A6B865EF8C2FE9FC680,
	XmlConverter_ToInt64_m36399DE24F4D697DE8C9B098396A63FC0A5D7416,
	XmlConverter_ToInt64_m6E2AAFB8EE90CDBFC1D26137F8E1161F2234365C,
	XmlConverter_ToSingle_m5D56139487026923BA88B2DDB01AA7BFA126E2A9,
	XmlConverter_ToSingle_m93A141334C40D5EB45EC722903B4889477DF72CF,
	XmlConverter_ToDouble_mE95C50FC0C3060AB3A762647B7CE3A4DB8B77727,
	XmlConverter_ToDouble_m8D5C04612CF408114898B95F0343FEC000A2058A,
	XmlConverter_ToDecimal_mA65B4259AED46C116691FBB8FCA935C6CC731BE6,
	XmlConverter_ToDecimal_m518C3767757D3D5607EAAE7B821B631865B6F90F,
	XmlConverter_ToDateTime_m81AB1612885E06EBE3412A04C9409EB42C8673F1,
	XmlConverter_ToDateTime_m4062BBC29003718C5BFD51B881622B9833EFD800,
	XmlConverter_ToDateTime_m2BAECA489504FB11F7514840EDBF28F45D5A0E33,
	XmlConverter_ToUniqueId_mB2AC4D5D75EFF9B09C69CDA43824D59559D06944,
	XmlConverter_ToUniqueId_m783D8FDE090E5BE2D589C4E48FC9FA44370CB603,
	XmlConverter_ToTimeSpan_m1DDC216C96E4BAB9B0FE8E1D2CF0449672A6400F,
	XmlConverter_ToTimeSpan_mECB46F078F57A6A23D19241E6C0FFD42B034645B,
	XmlConverter_ToGuid_mD1D198FB36C5BEB6ECB43F2E8D80EB1EDAC58F77,
	XmlConverter_ToGuid_m587B92DEB7BC6C607F6DB6E2930698A7C9E74591,
	XmlConverter_ToUInt64_m4D7024367AF853E1AF71D7695B6B05E13AD5FCBE,
	XmlConverter_ToUInt64_mEF5091DCB3B14A486BC9046D26AE0D7B47990984,
	XmlConverter_ToString_m7A44A92A3100BF31F87FA0C26A474B1B0EDCFEB6,
	XmlConverter_ToStringUnicode_mAC5D9BB533BF1CABD62BBE092E5426172585A623,
	XmlConverter_ToBytes_m1953DE59A2A82EF03F11D36D9CDF484F37346F4D,
	XmlConverter_ToChars_mDC8FC1B62411443907CA61E93D0900AB7273C33A,
	XmlConverter_ToString_m1433F7A935C7E548BA2D46C9385081081706C913,
	XmlConverter_ToString_m9332F121A42474A8C85093D4A9A3C4035AEDC19D,
	XmlConverter_ToString_m6FE866D0EFBF066F58062513CA33F16620D59AAD,
	XmlConverter_ToString_mFCB26021B2998C1847DCA938CDC8F3F0B9466942,
	XmlConverter_ToString_mEB0A94B676E1E8E9C265FC69194463D9440820B8,
	XmlConverter_ToString_m34BD76A5AC24B95F44236747DB3897BC3EEC28F8,
	XmlConverter_ToString_m59FEA065E8AF08706E83E25AD58E2ECB51A26552,
	XmlConverter_ToString_mF9F53B24599B02261A1FB21F25AD5C5684B4D28E,
	XmlConverter_ToString_m08A96685B703799BCA9A9C0B0574B6D92EBA064E,
	XmlConverter_ToString_m20356067F814B0D8595AE157CAAFDCC7B8DE0C79,
	XmlConverter_ToString_m0CCF6AA294A94216CA45CC2B64F835D81071D9BF,
	XmlConverter_ToString_m6633088E3C4BC8FCF5EB04C27749FEAA35DEEFBD,
	XmlConverter_ToString_m5077778BA9F74BF2633C7F5E943DBCD1C7443D80,
	XmlConverter_TryParseInt32_m5D01AA22682052CE632C3A6B163C2D3CB37496F1,
	XmlConverter_TryParseInt64_mB88800CD694A70C6F91211E0AF79B0DCC63EE4BE,
	XmlConverter_TryParseSingle_m2CBA17D516011E19A3168BBE5EBE64027008617D,
	XmlConverter_TryParseDouble_m0B657D2110FE6FC658354AA2343C5CFE7983144C,
	XmlConverter_ToInt32D2_m0C5B72210261E5BEFAB613AF89E7690FAC2C33D9,
	XmlConverter_ToInt32D4_mB7C2D7DAAF85723EE779C9D6F24B734E1850153A,
	XmlConverter_ToInt32D7_m335587E7675C1778B655EA7189330B8C38CA74BA,
	XmlConverter_TryParseDateTime_mBD69384077B13D27153A34E4BD0825C20E36FE80,
	XmlConverter_ToCharsR_mBB0F3685A99DB3020322C4FD52C54E21F3B38812,
	XmlConverter_ToChars_m925863EBC9E92EE8990EA6D9870C8338ACE525D2,
	XmlConverter_ToCharsR_m8144097C125B7F665B2CC5B2A94C66D0903D42EF,
	XmlConverter_ToChars_m72FA25B17203E5A0259729D7B467D031FABAE970,
	XmlConverter_IsNegativeZero_m923D3535F752421E6B6CC6F31E04384C8EA67326,
	XmlConverter_IsNegativeZero_mF2314BD43EE278FC3CBEA74C1757A263AEE8F2AD,
	XmlConverter_ToInfinity_m3A59377C8B6A8F8CC4BC974A539A9F68659F2AB2,
	XmlConverter_ToZero_mBCF3D69E2A4AEF8677446444B0D1844E138925DA,
	XmlConverter_ToChars_mD23C14B220D2947B3E3C9C32EE3B8D99B16B3C10,
	XmlConverter_ToChars_m63CA34D52B7682B5941E0895E6E94586618C5878,
	XmlConverter_ToChars_m4044F229E0B0FFBD7AEED08100B89695D0FD72A7,
	XmlConverter_ToChars_m14E932AF515C5D28220638360495DD5D7954161A,
	XmlConverter_ToAsciiChars_m37F512B5677C6FDF85B3616FCD097F49E284DD76,
	XmlConverter_ToCharsD2_m3DCEE867D85821B5A1E5E96A37C3C5517F88B1F4,
	XmlConverter_ToCharsD4_m6988851616847416E4F11EE7825D2A2A5A28F0A5,
	XmlConverter_ToCharsD7_m8C0A463B177582BB51F5F357072F09934A7673D3,
	XmlConverter_ToChars_mFC8C32C543B09D6A15162283F187A46310489251,
	XmlConverter_IsWhitespace_m4A87F7A30154747765687793A9E7D80918BBCA7E,
	XmlConverter_IsWhitespace_m012B47B3A9311728564D81C0310240D371D55E37,
	XmlConverter_StripWhitespace_m5A9A0830141974A95DF18F06D83E8758D032B405,
	XmlConverter_Trim_m37C261E6906910DB27ED04169A1A5AC9631A86E1,
	XmlConverter__cctor_m5108058988FCC1BEF8A57669FD70AC933CAA2E63,
	XmlDictionary__ctor_m80149ADA3E27CEB5020314BE104C8EC6E8E316FE,
	XmlDictionary__ctor_m73092DA3FFF9A794AED84013880357EE5B7C78C7,
	XmlDictionary_Add_m58F151BCF05F610278077EF479D28261FF2E4FC0,
	XmlDictionary_TryLookup_mD75EDA354C38466FE4BA3CDB24BC588932086D2A,
	OnXmlDictionaryReaderClose__ctor_mD3DA44CCD35D157D284B57F9C6FE904704C4630E,
	OnXmlDictionaryReaderClose_Invoke_m46D04A3210933F0E11318BE66952BB2E6AB00853,
	XmlDictionaryReader_CreateDictionaryReader_m18E876ACE129BAC911EF670483A6B3DB82C49889,
	XmlDictionaryReader_CreateTextReader_m1A71893F5FB45663233EE3C323D1C2A7734EC29F,
	XmlDictionaryReader_CreateTextReader_m99103BD84597F25404013DE4239DBCE6C48B462B,
	XmlDictionaryReader_get_Quotas_m56BC45C5DF654AEFBA290C5BA7ECBE58E12200E2,
	XmlDictionaryReader_MoveToStartElement_m46608243963F296EF0A06ACAEE363831F1039181,
	XmlDictionaryReader_IsLocalName_m69D8C62E52587B8B4406DF241853C7813F306760,
	XmlDictionaryReader_IsLocalName_mA3E8F8F860559FE47A1C44E469EE003A88D3F674,
	XmlDictionaryReader_IsNamespaceUri_mC4D76CBDF93A05AB69BBEBA79E16DBCDFB2CE75D,
	XmlDictionaryReader_IsNamespaceUri_m6641C4C8C0FB6B3D610F28D6FCE796A797DEDB26,
	XmlDictionaryReader_IsStartElement_mED109CB6A5050B97E0AF6F985923056FC2AF23F5,
	XmlDictionaryReader_IndexOfLocalName_mFDA2182B6FBA5884CD957A148455F8C4559FA5E1,
	XmlDictionaryReader_TryGetBase64ContentLength_m463D0E3366F9ABBED10380B8DE1FAEB7DDD95BCE,
	XmlDictionaryReader_ReadContentAsBase64_mB826AA83D5FEACA76F97AC02F7CB9F6EA3A36DEF,
	XmlDictionaryReader_ReadContentAsBase64_m76CB8C0BD3E7440F2C0780408A2C1ED7BFF869F3,
	XmlDictionaryReader_ReadContentAsString_m5A57F1860E316B1EA3022C1FD93DA37C24AE9662,
	XmlDictionaryReader_ReadContentAsString_m9BD42A62FEEA01EDD63BCBB0015B7A7D28BA23F1,
	XmlDictionaryReader_ReadString_mDD6D9F48D9A012C8049D9ADB41698B3105F781B8,
	XmlDictionaryReader_ReadString_mCFB26BCF0F3D078D7F4559D5A93ABBB1612CEF74,
	XmlDictionaryReader_ReadContentAsBytes_mDC409214ABC50F5B554484BE7807AED9FCF1E1D6,
	XmlDictionaryReader_IsTextNode_mC900A41B66DAA05511B42C4E4DBC47501B3D1259,
	XmlDictionaryReader_ReadContentAsChars_m92793BC3BC8FF1C5EB9DF44F1CFE46A28BEEC917,
	XmlDictionaryReader_ReadContentAs_mDB7C8F4CFE9C54E28A1564B83526340B70937464,
	XmlDictionaryReader_ReadContentAsDecimal_m2C6C847FC5CDE03C1744E3961D912A32E18DCFAF,
	XmlDictionaryReader_ReadContentAsFloat_mCB6509556CE695CD8CB0CC1498ECDC4150295EE8,
	XmlDictionaryReader_ReadContentAsUniqueId_m77943D8FC8ACA74896C661FD07D4DCFD5874A22F,
	XmlDictionaryReader_ReadContentAsGuid_mD52396E11083A38D9C90091D6D15BFBFC5E05694,
	XmlDictionaryReader_ReadContentAsTimeSpan_mEECFDF6A42D2368DFAFD7535FCFB986FFA3D6D1C,
	XmlDictionaryReader_ReadElementContentAsString_m336A15CB6D25D168335954B2DAA4841730F8B048,
	XmlDictionaryReader_ReadElementContentAsBoolean_mC63E427F53007FB9FC6F87987559B35328C1442C,
	XmlDictionaryReader_ReadElementContentAsInt_mE64366A2C946C4A041DD81A21E20AFEC7572E40E,
	XmlDictionaryReader_ReadElementContentAsLong_mD852C05EB64BD138EDF373878E839EEB791C8A25,
	XmlDictionaryReader_ReadElementContentAsFloat_mA99ED0F682D8C733A34FF7B20578775F8BF3191B,
	XmlDictionaryReader_ReadElementContentAsDouble_m06310EB05BFC23D72AEBE2AD1D5D19441CE50539,
	XmlDictionaryReader_ReadElementContentAsDecimal_mD0F3C22C02170A68029EDAE88E68F7E1631B6F8E,
	XmlDictionaryReader_ReadElementContentAsDateTime_mF44DD3DC831EA0ACA5BF0A047007B74B68946E09,
	XmlDictionaryReader_ReadElementContentAsBase64_mA3AFE3A9C8C71D6DC8375D266CE36EAC1B0242FF,
	XmlDictionaryReader_CheckArray_mDFC28EBD1BB8AA6E579E033E1E51F70A5E2BB4A5,
	XmlDictionaryReader_TryGetArrayLength_m78E054EA0E9ED69616252D6DC9BEB4E68D8A1710,
	XmlDictionaryReader_ReadArray_mD3F3E4546CA84FFC9666925F0961D9548B6BE68A,
	XmlDictionaryReader_ReadArray_m1A3295AF0760C38C76AD123E40B1F5A1746CC523,
	XmlDictionaryReader_ReadArray_mA83F324B90B48FD1FB96AA3E3790C49CD544FBAA,
	XmlDictionaryReader_ReadArray_m091987050897F2B6383CFAA5347AFA5525943DFC,
	XmlDictionaryReader_ReadArray_mB0DF87F3054175D9DE9A91CB1F881A339B9036AD,
	XmlDictionaryReader_ReadArray_mE0A1F132B6B391AD31FB3BE518CB55D7A53CD349,
	XmlDictionaryReader_ReadArray_m6419A17439562C08FCB7528BCE30DF54290E9EDC,
	XmlDictionaryReader_ReadArray_m46B7E8BF473E17A0D515F08CC0E069404ED0B6B4,
	XmlDictionaryReader_ReadArray_m949BA82143F47A7E4FCCE5234C8ED8EB1DC06074,
	XmlDictionaryReader_ReadArray_m0CD907A3CDCEA03D9AC58EB6C16C479FDC6FC95A,
	XmlDictionaryReader_ReadArray_m49857CC4CB579401F6A7B339F6B8D1F01395E98D,
	XmlDictionaryReader_ReadArray_m59973D723EBAA7DC80CB3D398EC320947137E9E7,
	XmlDictionaryReader_ReadArray_mC57A4DB8DC14425495603E6E3D0BFCF015EF2F79,
	XmlDictionaryReader_ReadArray_mA55687A3F05B147D472831256E233933A9FE2D0D,
	XmlDictionaryReader__ctor_m062FF9ED1A2156A5933A8DFDB47518D48C4F2AF6,
	XmlWrappedReader__ctor_m55981EA6C792042818060F41F38954A21D0F2E61,
	XmlWrappedReader_get_AttributeCount_m0F8A360B85D1633D927C91812B3BA4FD1EA8ED42,
	XmlWrappedReader_get_BaseURI_mC26BD71133EC092CADDD09B8C18922C9F81F63CF,
	XmlWrappedReader_get_CanReadValueChunk_mAB35F8DB9F156297C3E3A7E04BDEA11B59DF0FC8,
	XmlWrappedReader_Close_mB3E9EA5D2AF60A33E1459C7D4D5EE0B1D6656A26,
	XmlWrappedReader_get_Depth_mD02B78BD3F4F7135B038BBFE79B791943A422ABE,
	XmlWrappedReader_get_EOF_mC84F994547754EA226EB97C568B2538C844AEB3F,
	XmlWrappedReader_GetAttribute_mE138EEE5BCFB9EB194BCFA198BA43EE2C94D8277,
	XmlWrappedReader_GetAttribute_m222009A1443583D6229430ABBC3292687F6A94C7,
	XmlWrappedReader_GetAttribute_mE6D36BEDD37E1FC5F7B960626E2BF34687B69620,
	XmlWrappedReader_get_IsDefault_m197C75D6849C49B363F213289D1B67D66709FA30,
	XmlWrappedReader_get_IsEmptyElement_m4063EC5736776FA1348FF7EBC22C58B92BF4FF5A,
	XmlWrappedReader_IsStartElement_m559C390C06BB66BCDD70936456725B5F46C98C72,
	XmlWrappedReader_get_LocalName_m43B0F047B989F2B3C9EDD7A7AFA03807CAE6F2D5,
	XmlWrappedReader_LookupNamespace_m00BCA75DF9806EFA725D046363E53150964E69FE,
	XmlWrappedReader_MoveToAttribute_m6317BB2F643149331E47600F3834E726F2C0C218,
	XmlWrappedReader_MoveToAttribute_m91FA49E60C7D42853746E6F3066B1ECFCEAF16CB,
	XmlWrappedReader_MoveToAttribute_mBC9336CEFC77807D9173B006461E2640DD43CEBF,
	XmlWrappedReader_MoveToElement_m5FE7E50F908B823F43907D76DC6F41AEE6B880F8,
	XmlWrappedReader_MoveToFirstAttribute_m37885D7DD73E7769DA2B02D316FDFE5F7BFB770E,
	XmlWrappedReader_MoveToNextAttribute_mE4A9F8E2C19DA6CB2417A7462CE6943BE04EC68E,
	XmlWrappedReader_get_Name_m5F6F64AEF09EFA948CE83031805102CC0EF3FE5A,
	XmlWrappedReader_get_NamespaceURI_mA0F81025D3CD14833B9215FE760E6F19B1895C02,
	XmlWrappedReader_get_NameTable_m1269F2E40BD350B06D6B05B56B43DFF5A8E25E79,
	XmlWrappedReader_get_NodeType_mBBD7DDC5CA9AD84C490C7F2488158493EEF44504,
	XmlWrappedReader_get_Prefix_m6890FC9A0F821312F2E45FE40D9933D6AF61B1E5,
	XmlWrappedReader_get_QuoteChar_mC8FB1BBCF4AAE11DF300A0A7EA15E8D483888044,
	XmlWrappedReader_Read_mAE5CFDEC88AD7D7828A70A7EBB0D9E105C2B8C3C,
	XmlWrappedReader_ReadAttributeValue_mF8204B6A12359D29BEC23DE6509F6731514CD1DB,
	XmlWrappedReader_ReadInnerXml_m65EA725A2E086E9AB4EE551761358BDB5769BFD2,
	XmlWrappedReader_ReadEndElement_m9FE20C2722308D3D7B0C02F1663B17DEDBBEB968,
	XmlWrappedReader_ReadString_m422E134043F5929D18F0D7053E792B5F6793DC91,
	XmlWrappedReader_get_ReadState_m199D8ED3CE55A7574DBBE61DF77FC2A24FD4CDC4,
	XmlWrappedReader_ResolveEntity_m66216A1B2619544A7A90F65C1E23829F5924266F,
	XmlWrappedReader_get_Value_m3A61AB5998BAEA042C001B54A175C8FD79DB79A0,
	XmlWrappedReader_get_XmlLang_m9F752B1593988E839B08527C6FC7BFF568D0F977,
	XmlWrappedReader_get_XmlSpace_m02C31E1C409EB78F6B668081853BFF28061BB3C7,
	XmlWrappedReader_ReadContentAsBase64_m26F240E22D457146683F1B17CB4360D4F3F48E99,
	XmlWrappedReader_ReadContentAsBinHex_m192754CFF404AAEDD2AB8BC25E85C28DA97FE9E2,
	XmlWrappedReader_ReadValueChunk_mFE5CEE6552AA5CFAB9FFD0F65FB0E50B28A67BF3,
	XmlWrappedReader_get_ValueType_mFB4FEDC1B70B98CD33CC8E4231C8BE6995016AB0,
	XmlWrappedReader_ReadContentAsBoolean_m44D70FD7902FC2190EADFD4506F3AFA297C564B2,
	XmlWrappedReader_ReadContentAsDateTime_m34FE91C985B6412B36D192C624DD8C8E8BABBB01,
	XmlWrappedReader_ReadContentAsDecimal_mBE525950884903883B9ABAAEB7816AB0226E3670,
	XmlWrappedReader_ReadContentAsDouble_mC49C64BE4F83F7310A94504DE088950965664B68,
	XmlWrappedReader_ReadContentAsInt_mB77F9C85B2D7B0D0A4D35B58FCAB471DAFFC5F8E,
	XmlWrappedReader_ReadContentAsLong_mB95B286BA872D3BA1F25D2BE8A2CB1F1FE06C1AB,
	XmlWrappedReader_ReadContentAsFloat_m0D994FC4E7CBB55CE2305F1F8A8EB47791A8FC52,
	XmlWrappedReader_ReadContentAsString_mC62B4098881C4BC1291C1E6D30FD59A655421FD6,
	XmlWrappedReader_ReadContentAs_mB6364B2970FE525A2EB9CBFE9B566CB473D2CB9E,
	XmlWrappedReader_HasLineInfo_m2A50D6908C08681844AFC27D2D0A7E3F3C601730,
	XmlWrappedReader_get_LineNumber_mC72C34C555F11AD151AFB4ECCAFB3BC5CCE22996,
	XmlWrappedReader_get_LinePosition_m58E824774568D30D624A21697EDA53D7DC0D5591,
	XmlDictionaryReaderQuotas__ctor_mA21CAF208B4C76F493A3728860ED36A88D635E79,
	XmlDictionaryReaderQuotas__ctor_m7016CAF17938A0F0DACF82A8A2CBFBEBCBC29D84,
	XmlDictionaryReaderQuotas_get_Max_m484BBCE075849747D34B2E53D8FA636B1B53E05A,
	XmlDictionaryReaderQuotas_CopyTo_m43426A5E7C91A8F959EAB3658EB3BC5050BF966D,
	XmlDictionaryReaderQuotas_InternalCopyTo_m752609DBD59B02A2AC2F1D6CEA68732BA44DE01C,
	XmlDictionaryReaderQuotas_get_MaxStringContentLength_mB4796F5018372D78B0F3BEE79699F400656C5A0B,
	XmlDictionaryReaderQuotas_get_MaxArrayLength_m41A819E163B35557AAABA09B02D3DD10CB498575,
	XmlDictionaryReaderQuotas_get_MaxBytesPerRead_m999A4BC8A5BBB01757180B88F7902AC1637BAF4E,
	XmlDictionaryReaderQuotas_get_MaxDepth_mCE20B87DB0ED756DD6B79ABA7A625ABFA7B794A4,
	XmlDictionaryReaderQuotas_get_MaxNameTableCharCount_mC24ED7B957C87884986C2FDC250C790F3576E59C,
	XmlDictionaryReaderQuotas_MakeReadOnly_m3E6E37DC6075A3C3CFBD21606328AECED70E9B72,
	XmlDictionaryReaderQuotas__cctor_m06B6A24320F4B778ED23A76086DF7FE0EDEFD613,
	XmlDictionaryString__ctor_m269BA79FE70EBBA2C5FCBD0B0FE3FB69E802CB0B,
	XmlDictionaryString_GetString_mD837436BDE4F576F650DEADD1AA492ABB3D3FF6E,
	XmlDictionaryString_get_Empty_m8A0AA908A06EED85F0058E4617CB0411154FE85A,
	XmlDictionaryString_get_Dictionary_m233D200A59470470191AB39BFE27B731B7FBF710,
	XmlDictionaryString_get_Key_m681F82FDDFCD6F976122A6A0D39675B0ED7FDC48,
	XmlDictionaryString_get_Value_m193A6C5E88D06CDFDA1FC7AE98FECCA4EF49538B,
	XmlDictionaryString_ToUTF8_mDF4D7D163A6D954AE30A8A18BBBA1B64F0C34D5F,
	XmlDictionaryString_ToString_m1A56D65E3EE75A12A3080EC8E94DD1349AF6890C,
	XmlDictionaryString__cctor_m0CDA16203D5C4015813F618C8749AD55BE334B1E,
	EmptyStringDictionary__ctor_mFAFB66785724EA019768B44A9F5AE1B0643601E0,
	EmptyStringDictionary_get_EmptyString_m96A56F06EC8A1A8415FF132730CC50BF9EDF6B93,
	EmptyStringDictionary_TryLookup_m22EB86EC447F0F806C2F38798837FA3664FD1868,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XmlNodeWriter_WriteStartElement_m295A1D3B7AE38E06316A3E42796016B53EA4C0F3,
	NULL,
	NULL,
	XmlNodeWriter_WriteEndElement_m4EA7DA992828B0D1B8C0BA87EECFD822863D6A41,
	NULL,
	XmlNodeWriter_WriteXmlnsAttribute_m9067BEC55FB07960455784D686795C4A26D74ECE,
	NULL,
	XmlNodeWriter_WriteStartAttribute_m3C20D28E0B00A93D119985DE0B90DF53BB7858FF,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XmlSigningNodeWriter_Flush_mFC5E17616E4E822A9B3E63105CF6E89EC385DD5C,
	XmlSigningNodeWriter_Close_mD3AF86544467FA007FE24FB9F3B1950A804DF42C,
	XmlSigningNodeWriter_WriteDeclaration_m55F3958DCC8968559D4C3B993748DCE19D224831,
	XmlSigningNodeWriter_WriteComment_m800FE991C5D3B5507E56E16DB15047A84DE06001,
	XmlSigningNodeWriter_WriteStartElement_m782ADCA21DD25B7B10F8DF0D7C15FC5B3EB097B2,
	XmlSigningNodeWriter_WriteEndStartElement_mB6C7227C40BA2C70168A31981D634D03640744C6,
	XmlSigningNodeWriter_WriteEndElement_m3CF1413973ED72799E2B6091C185777E8931B273,
	XmlSigningNodeWriter_WriteXmlnsAttribute_mBF1B07DB694671D06527E9ADE0794D1953C41A99,
	XmlSigningNodeWriter_WriteStartAttribute_m819C4959E4C6D7A0431EBBF3E5C20F55A23FCEC4,
	XmlSigningNodeWriter_WriteEndAttribute_mC8F2D35A3478B2463A7D089B9A84D072496A6699,
	XmlSigningNodeWriter_WriteCharEntity_m93EF9634C08D9CF0C12859760A7A216A55940846,
	XmlSigningNodeWriter_WriteEscapedText_mE5E7CBA9B9AC06701A6FF6B3460FC601C31F979E,
	XmlSigningNodeWriter_WriteEscapedText_mBCB287DC7E2D6DE4AD54A7665DF5F1CF19F15478,
	XmlSigningNodeWriter_WriteEscapedText_m50B13618B56FABB7EC39DB93563106CDFE001558,
	XmlSigningNodeWriter_WriteText_m23B56CFC8840F8CD7C6983BC12CD3E6267F99B8D,
	XmlSigningNodeWriter_WriteText_m934F821AD12C7FC0EF1865D6554DF8AF1D4074CF,
	XmlSigningNodeWriter_WriteText_mAD56C89CAB1DCA52DE2F07AD5D008CFB01B7ADD7,
	XmlSigningNodeWriter_WriteInt32Text_m10CC3E4532513268C09263F84C7EABDA5C806AA4,
	XmlSigningNodeWriter_WriteInt64Text_m01EAAEAA5B62DBE96F0E4D923DAF7DF6E3CEEDBA,
	XmlSigningNodeWriter_WriteUInt64Text_m8F78DECBDA562448C64D0893C72EEBFD96AC3627,
	XmlSigningNodeWriter_WriteFloatText_mD884484ABD7D08442DAC360B4B4FF5B6EBB74565,
	XmlSigningNodeWriter_WriteDoubleText_m27A4A6243FF946B20DDE6C822906E129F4F9A349,
	XmlSigningNodeWriter_WriteDecimalText_m4E6FCA8E7B4A4E5E2E8B6A9B94B6FDC76B546B81,
	XmlSigningNodeWriter_WriteDateTimeText_m34D94AD32FBC8F59510F9DF6406CB2A525E75FE2,
	XmlSigningNodeWriter_WriteUniqueIdText_mB055B278B51B5F9590D30500A47B84FF7FE0783B,
	XmlSigningNodeWriter_WriteTimeSpanText_m63822F96F82ACD529C2C974F8399D0EF90BC7979,
	XmlSigningNodeWriter_WriteGuidText_m08D1F63E10088DF860D021D61CD413D923C0A36C,
	XmlSigningNodeWriter_WriteBase64Text_mFBDD0C216AF7586B209DA82799F4DAE6D18F6025,
	XmlSigningNodeWriter_WriteBase64Text_m8ECD05F804E83D5BC8BA7FCCE67B3DD6D3838F15,
	XmlStreamNodeWriter_get_Position_m8A75F46C4A513BB5BE2A3D12D591E206CF65C66C,
	XmlStreamNodeWriter_GetBuffer_m326E398FD0FE2C526EAEE3A938304BA3AD22653D,
	XmlStreamNodeWriter_Advance_m0DDFC2F7D13ED56DBA191DBC220810EC7A3A78B8,
	XmlStreamNodeWriter_EnsureByte_m0B06C1FA11B098050A26C1C78B8D25014F30B1B5,
	XmlStreamNodeWriter_WriteByte_m7B1FE9B99669AE1D4BA00EAE2CD13686F6DECF49,
	XmlStreamNodeWriter_WriteByte_m25A407DA1CD0DE052B011D9D735914EA147D82DB,
	XmlStreamNodeWriter_WriteBytes_m47FF6C042E7D67DDE5EAC75AA1DFA49FE3887191,
	XmlStreamNodeWriter_WriteBytes_mF473C1A3605F9DD93ABD9FB4AB9C108CA7FE1AC8,
	XmlStreamNodeWriter_WriteUTF8Char_m8F7338B64EE9D902306ED4D8D9A796661F5040C6,
	XmlStreamNodeWriter_WriteUTF8Chars_m31A03CAC6CEAB42A6BC2015B22FE663F0435FE78,
	XmlStreamNodeWriter_WriteUTF8Chars_mFC3FCDAD554AF8CAA040F3EB1A34714663FDD12A,
	XmlStreamNodeWriter_UnsafeWriteUTF8Chars_m06EFFE3C0A33684DA90E1B13B94AA8B0947BCAB1,
	XmlStreamNodeWriter_UnsafeGetUTF8Chars_m86B7E49E83B34C753798BCD41EDA3696F469ED4D,
	XmlStreamNodeWriter_FlushBuffer_m4D5B21D9B54FF7CE13989E73282F65177AFA71F6,
	XmlStreamNodeWriter_Flush_mD0F5EC4B2124D4072680ED2BB8AFD86014DC98F0,
	XmlStreamNodeWriter_Close_mB85A5C09F3512EED0E3C43B3A81E398F0812DF42,
	XmlStreamNodeWriter__cctor_m148DE9C4790757977E811173DF7660913262E178,
	XmlUTF8TextReader__ctor_m24E37A9DED8D3D08E9A0899E7AC0513ABFD64A63,
	XmlUTF8TextReader_SetInput_m628039266E0F8C899E01FABB655B9843801773DA,
	XmlUTF8TextReader_MoveToInitial_m51BD28E6B8FB38F5B11E4AE8E3FFE7657A28228A,
	XmlUTF8TextReader_Close_m5124EB0D653DEAD00F3B0742DF2A18AF28A05306,
	XmlUTF8TextReader_SkipWhitespace_m79622A38D768861BBE8367FEA700023EE73C74C1,
	XmlUTF8TextReader_ReadDeclaration_mC831B6028F0FDEEF517CF526026D8E16B2424D01,
	XmlUTF8TextReader_VerifyNCName_m57D13824CD1D24A6C21327C2E59194F1FB7B9E80,
	XmlUTF8TextReader_ReadQualifiedName_m25FF838814001C44B00D9C4C3939D13BBDDF7246,
	XmlUTF8TextReader_ReadAttributeText_mBDF9F756A2D27198B50502722953F17BFA0619C2,
	XmlUTF8TextReader_ReadAttributes_m3CA3ED42958AAA9D27BBFAC857561634C928924B,
	XmlUTF8TextReader_ReadNonFFFE_mB860C6ABF2284D077A5B1F0F757D18B1040230F8,
	XmlUTF8TextReader_IsNextCharacterNonFFFE_m470ED7C212632CC7EF9C7FE796631E328F37D5E2,
	XmlUTF8TextReader_BufferElement_m30BB745AB762C671BFFD38E82C515FECD13EEC7A,
	XmlUTF8TextReader_ReadStartElement_m1E5DC6D616EEAB45C5F0F50A78C6A69685EAB263,
	XmlUTF8TextReader_ReadEndElement_mA3ED56A65EC2B6815676BEE11C6BC1EDD500F617,
	XmlUTF8TextReader_ReadComment_m58FDA4C66B6BC7CEF298189660CF6048CD41701B,
	XmlUTF8TextReader_ReadCData_m9CE5B0AF40FEFE039EF279CDA17A399DBB538EBB,
	XmlUTF8TextReader_ReadCharRef_m3334575F050D4FB42BD4C627649F49B49062102D,
	XmlUTF8TextReader_ReadWhitespace_m1890CB354248770131B03D5C386AD33BDFB650F0,
	XmlUTF8TextReader_ReadWhitespace_mC5A34A4BE203C061D6782B0E3CC316877E1F395D,
	XmlUTF8TextReader_ReadText_m2C13FEFB234A3C025B95971E207D1FA4F74FCD15,
	XmlUTF8TextReader_ReadTextAndWatchForInvalidCharacters_m2B8BA60D891F5686CA9DA84BE167FCDC872F98E0,
	XmlUTF8TextReader_BreakText_m48D625746F367B5928D2494E57D0CFA6B707FECD,
	XmlUTF8TextReader_ReadText_mBF1133DFDC23CB5A8264EF4659B78CA520645346,
	XmlUTF8TextReader_ReadEscapedText_mF4428DD71BA49841F61F7DDAC79335812F863BBE,
	XmlUTF8TextReader_Read_mA858A9AD1130019EE6E958917CB63BE3C1554D50,
	XmlUTF8TextReader_HasLineInfo_mE3B1380B4F7DB5F7DA9DCED5598183A16BAC9CCC,
	XmlUTF8TextReader_get_LineNumber_m4AACCD46715FEAF1A88CC5AC094C503E2BEE5879,
	XmlUTF8TextReader_get_LinePosition_m0BDFD0DE14B2AB0FA1DB066146BB7404742FA85A,
	XmlUTF8TextReader_GetPosition_m36D6D03EE014CF31642B6EC4DE2C2B09789BA12F,
	XmlUTF8TextReader__cctor_m8EB968BA1D402157995DF4E67A88E8BE2CA8AB00,
	XmlUTF8NodeWriter_GetCharEntityBuffer_mB2A5717A751FA15321E2D43B168195FE4F3DCC5E,
	XmlUTF8NodeWriter_GetCharBuffer_mA4B9E1511D09CE6B5EE34F9C08076A2FE2795029,
	XmlUTF8NodeWriter_WriteDeclaration_m4F4D99B093DD268986CDEF9046BDBA35C2D89B68,
	XmlUTF8NodeWriter_WriteStartComment_m558F2B3378AAE16F66BF06D249BDAFB223A71449,
	XmlUTF8NodeWriter_WriteEndComment_m559FD20BA234BD5D5F0FB5067A78A8682B94F623,
	XmlUTF8NodeWriter_WriteComment_m26D03F890E9521DAF871EA1E25141D72302CD2E5,
	XmlUTF8NodeWriter_WriteStartElement_m4620D7B75CB3B260F69F0034B034B22E7B1A227A,
	XmlUTF8NodeWriter_WriteEndStartElement_m0716905A9BB896FC84E799CC83C60CFFE7E609DD,
	XmlUTF8NodeWriter_WriteEndElement_m098B0E86DA2DCC8E07976A823213DE2F22E2C7B1,
	XmlUTF8NodeWriter_WriteStartXmlnsAttribute_m648A206A6B972186E6A17CF9BE98F7E5721D77BE,
	XmlUTF8NodeWriter_WriteXmlnsAttribute_m1808DFD28206C7A0FEFC660CE8FEA227E59F3ADE,
	XmlUTF8NodeWriter_WriteStartAttribute_m17B9C5E365746275454BDAFEF839D6D1BA8A76DE,
	XmlUTF8NodeWriter_WriteEndAttribute_m395780ABB5DB14155208F3FDA2481AB1A2B5AE93,
	XmlUTF8NodeWriter_WritePrefix_m27DABE170E1EBA07CE92439C901DA156330DD6AB,
	XmlUTF8NodeWriter_WriteLocalName_m46F15EDCF17464FF03664248CB942A068FA8B1FD,
	XmlUTF8NodeWriter_WriteEscapedText_m8FF4C38BCD3D8938752F7996FC03C7360FC9516F,
	XmlUTF8NodeWriter_WriteEscapedText_mADE01614A1692E3302539AE6E6061D2237869F9B,
	XmlUTF8NodeWriter_UnsafeWriteEscapedText_mEABA506B8B2A13A7557153CCF123D4CE886C9F78,
	XmlUTF8NodeWriter_WriteEscapedText_mD51B04BAADE4225B27A222BFBDA9E9F6C659EFAD,
	XmlUTF8NodeWriter_WriteText_m5B3E9DC3E647769EAB81CE22768728B350DB180C,
	XmlUTF8NodeWriter_WriteText_mB23C6693B7F74CF79A15204E9F2A1D561AD15F75,
	XmlUTF8NodeWriter_WriteText_mE169416D4D2128C3A4C353C24526CBF1331BE69E,
	XmlUTF8NodeWriter_WriteText_m0AC61EA6ADB6D49924D015CD3425C4D1A7AE5C2B,
	XmlUTF8NodeWriter_WriteLessThanCharEntity_m78B63F77A6A9FD708A916FA7E271F25E080FE52F,
	XmlUTF8NodeWriter_WriteGreaterThanCharEntity_mAFAD16F4525654055EA3E1145307963A8422955A,
	XmlUTF8NodeWriter_WriteAmpersandCharEntity_m2052A0341DD309502D55D7C356F8A5C7FC2D65FB,
	XmlUTF8NodeWriter_WriteApostropheCharEntity_m06520B44097058B10CCA7306729B902E97EF71EB,
	XmlUTF8NodeWriter_WriteQuoteCharEntity_m17C1BFEA5C1F72CFD4C93B682DC1E3B23B3642B7,
	XmlUTF8NodeWriter_WriteHexCharEntity_mDD1CCA0248F01539F39CD2E8D1B7ED143499DDE9,
	XmlUTF8NodeWriter_WriteCharEntity_mB31C40C8130EA4FABAACD4A5D42BB369EA28547E,
	XmlUTF8NodeWriter_ToBase16_m4FA3B62D33191CD91EF982B0BEC79FD0BEFA89B6,
	XmlUTF8NodeWriter_WriteDecimalText_m8971282F0F158A2F40DADA5FCC8AAC2AC2AD5353,
	XmlUTF8NodeWriter_WriteDoubleText_m5B05FC80CE9FB534D9994EFFF17DA05606CD25B1,
	XmlUTF8NodeWriter_WriteFloatText_m3934342548A39E88ED41A85581DDAD5105CA4153,
	XmlUTF8NodeWriter_WriteDateTimeText_m6CB99EF963CABF144ECABEE98E5AB921A2C5C4F6,
	XmlUTF8NodeWriter_WriteUniqueIdText_m3C494B84873007BFB47558198CD27BC6F4555AE0,
	XmlUTF8NodeWriter_WriteInt32Text_mCB87DC533493088F562B68FAC8372A62693F479E,
	XmlUTF8NodeWriter_WriteInt64Text_m671D1DA84AF29EAA738BFE2D31981D09539A59B7,
	XmlUTF8NodeWriter_WriteUInt64Text_m453CDF0ADF4968FB5B2023F97D78A883A099E709,
	XmlUTF8NodeWriter_WriteGuidText_mC29137470190836FBC132C9A200DE0918EA5DA14,
	XmlUTF8NodeWriter_WriteBase64Text_m7BC174F8852B9618E3594A9CEA0EA4E4058C7E04,
	XmlUTF8NodeWriter_InternalWriteBase64Text_m0E173F1D8A301C7FA02B1DAFE961036B0D8BA71E,
	XmlUTF8NodeWriter_WriteTimeSpanText_mB86D96EF5AC05C78CD8101CDC58D902B20BF990D,
	XmlUTF8NodeWriter__cctor_mF9C5EC8E57CD2A590E05550E771736D6F2A54F0C,
	XmlExceptionHelper_ThrowXmlException_m9CAE837E532956B71A045E068C32D576E0210647,
	XmlExceptionHelper_ThrowXmlException_m51FA892F8FE973F87CFD72FB4EE1F225A270BA3A,
	XmlExceptionHelper_ThrowXmlException_mCAC8B944542C8B240E1BDD1C782EC9CCF8A0528F,
	XmlExceptionHelper_ThrowXmlException_m54C8B0AE5F3D1B9637DAE7C51249AE4AFEE74991,
	XmlExceptionHelper_ThrowXmlException_mEB4619E7E893211CB9486DE9A0FEDFB0A9943DBC,
	XmlExceptionHelper_GetName_m6DA69A2E5B90FC8B101252C17ACD452AED65E746,
	XmlExceptionHelper_GetWhatWasFound_m181A4BDBD95C74A19DB5AF3362E7AE89998725E1,
	XmlExceptionHelper_ThrowStartElementExpected_m8D7DC58E8FCC246981733C52E7F9FD18C3E9DC92,
	XmlExceptionHelper_ThrowEndElementExpected_mB7B44BEE122859BD8F08008C1D4602360717DDA2,
	XmlExceptionHelper_ThrowMaxStringContentLengthExceeded_mB5A4A675F73F149C01DF355BA601D00E13A0B264,
	XmlExceptionHelper_ThrowMaxArrayLengthExceeded_mDE31F18D5F2A78DF4D666B2B929280A260673A7D,
	XmlExceptionHelper_ThrowMaxArrayLengthOrMaxItemsQuotaExceeded_m3DE6227A4CBA7F38C4FB24D6D826299BB8295966,
	XmlExceptionHelper_ThrowMaxDepthExceeded_m98FCAAB451F07B7DEC230EFCBD47DD9348D90EA4,
	XmlExceptionHelper_ThrowMaxBytesPerReadExceeded_m00F4653331C6F7120292CA9F65C08ED578FAF9B4,
	XmlExceptionHelper_ThrowMaxNameTableCharCountExceeded_mC86AAE44E4436DC102ADA7BCE12A3F9BB08E4B44,
	XmlExceptionHelper_ThrowBase64DataExpected_m346A44349879059878180790C9A87C7EC1FD7D21,
	XmlExceptionHelper_ThrowUndefinedPrefix_m9A5D3AA34F7C20BB7CD8BAEF5233CE9C7345ACEA,
	XmlExceptionHelper_ThrowProcessingInstructionNotSupported_m30E0C1E97C3FC693F75CC767E7ABA3F554F5FC32,
	XmlExceptionHelper_ThrowInvalidXml_m310012A268BDF71C94FC4F4C605D3DCB5CD6DF3B,
	XmlExceptionHelper_ThrowUnexpectedEndOfFile_m7C9A4D5469020BB917B4C4DFE5B408E67CD532D6,
	XmlExceptionHelper_ThrowUnexpectedEndElement_m880D12A0C24692A7E82FEF7283A1AF87D54851F4,
	XmlExceptionHelper_ThrowTokenExpected_m218288535053C1390B223240085B1A46004DC808,
	XmlExceptionHelper_ThrowTokenExpected_mAD3DE4313365889AD55CDE51A9D103229494ECD1,
	XmlExceptionHelper_ThrowInvalidCharRef_mC48AC7C8FAB32BA288C434BB4B0414D9475B8A21,
	XmlExceptionHelper_ThrowTagMismatch_m18881234B90DED671F7DA63B38379289C01E2A49,
	XmlExceptionHelper_ThrowDuplicateXmlnsAttribute_m3C41CDEC7EC76ED3EE32BDFFDEE70049C910C53F,
	XmlExceptionHelper_ThrowDuplicateAttribute_m42FEEDA58E6AC5390E13CA8826373622329CF1EA,
	XmlExceptionHelper_ThrowInvalidBinaryFormat_mEF561549A3C8B62895E5A3F8CF95A1DD309AD490,
	XmlExceptionHelper_ThrowInvalidRootData_m0BFE3805A6AC2FD63B2BB9B00992A162367EEB1C,
	XmlExceptionHelper_ThrowMultipleRootElements_mD71E549C0C77B8808C45300F6A448EC9C8893215,
	XmlExceptionHelper_ThrowDeclarationNotFirst_mBB7EA50EFE7BB6553B73691B05A4C0BFB77B58E9,
	XmlExceptionHelper_ThrowXmlDictionaryStringIDOutOfRange_mBCAE826DAF4B325EF10662C8865E0D9B1A6B9B76,
	XmlExceptionHelper_ThrowXmlDictionaryStringIDUndefinedStatic_mA290F11778A6B966919B58C8E1D21ED1AC978BA3,
	XmlExceptionHelper_ThrowXmlDictionaryStringIDUndefinedSession_mD995F78A96E6A5FDB3CD506528643D002A12A452,
	XmlExceptionHelper_ThrowEmptyNamespace_m67BF85D1A5442D6602CD0169196D631E4A8C7F4F,
	XmlExceptionHelper_CreateConversionException_m8F81F4E882F53D9E2AA56D8F01E1A5EBB9D9B1B0,
	XmlExceptionHelper_CreateEncodingException_m392ABD430CCFF9B44633D413347397947387942F,
	XmlExceptionHelper_CreateEncodingException_m7B15262DE30FA7B28043F1BF2EE232549F53F8FE,
	Base64Encoding_GetMaxByteCount_m51B6111DA1895ED388A964D5D6A0BF20ED413117,
	Base64Encoding_IsValidLeadBytes_mED0B21CB66C2806EB8A548CE99E1713048A3A07F,
	Base64Encoding_IsValidTailBytes_mDDBBC54B947A85FFC7C6D5C265A6233FD1F5FEBF,
	Base64Encoding_GetByteCount_m971AC92CE18B71923A2444AF18D534DF50682017,
	Base64Encoding_GetBytes_mD79082D9A60E02FECAAD4CC49F06631DB32C1A85,
	Base64Encoding_GetBytes_mADDA35590622208F0630FA9893BCC63C0ED288D5,
	Base64Encoding_GetMaxCharCount_m0EB4F3BD40230F4B870646D784A5BC9D827C82DF,
	Base64Encoding_GetCharCount_m34C143F8A498EA2A5AEEB5CC104D1D4DCACA4868,
	Base64Encoding_GetChars_mC515857CD720B9CB76EA42E02644C987CE205AF1,
	Base64Encoding_GetChars_m20E968D66ACF5FC19175B2E48C6FBEDC218D9590,
	Base64Encoding__ctor_m9C21C2C9843ED10B6E8C349B53DE92C8FE875567,
	Base64Encoding__cctor_m7A2524C6758B4B37F396E753BD2EAAA23DB5478D,
	BinHexEncoding_GetMaxByteCount_mE79A3E229196187097236E31ECD8CE287A421893,
	BinHexEncoding_GetByteCount_m4B8FD64FB85DCB7209135138C913C64955BDAB94,
	BinHexEncoding_GetBytes_m267604CFC36D45F53C60235E3975EFA9BC327CFA,
	BinHexEncoding_GetMaxCharCount_m88E770D2D9517B44316D8E3359E6B4C39DE7CA17,
	BinHexEncoding_GetCharCount_m92846F47362E91144110B8014CABBBC13CB75BA0,
	BinHexEncoding_GetChars_m247DC4AB7B98C97D5C9507725B98AC8C63776AB4,
	BinHexEncoding__ctor_m762C3ED54232358E05C353DE539B0B9F21721190,
	BinHexEncoding__cctor_m5FC2F94EBC61279968A4043B1FA687EEC680A5B4,
	SurrogateChar__ctor_m0244C7438DA2C0EA0BCD7FC8280D78AEC54765E4,
	SurrogateChar__ctor_mD97B515A1E75EBB7BF68D9ABE65EF556C66B683C,
	SurrogateChar_get_LowChar_m93E0E738D16C16370CC7D14EE2FBC90869AA7007,
	SurrogateChar_get_HighChar_m2B1C01150EE9A470BF95D0F279A07DF8265CFF79,
	SurrogateChar_get_Char_mA8EF3784B38A8E24125A65F753E2BD110212E794,
	Attributes__cctor_m095FE3C97646DFCA1C184CBA01D803BE25E32A45,
	Attributes_Read_m34E0BCA5F58372E4233F5125616C6F32472D3B94,
	Attributes_Reset_mBF35F2C4464D14E3968D90FBA809ED6BA51A42F4,
	Attributes_ReadId_m9DBD839B9C2F8C4883F5E375FB30D22D17876FB9,
	Attributes_ReadRef_mB23806DA6B509ED49401B3C05684DC8A8B4B4565,
	Attributes_ReadXsiNil_mB3BBFB007134BCD5BDA03EB9F521E322814E9DEA,
	Attributes_ReadArraySize_m99B21F0084AF07C5FDA209BEE30DD110FC3FD142,
	Attributes_ReadXsiType_m440D33BF09A7B4546114CE66359D85240A1D4A7A,
	Attributes_ReadFactoryType_mD7878D4BF28559D2BB6EA190C723796AF5784A27,
	Attributes__ctor_m39FA7DE4B2EB04C811FE47743887AB59AB35332E,
	ClassDataContract__ctor_m3E50BE215740931FCCAE7D635807765788ABDF9F,
	ClassDataContract__ctor_mB2FC0D3831C2F22B4970E3F4F1B43725BC8F57E5,
	ClassDataContract_InitClassDataContract_m644CB667EED23B8BDDB318A28F89F08EFD33202C,
	ClassDataContract_get_BaseContract_m529E63AF1BBD922EFDE2B8C4DA658A84C6FFB4FB,
	ClassDataContract_get_Members_mCE63D5B7BC677C5DFFF987A2BC9ED58B2496A133,
	ClassDataContract_get_OnDeserializing_m8BBE2E906E203429847FFD9C8284942D2BF777F6,
	ClassDataContract_get_OnDeserialized_m638A30CDA2187CF748D8D68A544291645EC2BAA9,
	ClassDataContract_get_ExtensionDataSetMethod_m2EAAE1FD37F47C37C3C9CAAD93D2EE653564772B,
	ClassDataContract_get_KnownDataContracts_m50F67B3BDEE462E73A16F3FBF0693C8C726C8BDC,
	ClassDataContract_get_IsISerializable_mE43B80C3AB340B96B03F590CC9C2E6BB5776F5A9,
	ClassDataContract_get_IsNonAttributedType_mDD7E45DF027FFB545A657AE8E8E2074F9A49EBC6,
	ClassDataContract_get_HasExtensionData_m818AF75DD113A22E06911F7A90CB6C30747FC17C,
	ClassDataContract_get_SerializationExceptionMessage_m3F54FB2D95EBFE9E3937A6B504F49ED7FF29C016,
	ClassDataContract_get_DeserializationExceptionMessage_m591E76B280F7313EF709519850E9518A9CEB600E,
	ClassDataContract_get_IsReadOnlyContract_m148D29A5CAFB30D5D2F2139AA64452499FABD320,
	ClassDataContract_GetISerializableConstructor_m5F0437F7DA13B6677BA427726780A3BBA50A951E,
	ClassDataContract_GetNonAttributedTypeConstructor_m7C68EA3DEFB4BEF1DA8505B9B724CAF30F517B8A,
	ClassDataContract_get_XmlFormatReaderDelegate_m8399DC772FDE5678C8C50FD5B49AF7929ED6F351,
	ClassDataContract_CreateClassDataContractForKeyValue_m7E53BA161AA7CC12A220B583F55DD0E134CFD06D,
	ClassDataContract_CheckAndAddMember_m983623BBFCD0423695AF9ECF21C524C38FEFA58D,
	ClassDataContract_IsNonAttributedTypeValidForSerialization_m9CF012F366D51DD7A23F7321850A418D8AA6DE5D,
	ClassDataContract_ReadXmlValue_m2E6F19C473D3FCFA9F4E3683B263CF8502A48D16,
	ClassDataContract_Equals_m87142745BAA43FBA3D4F2F0DB15F3CB697C5E069,
	ClassDataContract_IsEveryDataMemberOptional_mEC90654333E338B895D8B1975FB86F16F4F43E1C,
	ClassDataContract_GetHashCode_m8FE32F33059E761578B7A4CC4C7D3A52DB8BAAD1,
	ClassDataContractCriticalHelper__ctor_mBA4BAD32BF3CC7948FE88E6D31AEA7ABE53B896E,
	ClassDataContractCriticalHelper__ctor_mD92C276A6E441A4613B8246D456DFBDA119C94B8,
	ClassDataContractCriticalHelper_EnsureIsReferenceImported_mCDF1BCF4B65B4FF2EB71C22EBFFB264BDDAA0BEA,
	ClassDataContractCriticalHelper_ImportDataMembers_m997865C92DE5FEA27C470E41FBD0990AE14DD8FC,
	ClassDataContractCriticalHelper_SetIfGetOnlyCollection_mEA35FF045B3A9DDF6F363624B104F8BE9FDCFF07,
	ClassDataContractCriticalHelper_SetIfMembersHaveConflict_m63B59D4DD12B3D5B506A8E05333E67E9E0C95ACA,
	ClassDataContractCriticalHelper_GetStableNameAndSetHasDataContract_mB89BBB0AC10D8273AAE4575ED783907FA4690AA3,
	ClassDataContractCriticalHelper_SetIsNonAttributedType_m1B3DC2C8DB9B7292A7B77D3EE4556444CEEBA378,
	ClassDataContractCriticalHelper_IsMethodOverriding_m62A99A43C504008BF5553D6F09E95559F1623AF0,
	ClassDataContractCriticalHelper_EnsureMethodsImported_mF26295ABB0B3BA7CAA99226CBA31F3724364925B,
	ClassDataContractCriticalHelper_IsValidExtensionDataSetMethod_m5F463177CF4AD755E9C326118AC7C89FBB7AF518,
	ClassDataContractCriticalHelper_IsValidCallback_m13FFF720DEDACD6B024FBB359F8FABD76CCAEB21,
	ClassDataContractCriticalHelper_get_BaseContract_m9F236D272CCF39FA47996EBB7A9050BFD824007F,
	ClassDataContractCriticalHelper_set_BaseContract_m1F97E9BBCC8BF99F77170B7123A626E0BE454F8D,
	ClassDataContractCriticalHelper_get_Members_m27872BAA0EBA2906AC2B765FDB130BD119B2FCEF,
	ClassDataContractCriticalHelper_get_OnDeserializing_m74B99882A8A8D3588FD723DDDBA30F2F198F007B,
	ClassDataContractCriticalHelper_get_OnDeserialized_mF57FBAF780804258954F617A4C17AAF9112FF744,
	ClassDataContractCriticalHelper_get_ExtensionDataSetMethod_m18533F14A5D759BC4D43E3C6AC0EB3DADEAA94E1,
	ClassDataContractCriticalHelper_get_KnownDataContracts_m4E305E351D80366E6A2936FE79E99D062A378FE5,
	ClassDataContractCriticalHelper_get_SerializationExceptionMessage_m50C38A04A92543BF18A007C8655832E0CA926062,
	ClassDataContractCriticalHelper_get_DeserializationExceptionMessage_m853DF06DBB4ACB82605A0AFBB9A8F4EA76C8EF8E,
	ClassDataContractCriticalHelper_get_IsISerializable_m1C4181C96C7FC420486CA9AB1652981C2A478421,
	ClassDataContractCriticalHelper_get_HasDataContract_mE9799CB546EA4DE723F22EFA994BC0D87241AC40,
	ClassDataContractCriticalHelper_get_HasExtensionData_m5570A5B7648C70D0C06B7A595C7E7649FD37EF12,
	ClassDataContractCriticalHelper_get_IsNonAttributedType_m9E1FBFE1E468684B7408B457FBB28C695E0E5E39,
	ClassDataContractCriticalHelper_GetISerializableConstructor_mA69653DE141FC276838DD101DA388834DA08F079,
	ClassDataContractCriticalHelper_GetNonAttributedTypeConstructor_m60E180482D78008C413E22D17C368028872B45A0,
	ClassDataContractCriticalHelper_get_XmlFormatReaderDelegate_mAD59C296EBC2473A492A2F9FF32F72518842B232,
	ClassDataContractCriticalHelper_set_XmlFormatReaderDelegate_mBF6AF7D84E8F9F89665A34E616427DC460D4210C,
	ClassDataContractCriticalHelper_get_SerInfoCtorArgs_mC4C84565A175F382DAC2CBB68673E50326E4E468,
	Member__ctor_mC61ED1E34A077EA1C8086CA839925EC6178F9A07,
	DataMemberConflictComparer_Compare_mC4692ECB8CA1D5B09A9E95616EFB1FF7A43DB2CD,
	DataMemberConflictComparer__ctor_m855262218ADBC28A3E49B9A1F689397086349152,
	DataMemberConflictComparer__cctor_m1B480C12704B7D6AAA8DA3761E324D5ED45CC52C,
	DataMemberComparer_Compare_m1FF6D7284E3BC4AC00BA9A12819A73C4E2758D94,
	DataMemberComparer__ctor_mFF31DAF0E3C22A17CEB4B6484B1F547ED3C54834,
	DataMemberComparer__cctor_m5BFDDF49CF8E68B5AD6FA08EF616A68A790BB781,
	CollectionDataContract__ctor_m6777638B7743BA7D2B7540414442EEA2FD1EBD31,
	CollectionDataContract__ctor_mC1CB6D7117B396C7FD3848D433A5CC3E8F20C7C3,
	CollectionDataContract__ctor_m87B331D673AF72BEED811A98B391523C49DC2030,
	CollectionDataContract__ctor_mDCAA85232069A07BDC2541132ECB5795E213F992,
	CollectionDataContract__ctor_mDBE931D1E4C29101058A49571C71ACCE62DE06D5,
	CollectionDataContract__ctor_m7EBB9F62F194975B1686E16FFFF56EC9B88628CB,
	CollectionDataContract_InitCollectionDataContract_mF0611E7628FD039669A7033978C89EEF5067597D,
	CollectionDataContract_get_KnownInterfaces_m60E4F0FA10A25164A5D230F9E2E4F566B1524F71,
	CollectionDataContract_get_Kind_m329F001A45936109A6EDC0EFB145DF99D2F22C97,
	CollectionDataContract_get_ItemType_mFB4F5A43869308FF5CC6DF11F1024E1C54080BD7,
	CollectionDataContract_get_ItemContract_mCDACD847FA90C3D14430C2D3A44AB31947B03DD6,
	CollectionDataContract_get_SharedTypeContract_m378BE3843E0429DBBF040A07D4C6EE8F76E53AC5,
	CollectionDataContract_get_ItemName_m83AF5EFBAD6C9DB5675614DF56F9AEFEF4BEB523,
	CollectionDataContract_get_CollectionItemName_m33DD883B834F5F99BC7931ED4DFC0FC96F1FE4B5,
	CollectionDataContract_get_IsItemTypeNullable_m4B10F8B8D2F8F367B923F1D24BCDAC0B6A76A11A,
	CollectionDataContract_get_IsConstructorCheckRequired_mF73FDF687A9C4730A8E0593ACDA65498DCCA582D,
	CollectionDataContract_set_IsConstructorCheckRequired_m679D74A4C1E94405F471D251B6D4BF0FD6605BCB,
	CollectionDataContract_get_AddMethod_m174AB03E4E6BB82D51B5469837E3C37F49F1FA6F,
	CollectionDataContract_get_Constructor_mAAFB6CA27FF2689A337A0E18DFB5CAC054A1FCB0,
	CollectionDataContract_get_KnownDataContracts_m5093238DC6D2AEF376D8D4AF40D4CA5A2001CD04,
	CollectionDataContract_get_InvalidCollectionInSharedContractMessage_mEFA91099925A2DCE41AE2A9C9B7F2535B6921144,
	CollectionDataContract_get_DeserializationExceptionMessage_m81CAC71617C1134C5409F5998CDB3CB7F66C3937,
	CollectionDataContract_get_IsReadOnlyContract_m62D148FE07D9526899BBB42B6F13F7D929377AA5,
	CollectionDataContract_get_XmlFormatReaderDelegate_mAFA49752954061EA2165122F118519D19729F1DF,
	CollectionDataContract_get_XmlFormatGetOnlyCollectionReaderDelegate_mB73649F5A766564EA0D0917488DA387404AD0593,
	CollectionDataContract_GetSharedTypeContract_m97D12C8A1A052D9EC17F0553C29523DFC1251A7D,
	CollectionDataContract_IsCollectionInterface_mFB04330CC719FFF02255E6BB4ECAC823A8F1A118,
	CollectionDataContract_IsCollection_m76E168BFC4BE4A69568D4803E23EA45710E4382D,
	CollectionDataContract_IsCollection_m2115E35A417F7A95C8F7D775AF907D8CCE739749,
	CollectionDataContract_IsCollection_m460F87F46D3F318593F9DEF78B9CE4242CF82404,
	CollectionDataContract_IsCollectionHelper_mCE2EBCA06C72F6DEE3B194F705FA50DBD431458C,
	CollectionDataContract_TryCreate_mFAFCC53DCCAED37F5AE01D3C4ED77E7EDCE40B8C,
	CollectionDataContract_TryCreateGetOnlyCollectionDataContract_mE6063288A48271D1DCE8308338D053E3AD42EF1C,
	CollectionDataContract_GetTargetMethodWithName_mCFD22BDA22D3DDBA387EC05E047B2838F9FAEFA3,
	CollectionDataContract_IsArraySegment_m31E86998A3B7FE2531C35309C4F078265C815195,
	CollectionDataContract_IsCollectionOrTryCreate_mC5D5DB2BE67DBE34B7FDFAB2FAAB127D923521AE,
	CollectionDataContract_IsCollectionDataContract_mD414A3A90FCAB243B6C46BCE0720BD780CED28AF,
	CollectionDataContract_HandleIfInvalidCollection_mA1335BFFDF4253DB73F6CC5A64135F64127AF7BD,
	CollectionDataContract_GetReadOnlyCollectionExceptionMessages_mAB64CC8E0C98B8551F873F6A40622288094B14D3,
	CollectionDataContract_GetInvalidCollectionMessage_m533ECA9D1644BB10184B9566584260D52BE69BA7,
	CollectionDataContract_FindCollectionMethodsOnInterface_m3F1B9C4F112FB696B64A1F8A0F505E5D81AF73DF,
	CollectionDataContract_GetCollectionMethods_m09BBF28F2549768FF7FB72AF24EC3916BEA311FD,
	CollectionDataContract_IsKnownInterface_mB26E3C02747E4FF0E0C5230CC7A9897F2F6C796C,
	CollectionDataContract_GetValidContract_mC547E309F037ECD1E6A010344E40DEDEAF610DCD,
	CollectionDataContract_ThrowIfInvalid_m20490FDC7C6B4F316FDA8F199891C3CA86408BD7,
	CollectionDataContract_GetValidContract_m2B29D132D45D731FAFFA940A8FC9D65A52928043,
	CollectionDataContract_CheckConstructor_m015995FD208FA3C48220DFC81DECB4CEBD80507A,
	CollectionDataContract_Equals_m40243712A6696A8A7A7C9C5D941527372D5C7166,
	CollectionDataContract_GetHashCode_m7385FAD8D3FAE229E9E43F7470FD35C74113490F,
	CollectionDataContract_ReadXmlValue_m34F0B58FBC8D09E0A20DE869F0256AAE6657CDD5,
	CollectionDataContractCriticalHelper_get_KnownInterfaces_m1D9EE5FE1199A88867C688742674D7429C1FCA98,
	CollectionDataContractCriticalHelper_Init_m811BEC57B063FAEE6E0A0D7D072AA836DB1A5278,
	CollectionDataContractCriticalHelper__ctor_m9F45111A7F3CFE02E29EE48932AD900F66D71DBF,
	CollectionDataContractCriticalHelper__ctor_m4BD884B606D6A433ECE0D6B2C53EA07849B831F1,
	CollectionDataContractCriticalHelper__ctor_m3FD48AC7828EB8600DA49EABD8034CBD7F99229E,
	CollectionDataContractCriticalHelper__ctor_mAB125428EF92E6C4A0F457B923F4BCDF32A45CD9,
	CollectionDataContractCriticalHelper__ctor_m96B3BEF50A419971A951B80F4C8C0EAA1D64E7E8,
	CollectionDataContractCriticalHelper__ctor_m2CA4DFE284F23E03F1F5C2E78ABE9BEF90822B03,
	CollectionDataContractCriticalHelper_get_Kind_m1C7543A0E819CD0FEAC864D83C809931D7D8C47C,
	CollectionDataContractCriticalHelper_get_ItemType_mA693E723E297CDD2B54C4C845EE578D31987881D,
	CollectionDataContractCriticalHelper_get_ItemContract_m05904E161F21B43F9E61E83AB1A338656CC06770,
	CollectionDataContractCriticalHelper_get_SharedTypeContract_m09257778C6CC3AE25C78296E6AFAD88B736A45DF,
	CollectionDataContractCriticalHelper_set_SharedTypeContract_m30A8A7878D6B1322A37FC5785917AC14BC2B588A,
	CollectionDataContractCriticalHelper_get_ItemName_m3791FAF7E72319D11E8B3380FF51F78D15C32E96,
	CollectionDataContractCriticalHelper_get_IsConstructorCheckRequired_mE40470BF7CCFD35DDA99372430E8B2E473761BAA,
	CollectionDataContractCriticalHelper_set_IsConstructorCheckRequired_m57D7BE3258E50F94C26F0937A237102C651C79CC,
	CollectionDataContractCriticalHelper_get_CollectionItemName_mE9EC1481B41C3D13429B9FA3D9466188D5A4C938,
	CollectionDataContractCriticalHelper_get_KeyName_mBC7F8ADBD7303F504C45B1478B0A7B00B99F647A,
	CollectionDataContractCriticalHelper_get_ValueName_m7368CFD1EE1C340D273E598B6721FD8A72281FDE,
	CollectionDataContractCriticalHelper_get_IsDictionary_m7AC42B2E41FAF17E4A93A52D20E0A2F4E06D375B,
	CollectionDataContractCriticalHelper_get_DeserializationExceptionMessage_mCBBA5CC38F50B0A0630C886E51E0C3B3964C5310,
	CollectionDataContractCriticalHelper_get_IsItemTypeNullable_mCA5100F0F95F48A23CA8C526AB4F1F814776D7CD,
	CollectionDataContractCriticalHelper_get_AddMethod_mB7C47A1D9021C5AEBD364B5A213F318EF7CCF225,
	CollectionDataContractCriticalHelper_get_Constructor_m101B584DCB84497D277CDE5B7FD64EFFC2FC60E8,
	CollectionDataContractCriticalHelper_get_KnownDataContracts_mBFB905AEA00196A36769470CF6A9C98A4854EC60,
	CollectionDataContractCriticalHelper_get_InvalidCollectionInSharedContractMessage_mF9A210924CDB16539F8FFB9509B9925D75AD447B,
	CollectionDataContractCriticalHelper_get_XmlFormatReaderDelegate_m495916F6F0FCF18D4C40928EB5453D1C5DFD43F1,
	CollectionDataContractCriticalHelper_set_XmlFormatReaderDelegate_m9993F514F3341CE0EE4CC6EF529016F094AA3C89,
	CollectionDataContractCriticalHelper_get_XmlFormatGetOnlyCollectionReaderDelegate_mB0D49D4FFF8626D30E4D92769F21C873B732E3E3,
	CollectionDataContractCriticalHelper_set_XmlFormatGetOnlyCollectionReaderDelegate_mD828DC3B7030CDE6D3575B83A9E8D533F1749350,
	CollectionDataContractAttribute_get_Namespace_m574780DB3D5DC453A8CF5559E2643352B14E0519,
	CollectionDataContractAttribute_get_IsNamespaceSetExplicitly_m8CE70683AF7896394FA66C7104E988FADCA67DD2,
	CollectionDataContractAttribute_get_Name_m26FD6BEF03EF3CA9D6A53C47508844D33D959A22,
	CollectionDataContractAttribute_get_IsNameSetExplicitly_m6A375802223F3CED08B290FB1B48794863A590F8,
	CollectionDataContractAttribute_get_ItemName_m883F4E83A02BCD9937AB904A2D1A780FC784EBE4,
	CollectionDataContractAttribute_get_IsItemNameSetExplicitly_m5DBB018F345BF338E40ACDEC66312EBAD0DAD733,
	CollectionDataContractAttribute_get_KeyName_m29EE583DE400478C734939AAB7AD962D615DC495,
	CollectionDataContractAttribute_get_IsReference_m549BF93C18D6FCA7337F83F12FF4B719A413199E,
	CollectionDataContractAttribute_get_IsKeyNameSetExplicitly_mE0F6E83BE97F7688D810B4A4A2707AFE85E5642D,
	CollectionDataContractAttribute_get_ValueName_m42453A62E67DBC7C9153E88FF48FFA1B952DE4D4,
	CollectionDataContractAttribute_get_IsValueNameSetExplicitly_mEED9A20B0E41A78141A3888A2918ADF66F0B24BF,
	ContractNamespaceAttribute_get_ClrNamespace_mA5D336E6D99C126F0C7F63CC6557A7AD4DDB06ED,
	ContractNamespaceAttribute_get_ContractNamespace_m5848D6C950635298259FFB1FA579A35975DEE2B3,
	DataContract__ctor_m1E2C82B57AA621451458646C4318E646A786A7BB,
	DataContract_GetDataContract_mBA770B937ED8D702264AB313FA59CAF5EA59E7A6,
	DataContract_GetDataContract_m3CE3DD2750DE7B8D898E4660BB3336F8F8B5A98D,
	DataContract_GetDataContract_mED052453E1B3BFD5D6D81AACB94C3322957080B4,
	DataContract_GetDataContractSkipValidation_m5F004DEDD09C2035A7BDD53E4913B061246B4F77,
	DataContract_GetGetOnlyCollectionDataContract_m6BE48AB9653085A43CCEE6FCD3E1B637737E3DFD,
	DataContract_GetGetOnlyCollectionDataContractSkipValidation_mBC257F1D3F65D884E1912834C6FCAF4870488418,
	DataContract_GetDataContractForInitialization_mFA1B08F22D93EC11FADBBCC88A383F581B586B0D,
	DataContract_GetIdForInitialization_m715CBCF1C0537A2B3A53D9A2AEF4B3888EE6C23B,
	DataContract_GetId_mED958E8391E92EDC169F887686083D41FF46E870,
	DataContract_GetBuiltInDataContract_mE628548EDE2AFFF85667B936484FDCC0A8552589,
	DataContract_GetBuiltInDataContract_m9359391AE416A48E248AC95289BE25194E1DE63D,
	DataContract_GetBuiltInDataContract_m00FAD7760C718B85D38B46877D2EFF2E5AEB404D,
	DataContract_GetNamespace_m7518FB977A5E09D395CF8156326F4C9EC404F1C9,
	DataContract_ThrowInvalidDataContractException_mB8F8BF369DAF3D8CBDE538489172129D6D4DC8C5,
	DataContract_get_Helper_m72DB07C7CA1851449E4D7BA1F3D0144C453AD194,
	DataContract_get_UnderlyingType_mA80B8DE82D5132DD89B918C53F8BF73090FF67AA,
	DataContract_get_OriginalUnderlyingType_mC109835A1947C23F8DA094E2D3D2F17E7E703FC9,
	DataContract_get_IsBuiltInDataContract_m36A615061FA563D2D3C5BAB1F3949F9DD723861D,
	DataContract_get_TypeForInitialization_mAD0F05E2AE47652CB5F2DDE0D1F097544CA7EA54,
	DataContract_ReadXmlValue_m5501D4F81CA64E9CE07AB3B987D5AB4DAABC4E44,
	DataContract_get_IsValueType_mE90FCD576A3C0D04985564FAA9E48E1F080B0EEF,
	DataContract_get_IsReference_mF6F507AEB818C2D27548E0108C5FE32447A59224,
	DataContract_get_StableName_mE4BCC3ABA5EC3BB0BEF5D5CBA3166E33B6947BD5,
	DataContract_get_KnownDataContracts_m320599888965FDD65763B468D18720B7E1E56EF8,
	DataContract_get_IsISerializable_mDC22E299561062AB1B835641384EA3FB10394AD9,
	DataContract_get_Name_m93AB090AD25A025DADE77B3AE9B4EB0B5B1F3DD6,
	DataContract_get_Namespace_mB5F6E1B32E31BCE96D039F093F4858C1C0A467FB,
	DataContract_get_HasRoot_m386C7A4356A2377CA46FCF9B9537D4066A7C5A04,
	DataContract_get_TopLevelElementName_mE31D463F3A76968E57EA84AB5AEE4D987EE85CDC,
	DataContract_get_TopLevelElementNamespace_m1CD514067BACECEC4511006CBE67431A6D79BFD8,
	DataContract_get_CanContainReferences_mE874CFC8BAAED96E50A54E0976B7EECB5001E341,
	DataContract_get_IsPrimitive_m3188C185506896283A3F1C52466CDCDBA0064686,
	DataContract_GetValidContract_m63D0284C2274CE47A8E9C249C9B6E40379EA5CA4,
	DataContract_GetValidContract_m7190DAC4CC35869BBCF0FA46CE3E8300DB2C4058,
	DataContract_get_ParseMethod_mB620839F3FFB5E80CE71EC85452CAD3C5781627F,
	DataContract_IsTypeSerializable_m821A4B66734DAF991F01AF9DD255BE7C4465A2E7,
	DataContract_IsTypeSerializable_m821675DD3DBE699B93B313C746E00A41F317DA3C,
	DataContract_ValidatePreviousCollectionTypes_m1D9425006F5B2CD4081EC65963C9D4B2FC1C7F64,
	DataContract_UnwrapRedundantNullableType_m03C79ACF6392E3CF16A317BEDDC6FA2382A616A5,
	DataContract_UnwrapNullableType_m54576AB328942170F973DFADF67C0C22DC89CAAB,
	DataContract_IsAlpha_mD48A2E78E05CADDA07AFAB04D76C16DD1E302016,
	DataContract_IsDigit_mB5DCC80DEE3D40F8B6E68E74B79EA38239F1AD41,
	DataContract_IsAsciiLocalName_mA06C0F6F11665A6DD7C2C94D2BC647179DB6E5BA,
	DataContract_EncodeLocalName_m100844AB708E541ED1E482B0AB5C62711928DFAF,
	DataContract_IsValidNCName_mEF6B640C7D66A857E6BFC4FDF94121328B7F76C3,
	DataContract_GetStableName_m78696CB03C56EDE4FBD2E4AF834369734182CB1A,
	DataContract_GetStableName_mF44BEEC6C410CF7B81FA15778115E6D0F6B93E04,
	DataContract_GetStableName_m77F85CF5241B341FA89CC3F3BC17100C3685FB0B,
	DataContract_GetDCTypeStableName_m10153826A4B4F9A969D5D786E51EA4F49E3F965E,
	DataContract_GetNonDCTypeStableName_mDD657ACCE09421AFC4626AD5891B2736C1B930F8,
	DataContract_TryGetBuiltInXmlAndArrayTypeStableName_mD25BC23C07D08283DAC0C1818429B15A335A2D7F,
	DataContract_TryGetDCAttribute_mC97C86794EA71CF38FF43F33E3B33B94383EEDE9,
	DataContract_GetCollectionStableName_m405DAC16C532F652651AFDE0D8FA8C80E66AD6AA,
	DataContract_GetCollectionStableName_m0B59EDD0BAF6D2E37D5EAAA509B348650F782277,
	DataContract_GetArrayPrefix_mCA93D66234D15B8F57EBC42EE87F6E41C072E932,
	DataContract_GetCollectionNamespace_m5C7DF725CCF526283E510F24F4BAEEFF7BEEA07D,
	DataContract_GetDefaultStableName_m4480CF3DB8B9BBFBE9C17D12837351DD16E21E09,
	DataContract_GetDefaultStableLocalName_m24A5669B39829529D08FD26AD53F2BB54BA72D7F,
	DataContract_GetDefaultDataContractNamespace_m9B9134D3DD5FABE803133444898766DA01AE07B7,
	DataContract_GetDataContractNameForGenericName_mE83D996F8532E605743525FAEDF1DBE84A410242,
	DataContract_IsBuiltInNamespace_m467535334A5835E9E83B736E278E8CF5537A8765,
	DataContract_GetDefaultStableNamespace_mF8A056971CBBC8E9C089B57697217072E93650C2,
	DataContract_CreateQualifiedName_mC99D649978B8EB8069DB1DE17D5C664BE746F0CA,
	DataContract_GetDefaultStableNamespace_m6365ABDC0B89B7DCA933D04C454053B24907516F,
	DataContract_CheckExplicitDataContractNamespaceUri_m76D26F1487B1CC46525B466872EB7AC6EAD40E36,
	DataContract_GetClrTypeFullName_m1DD7F24A5238F620D71A4B65BE8389637FA3E42D,
	DataContract_GetClrNameAndNamespace_mADC018571399B9D453E7ED6C7DAB7036CF100C57,
	DataContract_GetDefaultStableName_m616C5878A297A0EFA4D53F8DCA29371DD15CA3C7,
	DataContract_GetDefaultStableName_mF1007D156B0F2CA4252E09CB383CE8075F89AD64,
	DataContract_GetGlobalDataContractNamespace_m81BBF1211BAD23A9DFE4C9ACF83AF8AB595A466E,
	DataContract_GetNamespacesDigest_mE24791F8F0D932411B6155DB1F20CF24B34B0512,
	DataContract_ExpandGenericParameters_mD87910479151C802A20DC9BF7B9FD6F538C91714,
	DataContract_ExpandGenericParameters_mDDD71BD2A9D2CA09ABDEFAC189990E5DFCFCB2EF,
	DataContract_IsTypeNullable_m9FC1E41DCD2A1320BD83CD26BBBF6044E9869C83,
	DataContract_ThrowTypeNotSerializable_m6BF62F8C9E8FB59C42ACF5509BD5616BBE908A07,
	DataContract_ImportKnownTypeAttributes_m9A0721650C6A80E689C6F01B744EF2FB156BF00B,
	DataContract_ImportKnownTypeAttributes_mD655F55EE5D9A4BE23B2FAD865ADA9F9FEAFA75A,
	DataContract_LoadKnownTypesFromConfig_m1C951D8CB61D4C462D82014135E4EF1AC205EA55,
	DataContract_CheckAndAdd_m6A20F091575F4D0075A71360F3DCEC2DAA32F75E,
	DataContract_Equals_m7F0B789CB328574F880142419E723DCE9FBD58B8,
	DataContract_Equals_m5D50D881BDD8FE0140D7E992A98C9098FF1138BE,
	DataContract_IsEqualOrChecked_m5581DB93F379F8135AA35D9DF81C9F7B3A114A9A,
	DataContract_GetHashCode_m5A826FD58BE49EA2D312BF39009389D5C08B3C9B,
	DataContractCriticalHelper__cctor_m49BF509877916FAFB83730A518D1209E875DE752,
	DataContractCriticalHelper_GetDataContractSkipValidation_m2098609B6B36EC0D43615312A63AADDC2FF0F99C,
	DataContractCriticalHelper_GetGetOnlyCollectionDataContractSkipValidation_m7132039EE32555B1D3E3B08812AA492DB388565B,
	DataContractCriticalHelper_GetDataContractForInitialization_m09DE96D3EF9A25656EBC4347379817AC31637867,
	DataContractCriticalHelper_GetIdForInitialization_m8A54EC49713DFFBEEFF26C16CEDED04CE5D1ED0E,
	DataContractCriticalHelper_ContractMatches_m3734F8594C72177E428F89F7C2FC4799A8F6A47F,
	DataContractCriticalHelper_GetId_mE557F9BB20095FCCAF8AB33F2C69D9112057C3AF,
	DataContractCriticalHelper_GetNextId_m618E943FB47D7E4723F6FAE3B913E733A8B12448,
	DataContractCriticalHelper_CreateDataContract_m9169313221A6BA316B0AB0FB7C9A8E3DB61025E3,
	DataContractCriticalHelper_AssignDataContractToId_m6D84141D5502CA6C90DFA7A5853F50B9EB5917AD,
	DataContractCriticalHelper_CreateGetOnlyCollectionDataContract_mFBD638600403066A46A3238A3EAB52DFFB1BFDCB,
	DataContractCriticalHelper_GetDataContractAdapterType_m316915A8B3A9B74E8A4CEDCFC4A1CB674FC5A8EB,
	DataContractCriticalHelper_GetDataContractOriginalType_m9D0E003124A8941323B15568705E0A27708F7A00,
	DataContractCriticalHelper_GetDataContractAdapterTypeHandle_m66B60923D77B9C6D238A91722DF07F79E8B805D2,
	DataContractCriticalHelper_GetBuiltInDataContract_m6A43FBF7DEB3056A3F0BDB7A995D3F2B0A8CBB7E,
	DataContractCriticalHelper_GetBuiltInDataContract_m6ADB02F5B006C9C85BDD9C914C7D4FAA19AD4CA1,
	DataContractCriticalHelper_GetBuiltInDataContract_m2A577375EBFF61AA192C54A6FF854BB010C484E7,
	DataContractCriticalHelper_TryCreateBuiltInDataContract_m4FF96FEE283F4C96E5797E68DC67028C06F79F4E,
	DataContractCriticalHelper_TryCreateBuiltInDataContract_m6A2853E2EB93F043BAA85CD2012DCC92B6B94F3A,
	DataContractCriticalHelper_GetNamespace_mB11BA44DF4B3E1F0D33B8182F2E5DDD0D3DB0725,
	DataContractCriticalHelper_ThrowInvalidDataContractException_m803A635A1B0176D1C677928738164CD2F78CCE96,
	DataContractCriticalHelper__ctor_m8E03F6B13D9CB84CE55AF0F547A2804EE754E5F9,
	DataContractCriticalHelper_get_UnderlyingType_mAD9098BC59866C4C135E4B17ED83D169579735F0,
	DataContractCriticalHelper_get_OriginalUnderlyingType_m454A53FF65A804BCEBB97C657F201F9E15370F58,
	DataContractCriticalHelper_get_IsBuiltInDataContract_mD3DD3C02A90A7BDF07BAC19A6EB8ADDF6B8F61F2,
	DataContractCriticalHelper_get_TypeForInitialization_m273616DEC6D4063D72574F557F8109E05065F7A6,
	DataContractCriticalHelper_SetTypeForInitialization_m14D27CC95003B730AACBC0798912B0751381E550,
	DataContractCriticalHelper_get_IsReference_m97A9D03F97467697B377B5E5F70D7E37D7170DD1,
	DataContractCriticalHelper_set_IsReference_m8F7DFDA662E3F963F2F45BC6EC25671DEE0CD243,
	DataContractCriticalHelper_get_IsValueType_m59E332C964F68DE5D9E64E30C26CDC3A47C4B5D2,
	DataContractCriticalHelper_set_IsValueType_m499B65D3C5F4C27DCF597DAA8912CDF9E2AB4BF0,
	DataContractCriticalHelper_get_StableName_m8D61D5C10EC9BCD0F4915F0F30BA373153695E8E,
	DataContractCriticalHelper_set_StableName_m7521E5449AF8127C7AD791D6049F4658AB30076D,
	DataContractCriticalHelper_get_KnownDataContracts_mDD316C6E86B694D08A2C23AE1234E1C28D047301,
	DataContractCriticalHelper_get_IsISerializable_mFDE1E6C2581613D0E8F26C4854B6AC5EFDFF0AE4,
	DataContractCriticalHelper_get_Name_m43393164C029E0E5CFC0984C4CAA3F1C795717FE,
	DataContractCriticalHelper_set_Name_mACDA2CAC7ACDFA3BDE0EBCF1DB50AD1A25C40E19,
	DataContractCriticalHelper_get_Namespace_m8C77F20DA16BA600B89CA931F343D1DD85DE68B0,
	DataContractCriticalHelper_set_Namespace_mA86F62FED23ACF152B7C541BF7C5A3F94CA8AA47,
	DataContractCriticalHelper_get_HasRoot_mEA4D0DE6B9EB54A1E1E7DBB803C90AA6BD69B9FF,
	DataContractCriticalHelper_set_HasRoot_mF82A90FF9E214F51AFE31017AA1926153E8BB761,
	DataContractCriticalHelper_get_TopLevelElementName_m7D80CDE41BDEE879B421A4305F53078E72A43699,
	DataContractCriticalHelper_get_TopLevelElementNamespace_m2DDB324326F391448C66F620808D1004E400157F,
	DataContractCriticalHelper_get_ParseMethod_mE05A477F83994D6FDF7082CD72D7DA8E2A23FF83,
	DataContractCriticalHelper_SetDataContractName_m943E8C3CA5F156F84B9B1C78CEFAB630372EEAF6,
	DataContractCriticalHelper_SetDataContractName_m05A1906F78DCE63B3E565F7C940D64525B999DC3,
	DataContractCriticalHelper_ThrowInvalidDataContractException_m504C17AA06D1870F6F47543EE3032F457269908E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GenericNameProvider__ctor_mED6E4D4774764E36A400A32EE47BA32A435A4D61,
	GenericNameProvider__ctor_m56ACEB4F73A3D42917EFFEC32E519CC33044FBC9,
	GenericNameProvider_GetParameterCount_m0A80CEBA537B9773370CBF0F8EAA924ECEEE794C,
	GenericNameProvider_GetNestedParameterCounts_m584B38E5831E755D4B63B14D52787B6C42F48ED5,
	GenericNameProvider_GetParameterName_mF82356AA0CD6CE8453495A012EDABD834359C3BE,
	GenericNameProvider_GetNamespaces_mDA2DFA5221354CE07D3EA930E72D71FBA88A5BCB,
	GenericNameProvider_GetGenericTypeName_m3D97B1EADAEBB5FD06B4B4390B3B36BF03427A3C,
	GenericNameProvider_get_ParametersFromBuiltInNamespaces_mDB90051E26BA9ADE57B760C27E6FFD92526BD39F,
	GenericNameProvider_GetStableName_m7CABB6AAEA86E44CA6AB28B0F03CB70C7490DC2D,
	DataContractPairKey__ctor_mD6FEB36BB4C3FB5A43C092025F26221D5A17B6FB,
	DataContractPairKey_Equals_mBBC3442B372277340CAC451DC94D47FBD47A734C,
	DataContractPairKey_GetHashCode_mCFFAE318061322C1CFBCD7F154F77A4CE7D886A9,
	TypeHandleRefEqualityComparer_Equals_mCE837830517115C50890E92595A8D1D1F7E511F6,
	TypeHandleRefEqualityComparer_GetHashCode_m6A413F34A230B39EF437801AE85A340D907DC565,
	TypeHandleRefEqualityComparer__ctor_m261B2E6494BF0BF860627AA82082D25C8CBF9D73,
	TypeHandleRef__ctor_m0531D980804EDA2984BDA3CB5774529759625C8A,
	TypeHandleRef__ctor_mB5831268BC56493191CED6CCC45A977E5F29B2F2,
	TypeHandleRef_get_Value_m460E97A65BC7A790BFE6BADDD43A35C7EA461E1A,
	TypeHandleRef_set_Value_m903EE76F200BDA6885C6C7E91E01DEA1BDADFB58,
	IntRef__ctor_m10C215137E3118CCD8817803409C3EB9C62B1A5B,
	IntRef_get_Value_m8756811C1EC9AEA5E938B1425056D31947BF41E6,
	DataContractAttribute__ctor_mAFB75FDCDDBB5925CCE916496408E843E9DDB6BC,
	DataContractAttribute_get_IsReference_mEC2FFE0351B0DD896E7805670D6A614B1AE4C101,
	DataContractAttribute_get_IsReferenceSetExplicitly_m0469F760DCFA622F24F1298F4C9ABE7A053B8624,
	DataContractAttribute_get_Namespace_mA94B4E2DB961605035E012B22E09648236CE8DEA,
	DataContractAttribute_set_Namespace_m98C63DE53771DF8A1A1FD4C33BC508FE1A5B81D2,
	DataContractAttribute_get_IsNamespaceSetExplicitly_m8361D413268F79E5EB798255273710A4335D23EF,
	DataContractAttribute_get_Name_mF5B74CDE4B1F1031F2E53D93C97DC2A9136009C6,
	DataContractAttribute_set_Name_mD6136EF537543C289BE7F68B31EFAE0F0AAC75B2,
	DataContractAttribute_get_IsNameSetExplicitly_m19BA338BCE7ECD3DF5159DF5057E1BB4B8FBF748,
	NULL,
	DataContractResolver__ctor_m6C6DB5E1A3B929FFC671C8CA1562BA9A2920AADD,
	DataContractSerializer__ctor_mDDDA99C695BDBA2039E83662405D89CEE9412ED6,
	DataContractSerializer__ctor_m2FEBF7CC0DB3FF82C40CC16D7ED800FA76248218,
	DataContractSerializer_Initialize_m37C156B79BBAB8F69EC539735DF8292FFBC8F2C5,
	DataContractSerializer_get_KnownDataContracts_mD9B05083CBD12752F5ADD058627D70AFEC8F8CC2,
	DataContractSerializer_get_MaxItemsInObjectGraph_mE82DE78DBA485CCF2418CAF816EC9E06850172CD,
	DataContractSerializer_get_DataContractSurrogate_mDDA9011DE0DBE186A0380F60EC367EFFADE56F94,
	DataContractSerializer_get_PreserveObjectReferences_m9E55A6805D9660F8AE1377DB56160CB1EEA611C0,
	DataContractSerializer_get_IgnoreExtensionDataObject_m4A3062BF5E09D4C45AC7944998C97220B81B5094,
	DataContractSerializer_get_DataContractResolver_mD1F8B01596FFE7202C494BF25AF40C816A3919AF,
	DataContractSerializer_get_RootContract_m9EC579981B3216A1004F58E2C570C4F272D6F89D,
	DataContractSerializer_ReadObject_m348EE7350B992C5BCBB8DFB6F4E3641C5A8960B7,
	DataContractSerializer_ReadObject_mF7649AB7019939ADAF8098F1196AD3F7449E9AD7,
	DataContractSerializer_InternalReadObject_m682E7E4787BC241E6A1F441F31BD501C362286BE,
	DataContractSerializer_InternalReadObject_mBF5428E06638B59C3652652CB5CB3BF034770E51,
	DataContractSerializer_InternalIsStartObject_mCB41CA01C2597086E6A52219426D87C5EDEC269D,
	DataContractSerializer_GetDeserializeType_mD7F8FD75C34D7AF820C69064813C11301AE43A85,
	DataContractSerializer_GetSurrogatedType_m59609D54A16D71713C507B27F547571DD30CAF31,
	DataMember__ctor_mEAC19AE8D3C610B431DE12016BC6190F689F981F,
	DataMember_get_MemberInfo_m2D00DC6FA5407668B519576FFEB0ACADD3B11860,
	DataMember_get_Name_mBC18DFBF135F56356D8D9FCDF400E0B0943742A5,
	DataMember_set_Name_m60C8535A3682967CBB879F4950A60ED78AFFBDC9,
	DataMember_get_Order_m08A84853E2AC3B36434D229BC9CCD2FE95C7D7E8,
	DataMember_set_Order_m34AFA7CB7E4424E034FD230240F033DACD1EB27D,
	DataMember_get_IsRequired_m09F670A4F84861B869C6461A9143C2C5D4147BDA,
	DataMember_set_IsRequired_mA18592F2C87740745380BD69DC9C8018A4F0CCA1,
	DataMember_get_EmitDefaultValue_m5A0B7B7885E875F90FAE5536ABB04FAA146A8CC7,
	DataMember_set_EmitDefaultValue_m17625CA1EEE12698CCD1DF86546D760EDD834103,
	DataMember_get_IsNullable_mB58E9B51E5ABC88B76072FF92A9FE8E7413AE221,
	DataMember_set_IsNullable_m8FB9E9344616BC5EA0334C6B1834B6500AB9CB83,
	DataMember_get_IsGetOnlyCollection_mC1E55FD7D4F064490F8FAD558AC19D10B5A303AE,
	DataMember_set_IsGetOnlyCollection_m71FBD15C44290B6CD193172316304F844C2D2B23,
	DataMember_get_MemberType_mBD523A251037D594AC4B804FC7DC2EB3F4C059C2,
	DataMember_get_MemberTypeContract_m359A925E8C24546B367B28FB7F682997965FB29E,
	DataMember_get_HasConflictingNameAndType_m9C4702C5DD4B50AC86E06FF0F343D1C1A1B8431F,
	DataMember_set_HasConflictingNameAndType_mE50807865FA12770A89F6D4A113C2F958FFF8E37,
	DataMember_set_ConflictingMember_m618AA80151D69F18A9EAF3E82578BBA9D0D0956C,
	DataMember_Equals_mBDE715AFA065D8ABFFD55A7B0DEFB37C90F65A31,
	DataMember_GetHashCode_mDF33BC8C960DE7F4EEB5963EBE56F84053C4C3FC,
	CriticalHelper__ctor_m56D4FD316C9F32FB04C3035983683F462A7DE81B,
	CriticalHelper_get_MemberInfo_mBFF4A8E489ECF504D4C2307DF197EBFD070F2958,
	CriticalHelper_get_Name_m07182ED6F48E985F8A1DACDBFB5A56EA5FCF202D,
	CriticalHelper_set_Name_mD30834A46D36D37D2D48BA2133631DF8D295A374,
	CriticalHelper_get_Order_m14460CF7BB726B88E3167A7A6D655F8D81A3DB3E,
	CriticalHelper_set_Order_m4D8D4556E9A30FE21739E52E4C5CFE02F0A84625,
	CriticalHelper_get_IsRequired_m4D5FCFE49E81CF399CE7EF8794DD14E1F66DD870,
	CriticalHelper_set_IsRequired_m193C96DFA95764FED87B6C12DCD59AF0830FD2CA,
	CriticalHelper_get_EmitDefaultValue_m30CFD7B0FF1C67DC4D9F31CAF296616F8DFE8934,
	CriticalHelper_set_EmitDefaultValue_m9362B6F9928CE0706422D985F5A4D8DF21132BE6,
	CriticalHelper_get_IsNullable_mADB88A5C0FB9720D17BC0A16C3147A2309334F7F,
	CriticalHelper_set_IsNullable_m8ABE78265D7EF2CDEF2DE7FB0531691728062370,
	CriticalHelper_get_IsGetOnlyCollection_m8A6FBDDCCC79D46FF6231D73A3BE361B7E1F8DAD,
	CriticalHelper_set_IsGetOnlyCollection_m967066E7EDE35AB7BF89F530C26AD31D2A44473E,
	CriticalHelper_get_MemberType_m1E958DA4016FF0D8E0C5D9EB995EB10B9AAF7904,
	CriticalHelper_get_MemberTypeContract_m9C3BE50045944B5487E6DF872DE68489027F3324,
	CriticalHelper_get_HasConflictingNameAndType_m3C539480D1D2C0A38DF68EDA97C13D7C4717BA66,
	CriticalHelper_set_HasConflictingNameAndType_m603F0D858137881A458ABED7CAC0D32B9AE5D228,
	CriticalHelper_set_ConflictingMember_m609F51CDF9B1F1C8F21F538D033ED3213A651864,
	DataMemberAttribute__ctor_m077F867534BAD9865D6DD156A8FBBB4068283A42,
	DataMemberAttribute_get_Name_m8C4BF39A517D901076BAFF6FF89DD53C5F4B2B3E,
	DataMemberAttribute_set_Name_mCF9CB9ED10BD17E99D79CC5CA33431F2135971DF,
	DataMemberAttribute_get_IsNameSetExplicitly_m8B86CDF8508757C42320626F5A1F39E558F32EDE,
	DataMemberAttribute_get_Order_m34D8C756AE07BD345011D887546DF54D71898956,
	DataMemberAttribute_get_IsRequired_m318C586E28E349EA87096FE6FE473B4C4FD58C73,
	DataMemberAttribute_set_IsRequired_m660325F5E5D02CE9563D6E28CBC725A90ED63078,
	DataMemberAttribute_get_EmitDefaultValue_m430708B4CFB34DD522B6D01A66CE8FDEDCC088E8,
	DateTimeFormat_get_FormatString_m82144F58064C23C043221BC3DABE5C310428E450,
	DateTimeFormat_get_FormatProvider_m80F01972A865D14871A399F1CEC6051C60BE9B33,
	DateTimeFormat_get_DateTimeStyles_m676E25C0170328EBD595B9BE207179D7CB451F28,
	DateTimeOffsetAdapter_get_UtcDateTime_m39D5B6ED19930CBEB27FEA343255E90F2622D942,
	DateTimeOffsetAdapter_get_OffsetMinutes_m1ACFACA778391AA85C1C2F52337183E56B276F03,
	DateTimeOffsetAdapter_GetDateTimeOffset_mD78CF5AF0C81E1C755C772282C5424EE22F4AAC6,
	DateTimeOffsetAdapter_ToString_m7E7AC194BF52459160D5B64DC0C61D3F62896F6C,
	DictionaryGlobals__cctor_mB9FA129BAAE651E3F3175B59B659E3C3E7D839F2,
	EnumDataContract__ctor_m204F1FAAC423DA8A07AD3AD4E929F796150191EB,
	EnumDataContract_get_Members_m93BDD805F0F4D4FD6B8F555FF2ABC024801056B8,
	EnumDataContract_get_Values_m7EB6E78D871D792ED97B4BF7D6E0282AFA9079D1,
	EnumDataContract_get_IsFlags_m87131872D459F74F40974802B8EECD62125D16C0,
	EnumDataContract_get_IsULong_m35455CE4C71BDE2D4C8D4ECC05801BDE3E927650,
	EnumDataContract_get_CanContainReferences_m7C519397D3C6F8B299D94668FF0AF07AE61B17D5,
	EnumDataContract_ReadEnumValue_m305B3E194C620D02DF8739FA4ED0D5B1C316B545,
	EnumDataContract_ReadEnumValue_mC4243AF8CC8681AB2AA1571727E306B49FCFD06B,
	EnumDataContract_Equals_m7AB4B182AFE64DEA57AD4F34D9D7DF9E9D7F3318,
	EnumDataContract_GetHashCode_mCD18D46B195BD3B1CD78A3F459119B2B88AD8A8B,
	EnumDataContract_ReadXmlValue_m665D893DB8042FCD0CFDC124BDF088C3D7992B14,
	EnumDataContractCriticalHelper__cctor_mB876E15592C2D7F899FEAB82E894A1E0E63B9135,
	EnumDataContractCriticalHelper_Add_m388921BAB3A6752D22E01FEE44BF286C4EF0AFD8,
	EnumDataContractCriticalHelper_GetBaseContractName_m60D5DC53CC701C5CC3DED1D92E33F59F84C24836,
	EnumDataContractCriticalHelper__ctor_m7023C0597BFB9DDACDFE46369458440738885ADE,
	EnumDataContractCriticalHelper_get_Members_mA4864717BD92770470397464BCE8D4325BB19BB4,
	EnumDataContractCriticalHelper_get_Values_m70F4A0E90A6A09997E2B3F47188F0D44257FE45D,
	EnumDataContractCriticalHelper_get_IsFlags_m388F95377CFA6E11726A5CD23FCD82FBF1201F30,
	EnumDataContractCriticalHelper_set_IsFlags_mAC919BF7D3E5D378EF2A908CBA026F0E702E3A06,
	EnumDataContractCriticalHelper_get_IsULong_mDB91038EA68BB668F11E6DF92A9E1C1FAAA5FDF9,
	EnumDataContractCriticalHelper_ImportBaseType_mBBEA31C00A932FA6968318492ECB559AD24F096F,
	EnumDataContractCriticalHelper_ImportDataMembers_m5413CA1B3095C3C6A353C610C80988F6A4FE6918,
	EnumMemberAttribute_get_Value_mB41126B613B9FD1CD8A05D08FCEC4B6663864BE9,
	EnumMemberAttribute_get_IsValueSetExplicitly_m76EB4379A96CAF01562D8665018EA9D144DB69FA,
	ExtensionDataObject__ctor_mF097D712BD9FFEACB8D2F6F7C6F6DEC5AE31B2D9,
	ExtensionDataObject_get_Members_mBE275C0D5CDB974BFB0FBCE8BCF56800C6D85ED5,
	ExtensionDataObject_set_Members_m5730F07D4A09E1985C603EA406259479207EE250,
	ExtensionDataMember_get_Name_mA3D59F779C4D6B8125F6167A9261DD3DAEFCADAD,
	ExtensionDataMember_set_Name_mCE9A935CF0A0728BB09805B01C1D0BE59155E156,
	ExtensionDataMember_get_Namespace_m6E730ADD37BAF0B76BE7C69CAF5AE81E16720F86,
	ExtensionDataMember_set_Namespace_mBCB58D1AB6994DD5E28CD8BD0C15248B6DDB2366,
	ExtensionDataMember_get_Value_m53DBE8139C4178688183D4128C49A0F77816A06B,
	ExtensionDataMember_set_Value_mBDADBE9990D392656C61EE2126B95E39660CC7C3,
	ExtensionDataMember_set_MemberIndex_m959A643C72BDF915E03559B3DAF4958D382D9B91,
	ExtensionDataMember__ctor_m62922A523662394B3FBEA773617926492DD55A0E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ClassDataNode__ctor_m282D5CCB65E7DF23D7F0640EF66E988A54958B69,
	ClassDataNode_get_Members_m8D5DA6B2D8C7F5A9DE79B5697007AC2B32D3FED2,
	ClassDataNode_set_Members_mA1137CAA3CFB9D7052E8A6608CE02E5E63AF45F3,
	ClassDataNode_Clear_m1E7685E25755F5A1F6348DB4FCD524CF74537327,
	CollectionDataNode__ctor_m8437996FF88778A13F7CAEC30445AFBF32DF527F,
	CollectionDataNode_get_Items_m461D938C7315F6ECFB5D3E1844577699A10B7ECF,
	CollectionDataNode_set_Items_mBB0957B4C26EF2CD3D0D846F999465AA92FA3869,
	CollectionDataNode_get_ItemName_m7A50DCFBDD5A2FBAE593B1031C698D0A6F89F16A,
	CollectionDataNode_set_ItemName_mB65D8BEEDDE3B53CA459700ECDA74DED92AEC82E,
	CollectionDataNode_get_ItemNamespace_mA359CC1A70E02276129F05EF1E86C17FE4897237,
	CollectionDataNode_set_ItemNamespace_m9AF00F0FB66B99DBB3C1AA4F56FAB0C1A0A24C9E,
	CollectionDataNode_get_Size_m00B1B83F57D9E43C0193373713CD103BEA191A6D,
	CollectionDataNode_set_Size_m5231C354852EF9A115EE88167AF83FA94ACF7B19,
	CollectionDataNode_GetData_mF13B16A1773C02298B8571A1AB8A2A0B83A6D54F,
	CollectionDataNode_Clear_m9E13D55649207AAA0C8F6911A43A8791E5995895,
	XmlDataNode__ctor_m1FCD0F1409C622D7B0B6F5D7B224256F91FD185E,
	XmlDataNode_get_XmlAttributes_m56377CB7E8C4EBAB87DA279DB6B9564C1B4DAD57,
	XmlDataNode_set_XmlAttributes_mC2F00E7514659A5887D5C62BEBA0CE8D12119487,
	XmlDataNode_get_XmlChildNodes_m778F074CFFAC5DED6B546E101B9339965EF27343,
	XmlDataNode_set_XmlChildNodes_m2CFE7AC0F53073358CB046E9D40945660D942EBD,
	XmlDataNode_get_OwnerDocument_mC1ACC6907BE82F28375B433F5CF61E8DE50BDAD5,
	XmlDataNode_set_OwnerDocument_m102B2E441084099000B7EE064A812DDEF0497178,
	XmlDataNode_Clear_m5D0CCD8D9D85A0413428D6D5CB6618ACB66E0F04,
	ISerializableDataNode__ctor_mD939F56613046B2D049511CECB876F7D4C640DD3,
	ISerializableDataNode_get_FactoryTypeName_mE7E348D7FC2BABD38B486669410D03DCB2D33933,
	ISerializableDataNode_set_FactoryTypeName_m0947A9067E581122258BC10EB72CA983E0B2C0D7,
	ISerializableDataNode_get_FactoryTypeNamespace_mF98B4F318E1CCDACB25310EA42D0325662609999,
	ISerializableDataNode_set_FactoryTypeNamespace_m98BD435742708B6826B4816FE92317E4E1D5708B,
	ISerializableDataNode_get_Members_m3C127992D4B10D67FE24A7CC070CC2368DB907FC,
	ISerializableDataNode_set_Members_m4CA2BEEED203EAAB6B77AAA4C6E6E56960BB9ED5,
	ISerializableDataNode_GetData_m66A9B93A3C1339A24C0049FA861946BECD033CFB,
	ISerializableDataNode_Clear_m8C136DE8FECA8EE38D03B48FE65BA41088597EB3,
	ISerializableDataMember_get_Name_m062A3F0DD1357527E368758D20B4DC0AEDC65819,
	ISerializableDataMember_set_Name_m9DAADA316AAE0DA467A10F1BDD0C2EE836B8EE39,
	ISerializableDataMember_get_Value_mBE6B086C95B1F81827A219B2361BAB3850BD7D4C,
	ISerializableDataMember_set_Value_mE369EB65A7A829AB5FF8EA245EDD480AC146AABF,
	ISerializableDataMember__ctor_mBF9BFA10EB9968DC73E44EAE88E88E05942B4D09,
	ExtensionDataReader__cctor_m839B443444122F98002363C4F4EF4B4C2DBD9054,
	ExtensionDataReader__ctor_mB54CFD5A8537EEC255CDFEB0BC2EA971DB39169A,
	ExtensionDataReader_SetDeserializedValue_m13EAD431D03BC296D301B0253A5E27DB5C483911,
	ExtensionDataReader_GetCurrentNode_m053C86EACB5D1619B4DF2EF5B289972712FADED4,
	ExtensionDataReader_SetDataNode_mD8D95D1BBE0D23D45A6FD9ECACC2774A7974ACB0,
	ExtensionDataReader_Reset_mC007BF9DF58DFFA1CB2C6CDEF4580E55F774E5CB,
	ExtensionDataReader_get_IsXmlDataNode_mC37FC2CE390BAF4FE05E7026F988F753EE17E703,
	ExtensionDataReader_get_NodeType_m4B825025BC52970613CC0E704B5FC9AAEEBB6950,
	ExtensionDataReader_get_LocalName_mF3CBA7EA4ECFBC4A84A6D8AF9CA1526B9E70768E,
	ExtensionDataReader_get_NamespaceURI_m5C9AA50DAC27E3B843938530B914F458BA96C36B,
	ExtensionDataReader_get_Prefix_mDA6006B6B7056E6C9E7E087E94D9F9057CC58FD5,
	ExtensionDataReader_get_Value_mC93F0B9FB9A15D091A47BD08B06E806C1FDC641D,
	ExtensionDataReader_get_Depth_mD8A15DA6F74192AD5742F2E89B43D5C674CE22C6,
	ExtensionDataReader_get_AttributeCount_m3184A93E4A6F9C647716DCB674AB6B36CAD199E8,
	ExtensionDataReader_get_EOF_m39CE262A7DED0F5886FE76F19114D62AA9B10F3B,
	ExtensionDataReader_get_ReadState_mA566186F3645E3B4AB3837721283F525C5D58999,
	ExtensionDataReader_get_IsEmptyElement_m75481787492D37B952B64A9B7454A09DF24B8A2C,
	ExtensionDataReader_get_IsDefault_mDEC07FB38DF3F9C61A8D64D115EE92BDC4659C6F,
	ExtensionDataReader_get_QuoteChar_m852CB9025D106EAABC41FD265551A18EB619F17B,
	ExtensionDataReader_get_XmlSpace_mEA37C6C4EA3F6776D1953338017BAD773496E90B,
	ExtensionDataReader_get_XmlLang_m7B68C165EA5C4EB81751088F118F59347B2EE279,
	ExtensionDataReader_MoveToFirstAttribute_m5344934D0EA31A423ACDCA23A580D450A5C1B580,
	ExtensionDataReader_MoveToNextAttribute_m9A7B9D794A519B35DD932FCDB80E97F57CA54552,
	ExtensionDataReader_MoveToAttribute_m449420456C13DA4F0CA2A94D6E8362DBD733D628,
	ExtensionDataReader_GetAttribute_m705868F0F7DAEB9CF2198D1B1DA9646954D0653A,
	ExtensionDataReader_MoveToAttribute_m808730F93B7AA5C38EAF59214BB91F8A7D137768,
	ExtensionDataReader_MoveToElement_mD1D2782C77567A10D3CD00D34A6625B2291E58B6,
	ExtensionDataReader_SetElement_m23388DD6A1CB8C3A896CB4AA9E7B3942DCE70B8F,
	ExtensionDataReader_LookupNamespace_m7307CE855A0B76F411463ABEAC4FCB5A0FFB15EA,
	ExtensionDataReader_Skip_m9C9C872F2048DF3B20A30B5265F74068E85E0795,
	ExtensionDataReader_IsElementNode_mCD7C6030CA6D85D5D6A3C0F7FCCC6655E2FEA49D,
	ExtensionDataReader_Close_m9B79599FCD2CA59D7C65062C4A6A31F7A46F1091,
	ExtensionDataReader_Read_m199A4722C2FC8A4F8863CC64CF168C370AB875F1,
	ExtensionDataReader_get_Name_mF9F9AC24656BBD07A29B7BEE7C8C6A39573F9AAF,
	ExtensionDataReader_get_BaseURI_mCA539F24B6EA4D5BF5A6F1B202C9ABAE138B60C9,
	ExtensionDataReader_get_NameTable_mBDB125A2AD4F4F146B3F7A568B124618EA991095,
	ExtensionDataReader_GetAttribute_mE7EC9573E5ECB88214FBC640B562B435BE9982B6,
	ExtensionDataReader_GetAttribute_m6C990B9C53A6D6DD9A805C84C39D05D2F0F656CD,
	ExtensionDataReader_MoveToAttribute_m99ED4769ABD3FA56AD3FF6256C58C49AA8987616,
	ExtensionDataReader_ResolveEntity_m4F9434F7359571C5362A6A37E9DB34EA87D28E10,
	ExtensionDataReader_ReadAttributeValue_m15DE12EE7A8F76F4990C03617BA4B6CB2BF3B0D4,
	ExtensionDataReader_MoveNext_mE0AF59CB6C105B9166E6506404818DC671810AFE,
	ExtensionDataReader_SetNextElement_mB70C2444DDF40B71DE24589EA02DFFD923E6EC27,
	ExtensionDataReader_AddDeserializedDataNode_mDD326EB14C39B17CCCA5FCE7A1410E5461042EA6,
	ExtensionDataReader_CheckIfNodeHandled_m12411633BEC1BD42C008A5D08EE28171EEA58410,
	ExtensionDataReader_MoveNextInClass_m528CA888E8650126E9801538743B605D92CC072F,
	ExtensionDataReader_MoveNextInCollection_mDAC3EEAC85B933B22779FFAC1555AA41BC41C05F,
	ExtensionDataReader_MoveNextInISerializable_mDE56ADEC7BB0EDD1EF5CB598BBB73963FA78F91C,
	ExtensionDataReader_MoveNextInXml_m3456B68604C97B7A9FF261255E4BE1D047CD2A72,
	ExtensionDataReader_MoveToDeserializedObject_mAB97DE1C3965BFD29533FEECEE2074D51AAD71CD,
	ExtensionDataReader_MoveToText_m61169888E45A6F1FC79F5045292BBCD9770023E1,
	ExtensionDataReader_PushElement_m03A5B348C1AF268BA7EB866379231C3D66533BDB,
	ExtensionDataReader_PopElement_m1C1DEB0F1A06E24D744FD77AA3A550E8E8D16CFC,
	ExtensionDataReader_GrowElementsIfNeeded_mF765C63A03410D24F0E91264046FE849B23411C9,
	ExtensionDataReader_GetNextElement_m93E03F7C66043F7D97F16E922715C37CEFDC9467,
	ExtensionDataReader_GetPrefix_mED296B7F49A45A30C9D5BB4758CB0F43857F590F,
	ExtensionDataReader_AddPrefix_m1320A0FE49ADB77038EE426CBB148B8884830E21,
	AttributeData__ctor_m24890B9610DEEC2193027AA735381FD145608A47,
	ElementData_AddAttribute_m24C1277B7F19F8E0F713B12A12D3B3F56F52EF28,
	ElementData_GrowAttributesIfNeeded_m5B36DA990563BE4FEB15BF4CB23D00C227B9CB5B,
	ElementData__ctor_m4C5A48B14A41183637767ECAD284579650BC466C,
	GenericParameterDataContract__ctor_m62DBE6D257EA97FE782445DF8FB17420B8D62658,
	GenericParameterDataContract_get_IsBuiltInDataContract_m7B2122C972E2F77A289B347DCB55BBAB0775B0CA,
	GenericParameterDataContractCriticalHelper__ctor_mBBACB630C3844730B7B71F2FEC50186386EDD0F0,
	Globals_get_TypeOfObject_m821DC2E38514A362610C86CC23EE8E672A31DAF7,
	Globals_get_TypeOfValueType_mBBCEE4136A04605CEBB2DD290A58C419145CB969,
	Globals_get_TypeOfArray_m8846ECC7D44EC3E09798769E7335B35610E807E2,
	Globals_get_TypeOfString_mDA6D206966E9D0DA7D977E01D6BCD15108CD2083,
	Globals_get_TypeOfInt_m6C80173098F1DA80D11904E43CAC20B4228C310F,
	Globals_get_TypeOfULong_m112B4EF74D19C4207CE415A0B53461575409F350,
	Globals_get_TypeOfVoid_mB3A475FF906780040B4F97BBF0225044D907278F,
	Globals_get_TypeOfByteArray_mC3DEFACB2C260F2DA1A3F92499F93EA742528B8C,
	Globals_get_TypeOfTimeSpan_m660900ABFD7F46D3FA9A0C918D313AA68CC893FE,
	Globals_get_TypeOfGuid_mF300AE08E67E9B61027794A2EBFE90A4F1FA9139,
	Globals_get_TypeOfDateTimeOffset_mF3C7BFB68C1CB22F5D4B23C503B290DAD00555C6,
	Globals_get_TypeOfDateTimeOffsetAdapter_m3B63812849E2F7F2E02707B0B1E2C89E980EF9AA,
	Globals_get_TypeOfUri_mB863C6FCDB48C6DC281FDADA2B93D140654D0F52,
	Globals_get_TypeOfTypeEnumerable_mA2ABDCB60A7DC4DB6DD722CE682D606D215B6F54,
	Globals_get_TypeOfStreamingContext_m83C0D9B4846579A596C7B784367DEC04EA780D2F,
	Globals_get_TypeOfISerializable_mCD2A131F3322C8D4BA63852359597FDF078378DC,
	Globals_get_TypeOfIDeserializationCallback_mD1F6CFA8EF959646AA89C4ADF29C76FA40F23806,
	Globals_get_TypeOfIObjectReference_m757245111BFF254967FD5E42655E226335053742,
	Globals_get_TypeOfKnownTypeAttribute_mF99EF58E93B2A62A57C59ED6732E79A8C5ED7532,
	Globals_get_TypeOfDataContractAttribute_m4C6AE42C76F8C38E258C6778460BE19C03FAE770,
	Globals_get_TypeOfDataMemberAttribute_mC09F1DF4F1E08B5C3C0E0A5A5E912E1E94EEDA51,
	Globals_get_TypeOfEnumMemberAttribute_m9C560E3F90962B3E0E637FEAD994C57DD652F541,
	Globals_get_TypeOfCollectionDataContractAttribute_mDD1AE5FC7181F83B495EA189E501949B4D4D8CEF,
	Globals_get_TypeOfOptionalFieldAttribute_m78EEA3791B94E671962653900E8467145DB9C2C7,
	Globals_get_TypeOfObjectArray_m4A105D00ABE2B8AD57C5628C44BC69201A7DDFCF,
	Globals_get_TypeOfOnSerializingAttribute_mA7D6B606181512E7BF2136A991DB9BB0B74D18E6,
	Globals_get_TypeOfOnSerializedAttribute_mE7A62B796FA0DF7E5AD0588238627FA00CD97C9D,
	Globals_get_TypeOfOnDeserializingAttribute_m5FAE50465E9CD964BA7AEE14267A783C11550A7E,
	Globals_get_TypeOfOnDeserializedAttribute_m3020247F18C0D50EC8C85A36E7D4CA8750B77873,
	Globals_get_TypeOfFlagsAttribute_m15B5124E4630FB606188EC938783539BD5BF7BDF,
	Globals_get_TypeOfIXmlSerializable_mD205166C6082FB26FD4506389A1918F842C26AE0,
	Globals_get_TypeOfXmlSchemaProviderAttribute_m6E99D68CF1366F02293DD4AF2621C96496F19C13,
	Globals_get_TypeOfXmlRootAttribute_mD6F94A7B4DBE08BC5D60578B2726DD13D10C72A6,
	Globals_get_TypeOfXmlQualifiedName_mE8F51EDA34542512C71EA7A473A17C064F468606,
	Globals_get_TypeOfXmlSchemaType_mD1981EBAB7721B04DAA0CBA70DC554B8F07DD95D,
	Globals_get_TypeOfXmlNodeArray_m89055C4F845577B4F40D9CC350C69201CA870536,
	Globals_get_EmptyObjectArray_mFC912C4CEA3B19FEE703F1C277857D8EF82AC447,
	Globals_get_EmptyTypeArray_m5E2444A2AD08F138D0D7550BB8E3075FF89E6673,
	Globals_get_TypeOfIExtensibleDataObject_m26FB4439AA3AE12A3B25E667EC33FD929A35C1EB,
	Globals_get_TypeOfExtensionDataObject_m2432B9DAA370A6836672468850D626336ADAB851,
	Globals_get_TypeOfISerializableDataNode_mC382B873595EC09498D00325F844BE2B92E8737D,
	Globals_get_TypeOfClassDataNode_mFC1502378635430225B06C79C781CE3ECA4AFDB2,
	Globals_get_TypeOfCollectionDataNode_mCB3CB8D7A2B35A2D17F094F621808BEF250D51C0,
	Globals_get_TypeOfXmlDataNode_m91F9D1C7F196A5CE6C65DD9B5527187C2E74650B,
	Globals_get_TypeOfNullable_m8C368D6B7E3450342ACA2215E63F76C893E9995D,
	Globals_get_TypeOfReflectionPointer_mFC9D4461CC323FD38FBF9B93AEEEB1B90F96DC63,
	Globals_get_TypeOfIDictionaryGeneric_m270144C1FDD0C11F88AF1BBF8F7F8D981D474A72,
	Globals_get_TypeOfIDictionary_m6B39844438359096667CFA03AFEBB5D24E71162E,
	Globals_get_TypeOfIListGeneric_m79C32B6A5417AD653FFB65ED6214744A79E4399C,
	Globals_get_TypeOfIList_m56A41A3FDA376FDB072E64F8A112B550FD749D04,
	Globals_get_TypeOfICollectionGeneric_m8E7D618EBCE31FEC94EE1373DEC575CD05AC5CFD,
	Globals_get_TypeOfICollection_m1211961FE5E4BB78B3FADA7963823C782094FEC5,
	Globals_get_TypeOfIEnumerableGeneric_m5D4DCA2C8551F9507AB692EEBA1A9A807BF6A777,
	Globals_get_TypeOfIEnumerable_m8F00F1739B50215C507F1CFF3A0E380AA20CBCB2,
	Globals_get_TypeOfIEnumerator_m30D2EF76635C4A3C34CC6FAD98B347EA645214C7,
	Globals_get_TypeOfKeyValuePair_m9D7B32E478D122592E7E0230C49B43912107B62C,
	Globals_get_TypeOfKeyValue_m089699914EF2105352218553C7FFB52BB22D1F1A,
	Globals_get_TypeOfDictionaryGeneric_mFBCAC45C3BCAC574B166191934475634B390BE28,
	Globals_get_TypeOfHashtable_m9687819C4ABF1619960846BFC08803329DD98BF4,
	Globals_get_TypeOfXmlElement_m00545F53F686DC8E53C8C2E119AFC8E15CFF1173,
	Globals_get_TypeOfDBNull_mA106905BF4FA8186420C8EB63A5B3C167EDB97A6,
	Globals_get_DataContractXsdBaseNamespaceUri_m41DC518CB28E20D3B36E21BCCF8AC6E36334196E,
	Globals__cctor_mCD1AC5EEF827EE74F31C37E012156C297766A184,
	HybridObjectCache__ctor_mF59F29E84793641F3935AC5FD5427869103C8AED,
	HybridObjectCache_Add_mD243DC29A2F1B4D8DD9C33D209366871A8E1C4B7,
	HybridObjectCache_Remove_mD4C9581D63168B232F0905CD341727003546E5D9,
	HybridObjectCache_GetObject_m372D40FB61273072D24F6B1C641E9FC1E6213EB5,
	HybridObjectCache_IsObjectReferenced_mF7EFF705730BC9AD4F33CF9D3E71C31D73594D5B,
	NULL,
	NULL,
	DataContractSurrogateCaller_GetDataContractType_m716190FF34EB41BA2588F9125145A2C1BDA4B2D0,
	DataContractSurrogateCaller_GetDeserializedObject_m20606E9278D704C3C7D7D4DE8FFFE0DB79CA5E03,
	NULL,
	InvalidDataContractException__ctor_m1B7907967BE71E252FB194B48A5BAC81EBD7A497,
	InvalidDataContractException__ctor_m6C50A1259C6FD9C49EA59E0905FBCA103A472559,
	InvalidDataContractException__ctor_m4B8827EF5D454CB2E44460D237769C1067C198B8,
	JsonFormatGeneratorStatics_get_SerInfoCtorArgs_m99046D52803F8762D8EF8708CDFEF81C888584DB,
	JsonFormatGeneratorStatics_get_UnboxPointer_m3B478CE0F2273247E882E9E842AF5AB9169B765D,
	KnownTypeAttribute_get_MethodName_m03E297427311467FB8100421938FDBED0EF636F9,
	KnownTypeAttribute_get_Type_m5793D02AA0710114CED2E116FE487AD50FD97EB1,
	KnownTypeDataContractResolver__ctor_m0390C45BB89B4F852FCF096DE0C839EC73C05CEC,
	KnownTypeDataContractResolver_ResolveName_m05DF26BB60FF472DAAF911E44888B07BF0A630FC,
	NetDataContractSerializer_get_UnsafeTypeForwardingEnabled_m64837E5264C34A263EBF0C76ED1F2DBC8BB8FBAA,
	NetDataContractSerializer_ReadObject_mE38EEE65FDCD7BCC22D197E32B7CE40840C8C555,
	NetDataContractSerializer_GetSurrogate_m5BAD3BAFD8F4446E62ECF9FA0F054A42A59A234A,
	NetDataContractSerializer_GetDataContractFromSurrogateSelector_mF676988FF163F5FE901D107468587324D8BAAF28,
	NetDataContractSerializer__cctor_mF858EC3A27A0C8956CDB6F1BB0BEA117D17694E7,
	PrimitiveDataContract__ctor_m146C4E5AB0CAF99F9E39CC48708F6006F05CC192,
	PrimitiveDataContract_GetPrimitiveDataContract_m9B979CE9A15C991C6779E3D158BE04EC762AADE9,
	PrimitiveDataContract_GetPrimitiveDataContract_mD1EF14FB4CE2468A297C0F3BBBD8E232BC5143A6,
	NULL,
	PrimitiveDataContract_get_TopLevelElementNamespace_m3A41D206646AC6B8364A850B1EC5FAA59A26C4E7,
	PrimitiveDataContract_get_CanContainReferences_mEBEF354DD613240A2C90A1F962105E16B9F928C8,
	PrimitiveDataContract_get_IsPrimitive_mE1FE00D7006F12F99656CA1299E93DAE50E4AAF4,
	PrimitiveDataContract_get_IsBuiltInDataContract_mD852FBEFE8499A0A44E1BDC44C393B815639BD2C,
	PrimitiveDataContract_get_XmlFormatReaderMethod_m409918693BD1BD22A0C07F08D41CF1FA72BA8332,
	PrimitiveDataContract_HandleReadValue_m7B5E7A077F26AA47E35CB5619A5A31D6DB9D89F9,
	PrimitiveDataContract_TryReadNullAtTopLevel_m412A9940AA966C6ADCC8F0405ADE05F16B2CE656,
	PrimitiveDataContract_Equals_m882A3BEFF9635F1F43FE2EE50FD725CB2FA24FCA,
	PrimitiveDataContractCriticalHelper__ctor_mB64045A030B77F8C5B11C58523B769610593744A,
	PrimitiveDataContractCriticalHelper_get_XmlFormatReaderMethod_mB0CA0E901BEF0AD753B307AEF0872A6D3ED56F22,
	PrimitiveDataContractCriticalHelper_set_XmlFormatReaderMethod_m75BB08C3A1CD3F4F1D456D86CEEA31E1DB3715BA,
	CharDataContract__ctor_m2B0F1D8C7274D39ABADBC690505814B7668D9AE6,
	CharDataContract__ctor_m4313EFE361E7C3BBD9DCB417EA2C61EE4EE08F5C,
	CharDataContract_get_ReadMethodName_mF5F3558A682F847D94E860A1FAAF3E32A41EF74F,
	CharDataContract_ReadXmlValue_mE372966086CDCBA43D902A0538F1A2F962CBF20D,
	AsmxCharDataContract__ctor_m287D290FEF66B61B95029EB10B383E208C41E51F,
	BooleanDataContract__ctor_m1575CED4A6C16F86C3930DDE9CECBEB2DBEE83B1,
	BooleanDataContract_get_ReadMethodName_m5DA8FBFC935A7D571FAF6E7561A96EDA6E9CDECE,
	BooleanDataContract_ReadXmlValue_m78400BA87293DB4813B65F0E67E4DCEB91AE58B5,
	SignedByteDataContract__ctor_mC7DE5147DBB698FB077C86DEE323529912584A52,
	SignedByteDataContract_get_ReadMethodName_m24C57DB181EDCCAD07BFE1B36427EE791F00CB3F,
	SignedByteDataContract_ReadXmlValue_mC7FEA4B2BCD1F7BABC5E2BDFE661615C8DE118F4,
	UnsignedByteDataContract__ctor_m5E8DF24C41C19DAA4BD320501EFE5E614FE0516B,
	UnsignedByteDataContract_get_ReadMethodName_m9161A3DE99814644C1786710B319F48ABB436837,
	UnsignedByteDataContract_ReadXmlValue_mBB05641F0ED643E61E0876E5DB433B4D3D795761,
	ShortDataContract__ctor_m7B82F08EF0F673A5533C98F53F3321F813FA55AA,
	ShortDataContract_get_ReadMethodName_mECBACD49D537AEB52993E5280A89027827306C79,
	ShortDataContract_ReadXmlValue_m99DA88FAA4BAB01C9B5F7395707BE012C0EB3878,
	UnsignedShortDataContract__ctor_m8B579FABAA54E1F6ECF2EFCEDD51794700DAE856,
	UnsignedShortDataContract_get_ReadMethodName_m517DF5B0DB96D51045F751B0A4B25C7527388204,
	UnsignedShortDataContract_ReadXmlValue_m78D050D634ABB2FE70293EA1EBC5F0388377C7CC,
	IntDataContract__ctor_m4227B3E8F879241B92C6BB3E7453E019A244B956,
	IntDataContract_get_ReadMethodName_mBEEAD3CAAF520763357DF1390377558035AF05B4,
	IntDataContract_ReadXmlValue_m8492B7D5061C1639E32D3D9753302DB50A15978A,
	UnsignedIntDataContract__ctor_m8716177EF29CC598555EDB24717D5169FD7E9903,
	UnsignedIntDataContract_get_ReadMethodName_mBC8ADC4FBA21FC8B3BB812D4FC6AB1F463A0576E,
	UnsignedIntDataContract_ReadXmlValue_mC4097BB24D8B27DE42CAFC77163C0FB9BE137CC0,
	LongDataContract__ctor_mA6CC865BEE3F8CB9EAA001A7CE2F0AD2F136A5AB,
	LongDataContract__ctor_m9261B2651DA93C33A0AEC30FD379D4611F6825B7,
	LongDataContract_get_ReadMethodName_m8384B7F402A0CAAA856507BF44394C23659A7DFB,
	LongDataContract_ReadXmlValue_mA31F1D07CD0D1D47065D1284870BE6800BFB45BD,
	IntegerDataContract__ctor_mDFDE3B1AD72C7EB53169D47720CD557F8A5F1993,
	PositiveIntegerDataContract__ctor_mA1CE70333C73BE0986989721591E160D3ECC143E,
	NegativeIntegerDataContract__ctor_mE7753FE60AA2988087072BC9F6ABF0D01E1FD120,
	NonPositiveIntegerDataContract__ctor_m8165A54225F99393823396870B6B556F6BFFC639,
	NonNegativeIntegerDataContract__ctor_mB5976EAAC2280BA072B14202B2F4E91186BCC2E1,
	UnsignedLongDataContract__ctor_m395DA01C4F93D59503800860AAC8DB3F6F4E9545,
	UnsignedLongDataContract_get_ReadMethodName_m8A49C2BA7EB7D4B09EA0B85A071FAB5D3C14B8C7,
	UnsignedLongDataContract_ReadXmlValue_mB0DD0B8A69580AF2A8A288C4121FAF5EB75C310B,
	FloatDataContract__ctor_m5F758CF93725803C2010C17B40400737D901C957,
	FloatDataContract_get_ReadMethodName_mBCB4C14564866266213150261DA0581CC0EE02F2,
	FloatDataContract_ReadXmlValue_mEA5EAD723784C0275BE4706C8706611DB6F98C85,
	DoubleDataContract__ctor_mFB622F6BE2ACD6940BA603B528C912572307412E,
	DoubleDataContract_get_ReadMethodName_m53760BC810B2F59E5A739EE09AA061738F47C797,
	DoubleDataContract_ReadXmlValue_m2446B3234F6334B0BFD2DD3389B0321C37C7C177,
	DecimalDataContract__ctor_m99BC8FA1329566AC6AC1F5865A85FE5CD3364A3A,
	DecimalDataContract_get_ReadMethodName_mD9ACDE1A68C527053AEC346AAF004AF6D35CEAA1,
	DecimalDataContract_ReadXmlValue_mF05F3AA37259ACEF7E1E2C8F1A6D4DEFA5B2DB0E,
	DateTimeDataContract__ctor_mE6B755C86A5F1EB0E25166A6A7B6711B3A258989,
	DateTimeDataContract_get_ReadMethodName_m23145B831CACE8FCF94FC201CCECE9023E13CE86,
	DateTimeDataContract_ReadXmlValue_m8272BC82AC6767F4632E1DE3824220040C90E364,
	StringDataContract__ctor_mD6FFBDBD190A6663A8DC839242BE4CD7B829EB94,
	StringDataContract__ctor_m3BF90C66B3E5BD4CFCB83DD4B12AF85F247A3B25,
	StringDataContract_get_ReadMethodName_mE096888815A5210AEBDADCC195ECB2D83BC021C1,
	StringDataContract_ReadXmlValue_m6F0037360ABF31CF9537939801A4E854E0293F90,
	TimeDataContract__ctor_m81971C6320150DB6DB5827DF1D518AEB7D7490CE,
	DateDataContract__ctor_m0C5B45835BFE91956FE60BDEE005FF81B0632EFB,
	HexBinaryDataContract__ctor_m283272F87E989B6C645A8E7B709D0692E547A2B7,
	GYearMonthDataContract__ctor_m8340BC4BE93720C443CD405CEB902638F765A9F0,
	GYearDataContract__ctor_m1970AC0F99E024A9011DD5885DD0FBA1D4460D55,
	GMonthDayDataContract__ctor_m0DDE117041BA54A690B12D6C95E3285D952CC603,
	GDayDataContract__ctor_m01C7F98252D35397C8E1D04C25BD99A17921E588,
	GMonthDataContract__ctor_mA1E81297B02D0368A056DAF3DE5BB4F9D73C67C6,
	NormalizedStringDataContract__ctor_m11E8D3585B6331F69DBF4701021CEEC3CF3C4A3A,
	TokenDataContract__ctor_m3752CA0B63554D3787BBF2C58D828DBF5C46CBF1,
	LanguageDataContract__ctor_m8B180442E8A8DA3790800279ACCABDA696BDC31D,
	NameDataContract__ctor_m295CE4452CE55BDE19D7DE6A8F1EF43E3B59A75E,
	NCNameDataContract__ctor_m57CC5A46E10A382B386D4BB6795A7EB9EE0070CF,
	IDDataContract__ctor_m0255E33206C9EB11B03459315F5A24048F90DC58,
	IDREFDataContract__ctor_mC890B726FE7046408D87DB03C2ADBA5936004023,
	IDREFSDataContract__ctor_m6F23119E2E993A2793A1DE354D46D101CCA7628A,
	ENTITYDataContract__ctor_m315411D454310CEBB5BAEF57B24FFEF41D256A05,
	ENTITIESDataContract__ctor_m7707A09875003DBBA17051C15EFC4B784D55CEC1,
	NMTOKENDataContract__ctor_mF4DB7E259DB1CDD0DCE5E8400FAA92BAE23A82B5,
	ByteArrayDataContract__ctor_mFFFB833CCB945F125EBAD19EC9CF2C8797BAB67B,
	ByteArrayDataContract_get_ReadMethodName_mCC9515F07DFBAF6F34CFF0A27108D96B3B69FCE8,
	ByteArrayDataContract_ReadXmlValue_m693978DEA6E94372E52390B729BB5A3927421BD4,
	ObjectDataContract__ctor_m14C07F5DC455E690AE1585406D6EAB793912C41F,
	ObjectDataContract_get_ReadMethodName_m310BBC31C391FB9E7795F27E2B9588A16440F087,
	ObjectDataContract_ReadXmlValue_mB91EC4F9C50EDEEBB40EA85BAEA6576661F31F93,
	ObjectDataContract_get_CanContainReferences_m6C1659842F571CDB878BB75D299B4702A6E54631,
	ObjectDataContract_get_IsPrimitive_m0A520962DAEAF3747DF278D0F49BF7FE44B50F04,
	TimeSpanDataContract__ctor_m55478A7DD3D40035DF7EF192BF70A4F6505F4193,
	TimeSpanDataContract__ctor_m3E3082E93C20173597711405F978F926E035F53F,
	TimeSpanDataContract_get_ReadMethodName_mD74FAFCBD606618E81AF3847CAED7909B5B885B8,
	TimeSpanDataContract_ReadXmlValue_m1F4FB9326ECF6DC9FAC7AEE5604C425EADC32EB3,
	XsDurationDataContract__ctor_m51BAD021BEF550DFD713A93D6687A2345B9A64E1,
	GuidDataContract__ctor_m4D2670B581E275951F41F4AEC1B9D98814A6D84D,
	GuidDataContract__ctor_mAB82027B30438103D37BE53C1027D5A8CAF36A4A,
	GuidDataContract_get_ReadMethodName_m99B8B44FC9D6BC43CF620348BF78F2A0B8223499,
	GuidDataContract_ReadXmlValue_mCC24744FEB1C101C27DBF6DDAE4F0AAE66ECCB3F,
	AsmxGuidDataContract__ctor_m8CF55BCE694762004281B1C671E98A752A52A899,
	UriDataContract__ctor_m9098993B8C8A1C3B08234DE1D2FC6FE860684583,
	UriDataContract_get_ReadMethodName_mFCC5B25BD53F00227E2261C719FF37B1579EE980,
	UriDataContract_ReadXmlValue_mF248295567373E684CD71CBABEA6D02B1A5C9624,
	QNameDataContract__ctor_mB4804387AAF4999093C1742CE2B2E8CDF92EEE29,
	QNameDataContract_get_ReadMethodName_mB07D5400B519159A88D5340F397AFC7EC62581E1,
	QNameDataContract_get_IsPrimitive_m6103ED0FD0292966F373EDE89E256CCA2A60EE38,
	QNameDataContract_ReadXmlValue_mD7BED04A8F412296E9E98D90885D7D848CB7A790,
	SchemaExporter_ExportActualType_m24942764FFF573A7E0CBCFDAFF451D2E05B5EC9B,
	SchemaExporter_GetXmlTypeInfo_mE74DB2288D19D909AE9976A07C5F62411F5FDE9F,
	SchemaExporter_InvokeSchemaProviderMethod_m2DD9A38668F81280D25873387C5FDBF234758056,
	SchemaExporter_CreateAnyType_mE2C1EE621F4DEAB55FD792DC9130C66E089FC1CA,
	SchemaExporter_CreateAnyElementType_m94C90DE0F7A47EBEE2D7A69EFC89F6AA753B019C,
	SchemaExporter_IsSpecialXmlType_mB12F35AECC497EBB4BC01247CF2924993B3CD770,
	SchemaExporter_GetSchemaAnnotation_mD18B2890E76A130CB1C9DA75DAD0EEF7092E1683,
	SchemaExporter_get_ActualTypeAnnotationName_mF68C1E1644B1B4AC2CC5B43564B174D7FE53DEBF,
	ScopedKnownTypes_Push_mAEB53E753F4A8C2B043B054ABFA72F707744AB11,
	ScopedKnownTypes_Pop_m60142B3457456EDEF4B1E11D13ACE26CF76C61C5,
	ScopedKnownTypes_GetDataContract_m06420837D552E998FDBB5EAE2B2F8E6F8316DF08,
	SpecialTypeDataContract__ctor_m8D04133E04D1DA2B6C5F232F2F0D743BBD3263AB,
	SpecialTypeDataContract_get_IsBuiltInDataContract_m9BC25F7E2C1AE65C34613C7F42830DC504DC6702,
	SpecialTypeDataContractCriticalHelper__ctor_m13D41BE9DA2B1E1535CDEC2D66F77964BE5D26E5,
	SurrogateDataContract__ctor_m3BAFC01AE91FC2A0862475ED7AE272EFC633DA1F,
	SurrogateDataContract_get_SerializationSurrogate_mA5E4540AE08A14119D308015F1143E1BA5500AC2,
	SurrogateDataContract_SerializationSurrogateSetObjectData_m69B61758BF25709F42C36EE834EE9AF69E3DD0D2,
	SurrogateDataContract_GetRealObject_m18F438AB3E5445A8E782B4D275551416523197DE,
	SurrogateDataContract_GetUninitializedObject_m274D6C24878857BF7CB52FE9119F610A0B6AA75F,
	SurrogateDataContract_ReadXmlValue_m9F0F69B6FAEB434E2FD634E3C505C73764075171,
	SurrogateDataContractCriticalHelper__ctor_m535E26ADC0C27106B3E1AED275B1D9D7362BC3D4,
	SurrogateDataContractCriticalHelper_get_SerializationSurrogate_m1547D3B8C6142774E5962193913D680CC801A84A,
	CreateXmlSerializableDelegate__ctor_mE688BE59A7E4D7E47AC334794B4574BF27A13CB9,
	CreateXmlSerializableDelegate_Invoke_mBD36C23967C8C63DA2F94EC08AC35E6D337AB240,
	XmlDataContract__ctor_m290446C87F724C33DD9BE84767AC3C3892A19D09,
	XmlDataContract_get_KnownDataContracts_mA028687927ED95AB2DC4F16C733907907320D8DC,
	XmlDataContract_get_IsAnonymous_m134AD7B1215E89268A2902337B9EADDCBC9EE567,
	XmlDataContract_get_HasRoot_m7EFB591A1715D3F070D61EDE1931DA3DAA3C8E2F,
	XmlDataContract_get_TopLevelElementName_mAE8A979D8C1E09D78283A4BCE6D2806D20193507,
	XmlDataContract_get_TopLevelElementNamespace_m96A8A089E0A3F803995E7F99918E5A0C458AF2D0,
	XmlDataContract_get_CreateXmlSerializableDelegate_m1F3590D2022C619BF11BF47A57328BB2318EE98B,
	XmlDataContract_get_CanContainReferences_m71FC9ED3199802950272363302C24B21A7BC67B6,
	XmlDataContract_get_IsBuiltInDataContract_mA67778BB22B27F99759BB79F54B057B92A373BAB,
	XmlDataContract_Equals_m2375AAFA4A26543BE136779A62DA8DD0840800A5,
	XmlDataContract_GetHashCode_mBA62D57C73EE7B30A3EBDE71549F0F75E69ACCB1,
	XmlDataContract_ReadXmlValue_mD0076749BAAB80238BF3E86E2AAC835DD159C098,
	XmlDataContract_GenerateCreateXmlSerializableDelegate_m0534D6215C8853AA0719393E6935215E552045BA,
	XmlDataContract_U3CGenerateCreateXmlSerializableDelegateU3Eb__39_0_m2D950E71AE290A3A3286F0C04C4A4B222E2B0427,
	XmlDataContractCriticalHelper__ctor_m2CE02607B9C2888B4DC2852B59F3FD0097A215FB,
	XmlDataContractCriticalHelper_get_KnownDataContracts_mC4A96EDB700B22A808D622E335A4786AB601562D,
	XmlDataContractCriticalHelper_set_XsdType_m440C97C00F49C9C2609C937577C18BB2B84D53DB,
	XmlDataContractCriticalHelper_get_IsAnonymous_mDA58533D04B379BF048D5F47C317E0920292AF73,
	XmlDataContractCriticalHelper_get_HasRoot_m5D8A3F11110868154103966B5494049A0F75D1FE,
	XmlDataContractCriticalHelper_set_HasRoot_m1FC216372797FFAB5FB7E40E655A4C526BB7BEFE,
	XmlDataContractCriticalHelper_get_TopLevelElementName_m5A778AADA9E8A5A5D13D90139782B1246C35E151,
	XmlDataContractCriticalHelper_get_TopLevelElementNamespace_m98E6C3A209D5408EA756415FA100002412A1DDDC,
	XmlDataContractCriticalHelper_get_CreateXmlSerializableDelegate_m92E5716D5C6DFC4DBD71604E34F1C403E113F501,
	XmlDataContractCriticalHelper_set_CreateXmlSerializableDelegate_mA29E864DFE7F1B500469825F21C7089CD6B58F19,
	XmlFormatGeneratorStatics_get_UnboxPointer_m36CD58F307FE72D573ED31B7ADB15A6021FE5DD3,
	XmlFormatGeneratorStatics_get_HashtableCtor_m00FACE3C3F2EA8F572B4724B57F03F5196C20009,
	XmlFormatGeneratorStatics_get_EnsureArraySizeMethod_mD3E94D40B2C7B1119FCEA71FBF25C770ABC67530,
	XmlFormatGeneratorStatics_get_TrimArraySizeMethod_mE7864C8DD86DE1784A5D825A2392296C61752DB1,
	XmlFormatGeneratorStatics_get_ExtensionDataSetExplicitMethodInfo_mB258964B2B65D771AB8B92DE76526AAB7147EF54,
	XmlFormatClassReaderDelegate__ctor_m7540999C406A36A3D83FC80FA98CE265EB0876AB,
	XmlFormatClassReaderDelegate_Invoke_m2CD64C4BE88211C13EC30DB40D47878B265540E5,
	XmlFormatCollectionReaderDelegate__ctor_m1075FA08015455E5060AA15BA7F8B99F9F3B4FAA,
	XmlFormatCollectionReaderDelegate_Invoke_m2689513FBB8E1C025CE23BABBFCAB97DEF709269,
	XmlFormatGetOnlyCollectionReaderDelegate__ctor_m194D27CBCEBA0B47B75B848AE13D9BFFCA87B029,
	XmlFormatGetOnlyCollectionReaderDelegate_Invoke_m85C0D24CF14F622C320519F548D5A3CC8F6159D4,
	XmlFormatReaderGenerator__ctor_m1DAC2E3BB8A0396AEB95BBC4909A97D224F4102E,
	XmlFormatReaderGenerator_GenerateClassReader_mE348E481A99A53B1BE739CF53DD6CBD4591166FD,
	XmlFormatReaderGenerator_GenerateCollectionReader_mC262B1D1C90CF5C85FAC756EA38FE4272119B6DB,
	XmlFormatReaderGenerator_GenerateGetOnlyCollectionReader_m8A9D67F09A51940ECB853638F58D9CC056187C3A,
	XmlFormatReaderGenerator_UnsafeGetUninitializedObject_mD6B698A20D7C110B75E75068E1966F72445EA8CA,
	CriticalHelper_GenerateClassReader_m7D1701168B78CF1601BD9C986C233CABBACC7963,
	CriticalHelper_GenerateCollectionReader_mAA05B8B0EB88EB9C118CFD32617270E93594C92E,
	CriticalHelper_GenerateGetOnlyCollectionReader_m1EEC05751B3C0321D9A792C93805115A3184FC14,
	CriticalHelper__ctor_mED0BCF24551006D1D8E8BC27C2AEC359D2D76716,
	U3CU3Ec__DisplayClass0_0__ctor_m9ECC8FC647C8BAD12AC0BB6D676220E33987B7FA,
	U3CU3Ec__DisplayClass0_0_U3CGenerateClassReaderU3Eb__0_mEFFB53B59C1028F145CAF0E8C1468B06C4AA86FE,
	U3CU3Ec__DisplayClass1_0__ctor_mC1B7F5262D06CE6FA38BF3748E77DD06BB69A7D0,
	U3CU3Ec__DisplayClass1_0_U3CGenerateCollectionReaderU3Eb__0_mECA16C44D9C3C5EB20D40ADA15A352B02D7680EA,
	U3CU3Ec__DisplayClass2_0__ctor_m2E91805CA87AE98901DCDDD8A23A6FE3F4E97EA7,
	U3CU3Ec__DisplayClass2_0_U3CGenerateGetOnlyCollectionReaderU3Eb__0_m8727C046F7DABC40385590F32FAF56FCF41B945E,
	XmlObjectSerializer_get_KnownDataContracts_m4AB99E62A9A3D5E06F286D5E8A195ED251188F67,
	XmlObjectSerializer_CheckIfNeedsContractNsAtRoot_m851A33F9FFAB9ECE096D6F01DD3037100E91F6C5,
	XmlObjectSerializer_ReadObject_mA02AD3264C2E15EDA66BF1B421186875171E843F,
	XmlObjectSerializer_ReadObject_m2254F2A960C12CE85203ED7B209C96596D84C64A,
	XmlObjectSerializer_ReadObject_m666D95CAEA63C04C2B96B8CADE697FB65535B6DF,
	NULL,
	XmlObjectSerializer_InternalReadObject_m24E4FD046FEEDA3CA30A94E0C2B5881C7D3A79E1,
	XmlObjectSerializer_InternalReadObject_m86E071E707539594FF90B58E1C9E73111DBBE85B,
	XmlObjectSerializer_InternalIsStartObject_mFCF9E17599A6E362ED7AF11AE6A5CA19B633C9E2,
	XmlObjectSerializer_ReadObjectHandleExceptions_m1B315518C4090A3549166BFB1E2077D597603B89,
	XmlObjectSerializer_ReadObjectHandleExceptions_mA8D4369517F08DB469E801AFE08F51A74CD72084,
	XmlObjectSerializer_IsRootXmlAny_mCAF2B30ABD9CC93199BA6DFE25050B876948E909,
	XmlObjectSerializer_IsStartElement_mD594142280638E6470FE8229F24059C76497A6C7,
	XmlObjectSerializer_IsRootElement_m103207A51F8FA4045B48CC13CECCE39660C10094,
	XmlObjectSerializer_CheckNull_m36CB6C134A83A15B866E83876F6C045F8F288659,
	XmlObjectSerializer_TryAddLineInfo_mF60B818D3CD897C6AA938049FD3B46315898CEF6,
	XmlObjectSerializer_CreateSerializationExceptionWithReaderDetails_m14080F0D052B10942003B969DD648A6110CE3B18,
	XmlObjectSerializer_CreateSerializationException_m14581C5D9FE35E14E819276C06E69548661ED683,
	XmlObjectSerializer_CreateSerializationException_m89D67E6172D4C9EAE21AD46BC7F1A51FD699AC67,
	XmlObjectSerializer_GetTypeInfo_mEF2C337869A33349B0137C8831D3199C1B7387A7,
	XmlObjectSerializer_GetTypeInfoError_mAA19E974B1D87E706ACA54240E9671919D8E5D91,
	XmlObjectSerializer_GetDeserializeType_m8175483C7CF73CF85B5893AA51E9C568C6E324E2,
	XmlObjectSerializer_get_FormatterConverter_mEEB240C964EACEFFA8BB599349C5514E570B6F50,
	XmlObjectSerializer__ctor_mD9F7398F63320021BC20A375FBC88A25ABB49B8E,
	XmlObjectSerializerContext__ctor_m7F7FF6016E06319A448E8D8A39D82824D4811184,
	XmlObjectSerializerContext__ctor_mEF0A0207FF9DF5CDB412BD61B1F65832E5625E4C,
	XmlObjectSerializerContext__ctor_m8789317F5CAC1B3563ED4EF4343A017419A2D2F5,
	XmlObjectSerializerContext_get_Mode_mA76A9A0204EBAB9751092FAEB6D6D46A904D6EC7,
	XmlObjectSerializerContext_get_IsGetOnlyCollection_m061C960C5E1EFF48CFDAEFE9A0CEEE1F2F9A91C2,
	XmlObjectSerializerContext_set_IsGetOnlyCollection_mCC176D028E701336FAEF33B1937766413064F506,
	XmlObjectSerializerContext_GetStreamingContext_m0CDE8264CA73B597CEB88C321B428C996409189A,
	XmlObjectSerializerContext_IncrementItemCount_mDADAD621EED6E96EA12DAD9EC3CF3A5F74A21113,
	XmlObjectSerializerContext_get_RemainingItemCount_m958D1AECB35E28A9B81F54CDE7D8D95B83F39149,
	XmlObjectSerializerContext_get_IgnoreExtensionDataObject_mCE077D7936D9819979BFF252D5B0DBF5A640A465,
	XmlObjectSerializerContext_get_DataContractResolver_mC95624015ACF30E8886958E0D86A9E993AEBAF5F,
	XmlObjectSerializerContext_get_KnownTypeResolver_m90F7FE87E820247DA9EB2AAD29EC632E4D31B7EE,
	XmlObjectSerializerContext_GetDataContract_m89BD7838153BFE29919053F7882C1343954480BC,
	XmlObjectSerializerContext_GetDataContract_m3E68834FFFCC2E3E665A7EE70720F7AA9BE5B4A0,
	XmlObjectSerializerContext_GetDataContract_mBD1259B5AC635FAED1D8FA516BCDE3993A399816,
	XmlObjectSerializerContext_CheckIfTypeSerializable_m35D8AC9DBC193F8701F7B98D3140024DBFE609B6,
	XmlObjectSerializerContext_GetSurrogatedType_mC3A2A3A15C7C87D3F5BA4D2304C61DFAA0630B22,
	XmlObjectSerializerContext_get_SerializerKnownDataContracts_m6BD78E52500AEE2BC8F14ED36C7BE19EC3683B30,
	XmlObjectSerializerContext_GetDataContractFromSerializerKnownTypes_mAE6DE0F22C4E2DA2B7FA3CA3228A46F62332E86F,
	XmlObjectSerializerContext_GetDataContractsForKnownTypes_m69728BA7FCC48DB3E8A98990B79CC65DADF2DDE4,
	XmlObjectSerializerContext_ResolveDataContractFromKnownTypes_m86965A0EC92F932058FB4DB12AD20D0DF5470CFC,
	XmlObjectSerializerContext_ResolveDataContractFromDataContractResolver_m40B4DBEA2C289DB6B1C677733F2B195F94B88BF4,
	XmlObjectSerializerContext_ResolveNameFromKnownTypes_m56854743EDCB03418893A0933E8E547E46216ECA,
	XmlObjectSerializerContext_ResolveDataContractFromKnownTypes_mCFC92773A7FC04B4D85946E1B424E2AE36DBF0FF,
	XmlObjectSerializerContext_ResolveDataContractFromRootDataContract_m2BBFC7C7384B8F15045D4A052C6BA551C23DAD5D,
	XmlObjectSerializerReadContext_get_DeserializedObjects_m1135E7CAF7F7ED782DB9C48D0D15A48CF6269F22,
	XmlObjectSerializerReadContext_get_Document_m4C73E864B791B29E38B8E876AC67B466015861E0,
	XmlObjectSerializerReadContext_get_IsGetOnlyCollection_m7EDC6A09C1DCD7B4D810D358FB5A95AB17854EEF,
	XmlObjectSerializerReadContext_set_IsGetOnlyCollection_m9A0B06C07042C9EDC8DABBCD86A9807BB6F8820D,
	XmlObjectSerializerReadContext_GetCollectionMember_m318167A04E79B7C332391EDFF15BBDE6CF1FF8D2,
	XmlObjectSerializerReadContext_StoreCollectionMemberInfo_mB15388D0739B55311B259BA368430D4D9F581E3E,
	XmlObjectSerializerReadContext_ThrowNullValueReturnedForGetOnlyCollectionException_m2487B962B1B98AD9370B7FDE8B32C0E3257D73ED,
	XmlObjectSerializerReadContext_ThrowArrayExceededSizeException_m2164AE3669BABBC863F6C59B9B5950A32A54E506,
	XmlObjectSerializerReadContext_CreateContext_m7CDAC27D66E7DF8DE7C6499FF484CB6B108D72A5,
	XmlObjectSerializerReadContext__ctor_mD0C1321D113FD28FDC91525AD5845A683E264EAA,
	XmlObjectSerializerReadContext__ctor_m91703A76AC64EC5E3D549B46BEF5F753FB263EEB,
	XmlObjectSerializerReadContext_InternalDeserialize_mFE4D3E3F7AC21C4FDF54B9DD0ECAE204887E94FF,
	XmlObjectSerializerReadContext_InternalDeserialize_m3833C14A08C93A875AC5AD0B43AF9FA01A12F12C,
	XmlObjectSerializerReadContext_InternalDeserialize_m15D26A6E1684D9A26C49C570E4D8F466EF426B35,
	XmlObjectSerializerReadContext_TryHandleNullOrRef_m9367AAD76C139453DE2A4D39B79235D1B47170BC,
	XmlObjectSerializerReadContext_InternalDeserialize_m59AB5DF5675EBF635551B0AD83FE554C44451B12,
	XmlObjectSerializerReadContext_ReplaceScopedKnownTypesTop_mFEBF7A7947ECCCC68A3661B57E9DEDB84131B46F,
	XmlObjectSerializerReadContext_MoveToNextElement_m3FE7D91B83F11C1C125DCD11058CCA8425D1FCD3,
	XmlObjectSerializerReadContext_GetMemberIndex_mEDE68AC0F431A4390330B403AF8863157980E1E8,
	XmlObjectSerializerReadContext_GetMemberIndexWithRequiredMembers_m9DD5C1C0E8B71EC59B4384917F30F440F09999CF,
	XmlObjectSerializerReadContext_ThrowRequiredMemberMissingException_m37272374BE65C5E4A94BE5CFA8EB648287A1BE81,
	XmlObjectSerializerReadContext_HandleMemberNotFound_mE592CF9FB5D991DB7A680FA52CF189EF6B2E2E83,
	XmlObjectSerializerReadContext_HandleUnknownElement_m84D5094C407AE36361009DFE51FC15D27EF4F92F,
	XmlObjectSerializerReadContext_SkipUnknownElement_m09DC13E40D04E3A3E5772C96B2675F35579845DD,
	XmlObjectSerializerReadContext_ReadIfNullOrRef_m37AF4C79C0A9666A067D09BFD1D614641A2735E2,
	XmlObjectSerializerReadContext_ReadAttributes_m376561B9161938A5AFBA18EC36309066151EC3FB,
	XmlObjectSerializerReadContext_ResetAttributes_m9D9479017D0678452FBAC19051F25DEDC3EC59FC,
	XmlObjectSerializerReadContext_GetObjectId_mA8DDBFE7E4CF3181E53A71CC80B338AED3E1FF3B,
	XmlObjectSerializerReadContext_GetArraySize_mDF5FA348F26E632DC923F768FE50E552657B6B59,
	XmlObjectSerializerReadContext_AddNewObject_mAF67A9375CCB014DA9229B30D8FB73800FED3E4F,
	XmlObjectSerializerReadContext_AddNewObjectWithId_mA025D37DE842CC7FBFA296623365B60B0E8C4D61,
	XmlObjectSerializerReadContext_ReplaceDeserializedObject_m6DFB72A236EABA37FB18DCA12B97E82D78C71B58,
	XmlObjectSerializerReadContext_GetExistingObject_m2F6E47B776BAC1123105CCF2C6E2F03AA631AABF,
	XmlObjectSerializerReadContext_GetExistingObjectOrExtensionData_mECD9E949454AB3A47C50AA5D61BCE33BF33D994E,
	XmlObjectSerializerReadContext_GetRealObject_m5ABF9F7B2C71F9B0E7829B8AD935A6EDEC9E6311,
	XmlObjectSerializerReadContext_DeserializeFromExtensionData_m84BB24DC28F9E873250F3FA4D74E1614D7D49CDF,
	XmlObjectSerializerReadContext_Read_mF95A19F2DA6548034AE42E2A20E0AEB441286542,
	XmlObjectSerializerReadContext_ParseQualifiedName_m9FE0EE3917A6654C05D8105F7EC290629D381D67,
	NULL,
	NULL,
	XmlObjectSerializerReadContext_CheckEndOfArray_m3C446EDF2BA75B22B98A61E587F6333A3CE0EA28,
	XmlObjectSerializerReadContext_ReadIXmlSerializable_mC90B09F03FADC07568F73162B9E5DF0A71053759,
	XmlObjectSerializerReadContext_ReadRootIXmlSerializable_mCE2EBBFF0B62120B535F0177580B43C2C0B16A56,
	XmlObjectSerializerReadContext_ReadIXmlSerializable_m566CB1998DC64A1F59155EA65CC169A09F2C9686,
	XmlObjectSerializerReadContext_ReadSerializationInfo_mCDDBC0788E6F1B7C790ECB32813470C9A4FB83F8,
	XmlObjectSerializerReadContext_ResolveDataContractFromTypeName_m93C9E7BE15CAF9C3BC4D071802788E1AE2D84F21,
	XmlObjectSerializerReadContext_ReadExtensionDataMember_mC93DDF7CAB5B8A41D261FBD157E838A193158AF2,
	XmlObjectSerializerReadContext_ReadExtensionDataValue_mBB94399C4AC9D6BD1939BB64311FB662AC3E31CC,
	XmlObjectSerializerReadContext_StartReadExtensionDataValue_mA4E5924F8529211767F7199794A56AAACCE04440,
	XmlObjectSerializerReadContext_ReadExtensionDataValue_m7DDEFDDE9050147E6655BD6D3448E9256E5AE222,
	XmlObjectSerializerReadContext_ReadPrimitiveExtensionDataValue_mCEC49106E93B9FC63CF3BF15A52A361AD1B14C8E,
	XmlObjectSerializerReadContext_InitializeExtensionDataNode_mE878A22871D7179FE4C2FCFDD9A341D2A9DF5088,
	XmlObjectSerializerReadContext_ReadUnknownPrimitiveData_mCDC97BBCD8344F4AF81364C62369EB1E82F5FECF,
	XmlObjectSerializerReadContext_ReadUnknownClassData_mB0FC1D56B883A0B34587ECFC9802E30B4A10B362,
	XmlObjectSerializerReadContext_ReadUnknownCollectionData_m4209419BE0F52D01E50109954B352C0479A0463C,
	XmlObjectSerializerReadContext_ReadUnknownISerializableData_m544DF935E14D84164EC8C4DDBF8E4C26591C8583,
	XmlObjectSerializerReadContext_ReadUnknownXmlData_m60B697E1D88CE2C4173D5B81A4C86BEE58E9E2ED,
	XmlObjectSerializerReadContext_ReadAndResolveUnknownXmlData_mA97FC9F7E2703BE67AC7E8EEC83205366E0F30F2,
	XmlObjectSerializerReadContext_IsContentNode_mB5A6BE0A4CCEF1D094427BC8A6E48386BD0627C1,
	XmlObjectSerializerReadContext_CreateReaderOverChildNodes_m77397BF85CA394E44164484A442FFC17FB42578C,
	XmlObjectSerializerReadContext_CreateWrapperXmlElement_mD94974CFC58F62A99845D39F3A51C8E3E81EABB9,
	XmlObjectSerializerReadContext_AddNamespaceDeclaration_m3AC13188DB1C89566FD12510650D3D526A6875B1,
	XmlObjectSerializerReadContext_CreateUnexpectedStateException_mFCBA863B32D81FE866E5062057FB9ABE335B969E,
	XmlObjectSerializerReadContext_ReadDataContractValue_m63F058C212D275967C12BC48FC980BDE3A739937,
	XmlObjectSerializerReadContext_CreateReaderDelegatorForReader_m27BCA4A3DD4532E7A25A24C3827AA35907D1D01E,
	XmlObjectSerializerReadContext_IsReadingCollectionExtensionData_mA86BC09F259869A64F3C90047CF2F79B032B6373,
	XmlObjectSerializerReadContext_IsReadingClassExtensionData_mACFE1FCE36E11DAAF0F73E9CDC99AB3685C4F417,
	XmlObjectSerializerReadContextComplex__ctor_mD03833D98556A401FA95FD59CD317AE66D044CB3,
	XmlObjectSerializerReadContextComplex__ctor_m6AC85976446C15DEE0A6E11244A7AECED10AD311,
	XmlObjectSerializerReadContextComplex_get_Mode_m4C718FA2C1BC99E7518384C825DC21BF3E656F7B,
	XmlObjectSerializerReadContextComplex_GetDataContract_m41E205D5E0C161E588A165FE762A110B6A10E3CC,
	XmlObjectSerializerReadContextComplex_GetDataContract_mE283D1C21257274BF9E34FD20BD070945485C479,
	XmlObjectSerializerReadContextComplex_InternalDeserialize_m6C11A2423EAD377112D8B6E6CC59AE4BEAA89D19,
	XmlObjectSerializerReadContextComplex_InternalDeserialize_mCBF64075D72A021B47C3A75B563618EEC2BC7118,
	XmlObjectSerializerReadContextComplex_InternalDeserialize_m7359A5865B64347A5B9A0CBE12520A6A8E1A3619,
	XmlObjectSerializerReadContextComplex_InternalDeserializeInSharedTypeMode_m5D4AE7CB90BFA797EC24C0FDC2B7F0DF59CD1AB9,
	XmlObjectSerializerReadContextComplex_InternalDeserializeWithSurrogate_mE0DDDAD0F4BF260FC0865432A321B298454FCDF1,
	XmlObjectSerializerReadContextComplex_ResolveDataContractTypeInSharedTypeMode_m5D624616C89F0B7CC5197E05125B464A21FEBA47,
	XmlObjectSerializerReadContextComplex_ResolveDataContractInSharedTypeMode_mC8E73252B455352510F1E3403A57CD144E14635A,
	XmlObjectSerializerReadContextComplex_ResolveDataContractFromTypeName_mF9626788898255D6573BA4C3277CA6F087193C8E,
	XmlObjectSerializerReadContextComplex_CheckIfTypeSerializableForSharedTypeMode_mA241A6844FFE78E06BB63E077200EE9EF5DEAD71,
	XmlObjectSerializerReadContextComplex_CheckIfTypeSerializable_m30755D9A3A302F1DA68A2AACB3F89ACF23036414,
	XmlObjectSerializerReadContextComplex_GetSurrogatedType_mBFA4CD50C5ECFB4DB44D47CEA4CBDEB61159A68D,
	XmlObjectSerializerReadContextComplex_GetArraySize_m676279CD1E13EA195E94F8203AA2BE7D7F2050AF,
	XmlObjectSerializerReadContextComplex_ResolveSimpleAssemblyName_mE29133F8114C234CCF4B0A7E4108DBDE81926BC1,
	XmlObjectSerializerReadContextComplex_ResolveSimpleAssemblyName_m2AF5E3BA9F937F2DB3989B0438432A8E4910847C,
	XmlObjectSerializerReadContextComplex_CheckTypeForwardedTo_mBD947AD2394CFDADE4639ED510F2D186A18D117D,
	XmlObjectSerializerReadContextComplex__cctor_m72A87E5CDB277460F60C5BFBAD671C8FF3F2DF8D,
	TopLevelAssemblyTypeResolver__ctor_m28B39914F9DE57129656DD64582D1E4B1376C4CF,
	TopLevelAssemblyTypeResolver_ResolveType_m3FC6132EBB2FB8D48EE462735FA1945605F2D777,
	XmlObjectDataContractTypeInfo__ctor_m98CE7DAC6FBFE09FDE9F41BD6E1C4CE2948CEF37,
	XmlObjectDataContractTypeInfo_get_Assembly_m9A661F828081CE309A5C775571732C42FA44A368,
	XmlObjectDataContractTypeInfo_get_Type_mC38109214EFAF6BE6F7BCC3E7676B1202247D943,
	XmlObjectDataContractTypeKey__ctor_mA6770F3220D706F2D7ED9748FE20AC5273E0765F,
	XmlObjectDataContractTypeKey_Equals_mC4C4AE83B8A33FA77BF4F651128E4F82A9B70F5F,
	XmlObjectDataContractTypeKey_GetHashCode_m16159C93712604A06A0CEF2B0811E5169159B74A,
	XmlReaderDelegator__ctor_m86F759055A24BCB7E6B61563FE6EA99A9BBB4ADD,
	XmlReaderDelegator_get_UnderlyingReader_mA881749D0A82CAA178175411409CB4B09E56B6C2,
	XmlReaderDelegator_get_UnderlyingExtensionDataReader_m4D4FE50A454FC18380938633D58A137CA0745AD7,
	XmlReaderDelegator_get_AttributeCount_m68635E8A6050ABB50497BD1F8FB36598D2588717,
	XmlReaderDelegator_GetAttribute_mA5E33B6B04C18E07EDF5C4C0049C43A7AB2AAA42,
	XmlReaderDelegator_GetAttribute_mAF37FD5BACCDF7829047CA9148879A0E21B613AB,
	XmlReaderDelegator_GetAttribute_mFB87CB78870070EE8465C47323FD42D7BEA70FBC,
	XmlReaderDelegator_get_IsEmptyElement_m3AB8D9EAB1BE3ED9EF10ED42498FC779302128EA,
	XmlReaderDelegator_IsNamespaceURI_m7102C183363D95F232B8AB1B7C9D18B0BB9D8691,
	XmlReaderDelegator_IsLocalName_m19A26A86B1C125414B73AB11A750BA32468F38A8,
	XmlReaderDelegator_IsNamespaceUri_mEF3A30B819D823EF65A09CAD673D473628255A6B,
	XmlReaderDelegator_IsLocalName_m33854F779A2DA7D902C6FA548A307896CC006B9A,
	XmlReaderDelegator_IndexOfLocalName_mE69EAC3EF256F7062FBE7D9AB7AA95FE52F7ED63,
	XmlReaderDelegator_IsStartElement_mEF1624BAA20BBACB032D65BB32008A2CACC3A835,
	XmlReaderDelegator_IsStartElement_mE7A06394F3F473E5E04258F439763B4F7D46E80F,
	XmlReaderDelegator_IsStartElement_m10E2BA5D745DEA429513E28FFD06BA41B85162D1,
	XmlReaderDelegator_MoveToAttribute_m84B1DB12A2C6FF8F1C7CE98581696666D4F4A411,
	XmlReaderDelegator_MoveToAttribute_mCCC01D964006036A8721B9685C7E6E14DCDB54B5,
	XmlReaderDelegator_MoveToAttribute_m64161D12742B1AD2614E1F85324B735A725A48A0,
	XmlReaderDelegator_MoveToElement_m3D6BA21BF925B9FEB6C795E5120DC8901289945C,
	XmlReaderDelegator_MoveToFirstAttribute_m1F65752A23590A550E9F7D045F675092A7FF6B23,
	XmlReaderDelegator_MoveToNextAttribute_mE546DED2B738D7A87F000CECA5ABC2272291C7C0,
	XmlReaderDelegator_get_NodeType_mCA3CCC1C3403C8CBFAB9AA5A97133735C913F940,
	XmlReaderDelegator_Read_m33D68413FFA1ED6AC36CCE6C216628B11A4D6F03,
	XmlReaderDelegator_MoveToContent_m945C5E02682DAFC31A13791EC5F79D1731115B85,
	XmlReaderDelegator_ReadAttributeValue_m9B1948224E6E8C57D6FC35F266D883DE0B32DF34,
	XmlReaderDelegator_ReadEndElement_m55090939D60CC18064BB9FDE79A33757615A63A4,
	XmlReaderDelegator_CreateInvalidPrimitiveTypeException_mA9FA6E1D5EB6EF70F3EEE0CF37ACE8584AB05829,
	XmlReaderDelegator_ReadElementContentAsAnyType_m9127162869A572EF18D797A71228D65A0501AE98,
	XmlReaderDelegator_ReadContentAsAnyType_m6C689E81F1C20F3A23F4C31DBA48A036DF31E9A9,
	XmlReaderDelegator_ReadExtensionData_m6C772EC19343083F36C782193F7A309DBD9E5EF6,
	XmlReaderDelegator_ThrowConversionException_mA8ED224EFC068123101B7322E9685B364DD9C3D3,
	XmlReaderDelegator_ThrowNotAtElement_m2F00424DA34AAE315F2AC95A6D7551902A02E1D4,
	XmlReaderDelegator_ReadElementContentAsChar_mB3EF316599AC07D07571C6CAB8C0831842192574,
	XmlReaderDelegator_ReadContentAsChar_mBD50A4C640E5A66237AC26F7372E5359A6337B17,
	XmlReaderDelegator_ToChar_m5155FF5D55886CDB618F74CDCE344A129C3DE88E,
	XmlReaderDelegator_ReadElementContentAsString_mBFB45337BC2DBE04C102D80AD188E1A5AF63C44E,
	XmlReaderDelegator_ReadContentAsString_mC50E197B7B6AA7A93C51E6DCE92249F325E0773D,
	XmlReaderDelegator_ReadElementContentAsBoolean_m20DBF68E383BEEBADD3934FC1A2595803AA08209,
	XmlReaderDelegator_ReadContentAsBoolean_mC037E50245F32951DD681D111C4534FFE7BA32A9,
	XmlReaderDelegator_ReadElementContentAsFloat_mEC88AFC2DDBD68A2E5563624F696F6FAD5909132,
	XmlReaderDelegator_ReadContentAsSingle_m8A39697BE57361E244905E5B82363FFC2144AAB0,
	XmlReaderDelegator_ReadElementContentAsDouble_m34DDF7F6461BF47A77B8210764DF850802A4A83A,
	XmlReaderDelegator_ReadContentAsDouble_m1C3C1D0B1BFD031AC0FF71181F80DFC352E22700,
	XmlReaderDelegator_ReadElementContentAsDecimal_m349146C56A137CF41FC09AD197F24EE511E45DC3,
	XmlReaderDelegator_ReadContentAsDecimal_m76095574FC3148D9ADAC8BD72CA99B05952A6239,
	XmlReaderDelegator_ReadElementContentAsBase64_mC8C926D4F848084CAC7775059C9ABB90824FBBF9,
	XmlReaderDelegator_ReadContentAsBase64_mEA43940F9D51F8B0C21ED4B66495F9EF858CFF3D,
	XmlReaderDelegator_ReadContentAsBase64_mC0728F7AE436B4CC8B4451AFA7546107A2EB4EDE,
	XmlReaderDelegator_ReadElementContentAsDateTime_m023316266236EAC41C9FDE1D285709ED8943E3B1,
	XmlReaderDelegator_ReadContentAsDateTime_m92BCFE2981C106C248C79676AED1A3114F99BB0C,
	XmlReaderDelegator_ReadElementContentAsInt_m952438BEAD7601E51C41804CAAF9D4B494D1A1E9,
	XmlReaderDelegator_ReadContentAsInt_mBB5756F1602500C8FCACC863B4CA484F99B08969,
	XmlReaderDelegator_ReadElementContentAsLong_m1E4FDD3C7FEAA366CAC6CF57F5AA6954CDEF61B6,
	XmlReaderDelegator_ReadContentAsLong_mF175251B65D1EF4E9CB17DA6748CF4892BA16479,
	XmlReaderDelegator_ReadElementContentAsShort_m774A363660F9ACDC36FCFDA3A8AC188C99390639,
	XmlReaderDelegator_ReadContentAsShort_mF103E0096521F007C3D84321990AE16CC73851EE,
	XmlReaderDelegator_ToShort_m5A243984E8172AC058A88970C7217752A85C9820,
	XmlReaderDelegator_ReadElementContentAsUnsignedByte_m2847BF385B43F06C553EECE192CEEBFE4B5F4493,
	XmlReaderDelegator_ReadContentAsUnsignedByte_m0E09C9E1BC1818371E78E8608D0D409612B9977F,
	XmlReaderDelegator_ToByte_m6240E515D0E6F6A8846D0110607C2E1B2C4E75F0,
	XmlReaderDelegator_ReadElementContentAsSignedByte_mF8505ACC1C110D9D1C5400B28DACF49A6C4AA69E,
	XmlReaderDelegator_ReadContentAsSignedByte_m860191558F53BF5EE84809A9860CFED71CF96DDF,
	XmlReaderDelegator_ToSByte_mB6E251CF0DC59786BF2BCA821DA123AF01DBF1BC,
	XmlReaderDelegator_ReadElementContentAsUnsignedInt_m0EA5107EC3302847E371FE9D1CC345FAEB663F9D,
	XmlReaderDelegator_ReadContentAsUnsignedInt_mC1879B95AD6602C122C846C4C495894B790D1A4A,
	XmlReaderDelegator_ToUInt32_m152D33ED394D13A046AB8C50D768EDB041AE3457,
	XmlReaderDelegator_ReadElementContentAsUnsignedLong_mC10CF7829EE255DEB0B22E7E32A9B1FC8DDA8A6D,
	XmlReaderDelegator_ReadContentAsUnsignedLong_m9B47DA4B42D246EC28FAB902A83EFC1819F81471,
	XmlReaderDelegator_ReadElementContentAsUnsignedShort_m61489300D28D0BE3A66BDC5F633DE6DDFDB49605,
	XmlReaderDelegator_ReadContentAsUnsignedShort_mE91DC6BE83107493F115B504139AC9FF12CAA00F,
	XmlReaderDelegator_ToUInt16_mFA46959C9DC564892A80EED68DD7FF139A77646A,
	XmlReaderDelegator_ReadElementContentAsTimeSpan_m5AC5537998F72B6C623A30772C9E229EB53B3743,
	XmlReaderDelegator_ReadContentAsTimeSpan_m655BEA2FCFB899CE85CC92F1D22ECEC644A10685,
	XmlReaderDelegator_ReadElementContentAsGuid_m779466EC0D44FAD7D13A033294F5A5FEA45FBED3,
	XmlReaderDelegator_ReadContentAsGuid_m8414FB677536001786501D8FF8AD3B2BD43C6A79,
	XmlReaderDelegator_ReadElementContentAsUri_m6B0701382202AF06AD02048F2041233C6D08DC66,
	XmlReaderDelegator_ReadContentAsUri_m69357E242F8A68F36F804E2748C0D25431C34012,
	XmlReaderDelegator_ReadElementContentAsQName_m439DF2A617C9B53BE3EA4BEF597BA2780C902EF0,
	XmlReaderDelegator_ReadContentAsQName_mC0A56259142D1ED5EBE1383AF1115553CE7ED51F,
	XmlReaderDelegator_ParseQualifiedName_m9320F27AF78F36D713CE8FE574446FEF751DB87F,
	XmlReaderDelegator_CheckExpectedArrayLength_m6559D555E79642925361B20C95F29D819F15AA84,
	XmlReaderDelegator_GetArrayLengthQuota_mD0E4EA9BCAF137D48B457D4ED7E97DC7B09AABA9,
	XmlReaderDelegator_CheckActualArrayLength_m1B3BF699E18FE3D772527AC941F428E8A754A9BC,
	XmlReaderDelegator_TryReadBooleanArray_m804FAC13D5E280810A092EB33072B263254B4CFE,
	XmlReaderDelegator_TryReadDateTimeArray_mA792F81DEEA9715D98922C0103A4A94EBDE83FB7,
	XmlReaderDelegator_TryReadDecimalArray_m8DD03D36FCC0FC9637A05932C6A96CA0E44F3BF6,
	XmlReaderDelegator_TryReadInt32Array_m165996D3678016407537B23DF5B8CB92C5AFBE31,
	XmlReaderDelegator_TryReadInt64Array_m93041E905F44F56C7F9D157A4850DB4CE9391324,
	XmlReaderDelegator_TryReadSingleArray_m8AEDDD9FD7EE4D7ECADE74A39CC41423177A64BF,
	XmlReaderDelegator_TryReadDoubleArray_m0B3A95C4A9A7991784D0EB1C5743520EF7766DB6,
	XmlReaderDelegator_GetNamespacesInScope_mB0D98B1A49EAB2746CCC05AD2BCFC421EFF8D1A4,
	XmlReaderDelegator_HasLineInfo_mFF93DD6C3A0A08EC68639C106325C974DBA2EBA6,
	XmlReaderDelegator_get_LineNumber_mE950CE4951D3B4E932D22B6230BB0F84FB26B594,
	XmlReaderDelegator_get_LinePosition_m5B087F1B1E4393AB11CCF3048AF018621DEC49C7,
	XmlReaderDelegator_get_Normalized_m2436EC5C87364BB48A774972DFD764D7E408CC71,
	XmlReaderDelegator_set_Normalized_mBE07713C1E365E9896C09F2768DAB3569E0E488C,
	XmlReaderDelegator_get_WhitespaceHandling_mEA94484409EE533E2BA15F9575F9C3BE45AD9298,
	XmlReaderDelegator_set_WhitespaceHandling_mC53C683711FA0502D11D19C675CF6450ECF5E2B1,
	XmlReaderDelegator_get_Name_m4C26E699D9205D6D4A17AF3A526506FF1A3D9114,
	XmlReaderDelegator_get_LocalName_mA05D1C9F06E1953CEA407863750F1864461CBE93,
	XmlReaderDelegator_get_NamespaceURI_m36271C19CC2C823C8B5C83B0FA0117EDFDF8922C,
	XmlReaderDelegator_get_Value_mEF602439F82848968A21FE32761D85BE665A0AF8,
	XmlReaderDelegator_get_ValueType_m75C2CDCEA03407C75A4CF41BF4EC0A475E1EC117,
	XmlReaderDelegator_get_Depth_mF582B1E54DE7BA9353D51041259EE1D711C99675,
	XmlReaderDelegator_LookupNamespace_m3D2E880E29F4B53AA1276325099B468529706EF4,
	XmlReaderDelegator_get_EOF_m6485B110598DB0CFDCF6B4824410ED66C55A94C9,
	XmlReaderDelegator_Skip_m488FCB522CE0787DFEA06AB903883AC13DBE67F3,
	XmlSerializableReader_get_InnerReader_mEEC93F0EB9C933BAF4A8679DFC8B9CF09B74E63C,
	XmlSerializableReader_BeginRead_m50F975F62A3B9733AE85898BA4447BF4D5D4C0BF,
	XmlSerializableReader_EndRead_m9C11F71877333A0E80D3F523767414177A6790B9,
	XmlSerializableReader_Read_mF90FBB227A053E3A1D25F84B6F89CE15E65EFFD3,
	XmlSerializableReader_Close_m35B0A44D046BD80D207D4574539900AFC77803D7,
	XmlSerializableReader_get_Settings_mF80753DF678C8CF14323ACF6FD3DCC6FBA9D9D4C,
	XmlSerializableReader_get_NodeType_mAC4399D6E4EE22A40BDA932DA5BD0B34BC9AF5AF,
	XmlSerializableReader_get_Name_mC332FDF48E6922E43013E2C14A3B7FF2969E7B5D,
	XmlSerializableReader_get_LocalName_m36120176B392292BD4B3E118E9F5144497614114,
	XmlSerializableReader_get_NamespaceURI_mD56291F6E819EF9D5FF4989B578F7135D55E248E,
	XmlSerializableReader_get_Prefix_mDA8D157675C91660174E052BB4B78DD94ACB5952,
	XmlSerializableReader_get_Value_m83DE1A38461F6E206EFD564AC66454442BC20CB2,
	XmlSerializableReader_get_Depth_m8759B3E419DDBD50F4ADB820A813F87B37AFC9DA,
	XmlSerializableReader_get_BaseURI_m32A74107A9A9EB4A6E7C7B4CB41CF710F77867ED,
	XmlSerializableReader_get_IsEmptyElement_m9A451C82BD4C2DA28FF80D3F243A1B453D087AAC,
	XmlSerializableReader_get_IsDefault_mA3DB0825A08A05FDF7A009F98703CA868FA78F38,
	XmlSerializableReader_get_QuoteChar_m8859CC64E52311816D0C8876E7DC70DD5FAF606B,
	XmlSerializableReader_get_XmlSpace_m6B6BF92B7765F973B96FBBCE3E0BCD98A1FC6E4F,
	XmlSerializableReader_get_XmlLang_m11C660C7EB7E3FEC6F17D3D27EB40FF8580950A8,
	XmlSerializableReader_get_SchemaInfo_mA2BF0B7C2B56D8E8EA62302C527753EA9B2AE56C,
	XmlSerializableReader_get_ValueType_m4BD7D4499DD09BBC0805D819BF609978C93BD5A8,
	XmlSerializableReader_get_AttributeCount_mB25688DCBFC141913F1B51CDAAC70EAD419599A5,
	XmlSerializableReader_get_EOF_mB1D92C6B579B179486419BFB8EB2ADDCB3276559,
	XmlSerializableReader_get_ReadState_mB351254052AB5FDA530FE1E77C08FC3208140C9F,
	XmlSerializableReader_get_NameTable_m9365876DEA928015730D5F4F7EBD57C023AE7E6F,
	XmlSerializableReader_get_CanResolveEntity_m0666DE1F1AEB3C6F3D3A0CE11671821A79DCA904,
	XmlSerializableReader_get_CanReadValueChunk_mC938231E2506F66836CA0CDBE989CA53655B05C2,
	XmlSerializableReader_get_HasAttributes_m7B1D3E2690E467EE8253E1AB178A89880C158843,
	XmlSerializableReader_GetAttribute_m7A16441E87283C4C285E6281D1BFEC2EE7F82B7E,
	XmlSerializableReader_GetAttribute_mF1808C2E0DC0B9DFBBBC762ACCFFF27BA812E4BB,
	XmlSerializableReader_GetAttribute_mDA8570E800ACD3DF2EA6C37D259E19A41E86FF39,
	XmlSerializableReader_MoveToAttribute_mB44332BC4B48CFC00E5F7AE8C2D36439BB01AEAC,
	XmlSerializableReader_MoveToAttribute_m46F65051760BDCA15CB4FB62FCD746F1D8EC1437,
	XmlSerializableReader_MoveToAttribute_mAB5586FA653054EEC88C729CF63B8FFFCF30D697,
	XmlSerializableReader_MoveToFirstAttribute_m85E86FE369CD0C118BB8093050A3D9C1BBFD2EAB,
	XmlSerializableReader_MoveToNextAttribute_m657C1DD81AC33FEE3D726B42DBDF389C1D8560B2,
	XmlSerializableReader_MoveToElement_m90B4CB16D22AFBBF49D0FE02D9C589AD1941DCF1,
	XmlSerializableReader_LookupNamespace_mBB79CA6D5D89CA7A1647E4CEE3B781F9EDC85F37,
	XmlSerializableReader_ReadAttributeValue_m3CCEAE702E34053251FCE38C8229A277AD2198A3,
	XmlSerializableReader_ResolveEntity_m8464547F8DB2FF484384F728B4736C927BB89A51,
	XmlSerializableReader_IsStartElement_m9204015FFFD7DA486FF14D281C06D0035BE2026B,
	XmlSerializableReader_IsStartElement_m720F1B14D715A2AD5AE9076FA61523755297C6A1,
	XmlSerializableReader_MoveToContent_m93756103292DBD2A92F5FC05CF26FC808D4AC10B,
	XmlSerializableReader_ReadContentAsObject_m803DDCA894011D3A1B452399BBC5186ED95AFCFF,
	XmlSerializableReader_ReadContentAsBoolean_m530E54220EEA2EB7018C4E257FA96C32C7233623,
	XmlSerializableReader_ReadContentAsDateTime_m4DF5312E0B4D47B5589DAD0EB7FF7680E08B2821,
	XmlSerializableReader_ReadContentAsDouble_m011F9CCD2BBE6B4AB6C06C8BF13C1DFF5B9F3958,
	XmlSerializableReader_ReadContentAsInt_m5635875B3ECE82AA1AE18F1885D451E26B52683D,
	XmlSerializableReader_ReadContentAsLong_mA5AF7ED8C355FF57A939904A7B205010CA6DA46A,
	XmlSerializableReader_ReadContentAsString_m47863037B9D9E57A3B36E8F21EDB107D4A2454B8,
	XmlSerializableReader_ReadContentAs_mE0E7454E258FD1BF77A56129828BD4ACA5DD0C04,
	XmlSerializableReader_ReadContentAsBase64_mD378E59686629BC6B66851CC445EDF22373AD63C,
	XmlSerializableReader_ReadContentAsBinHex_m5F43A9B5ABFDD0FBC3AC505A891D1E9E487818DD,
	XmlSerializableReader_ReadValueChunk_mEDDF5597444B4549716EDBAC0FAA852B694C2D07,
	XmlSerializableReader_ReadString_m3C9C95DA6B1F8236DB5B3CE85414C9751990FB54,
	XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_get_Normalized_mAD0E03710EA89B8C7102D9FA137BA094A8C6227F,
	XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_set_Normalized_mD23FE8BA4181588F701799150851FEDE53D8262C,
	XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_get_WhitespaceHandling_mDD7AD8843204CBD378C7F1765ED6C4730D2E9264,
	XmlSerializableReader_System_Xml_Serialization_IXmlTextParser_set_WhitespaceHandling_mB322D20FD78B463C63CCADAC8B13118042019CEB,
	XmlSerializableReader_System_Xml_IXmlLineInfo_HasLineInfo_mBC1882F34A081DA753092CB238EEE83C6030B67F,
	XmlSerializableReader_System_Xml_IXmlLineInfo_get_LineNumber_m983064892A7D0C8B81AE735B8FC7D19B6D3D69A9,
	XmlSerializableReader_System_Xml_IXmlLineInfo_get_LinePosition_m5E6B786B256CCAB666701875D59EF5018123F0F9,
	XmlSerializableReader__ctor_mEFF4D9B60FBFAB4DEE33C988138C8435CD6D69E4,
	XmlSerializableServices_ReadNodes_m25CED267F2F1FEF95D104A2A389885E6B4BCE256,
	XmlSerializableServices_IsValidAttribute_mBDC9273980421A6E4E769DF0F5956728DDF010CF,
	XmlSerializableServices__cctor_m3439B3A0CB3F11DEB556DC552A50C3E595D64419,
	BitFlagsGenerator__ctor_mBF4444E1B242ABD6ED751FE7362D9431EA0128D7,
	BitFlagsGenerator_Store_mE2EB70CD5B4611E3B66E6E306FC406F5B0B25437,
	BitFlagsGenerator_Load_mC08357BA2A65F5FBE3974AF2A79DD89A58715368,
	BitFlagsGenerator_LoadArray_m8D77D7198390C4896198F147BF195825E7E30AA3,
	BitFlagsGenerator_GetLocalCount_m0DBD381788632CB4C696ABB48970C120CD205DD4,
	BitFlagsGenerator_GetBitCount_m9C65E15FF21FAD9F48313F626C6372EB91586CF2,
	BitFlagsGenerator_GetLocal_mC27A703EDB4133C29EBD56405A5DA27DE620DC7D,
	BitFlagsGenerator_IsBitSet_m653D1EEA314AC752B63A21ABDC010A3DEEBA407D,
	BitFlagsGenerator_SetBit_m0C2FCDF279F946381F2092FC8652EB0C6963B0F6,
	BitFlagsGenerator_GetByteIndex_mD2BC56AC9E4FAC3266B3FC1151C3D788F02A4B49,
	BitFlagsGenerator_GetBitValue_m2D7DE0BB46380E80BE5AE746BAEDC6BA2F44C292,
	CodeInterpreter_ConvertValue_mE184C0E4C56A45864BEB7E7F81A4C4F24BE53A3D,
	CodeInterpreter_CanConvert_mF09439AA95AB2169D4D9AA0B2F0C62EF6ED9845B,
	CodeInterpreter_InternalConvert_m3A85D95C28398A1C6BDFAB880E6F8A465D4EC80C,
	CodeInterpreter_GetMember_m7DA7EEB040C6D19FFDCD06492A163B8FAF9AB155,
	CodeInterpreter_SetMember_m71954618E3A5A1201150D1A591F3D7126ECD8DB8,
	DiagnosticUtility__cctor_m5F64B6C8FE8B54849A165BE67252B32CC1ACED1A,
	DiagnosticTrace_TraceEvent_m2AC3A2106A380B47251EC3AC6D48E835EFEE58F4,
	ExceptionUtility_ThrowHelperError_mB01429D47ABA81955EC561D8286C63E8C74D5FB6,
	ExceptionUtility_ThrowHelperCallback_mC035C0936B0B4DFD780FE9E3B356401880460241,
	ExceptionUtility_ThrowHelper_mB8572AC383576258341DCD063A8B28ECB635F081,
	ExceptionUtility_ThrowHelperArgument_m3742379C7B9235D0A083D5FBE7E528071D86B6CB,
	ExceptionUtility_ThrowHelperArgumentNull_m758514C87C3B905C2DFF60D19630F479958BEE79,
	ExceptionUtility_ThrowHelperFatal_mACCEE6A91E32560E8F884432D126992DA1C94700,
	FxTrace_get_Trace_m5C29850211785937295F00E947CB9855B011C210,
	FxTrace_IsEventEnabled_mB5C223ECE3EEC745E2801FD8CCB28A5718CFDD9E,
	FxTrace_UpdateEventDefinitions_mD9D92212E2CEDBC23BAD9907A396BC20866B97DA,
	FxTrace__cctor_m65A354FD4FEC05CD6917A8CF9276DDF15CB62CF7,
	SR_GetString_mCB22EBBC246A223CDDA76C1D8F355262069E2DD4,
	SR_GetString_mACA6407683C37D3EF5674BC49C44F3830ED60199,
	SR_GetString_mBD8F2ECD53B5DF9AADDE7871DB25FCBA4D50025D,
	CodeTypeReference__ctor_m089E48CB392B602025ACAD901A8804F3A1C037AB,
	CodeTypeReference__ctor_m6BBFD6D30604A75C4219A7183CD9C34A52C5641F,
	CodeTypeReference_Initialize_mB4459889F5CE3DF18CCA6B13614EAA5902654B34,
	CodeTypeReference_Initialize_mEAE97FA187F01B86C4D0FBF22A0DDDE37CBFBB52,
	CodeTypeReference__ctor_mDDDD5E8B359269E81F1D15837EDD204FCA868D64,
	CodeTypeReference_get_BaseType_mFEA2E3FCA0AF01F5FB973C46EA737280360932CC,
	CodeTypeReference_get_Options_m1B59BF301B82B465C621FDA0C7970D8BBB03BF91,
	CodeTypeReference_set_Options_mE1B0FACDE4A337A61EF593ABAC1B836A0DA92580,
	CodeTypeReference_get_TypeArguments_mAFE5B459E8EE2B6DF5E51EEC6882E5059990D5F3,
	CodeTypeReference_RipOffAssemblyInformationFromTypeName_m248C55245E91D1A501ADEA2248A0B6AE5A89F27B,
	XmlDataContractInterpreter__ctor_mDF0271C5F01EF0302351DD287FD7D760832B32F7,
	XmlDataContractInterpreter_CreateXmlSerializable_mE0C0AD3EBA97A902E1E9678628777E4CF6C942EE,
	XmlDataContractInterpreter_GetConstructor_m2EC6FB905734629ABA9537F417F54C909A2DFDFD,
	XmlFormatReaderInterpreter__ctor_mC144D3623656AD6093EA78FAC0F916AF26A5D124,
	XmlFormatReaderInterpreter__ctor_m4E4AC9589717FBDC9E05CF4F8E9DA9ADE5F6636A,
	XmlFormatReaderInterpreter_ReadFromXml_mF6B79876541301C2EAE0EFB1C2F4BB53074A3D86,
	XmlFormatReaderInterpreter_ReadCollectionFromXml_m1D442C039CAD333F5BDFDE9EF596A179C58DCC27,
	XmlFormatReaderInterpreter_ReadGetOnlyCollectionFromXml_m63C147876DD578A147C827276263E5CE56594C99,
	XmlFormatReaderInterpreter_CreateObject_m068757F2D37ACC691BDD559996B1F2223A5785F3,
	XmlFormatReaderInterpreter_InvokeOnDeserializing_m267CB7BA61240CF1967ECDFF8914EA9DB99FA187,
	XmlFormatReaderInterpreter_InvokeOnDeserialized_mCC5CBD61D2DC2A3E12CDAD92796ECB67538B6CCC,
	XmlFormatReaderInterpreter_HasFactoryMethod_m5542C9CF5C7D24792D5AFF8677528CE9B1842B0C,
	XmlFormatReaderInterpreter_InvokeFactoryMethod_mCBA762FC03426A448BB845F53D99B6DDE3B49B03,
	XmlFormatReaderInterpreter_ReadISerializable_mD718C6A6375FDF275F647C7EBF30D196666F1C95,
	XmlFormatReaderInterpreter_ReadClass_mB0CC70A813710813D1796884EF61FEBF7A51E863,
	XmlFormatReaderInterpreter_ReadMembers_mEFC2959C959ADF9670551916B1311CDEA5BFD4B1,
	XmlFormatReaderInterpreter_ReadMembers_m7CD09378520806270C8E278AC1A6A4F1B4DAC5AC,
	XmlFormatReaderInterpreter_GetRequiredMembers_m87578C30B2C524269CDF25F7BC80761E20A04A14,
	XmlFormatReaderInterpreter_GetRequiredMembers_m595218E4E6A0C79546E0D519E248E2751E929DE0,
	XmlFormatReaderInterpreter_ReadValue_m7688CA2B813CEAA403F73A6CCC997334DC1201A6,
	XmlFormatReaderInterpreter_InternalDeserialize_m01E0878754D8DB05105A14AD23ECCE83EE46F1DE,
	XmlFormatReaderInterpreter_WrapNullableObject_mE377C7E81B6DF0F8EE0B949278CEA7758C2AC182,
	XmlFormatReaderInterpreter_ReadCollection_mB396F6AB6407698961EC8DBCBF6A5DF535546E2C,
	XmlFormatReaderInterpreter_ReadGetOnlyCollection_m74C9DACDEDEA81FA2B680D35D055A99A272E8305,
	XmlFormatReaderInterpreter_TryReadPrimitiveArray_mFFE30A1F7E3D85890B0D15EBCF08C9C8E79B0069,
	XmlFormatReaderInterpreter_ReadCollectionItem_m71C427064AC568380F49B5E2CF46F0CD2C99FEB7,
	XmlFormatReaderInterpreter_StoreCollectionValue_mC1A3CFC655DFE24CB3BEDCBE4C774163F92B8833,
	XmlFormatReaderInterpreter_HandleUnexpectedItemInCollection_m6936FB841525F86C45E6B561723F867142084656,
	XmlFormatReaderInterpreter_IsStartElement_m381B0C239284DD41918C37FBDCDDF6E8D31E8384,
	XmlFormatReaderInterpreter_IsStartElement_m0D5933794D083CE3E5988E3707AF0009C7255FD6,
	XmlFormatReaderInterpreter_IsEndElement_m1064E2E63279CCACE84B30DED95DD084342AB90C,
	ByteArrayHelperWithString_ReadArray_mB3AB2BD38AF548098816812EDC5272F5BCA7F21F,
	ByteArrayHelperWithString_ThrowConversionException_mB6880A7C7C1E90BF9CBF6567DB09699FD2CA2564,
	ByteArrayHelperWithString_ToByte_mE6F6A9A860BC193F5BE6257B335A60031C42A225,
	ByteArrayHelperWithString__ctor_m1B794705D1A61D8B399AF85ACDFC02BC6246A987,
	ByteArrayHelperWithString__cctor_mA6E8A5750AEA133F084C055AFA799CBB8B103186,
	DataContractJsonSerializer__ctor_mDBAD2FB5F119218821A9805D8F576DD2FAF7F639,
	DataContractJsonSerializer__ctor_m558ADAF0B17436D1970D4A62FB63CB4DBA1ED006,
	DataContractJsonSerializer__ctor_mA81FB3CB6F4A3F2D769551B5C7177AEFCD3F548B,
	DataContractJsonSerializer_get_DataContractSurrogate_m1C64289ADA6874FA4D22DC7DEDCAA942A1E94203,
	DataContractJsonSerializer_get_IgnoreExtensionDataObject_m1FD14E3DA7649A69B4F9799FC739BBC1045DA9B7,
	DataContractJsonSerializer_get_KnownDataContracts_m2094716DA8F4B4911F55108AF6A58C3E1004838D,
	DataContractJsonSerializer_get_MaxItemsInObjectGraph_mD7A1F691B986F383033A6F34FBB98A2BD9EDB369,
	DataContractJsonSerializer_get_DateTimeFormat_mDCE3872786BB543FC7A58BE55E661735FBFEBF98,
	DataContractJsonSerializer_get_UseSimpleDictionaryFormat_mAFA38F1790DD2318B8537D353DA578F4F6C1859C,
	DataContractJsonSerializer_get_RootContract_m5AF8FFA664AB905DAB99C4B0CF0E92E1BD9EEF39,
	DataContractJsonSerializer_get_RootName_m9A889DAA72098400AA3A2422D80A09D6984FBE24,
	DataContractJsonSerializer_ReadObject_mCF613FC3BDF510375E609FE7A7867ADE00F26B6A,
	DataContractJsonSerializer_ReadObject_m3511A16A95C047B844E1BA6A8801ACA9777BC031,
	DataContractJsonSerializer_ReadObject_m8CD7300185045923CBCEDEF5E7085100A171969F,
	DataContractJsonSerializer_ReadObject_m8482103334C6BBD49D7AE85DE9E6CBBD5ED0C251,
	DataContractJsonSerializer_ConvertXmlNameToJsonName_m50587D1A3791480FF1B67520DED41279C4BDA7B8,
	DataContractJsonSerializer_ConvertXmlNameToJsonName_m296CB32813B04EC4E3FECB16FA3D7748E002A6CA,
	DataContractJsonSerializer_IsJsonLocalName_m385B49F0478862BEE7607EF2E61CDE0091E0BFF6,
	DataContractJsonSerializer_ReadJsonValue_m2DD44F490A394660A3A9AC13D10F374054432A67,
	DataContractJsonSerializer_GetDeserializeType_m1F5931EFB44A4EAAE5EB7462E38194B09FC428BC,
	DataContractJsonSerializer_InternalIsStartObject_m7D0BAE67C02837E00E240259D75D3D4C0A518B73,
	DataContractJsonSerializer_InternalReadObject_mB750923CEA1B7E8873E72D3BCFEB60D41A13B2A2,
	DataContractJsonSerializer_AddCollectionItemTypeToKnownTypes_m344C0164F99638654ADB9A3540F91CD71058539B,
	DataContractJsonSerializer_Initialize_m213EB8E92CB41AAC0B39EECC71DF0765BDBA81BD,
	DataContractJsonSerializer_CheckIfTypeIsReference_mB433F59C8FF210AFDDC842CC6FBD08E38B6F6690,
	JsonByteArrayDataContract__ctor_m16A4CDECB6FF9E5135789E9FB0F1E4BEC28156EC,
	JsonByteArrayDataContract_ReadJsonValueCore_m36425EA858E131FC6D168E6EBEE7668DB9AD8731,
	JsonClassDataContract__ctor_m2DF702BF896653932C9A624A58004FC365948842,
	JsonClassDataContract_get_JsonFormatReaderDelegate_m6C1981D88C32ED659BBD26E3D76F5D4E38514E41,
	JsonClassDataContract_get_MemberNames_m2325D54594ACAC4201BD59C09E21D1C5E646F1B1,
	JsonClassDataContract_get_TraditionalClassDataContract_mD568B405A14E04823E4842513CC52CD313995C0B,
	JsonClassDataContract_ReadJsonValueCore_m837A00A26EA027552A663B143FEB8967860A481E,
	JsonClassDataContractCriticalHelper__ctor_m20E10E2F719458680951710713D0183FF9E666EE,
	JsonClassDataContractCriticalHelper_get_JsonFormatReaderDelegate_mACB761B123592E44B8CB07D06F64DBC2BBD2C7A2,
	JsonClassDataContractCriticalHelper_set_JsonFormatReaderDelegate_m04BD3CD2EAEE846F572AEEE6AE3AE33E38A8C90C,
	JsonClassDataContractCriticalHelper_get_MemberNames_m019B90803B40FCD141777B8659A70604AFB20552,
	JsonClassDataContractCriticalHelper_get_TraditionalClassDataContract_m4BF70788225F03091B982381EE30141C0AED6C5D,
	JsonClassDataContractCriticalHelper_CopyMembersAndCheckDuplicateNames_m8055F8B0EC3C4B387DD81FAC8C975AE40912A11A,
	JsonCollectionDataContract__ctor_m2E15722B25974EE7F46C3057984E00B4E4ADCBD0,
	JsonCollectionDataContract_get_JsonFormatReaderDelegate_mF6677082D793464D5429DA8B3702DDF0CC7E3627,
	JsonCollectionDataContract_get_JsonFormatGetOnlyReaderDelegate_mAAE3A3147EED31EC77F3A056EDD909BB84C573DD,
	JsonCollectionDataContract_get_TraditionalCollectionDataContract_m5E5F2AED19B597EFA0B30639A3A07E5B344052CE,
	JsonCollectionDataContract_ReadJsonValueCore_m16F8F7087AAD6CA9701DD02D9C03B15386C69FAE,
	JsonCollectionDataContractCriticalHelper__ctor_m0D5F3F29E4FB5A3E874D48C823A47494176146EA,
	JsonCollectionDataContractCriticalHelper_get_JsonFormatReaderDelegate_mE2E4FFF15C80E60EF435A2ECE3E855B4A52C6D39,
	JsonCollectionDataContractCriticalHelper_set_JsonFormatReaderDelegate_m431D30336E761E93489BDF94D80BF4BF8B5CD13A,
	JsonCollectionDataContractCriticalHelper_get_JsonFormatGetOnlyReaderDelegate_mBD4A37C895337475A6AD51783B74E9FA19F735B7,
	JsonCollectionDataContractCriticalHelper_set_JsonFormatGetOnlyReaderDelegate_m618607EF3DF5B720049767AC4937BBE7C0821336,
	JsonCollectionDataContractCriticalHelper_get_TraditionalCollectionDataContract_m9F8C7EF7BC66B0C54BFF12D73284CE87BBB1FFFF,
	JsonDataContract__ctor_m2AE5BA1403129478C92F28B41D8140A6AC3637B9,
	JsonDataContract__ctor_mA93F655166D5211899A9E9B29C8B76823C02CA74,
	JsonDataContract_get_Helper_mDC4D4244B2C7ECDB3BEE95044F7597A6649CACED,
	JsonDataContract_get_TraditionalDataContract_m236E30BF2485A969D21BC8B0D23767D67BDD2197,
	JsonDataContract_get_KnownDataContracts_m406233066ADF9442874CF21756C284EE9124AFFE,
	JsonDataContract_GetJsonDataContract_m18EE3442A309734B894217D3D52BBA7C7E04FA1F,
	JsonDataContract_ReadJsonValue_mF9898B88487F0E90B879A3026DD13907B761848A,
	JsonDataContract_ReadJsonValueCore_m284221E4CB2BA96E3E2AB4DBFFDF85B46FA1A2E6,
	JsonDataContract_HandleReadValue_mE2CCEA432EE960DEB8CDC04B729C641E8A4BD832,
	JsonDataContract_TryReadNullAtTopLevel_m67448DFCD7C56478EA2E563D7F4F41344D7E2B77,
	JsonDataContract_PopKnownDataContracts_m739AACE9797AC5518EBA40A0F85638C37407F6C7,
	JsonDataContract_PushKnownDataContracts_mCF669588E06B5768C5CD5796B997D9E3D9ECA7E9,
	JsonDataContractCriticalHelper__ctor_m8E39F6E4EF1638DDD48DA5983C59646BD24A949D,
	JsonDataContractCriticalHelper_get_KnownDataContracts_m26F06804EC3C7A4FAE343971B2EEC26807ADC0A3,
	JsonDataContractCriticalHelper_get_TraditionalDataContract_mC51A222FB32748EC2F5AFB9B79998A393A13AFAF,
	JsonDataContractCriticalHelper_GetJsonDataContract_mD351272C0675E3DBE9FB77432E1413E1344BC68D,
	JsonDataContractCriticalHelper_GetId_m14A8A3E4621F058CF94DDC8E95EDF8005E2CCE42,
	JsonDataContractCriticalHelper_CreateJsonDataContract_m0D70DF5BA5D4753D567430BA9831E09E07C5EB41,
	JsonDataContractCriticalHelper_AddCollectionItemContractsToKnownDataContracts_m5ED38536A543F80022532A7274C27DF6ADE7D075,
	JsonDataContractCriticalHelper__cctor_m270ACC278080F70187F80AC36BDD25FA5C3EF545,
	JsonEncodingStreamWrapper__ctor_m55881BFCA9AE245054CD741AE643D663E22659D6,
	JsonEncodingStreamWrapper_get_CanRead_m92037440463B605B6972287DD5DAE31D0E129ECB,
	JsonEncodingStreamWrapper_get_CanSeek_mC32DFA69021433D2851031F41941CCEFA024C479,
	JsonEncodingStreamWrapper_get_CanTimeout_m97AD5DC5F87318FD7D41C383D76954330A62F7CA,
	JsonEncodingStreamWrapper_get_CanWrite_m22EC5145193F1D571AA40F18A3AE2286C3D7D95B,
	JsonEncodingStreamWrapper_get_Length_m2AD801FFB3C021ACC7F80590D6C909C618069AFC,
	JsonEncodingStreamWrapper_get_Position_m95CFB106FAB3DF90620FEF9E06DEA115DBB582FC,
	JsonEncodingStreamWrapper_set_Position_m0767A4B0F5B491614A995DCFCCA20085D7DD8684,
	JsonEncodingStreamWrapper_get_ReadTimeout_mBCA54F9F4F0E998BDDC7BB56E884039F7FACF540,
	JsonEncodingStreamWrapper_set_ReadTimeout_mB1118C8F0E59FA6F75614E5564209B416971B4E2,
	JsonEncodingStreamWrapper_get_WriteTimeout_m3363AFD655EBFD9E551E642088BCD69AF8780D4A,
	JsonEncodingStreamWrapper_set_WriteTimeout_m2FBF47522B356C12AF3EC3562EE1C0FA0C626BD7,
	JsonEncodingStreamWrapper_Close_m3D9E823A4C242CBBB6B7FE895D22B8E2F10307A8,
	JsonEncodingStreamWrapper_Flush_m18137D8FD12C6FA7AD97D0651159807334FFF91B,
	JsonEncodingStreamWrapper_Read_m5FE4432249CF12DEBA74D176C0B95DE3651B7CEF,
	JsonEncodingStreamWrapper_ReadByte_m75428C04EC879163A47768212851FC71D3DF1CFA,
	JsonEncodingStreamWrapper_Seek_mDA54187828F3CEEA64F1379C9CBF1A836E0758D5,
	JsonEncodingStreamWrapper_SetLength_m625E5B4D0DE38C5913507DA92ACED513A047A8BC,
	JsonEncodingStreamWrapper_Write_mBA0BE019A09B3D5B2C51650F703732DF08A96358,
	JsonEncodingStreamWrapper_WriteByte_m63082DE505B870A7EDC898D2C56002E2BCA2AE75,
	JsonEncodingStreamWrapper_GetEncoding_m67C305A05554D08C1A3B9CD5E261C4146ED0CE21,
	JsonEncodingStreamWrapper_GetEncodingName_m6E9E73420497391158E41652A2749A9DB17EC8E9,
	JsonEncodingStreamWrapper_GetSupportedEncoding_m843367225D3B2D69B399892809B792E889B521E8,
	JsonEncodingStreamWrapper_ReadEncoding_mA95F2B3E0AA1C2D2D9AB281B4C44EA2F325DC79D,
	JsonEncodingStreamWrapper_ThrowExpectedEncodingMismatch_m4291E6EC42820B67948580D01DF17E6DD406DAE6,
	JsonEncodingStreamWrapper_CleanupCharBreak_mA7C555BCFEFAC40810288A21193974401B914919,
	JsonEncodingStreamWrapper_EnsureBuffers_m63DF4630980BA430B69DB2D296FC7C5D7778E1FC,
	JsonEncodingStreamWrapper_EnsureByteBuffer_m628B607930D1E26D3CED7032E9DD7F7B37486050,
	JsonEncodingStreamWrapper_FillBuffer_m543CE1A485A4229839AA5FACB39AF52419C86107,
	JsonEncodingStreamWrapper_InitForReading_mE6CA3CAD8601EA31F0CCBD62371AE695D1DA2C75,
	JsonEncodingStreamWrapper_InitForWriting_m2EED8243D269538EFCE9C45C73CF708B748912F8,
	JsonEncodingStreamWrapper_ReadEncoding_mC82C71C0AA3A34698A4F595E4B6F61B5A1C413E3,
	JsonEncodingStreamWrapper__cctor_m3C75D41AC613032B59329315132456374CF03BE4,
	JsonEnumDataContract__ctor_mE47E7FF170FD7F3C5AE4A3C4D077383D0DC1145E,
	JsonEnumDataContract_get_IsULong_m05F0FFE0858D88D8895ED2DD47DF5564BC00A91F,
	JsonEnumDataContract_ReadJsonValueCore_m670EDE889054D8762995D924805033A7B8EE26C5,
	JsonEnumDataContractCriticalHelper__ctor_mBB17A840DC678D491F820D8D7D15F579F6D66E3D,
	JsonEnumDataContractCriticalHelper_get_IsULong_m5EAD37449874373EBDACCEB919778B58E34A4162,
	JsonFormatClassReaderDelegate__ctor_m2F4DBCB5849DF53C2AE67EC89AE84E70F8AD8866,
	JsonFormatClassReaderDelegate_Invoke_mAAB83E87D989C5C2E6207E8635AF98DFA726CFEF,
	JsonFormatCollectionReaderDelegate__ctor_mB89481ABA75B71FC642551360B8F6F862D086EA9,
	JsonFormatCollectionReaderDelegate_Invoke_m04E7661456E088542702A50B37CA9FE32DCC9DF6,
	JsonFormatGetOnlyCollectionReaderDelegate__ctor_mBC50D36CE7B9F664BDC7ADBBB586C4539C028098,
	JsonFormatGetOnlyCollectionReaderDelegate_Invoke_mCCFFC3D1894228A4659DA55374DB3225A4A853A9,
	JsonFormatReaderGenerator__ctor_mAE40E9556456C29F3B8EED1D6832931DB2CD7EE8,
	JsonFormatReaderGenerator_GenerateClassReader_m204BAB8CC82A5282AA41E97138D4C034382615CB,
	JsonFormatReaderGenerator_GenerateCollectionReader_mFA5464DD44D51CA4845C98BB8F43DEA99366A195,
	JsonFormatReaderGenerator_GenerateGetOnlyCollectionReader_m911990A0E21A319FA0A10BEFFB84DE78A2F158B9,
	CriticalHelper_GenerateClassReader_m5463698C2D0AFA303C2C3430FE0DF6A77DD016DA,
	CriticalHelper_GenerateCollectionReader_m3E9D3E773C5F5607FBE9CB2E4AFAB7447FEBC957,
	CriticalHelper_GenerateGetOnlyCollectionReader_mAE9F4B788F6A216B7420ABED5943BE30C178BC00,
	CriticalHelper__ctor_m399F61544F67A2F49613EBB21A7C9C9E58FAEEEA,
	U3CU3Ec__DisplayClass0_0__ctor_m8AAF28EEB4B3494013AFF0BEA19D6F1D65CE7B12,
	U3CU3Ec__DisplayClass0_0_U3CGenerateClassReaderU3Eb__0_m7F635744D426476BF93FD6B2143084707C5643CD,
	U3CU3Ec__DisplayClass1_0__ctor_mFCA0B3FC1151A429C5785BA636443B252AC3E42E,
	U3CU3Ec__DisplayClass1_0_U3CGenerateCollectionReaderU3Eb__0_m716BA6A2FE1525BF906C5DB301C81731D16F1549,
	U3CU3Ec__DisplayClass2_0__ctor_m4B934391FD0EA30137B0E6CA9845B532F09AA1E2,
	U3CU3Ec__DisplayClass2_0_U3CGenerateGetOnlyCollectionReaderU3Eb__0_m98B14D1C7978DAD4C7640D927AD079A1EEACA188,
	JsonGlobals__cctor_m499E735778FC97B03243105D23C173D8552D362E,
	JsonObjectDataContract__ctor_m00AB3A171DB0249D0ADCF2E29FFD5FDCB17FC97C,
	JsonObjectDataContract_ReadJsonValueCore_m78253A21FE0C49CB809C171CAD9DBC8EE145224E,
	JsonObjectDataContract_ParseJsonNumber_m0B56A61CC1D26EAF19649FD6D1C3C4E92ADB137D,
	JsonObjectDataContract_ParseJsonNumber_mD695A7CDF1510F3F0FB9EAEEAABF1F1BB19A07F7,
	JsonQNameDataContract__ctor_m0D45B7573F11C5B5F76AE3C97E0D9750253F6617,
	JsonQNameDataContract_ReadJsonValueCore_mF241330C6847FAC9C5E29543F3CC2BA12F92BFF3,
	JsonReaderDelegator__ctor_mF8A9B93C8461179AE979410D66FFA9A6EA1F5F5F,
	JsonReaderDelegator__ctor_mB6DD03CB22CFE005A1F9A9F37934911788A396E9,
	JsonReaderDelegator_get_ReaderQuotas_mC60FE55589D8A0A209B4C31C7A0490938BC0DFDA,
	JsonReaderDelegator_get_DateTimeArrayHelper_mF83DCAA117D8ED0C177FBC8625C9CF7D251534D9,
	JsonReaderDelegator_ParseQualifiedName_mD6829EAB7DEEF92FFD1D410471797901D5251706,
	JsonReaderDelegator_ReadContentAsChar_mF3E7BDB28C7C94F9DCE5B7565EF5B1FE56434DAE,
	JsonReaderDelegator_ReadContentAsQName_m4141C9F78047037BB3C0516D4F95FBFB71E731EC,
	JsonReaderDelegator_ReadElementContentAsChar_mE752F9DB2D01DFAEC5B98EB58B54D9DC49A903AF,
	JsonReaderDelegator_ReadContentAsBase64_m31208E3A55F15F0627637D1BFDC29337ACD7C230,
	JsonReaderDelegator_ReadElementContentAsBase64_m904F764AE29C2D11C42D437EE9A23B5616CF8731,
	JsonReaderDelegator_ReadContentAsDateTime_mED4039C9CBB951459C92B17F03C71269A5B3096B,
	JsonReaderDelegator_ParseJsonDate_m629EA10B51432F2DC6F0EF08A0A6165277C7CB92,
	JsonReaderDelegator_ParseJsonDateInDefaultFormat_m0847D5A4DCCAB0ED2CA4D0F7A158575CE249B0F8,
	JsonReaderDelegator_ReadElementContentAsDateTime_m489BA45397AF1ED781A00AF3AD0D3100FE237C6A,
	JsonReaderDelegator_TryReadJsonDateTimeArray_mBEEF54F15BCDBD2FD68675337EE11EF7D6BFC5A1,
	JsonReaderDelegator_ReadContentAsUnsignedLong_m3AF9061BDE3589930DDA726BAEBBF72E96089DFF,
	JsonReaderDelegator_ReadElementContentAsUnsignedLong_mFFE7812B07B7ADC4BA547D0D1823C57801100F4E,
	DateTimeArrayJsonHelperWithString__ctor_m80D81CC6DAB430F7BCD9D714F2D88334F1EE9AE7,
	DateTimeArrayJsonHelperWithString_ReadArray_mDA4C7CA5FBA3C3829DC7B5CFAB267483A9F82511,
	JsonReaderWriterFactory_CreateJsonReader_m662CFCA2554A46B4357A4A1776B6F7029A216820,
	JsonReaderWriterFactory_CreateJsonReader_m5B490359A2903A9E0E53F5A8866309E343ADB751,
	JsonStringDataContract__ctor_mC6767265D363AD99D2B30DD6A47CE0EBABED10DC,
	JsonStringDataContract_ReadJsonValueCore_mC1B32A955B9A4D8B7CAD7E2FF1E7B676A768E029,
	JsonUriDataContract__ctor_mC851DE0D2713F44C8D9B8C45B07042F02A43F5E1,
	JsonUriDataContract_ReadJsonValueCore_m9790136115B682C01298F54D27B70718F6B5DCED,
	JsonXmlDataContract__ctor_m96D8E4ED9FADFB15AD9EB6AFF8E95A266182C31D,
	JsonXmlDataContract_ReadJsonValueCore_m9E3A438D2AD28ABA834260BA88B52698D6E5BA7B,
	JsonXmlDataContract_GetKnownTypesFromContext_m791F316BDEA4A1E656950D85EACC2797F0F64F05,
	XmlJsonReader_get_Value_mD4BF363350C3D29441F286CDC07BB1D7ACD1CF75,
	XmlJsonReader_get_IsAttributeValue_m990BCD4E841CC82CE8D9FD1AAC6D62D72D14CDC4,
	XmlJsonReader_get_IsReadingCollection_mC54F2AAD455D4F32B115877FF26ABEAF7159DBCB,
	XmlJsonReader_get_IsReadingComplexText_m27B930346FEA477A768156C5A9C5CBB9A410E367,
	XmlJsonReader_Close_m3443826B75CD941D16A1E2D619722A4CF9F8F453,
	XmlJsonReader_GetAttribute_m1122C3CA0CD42F5A574E508B3A6457C6F23FF470,
	XmlJsonReader_GetAttribute_mF24B5C7DA226323C36FA8D6BF9B8DD9754A08F13,
	XmlJsonReader_GetAttribute_m0842A6194C64222D2EE9CC8336E1D1CDBB3E3ECF,
	XmlJsonReader_Read_m54540A632EDD2A067F481B9C6B0304A8C3BE1BF9,
	XmlJsonReader_ReadContentAsDecimal_mBB60C8BDA8062CE587B3868248E521DDDE0992D9,
	XmlJsonReader_ReadContentAsInt_mAACC2DF2C9D31C07E61FC82D0013BD39FE0B7579,
	XmlJsonReader_ReadContentAsLong_m0B876F9FE68E02D43ACA903DEFC4070630E7738D,
	XmlJsonReader_ReadValueChunk_m6F2DE5BE6815F23490512C3BBB7A6DC7B62AA0BC,
	XmlJsonReader_SetInput_mABD3376B5D0FD1D69038083AE5DC064B1705933A,
	XmlJsonReader_CheckArray_mD74CF6709FD77A398182C97213756C843F5A440B,
	XmlJsonReader_BreakText_m8B06025EEFB3FD3DE06ABB870D3D1780A2284D83,
	XmlJsonReader_ComputeNumericalTextLength_m8C2977B55F37664CFE41A72B232668139E0EAB0A,
	XmlJsonReader_ComputeQuotedTextLengthUntilEndQuote_m2D2BEE40C0A43F74F38FE34B57ECD2F424E4DCA8,
	XmlJsonReader_IsWhitespace_mBCF2E133AE90FCD83F906CC131D20A37BB328EA8,
	XmlJsonReader_ParseChar_mA0A06B22BDDEEB7FC00A2AB917BF8ACB51A6706F,
	XmlJsonReader_ParseInt_m505C732803238B20A0DC8C32AB0970A969856CF2,
	XmlJsonReader_BufferElement_m53721DB9427ED257E7670E60B5217B45D17076D4,
	XmlJsonReader_EnterJsonScope_m2E3160962A4EFACE20926EE49A7DFA09913F3522,
	XmlJsonReader_ExitJsonScope_mA4424BAC4A699A14E91C1F0EF7A9597960816BD3,
	XmlJsonReader_MoveToEndElement_m62D3B49AAC273F3DBF202ED6FE1863964C6E6AF8,
	XmlJsonReader_MoveToInitial_mCBF287D1219E08D1C7FFE45BB22522D5DE0241ED,
	XmlJsonReader_ParseAndSetLocalName_m981C74E15BB443197E58177396614B8CD4402F79,
	XmlJsonReader_ParseStartElement_mF0412AE34B040155CAEC349BAF7F34DACEFC7742,
	XmlJsonReader_ReadAttributes_mF653B2BF7C5D844AF1D71FA9BC78C9B8121ED6DA,
	XmlJsonReader_ReadEscapedCharacter_m21AAF4DE32B3B517A85B8821B6F3A2AAD65CF70A,
	XmlJsonReader_ReadNonExistentElementName_m2B747B93D4C999CBB4AC34E69F30C6C7BCEF9551,
	XmlJsonReader_ReadNonFFFE_m7320B9CB92794E7A944AAA9B76B6B843E4B83E25,
	XmlJsonReader_ReadNumericalText_m94D23C6F281F6EF938E092DF0282FF0C751D8043,
	XmlJsonReader_ReadQuotedText_m9CE9C4FD3229C5C5B56B51A80470EFD003EECDD5,
	XmlJsonReader_ReadServerTypeAttribute_m3A306BB46F0E0DB0D46195FD7AAC2969A717FFC0,
	XmlJsonReader_ResetState_mF12297948ED759E6FB480716ACD5FA37677F5741,
	XmlJsonReader_SetJsonNameWithMapping_m9606EB7D58A5645563674A269D12ACFED6C08E66,
	XmlJsonReader_SkipExpectedByteInBufferReader_mB12E9997E348BEA4C3C3B57D4B7A2BF3075095BE,
	XmlJsonReader_SkipWhitespaceInBufferReader_m4BF0995B42B369AF46F66B2F31D570F12FB28181,
	XmlJsonReader_TryGetByte_mDAE95F5BC57D39A9D3D3D49D051F556A383A85DD,
	XmlJsonReader_UnescapeJsonString_m8CAD0BCC9C4A60733066ADA5BA35CE80717252DD,
	XmlJsonReader__ctor_m25BAEF29BFBE83CF3477C0C15C8C172A7C0BF489,
	XmlJsonReader__cctor_mFA9E339A920E19987B1153CA1F9C688C0FDD3EF6,
	XmlObjectSerializerReadContextComplexJson__ctor_mA4FB3F666BBE801724B58B84FF092E7DAF41A937,
	XmlObjectSerializerReadContextComplexJson_get_SerializerKnownTypeList_mE5FFF65B9AFA299A5D0E250463A4C646C45A1B8D,
	XmlObjectSerializerReadContextComplexJson_get_UseSimpleDictionaryFormat_m891CEB8E032AD682A4575507FBB8D8FA04E71852,
	XmlObjectSerializerReadContextComplexJson_StartReadExtensionDataValue_mFFF0340898ABBE6E0326CF724BF13706A669FDC0,
	XmlObjectSerializerReadContextComplexJson_ReadPrimitiveExtensionDataValue_m5BF7CA4A44BBEF33B6E733403BDABD4C7628CC45,
	XmlObjectSerializerReadContextComplexJson_ReadNumericalPrimitiveExtensionDataValue_mF5C6447DE7B7370225C5727B78E47F998CD25749,
	XmlObjectSerializerReadContextComplexJson_CreateContext_mE4338F45843C78C04364174681FAFD52F524BBA3,
	XmlObjectSerializerReadContextComplexJson_GetArraySize_mA334060CCC3BB1DBFCF554B49E9EF026867C1C31,
	XmlObjectSerializerReadContextComplexJson_ReadDataContractValue_mCE8D60BC28F63C4C46064EC666963BF4AE7D9E7F,
	XmlObjectSerializerReadContextComplexJson_ReadAttributes_m04D5CBED4C97E4B3738C5782771A759D23AF0B26,
	XmlObjectSerializerReadContextComplexJson_GetJsonMemberIndex_m05E217B888BD74F6E817B911F742B6773A7FEF26,
	XmlObjectSerializerReadContextComplexJson_TryGetJsonLocalName_mD6EEF559A324ED2EF2D16E4BB14008593E5E98DA,
	XmlObjectSerializerReadContextComplexJson_GetJsonMemberName_m90D66B9C6054F89339A8CA92AB35F75E6E18F293,
	XmlObjectSerializerReadContextComplexJson_ThrowMissingRequiredMembers_m73D747E0208F694CF63CB106922A66C2A7EC95EA,
	XmlObjectSerializerReadContextComplexJson_ThrowDuplicateMemberException_m08D759732DDA8BFFE4F7A0188E74386D2C6E20FB,
	XmlObjectSerializerReadContextComplexJson_IsBitSet_m72FDAE03639CB312A8CE7ABE89BA7A69B172E8B5,
	XmlObjectSerializerReadContextComplexJson_IsReadingCollectionExtensionData_m618285C809989EDDEE00B10C6BFCDE6107CF2425,
	XmlObjectSerializerReadContextComplexJson_IsReadingClassExtensionData_mF19A27601537471AE424FCBE6A6FF80A5B65478B,
	XmlObjectSerializerReadContextComplexJson_CreateReaderDelegatorForReader_m60124A85A0F7C06FDA26374DEA8B8BFBB3C64644,
	XmlObjectSerializerReadContextComplexJson_GetDataContract_mC8604C73154004708CF3A5826820ECC6F0B9F49F,
	XmlObjectSerializerReadContextComplexJson_GetDataContract_mAFF74F11AAFC6086E312F612477E3CD133C930C1,
	XmlObjectSerializerReadContextComplexJson_ResolveDataContractFromRootDataContract_mA2B57FDBA3AA01D47633CC08D9387539AD4D714D,
	XmlObjectSerializerWriteContextComplexJson_TruncateDefaultDataContractNamespace_mC448B0AE4CE3A780355F1B57B98785F2F793200E,
	XmlObjectSerializerWriteContextComplexJson_GetRevisedItemContract_m7C14769A8582010E52D3CE588442909DE79B1C8C,
	XmlObjectSerializerWriteContextComplexJson_ResolveJsonDataContractFromRootDataContract_m71FD9B77844636CAB242D498644CB924F455641E,
	JsonFormatReaderInterpreter__ctor_m0222DA24BAF5BD35FA62BB78EE101E512AE69500,
	JsonFormatReaderInterpreter__ctor_m3B3A5ABDAC42DBE3EE91F7102B9BD9AD8581DB6A,
	JsonFormatReaderInterpreter_ReadFromJson_mC988F76CE080FC1DE1EAFEBAF095E278B82D0935,
	JsonFormatReaderInterpreter_ReadCollectionFromJson_m225B84746BAD45B221783BB43EF85D1024AB99B1,
	JsonFormatReaderInterpreter_ReadGetOnlyCollectionFromJson_m27A25F3DA314BC665EBE3D2527FD530BB4A92DB0,
	JsonFormatReaderInterpreter_CreateObject_m2ABDAD5DECAE5779CC9039F17C0D9EC48765DBE4,
	JsonFormatReaderInterpreter_InvokeOnDeserializing_m5C6FCB6131B58E75FB81ED55B62AD9FBC81DDD90,
	JsonFormatReaderInterpreter_InvokeOnDeserialized_mCA6B72505E3E4BA909BFCE0B79F397AAC19BAA58,
	JsonFormatReaderInterpreter_HasFactoryMethod_mF122F074F14A2B2513E72BFA213E0E979EFEE9F2,
	JsonFormatReaderInterpreter_InvokeFactoryMethod_m3BC60765CAAF5AF37079AC99A921945570CACEC7,
	JsonFormatReaderInterpreter_ReadISerializable_m22B284EE27F0C336927E3F004E0594C12AFABAEC,
	JsonFormatReaderInterpreter_ReadClass_m56B55EECA1DC9ACF0564D06C31E18881A8B381B8,
	JsonFormatReaderInterpreter_ReadMembers_mE3E4DF680B4570AD3736EFCB079421589A04FF4F,
	JsonFormatReaderInterpreter_ReadMembers_m5A1DBCDDD5689AD66771C6A36B6D1DDB810A6525,
	JsonFormatReaderInterpreter_CheckRequiredElements_mBB35E4F8DADF7338785FFC00C0F5F6220255B772,
	JsonFormatReaderInterpreter_SetRequiredElements_mB34D263AA306399EB9CA426AF481150283E381C1,
	JsonFormatReaderInterpreter_SetExpectedElements_m14EFE26AC7D1EEC5F527735D195F3EC9211CCB9F,
	JsonFormatReaderInterpreter_ResetExpectedElements_mFEE3803809D942B1827E1EC4C8D67FE1580AC72D,
	JsonFormatReaderInterpreter_ReadValue_m2E561FFE42D05453B991D5EEECF8A12EBAA509DE,
	JsonFormatReaderInterpreter_InternalDeserialize_m318E5EE4880EA46E28D7E15B5408653F01785936,
	JsonFormatReaderInterpreter_WrapNullableObject_m3C88608667C5AD77090F0C0FB88DC1747D460821,
	JsonFormatReaderInterpreter_ReadCollection_m7DFFAE4C8C2E0A8349FE915635C414D4EB3E3B7E,
	JsonFormatReaderInterpreter_ReadSimpleDictionary_mBBFEEBFADCD6BEDE713B2343F5CF7623DEF56335,
	JsonFormatReaderInterpreter_ReadGetOnlyCollection_mCEFE032954306DEDF057A4907A73FC17C57DD1D5,
	JsonFormatReaderInterpreter_TryReadPrimitiveArray_m1393B0618E0EDFE1429C82AD4B03089BB306C3C1,
	JsonFormatReaderInterpreter_ReadCollectionItem_mFE6FB737590592AC1A722B6AE0825DAC46B30EF9,
	JsonFormatReaderInterpreter_StoreCollectionValue_m51CA54DEC022BE98FA8D4639D002BF12E893A7BE,
	JsonFormatReaderInterpreter_HandleUnexpectedItemInCollection_mE8FB20C69166FA59B01AEEA6F81765A60E99E65C,
	JsonFormatReaderInterpreter_IsStartElement_m122BD53034B61503CD9868D09E2B15BBFF730D22,
	JsonFormatReaderInterpreter_IsStartElement_m994C7347CDA77B7AEF20DB4CF9236A569E01C7AF,
	JsonFormatReaderInterpreter_IsEndElement_m4ACD48AAC961A211E74E73F1627956F752559528,
	JsonFormatReaderInterpreter_ThrowUnexpectedStateException_mE3E3518AD4009DDAB0EDB4A0FA2D20E529093ED3,
	JsonFormatReaderInterpreter_ThrowSerializationException_mB5CD7A508ED953E2EAE446CE783DDF631CB9F5F0,
	TraceUtility_Trace_m6F966E47EE0ECABFDF5B729E49E9F8AD4ACC03F7,
	TraceUtility_Trace_m055DDA8CF63451828191C8ADA392A05418952426,
	TraceUtility__cctor_m05F3720E1020896ED589CFB4D28E776440D14928,
	TD_ReaderQuotaExceededIsEnabled_m0A8046964C4EC32C05B6D77AF32BF29D0870CBAE,
	TD_ReaderQuotaExceeded_m6067AAA1D27BFE5B493EE5420EE1EA6A71497538,
	TD_DCDeserializeWithSurrogateStartIsEnabled_m082A707D702A00A70A60B11B5E9D060BAEC0F6AA,
	TD_DCDeserializeWithSurrogateStart_m90A760EAD6B4964EE0D6E1190EC5EDE051F40C3D,
	TD_DCDeserializeWithSurrogateStopIsEnabled_m46277B8CE26D7CCA516EFCCB872E2CC894B7C6A5,
	TD_DCDeserializeWithSurrogateStop_m84C102B4E0745BF6116A4B76C1FA3A7938C56D8A,
	TD_ImportKnownTypesStartIsEnabled_m7FB8E8E0F5CEAAD415C702632A05972E18DF9A76,
	TD_ImportKnownTypesStart_m4B9C6F129422BA7C91BA9F9CCD55050F3EBA4205,
	TD_ImportKnownTypesStopIsEnabled_m609360DC76351075A9A9A67E120D01363E71D637,
	TD_ImportKnownTypesStop_m9E457405D857FF249B77C2E82AE055809399566D,
	TD_DCResolverResolveIsEnabled_mA594BDA76F874A82CFD7EED8BBDFF57EBE8198DD,
	TD_DCResolverResolve_m1506172A442EF553AEBB8F8B94892B84CA6F4A57,
	TD_DCGenReaderStartIsEnabled_m4CAA1D5BD10C12CA13A36209687DAE530D068AAE,
	TD_DCGenReaderStart_m1206B935E37799C77C96EDB75D86F62439663AA4,
	TD_DCGenReaderStopIsEnabled_mA6B75A7192D3AF25F80C8466D8137D960C3CABBD,
	TD_DCGenReaderStop_mD2D403F60D15D7F2C3F3E19DC92F1ADB8FD7F8D9,
	TD_DCJsonGenReaderStartIsEnabled_m4CFA5ABF9CE848E1B7E25372CE80A75C9F37967E,
	TD_DCJsonGenReaderStart_mA0B80BAAAE2F97B0E17196F73C16082C1E49DF03,
	TD_DCJsonGenReaderStopIsEnabled_m6BB34F91C03FCD1EDA3670F1F8429EC2478FB00B,
	TD_DCJsonGenReaderStop_m863CE464317D7C2942B048248BCDC2809D78F656,
	TD_CreateEventDescriptors_mF1EDD6DE59A790098718CE7991A5036A2837ED46,
	TD_EnsureEventDescriptors_mA8856CD6B58C2C7F8935970819D855990AFB41A0,
	TD_IsEtwEventEnabled_m91707199E84DB7356D401D935E96AAC943B60BD0,
	TD_WriteEtwEvent_mE6054960D2BF50ECDCC3550B12E3F5C6DA97534A,
	TD_WriteEtwEvent_m5F115E0434F9E0BCDA24EE6CF9683CA462577F56,
	TD_WriteEtwEvent_m4D037EF8CC4D439A6309D957719E2CE125299913,
	TD__cctor_m2F5A05FD6D70705130B47F11BCD9FD1187B03A80,
};
extern void SurrogateChar__ctor_m0244C7438DA2C0EA0BCD7FC8280D78AEC54765E4_AdjustorThunk (void);
extern void SurrogateChar__ctor_mD97B515A1E75EBB7BF68D9ABE65EF556C66B683C_AdjustorThunk (void);
extern void SurrogateChar_get_LowChar_m93E0E738D16C16370CC7D14EE2FBC90869AA7007_AdjustorThunk (void);
extern void SurrogateChar_get_HighChar_m2B1C01150EE9A470BF95D0F279A07DF8265CFF79_AdjustorThunk (void);
extern void SurrogateChar_get_Char_mA8EF3784B38A8E24125A65F753E2BD110212E794_AdjustorThunk (void);
extern void Member__ctor_mC61ED1E34A077EA1C8086CA839925EC6178F9A07_AdjustorThunk (void);
extern void DateTimeOffsetAdapter_get_UtcDateTime_m39D5B6ED19930CBEB27FEA343255E90F2622D942_AdjustorThunk (void);
extern void DateTimeOffsetAdapter_get_OffsetMinutes_m1ACFACA778391AA85C1C2F52337183E56B276F03_AdjustorThunk (void);
extern void DateTimeOffsetAdapter_ToString_m7E7AC194BF52459160D5B64DC0C61D3F62896F6C_AdjustorThunk (void);
extern void ScopedKnownTypes_Push_mAEB53E753F4A8C2B043B054ABFA72F707744AB11_AdjustorThunk (void);
extern void ScopedKnownTypes_Pop_m60142B3457456EDEF4B1E11D13ACE26CF76C61C5_AdjustorThunk (void);
extern void ScopedKnownTypes_GetDataContract_m06420837D552E998FDBB5EAE2B2F8E6F8316DF08_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[12] = 
{
	{ 0x060003A8, SurrogateChar__ctor_m0244C7438DA2C0EA0BCD7FC8280D78AEC54765E4_AdjustorThunk },
	{ 0x060003A9, SurrogateChar__ctor_mD97B515A1E75EBB7BF68D9ABE65EF556C66B683C_AdjustorThunk },
	{ 0x060003AA, SurrogateChar_get_LowChar_m93E0E738D16C16370CC7D14EE2FBC90869AA7007_AdjustorThunk },
	{ 0x060003AB, SurrogateChar_get_HighChar_m2B1C01150EE9A470BF95D0F279A07DF8265CFF79_AdjustorThunk },
	{ 0x060003AC, SurrogateChar_get_Char_mA8EF3784B38A8E24125A65F753E2BD110212E794_AdjustorThunk },
	{ 0x060003EE, Member__ctor_mC61ED1E34A077EA1C8086CA839925EC6178F9A07_AdjustorThunk },
	{ 0x0600053F, DateTimeOffsetAdapter_get_UtcDateTime_m39D5B6ED19930CBEB27FEA343255E90F2622D942_AdjustorThunk },
	{ 0x06000540, DateTimeOffsetAdapter_get_OffsetMinutes_m1ACFACA778391AA85C1C2F52337183E56B276F03_AdjustorThunk },
	{ 0x06000542, DateTimeOffsetAdapter_ToString_m7E7AC194BF52459160D5B64DC0C61D3F62896F6C_AdjustorThunk },
	{ 0x060006BE, ScopedKnownTypes_Push_mAEB53E753F4A8C2B043B054ABFA72F707744AB11_AdjustorThunk },
	{ 0x060006BF, ScopedKnownTypes_Pop_m60142B3457456EDEF4B1E11D13ACE26CF76C61C5_AdjustorThunk },
	{ 0x060006C0, ScopedKnownTypes_GetDataContract_m06420837D552E998FDBB5EAE2B2F8E6F8316DF08_AdjustorThunk },
};
static const int32_t s_InvokerIndices[2480] = 
{
	0,
	0,
	0,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	237,
	5146,
	8039,
	2568,
	4230,
	7676,
	7676,
	7597,
	3582,
	5448,
	4230,
	5146,
	5146,
	5828,
	6386,
	6386,
	7481,
	7315,
	7353,
	7357,
	4963,
	4963,
	4963,
	5017,
	4231,
	5146,
	5146,
	5016,
	1245,
	5146,
	2018,
	4177,
	1508,
	4963,
	5017,
	5016,
	4230,
	5016,
	4230,
	4231,
	8039,
	0,
	4248,
	4230,
	4248,
	2368,
	4963,
	4963,
	4963,
	3048,
	7676,
	7593,
	6541,
	3835,
	5036,
	2032,
	3636,
	3142,
	3142,
	3142,
	6920,
	6920,
	6920,
	3142,
	5036,
	5016,
	8039,
	4248,
	2368,
	4230,
	1457,
	4248,
	4963,
	4963,
	4248,
	3835,
	5036,
	2032,
	5036,
	1661,
	3142,
	3142,
	1147,
	3142,
	6920,
	6920,
	6920,
	6920,
	3636,
	3142,
	5016,
	8039,
	2564,
	4248,
	5016,
	1217,
	1395,
	4963,
	2161,
	1892,
	5036,
	6920,
	3142,
	5016,
	3785,
	3573,
	2533,
	2321,
	8039,
	4248,
	8011,
	4230,
	4230,
	4230,
	4230,
	2368,
	1460,
	4963,
	5036,
	4963,
	5016,
	5017,
	5134,
	5077,
	4985,
	4982,
	4980,
	5036,
	5120,
	5010,
	5036,
	5036,
	5036,
	1684,
	4248,
	5036,
	5036,
	622,
	622,
	622,
	3048,
	5036,
	5036,
	5036,
	5036,
	5016,
	5016,
	5016,
	5016,
	5017,
	5134,
	5077,
	4985,
	4982,
	5036,
	5010,
	1508,
	5036,
	5036,
	8039,
	5146,
	8011,
	8011,
	5036,
	5036,
	5036,
	4248,
	4248,
	5036,
	3121,
	344,
	5036,
	5036,
	5036,
	5036,
	5036,
	5036,
	5146,
	5146,
	5036,
	5146,
	2049,
	5036,
	5036,
	5036,
	3835,
	4248,
	4963,
	4963,
	5036,
	4963,
	5016,
	5146,
	5016,
	4963,
	3832,
	3835,
	2067,
	3832,
	3835,
	2067,
	4963,
	5036,
	3835,
	3835,
	5146,
	2564,
	2564,
	4230,
	3142,
	1689,
	4963,
	5016,
	4963,
	4963,
	5036,
	5036,
	5016,
	5036,
	5132,
	3822,
	3822,
	3142,
	3142,
	3142,
	3142,
	4963,
	1689,
	1689,
	1893,
	1245,
	5036,
	5036,
	5146,
	5146,
	4963,
	5016,
	4248,
	3048,
	5036,
	1245,
	1245,
	149,
	5036,
	4963,
	5017,
	5016,
	4980,
	4985,
	5077,
	4982,
	5036,
	5120,
	5010,
	5036,
	2067,
	5146,
	5146,
	5036,
	5036,
	5036,
	5016,
	5036,
	3832,
	4248,
	2568,
	4248,
	4248,
	5146,
	8039,
	110,
	5016,
	5036,
	5036,
	4963,
	4963,
	5036,
	4963,
	5036,
	5016,
	4963,
	5016,
	4230,
	5016,
	4230,
	5036,
	4248,
	4963,
	4177,
	4963,
	4177,
	4963,
	4177,
	5132,
	4333,
	3142,
	3142,
	3142,
	3142,
	1689,
	1689,
	5036,
	4248,
	1529,
	5036,
	5016,
	4230,
	4248,
	1529,
	1529,
	110,
	4248,
	4248,
	4248,
	4248,
	1529,
	4248,
	4248,
	4248,
	4248,
	4248,
	1687,
	2159,
	5146,
	4963,
	4963,
	1893,
	1872,
	5146,
	4248,
	5146,
	8011,
	8011,
	5036,
	5016,
	5146,
	5146,
	5146,
	4248,
	4230,
	5146,
	4248,
	5036,
	3832,
	3835,
	3835,
	1683,
	8039,
	5146,
	5016,
	4230,
	5036,
	4248,
	5016,
	4230,
	4248,
	5146,
	5016,
	4230,
	5036,
	3142,
	3142,
	5036,
	5036,
	4248,
	2564,
	1303,
	3835,
	4230,
	1303,
	3835,
	1655,
	4248,
	4248,
	8011,
	5036,
	4963,
	1529,
	306,
	5146,
	4963,
	4963,
	5146,
	4963,
	2048,
	1277,
	2032,
	2048,
	5146,
	4963,
	4230,
	3121,
	4230,
	2368,
	5016,
	4230,
	3620,
	5016,
	5016,
	5016,
	5016,
	5016,
	3832,
	1226,
	670,
	2051,
	2051,
	1281,
	1226,
	3121,
	2051,
	1281,
	1872,
	1872,
	1872,
	1872,
	1872,
	1872,
	1872,
	1872,
	3121,
	1658,
	1658,
	1147,
	1661,
	1147,
	343,
	612,
	1147,
	664,
	3121,
	3620,
	3620,
	3620,
	3789,
	3973,
	3893,
	3391,
	3384,
	3832,
	3417,
	997,
	5016,
	5146,
	2051,
	3832,
	5016,
	2384,
	1508,
	2564,
	4248,
	4248,
	5036,
	8039,
	5146,
	5146,
	5146,
	4248,
	5146,
	5146,
	2568,
	3048,
	4177,
	2568,
	4230,
	2568,
	2568,
	5146,
	4230,
	4248,
	1508,
	1508,
	4230,
	1508,
	4248,
	1508,
	5146,
	5146,
	4165,
	5146,
	4165,
	4165,
	983,
	4165,
	5146,
	1839,
	1839,
	387,
	232,
	223,
	8039,
	4248,
	5146,
	1893,
	8011,
	8011,
	8011,
	7490,
	6380,
	7597,
	6480,
	7617,
	6510,
	7735,
	6629,
	7553,
	6426,
	7538,
	6418,
	7522,
	7523,
	6414,
	7679,
	6572,
	7829,
	6642,
	7566,
	6432,
	7871,
	6656,
	6572,
	6572,
	7679,
	5635,
	7664,
	7676,
	7677,
	7687,
	7671,
	7670,
	7688,
	7679,
	7674,
	7691,
	7668,
	7679,
	7679,
	5900,
	5900,
	5900,
	5900,
	7056,
	6480,
	6480,
	5900,
	6459,
	6459,
	6461,
	6461,
	7494,
	7483,
	6450,
	6450,
	6453,
	6500,
	6452,
	6502,
	6488,
	6459,
	6459,
	6459,
	6451,
	7490,
	7499,
	7679,
	7679,
	8039,
	5146,
	4230,
	3835,
	1655,
	2566,
	4248,
	7679,
	7132,
	6137,
	5036,
	5146,
	3142,
	3142,
	3142,
	3142,
	1689,
	1893,
	3048,
	5036,
	2051,
	5036,
	3832,
	5036,
	3832,
	2039,
	3121,
	1245,
	2067,
	4982,
	5077,
	5036,
	5010,
	5120,
	5036,
	4963,
	5016,
	5017,
	5077,
	4985,
	4982,
	4980,
	5036,
	1508,
	3048,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	456,
	5146,
	2568,
	5016,
	5036,
	4963,
	5146,
	5016,
	4963,
	3832,
	3835,
	2067,
	4963,
	4963,
	1689,
	5036,
	3835,
	4230,
	3142,
	1689,
	4963,
	4963,
	4963,
	5036,
	5036,
	5036,
	5016,
	5036,
	5132,
	4963,
	4963,
	5036,
	5146,
	5036,
	5016,
	5146,
	5036,
	5036,
	5016,
	1245,
	1245,
	1245,
	5036,
	4963,
	4980,
	4982,
	4985,
	5016,
	5017,
	5077,
	5036,
	2067,
	4963,
	5016,
	5016,
	5146,
	270,
	8011,
	4248,
	4248,
	5016,
	5016,
	5016,
	5016,
	5016,
	5146,
	8039,
	1527,
	7679,
	8011,
	5036,
	5016,
	5036,
	5036,
	5036,
	8039,
	5146,
	5036,
	1655,
	0,
	0,
	0,
	0,
	0,
	293,
	0,
	0,
	293,
	0,
	293,
	0,
	293,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5146,
	5146,
	5146,
	4248,
	2568,
	4177,
	2568,
	2568,
	2568,
	5146,
	4230,
	4248,
	1508,
	1508,
	4248,
	1508,
	1508,
	4230,
	4231,
	4335,
	4285,
	4204,
	4201,
	4199,
	4248,
	4322,
	4226,
	547,
	1508,
	5016,
	2048,
	4230,
	5146,
	4177,
	4333,
	2171,
	2616,
	4230,
	1508,
	4248,
	2161,
	645,
	5146,
	5146,
	5146,
	8039,
	5146,
	1080,
	2568,
	5146,
	5146,
	5146,
	4248,
	2568,
	1245,
	5146,
	5146,
	1687,
	5146,
	5146,
	5146,
	5146,
	5146,
	5016,
	5146,
	1245,
	1245,
	1245,
	1245,
	4177,
	5146,
	4963,
	4963,
	5016,
	5016,
	2159,
	8039,
	5036,
	3832,
	5146,
	5146,
	5146,
	4248,
	2568,
	4177,
	2568,
	5146,
	2568,
	2568,
	5146,
	4248,
	4248,
	4248,
	1508,
	2161,
	1508,
	4230,
	1508,
	1508,
	4248,
	5146,
	5146,
	5146,
	5146,
	5146,
	4230,
	4230,
	1248,
	4201,
	4204,
	4285,
	4199,
	4248,
	4230,
	4231,
	4335,
	4226,
	547,
	1508,
	4322,
	8039,
	7357,
	6785,
	6288,
	5845,
	7357,
	7132,
	7679,
	7907,
	6785,
	7353,
	7353,
	7353,
	7353,
	7353,
	7353,
	7907,
	7357,
	7907,
	7351,
	7907,
	7907,
	6788,
	6785,
	7907,
	5845,
	6785,
	5845,
	7907,
	7907,
	7907,
	7907,
	7907,
	7353,
	7353,
	7907,
	6578,
	6119,
	7132,
	3620,
	612,
	1658,
	1245,
	393,
	393,
	3620,
	1245,
	393,
	393,
	5146,
	8039,
	3620,
	1245,
	393,
	3620,
	1245,
	393,
	5146,
	8039,
	4230,
	2616,
	5132,
	5132,
	5016,
	8039,
	4248,
	5146,
	4248,
	4248,
	4248,
	4248,
	4248,
	4248,
	5146,
	4248,
	1529,
	5146,
	5036,
	5036,
	5036,
	5036,
	5036,
	5036,
	4963,
	4963,
	4963,
	5036,
	5036,
	4963,
	5036,
	5036,
	5036,
	6578,
	6785,
	7490,
	2067,
	1689,
	3142,
	5016,
	4248,
	1529,
	4248,
	5146,
	1684,
	4248,
	3835,
	4248,
	7490,
	5146,
	1689,
	5583,
	5036,
	4248,
	5036,
	5036,
	5036,
	5036,
	5036,
	5036,
	5036,
	4963,
	4963,
	4963,
	4963,
	5036,
	5036,
	5036,
	4248,
	8011,
	1527,
	2013,
	5146,
	8039,
	1893,
	5146,
	8039,
	4248,
	2568,
	282,
	282,
	174,
	2568,
	4248,
	8011,
	4963,
	5036,
	5036,
	5036,
	5036,
	5036,
	4963,
	4963,
	4177,
	5036,
	5036,
	5036,
	5036,
	5036,
	4963,
	5036,
	5036,
	3835,
	7490,
	7490,
	6915,
	6375,
	5896,
	6915,
	6915,
	6578,
	7490,
	5427,
	7490,
	5348,
	5524,
	6578,
	6276,
	5529,
	7490,
	3832,
	5146,
	5036,
	5146,
	1689,
	5016,
	2067,
	8011,
	1416,
	4248,
	2568,
	282,
	282,
	174,
	2568,
	4963,
	5036,
	5036,
	5036,
	4248,
	5036,
	4963,
	4177,
	5036,
	5036,
	5036,
	4963,
	5036,
	4963,
	5036,
	5036,
	5036,
	5036,
	5036,
	4248,
	5036,
	4248,
	5036,
	4963,
	5036,
	4963,
	5036,
	4963,
	5036,
	4963,
	4963,
	5036,
	4963,
	5036,
	5036,
	4248,
	7679,
	6600,
	6550,
	6551,
	6097,
	6551,
	7676,
	7597,
	7598,
	7679,
	7132,
	7679,
	7679,
	7357,
	5036,
	5036,
	5036,
	4963,
	5036,
	2067,
	4963,
	4963,
	5036,
	5036,
	4963,
	5036,
	5036,
	4963,
	5036,
	5036,
	4963,
	4963,
	3832,
	5036,
	5036,
	7490,
	6920,
	6785,
	7679,
	7679,
	7499,
	7499,
	7490,
	7679,
	7490,
	7679,
	7121,
	6575,
	7132,
	7132,
	6384,
	6915,
	6575,
	6134,
	7662,
	7679,
	7679,
	7679,
	7679,
	7132,
	7490,
	7679,
	7132,
	7679,
	7357,
	7679,
	6758,
	6758,
	6758,
	7132,
	7679,
	7132,
	7132,
	7490,
	7907,
	7679,
	6779,
	6779,
	6779,
	3142,
	1689,
	1689,
	5016,
	8039,
	6551,
	6551,
	7676,
	7597,
	6920,
	7598,
	8011,
	6551,
	7353,
	6551,
	7679,
	7679,
	7710,
	7679,
	7132,
	7679,
	6915,
	6384,
	7679,
	7357,
	4248,
	5036,
	5036,
	4963,
	5036,
	4248,
	4963,
	4177,
	4963,
	4177,
	5036,
	4248,
	5036,
	4963,
	5036,
	4248,
	5036,
	4248,
	4963,
	4177,
	5036,
	5036,
	5036,
	4248,
	2568,
	4248,
	0,
	0,
	0,
	0,
	0,
	0,
	4248,
	2568,
	5016,
	5036,
	3832,
	5036,
	5036,
	4963,
	3832,
	2568,
	3142,
	5016,
	1689,
	3636,
	5146,
	5146,
	4277,
	5069,
	4277,
	4230,
	5016,
	5146,
	4963,
	4963,
	5036,
	4248,
	4963,
	5036,
	4248,
	4963,
	0,
	5146,
	304,
	182,
	116,
	5036,
	5016,
	5036,
	4963,
	4963,
	5036,
	5036,
	2062,
	2062,
	2062,
	1298,
	3142,
	5036,
	7132,
	4248,
	5036,
	5036,
	4248,
	5016,
	4230,
	4963,
	4177,
	4963,
	4177,
	4963,
	4177,
	4963,
	4177,
	5036,
	5036,
	4963,
	4177,
	4248,
	1689,
	5016,
	4248,
	5036,
	5036,
	4248,
	5016,
	4230,
	4963,
	4177,
	4963,
	4177,
	4963,
	4177,
	4963,
	4177,
	5036,
	5036,
	4963,
	4177,
	4248,
	5146,
	5036,
	4248,
	4963,
	5016,
	4963,
	4177,
	4963,
	5036,
	5036,
	5016,
	4980,
	5015,
	7527,
	3835,
	8039,
	4248,
	5036,
	5036,
	4963,
	4963,
	4963,
	3835,
	1259,
	1689,
	5016,
	2067,
	8039,
	7357,
	7679,
	4248,
	5036,
	5036,
	4963,
	4177,
	4963,
	4248,
	5146,
	5036,
	4963,
	5146,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	4230,
	5146,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5146,
	5036,
	4248,
	5146,
	5146,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	5016,
	4230,
	4248,
	5146,
	5146,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	5146,
	5146,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	4248,
	5146,
	5036,
	4248,
	5036,
	4248,
	5146,
	8039,
	4248,
	4248,
	5036,
	1529,
	5146,
	4963,
	5016,
	5036,
	5036,
	5036,
	5036,
	5016,
	5016,
	4963,
	5016,
	4963,
	4963,
	5132,
	5016,
	5036,
	4963,
	4963,
	4230,
	2067,
	1689,
	4963,
	5146,
	3835,
	5146,
	3121,
	5146,
	4963,
	5036,
	5036,
	5036,
	3835,
	3832,
	3142,
	5146,
	4963,
	4248,
	1080,
	4248,
	3142,
	4248,
	4248,
	4248,
	4248,
	4248,
	1179,
	5146,
	5146,
	5146,
	5036,
	7679,
	7357,
	5146,
	1080,
	5146,
	5146,
	4248,
	4963,
	4248,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8011,
	8039,
	5146,
	2568,
	4248,
	3835,
	3142,
	0,
	0,
	7132,
	6137,
	0,
	5146,
	4248,
	2573,
	8011,
	8011,
	5036,
	5036,
	4248,
	912,
	7985,
	2062,
	6581,
	5751,
	8039,
	1529,
	7679,
	7132,
	0,
	5036,
	4963,
	4963,
	4963,
	5036,
	2067,
	3142,
	1689,
	1529,
	5036,
	4248,
	5146,
	2568,
	5036,
	2067,
	5146,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	2568,
	5036,
	2067,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	5146,
	2568,
	5036,
	2067,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5146,
	5036,
	2067,
	5146,
	5036,
	2067,
	4963,
	4963,
	5146,
	2568,
	5036,
	2067,
	5146,
	5146,
	2568,
	5036,
	2067,
	5146,
	5146,
	5036,
	2067,
	5146,
	5036,
	4963,
	2067,
	7132,
	6261,
	5577,
	8011,
	8011,
	5895,
	7679,
	8011,
	4248,
	5146,
	3835,
	1529,
	4963,
	1529,
	2568,
	5036,
	1312,
	7135,
	3835,
	2067,
	2568,
	5036,
	2566,
	5036,
	4248,
	5036,
	4963,
	4963,
	5036,
	5036,
	5036,
	4963,
	4963,
	1689,
	5016,
	2067,
	5036,
	5036,
	4248,
	5036,
	4248,
	4963,
	4963,
	4177,
	5036,
	5036,
	5036,
	4248,
	8011,
	8011,
	8011,
	8011,
	8011,
	2566,
	912,
	2566,
	491,
	2566,
	572,
	5146,
	3835,
	3835,
	3835,
	7676,
	3835,
	3835,
	3835,
	5146,
	5146,
	912,
	5146,
	491,
	5146,
	572,
	5036,
	1181,
	3835,
	3835,
	2062,
	0,
	2062,
	1298,
	3142,
	2062,
	1298,
	1689,
	3142,
	632,
	7357,
	7132,
	7132,
	7679,
	7132,
	7679,
	6578,
	5036,
	8011,
	5146,
	552,
	1055,
	1529,
	5016,
	4963,
	4177,
	5092,
	4230,
	5016,
	4963,
	5036,
	5036,
	3835,
	2070,
	2054,
	2554,
	3835,
	5036,
	3835,
	7679,
	3835,
	2067,
	3835,
	912,
	3835,
	5036,
	5036,
	4963,
	4177,
	5036,
	4248,
	7907,
	7317,
	6578,
	1055,
	1529,
	479,
	912,
	491,
	355,
	489,
	1684,
	7490,
	457,
	235,
	6269,
	1527,
	1527,
	4248,
	1306,
	4248,
	5146,
	5036,
	5016,
	4248,
	2568,
	1529,
	912,
	3835,
	2067,
	912,
	7907,
	5835,
	0,
	0,
	1053,
	1306,
	6576,
	6135,
	2067,
	5036,
	2065,
	3835,
	4248,
	1309,
	1309,
	1529,
	912,
	1309,
	1309,
	1309,
	1309,
	912,
	3121,
	2067,
	5482,
	2067,
	7113,
	2067,
	3835,
	3142,
	3142,
	1529,
	1055,
	5016,
	2054,
	2070,
	479,
	912,
	491,
	478,
	491,
	1305,
	901,
	5036,
	3142,
	2554,
	3835,
	5016,
	7679,
	7679,
	6785,
	8039,
	4248,
	1306,
	2568,
	5036,
	5036,
	2568,
	3142,
	5016,
	4248,
	5036,
	5036,
	5016,
	3835,
	2067,
	3832,
	4963,
	3142,
	3142,
	3142,
	3142,
	1893,
	4963,
	1689,
	1689,
	3142,
	1689,
	4230,
	4963,
	4963,
	4963,
	5016,
	4963,
	5016,
	4963,
	5146,
	3835,
	3835,
	3835,
	3835,
	2568,
	5146,
	5132,
	5132,
	3964,
	5036,
	5036,
	4963,
	4963,
	5077,
	5077,
	4985,
	4985,
	4982,
	4982,
	5036,
	5036,
	3835,
	4980,
	4980,
	5016,
	5016,
	5017,
	5017,
	5015,
	5015,
	3420,
	4963,
	4963,
	3121,
	5070,
	5070,
	3882,
	5133,
	5133,
	3970,
	5134,
	5134,
	5132,
	5132,
	3964,
	5120,
	5120,
	5010,
	5010,
	5036,
	5036,
	5036,
	5036,
	3835,
	2564,
	3636,
	993,
	353,
	353,
	353,
	353,
	353,
	353,
	353,
	3832,
	4963,
	5016,
	5016,
	4963,
	4177,
	5016,
	4230,
	5036,
	5036,
	5036,
	5036,
	5036,
	5016,
	3835,
	4963,
	5146,
	5036,
	4248,
	5146,
	4963,
	5146,
	5036,
	5016,
	5036,
	5036,
	5036,
	5036,
	5036,
	5016,
	5036,
	4963,
	4963,
	5132,
	5016,
	5036,
	5036,
	5036,
	5016,
	4963,
	5016,
	5036,
	4963,
	4963,
	4963,
	3835,
	2067,
	3832,
	3142,
	1689,
	4230,
	4963,
	4963,
	4963,
	3835,
	4963,
	5146,
	4963,
	1689,
	5016,
	5036,
	4963,
	4980,
	4985,
	5016,
	5017,
	5036,
	2067,
	1245,
	1245,
	1245,
	5036,
	4963,
	4177,
	5016,
	4230,
	4963,
	5016,
	5016,
	5146,
	7679,
	7490,
	8039,
	4230,
	2330,
	3121,
	5036,
	5016,
	5016,
	3121,
	6918,
	7353,
	7593,
	7486,
	6578,
	7486,
	6135,
	7132,
	6785,
	8039,
	7907,
	7679,
	7679,
	7129,
	7132,
	7679,
	7132,
	8011,
	7486,
	7357,
	8039,
	7132,
	6578,
	7679,
	2564,
	4248,
	4248,
	2564,
	2564,
	5036,
	5016,
	4230,
	5036,
	3835,
	4248,
	5036,
	5036,
	4248,
	2554,
	912,
	491,
	572,
	4248,
	4248,
	4248,
	3142,
	1689,
	4248,
	4248,
	2568,
	365,
	2061,
	1893,
	1309,
	1309,
	911,
	4248,
	4248,
	628,
	912,
	1080,
	4165,
	1689,
	4963,
	4963,
	237,
	2568,
	3121,
	5146,
	8039,
	4248,
	2568,
	305,
	5036,
	4963,
	5036,
	5016,
	5036,
	4963,
	5036,
	5036,
	3835,
	2062,
	3835,
	2062,
	7679,
	7679,
	6920,
	6578,
	5036,
	3142,
	2062,
	4248,
	52,
	7907,
	4248,
	2067,
	4248,
	5036,
	5036,
	5036,
	2067,
	4248,
	5036,
	4248,
	5036,
	5036,
	5146,
	4248,
	5036,
	5036,
	5036,
	2067,
	4248,
	5036,
	4248,
	5036,
	4248,
	5036,
	4248,
	4248,
	5036,
	5036,
	5036,
	7679,
	2067,
	2067,
	7132,
	7490,
	4248,
	4248,
	4248,
	5036,
	5036,
	7679,
	7598,
	7113,
	5146,
	8039,
	1525,
	4963,
	4963,
	4963,
	4963,
	5017,
	5017,
	4231,
	5016,
	4230,
	5016,
	4230,
	5146,
	5146,
	1245,
	5016,
	2018,
	4231,
	1508,
	4177,
	7676,
	7676,
	7597,
	7039,
	7315,
	5146,
	5146,
	5146,
	4230,
	2568,
	2568,
	5016,
	8039,
	4248,
	4963,
	2067,
	4248,
	4963,
	2566,
	912,
	2566,
	491,
	2566,
	572,
	5146,
	3835,
	3835,
	3835,
	3835,
	3835,
	3835,
	5146,
	5146,
	912,
	5146,
	491,
	5146,
	572,
	8039,
	4248,
	2067,
	7121,
	7679,
	4248,
	2067,
	4248,
	2568,
	5036,
	5036,
	7679,
	5132,
	5036,
	5132,
	5036,
	5036,
	4980,
	7004,
	7523,
	4980,
	353,
	5134,
	5134,
	4248,
	237,
	7132,
	6137,
	4248,
	2067,
	4248,
	2067,
	4248,
	2067,
	2067,
	5036,
	4963,
	4963,
	4963,
	5146,
	3832,
	2067,
	3835,
	4963,
	4982,
	5016,
	5017,
	1245,
	1080,
	6771,
	6480,
	6480,
	5990,
	7481,
	7237,
	7056,
	5146,
	4230,
	5016,
	5146,
	2568,
	5146,
	5146,
	5146,
	4177,
	4230,
	5016,
	5146,
	4177,
	4177,
	5146,
	4248,
	4177,
	5146,
	3048,
	3835,
	5146,
	8039,
	2568,
	5036,
	4963,
	4248,
	1309,
	3835,
	7132,
	5016,
	2067,
	4248,
	778,
	6915,
	7679,
	6288,
	6783,
	6918,
	3142,
	3142,
	3835,
	2070,
	2054,
	3835,
	7679,
	7679,
	6578,
	4248,
	2554,
	912,
	491,
	572,
	4248,
	4248,
	4248,
	3142,
	3142,
	4248,
	4248,
	2568,
	727,
	1689,
	1893,
	2564,
	2564,
	2067,
	2067,
	911,
	4248,
	2568,
	4248,
	1683,
	2067,
	1080,
	4165,
	1689,
	4963,
	4963,
	4230,
	2568,
	6247,
	5798,
	8039,
	7985,
	7907,
	7985,
	7907,
	7985,
	8039,
	7985,
	8039,
	7985,
	8039,
	7985,
	7907,
	7985,
	7357,
	7985,
	8039,
	7985,
	7357,
	7985,
	8039,
	8039,
	8039,
	7486,
	5890,
	6367,
	5562,
	8039,
};
static const Il2CppTokenRangePair s_rgctxIndices[4] = 
{
	{ 0x02000002, { 0, 4 } },
	{ 0x0200006C, { 4, 8 } },
	{ 0x06000757, { 12, 2 } },
	{ 0x06000758, { 14, 1 } },
};
extern const uint32_t g_rgctx_TArrayU5BU5D_tCFDD9424C14255B7CB9B9AD11AC324C03FC9F300;
extern const uint32_t g_rgctx_ArrayHelper_2_t9E34A543AD608E718A2CC411A7CD07A66E1DC6B2;
extern const uint32_t g_rgctx_ArrayHelper_2_ReadArray_m4993F227FF40AB8823D88C302D183CFA2693B6C7;
extern const uint32_t g_rgctx_TArrayU5BU5DU5BU5D_tC9F5FDF37480C6511453D4F9FE30DFE30692B826;
extern const uint32_t g_rgctx_T_tDE8D43008CC302C19B108B70E56C6BC71DE05287;
extern const uint32_t g_rgctx_DataNode_1__ctor_m1E81EDA3F96F573308BE027C1D3E237C1ED14851;
extern const uint32_t g_rgctx_T_tDE8D43008CC302C19B108B70E56C6BC71DE05287;
extern const uint32_t g_rgctx_DataNode_1_get_DataContractName_mECFCF0849FA3AE6439EE114C689ED37CC2345CE7;
extern const uint32_t g_rgctx_DataNode_1_get_DataContractNamespace_m2E4AA15F0FF36723B98E71B1C161A3E25E9B6C1F;
extern const uint32_t g_rgctx_DataNode_1_AddQualifiedNameAttribute_mBBAD35F77F911390CD05B576B3A80B1BA9E69A71;
extern const uint32_t g_rgctx_DataNode_1_get_ClrTypeName_mC3BC59D979F56DE4131735B85153937A1B945AB7;
extern const uint32_t g_rgctx_DataNode_1_get_ClrAssemblyName_m0D14A09D7B7798F213E98CA9BBCC79302A4C76EC;
extern const uint32_t g_rgctx_T_t2D39B952ACC1800100C8ED48E9073383D92E7A09;
extern const uint32_t g_rgctx_TU5BU5D_t811F9727E636FB4625C4862718A06FA9CE70CED5;
extern const uint32_t g_rgctx_TU5BU5D_t12189D7CF95A07B037B54F24DD1CAE01DD849BDB;
static const Il2CppRGCTXDefinition s_rgctxValues[15] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TArrayU5BU5D_tCFDD9424C14255B7CB9B9AD11AC324C03FC9F300 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ArrayHelper_2_t9E34A543AD608E718A2CC411A7CD07A66E1DC6B2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ArrayHelper_2_ReadArray_m4993F227FF40AB8823D88C302D183CFA2693B6C7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TArrayU5BU5DU5BU5D_tC9F5FDF37480C6511453D4F9FE30DFE30692B826 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tDE8D43008CC302C19B108B70E56C6BC71DE05287 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1__ctor_m1E81EDA3F96F573308BE027C1D3E237C1ED14851 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tDE8D43008CC302C19B108B70E56C6BC71DE05287 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1_get_DataContractName_mECFCF0849FA3AE6439EE114C689ED37CC2345CE7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1_get_DataContractNamespace_m2E4AA15F0FF36723B98E71B1C161A3E25E9B6C1F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1_AddQualifiedNameAttribute_mBBAD35F77F911390CD05B576B3A80B1BA9E69A71 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1_get_ClrTypeName_mC3BC59D979F56DE4131735B85153937A1B945AB7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DataNode_1_get_ClrAssemblyName_m0D14A09D7B7798F213E98CA9BBCC79302A4C76EC },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t2D39B952ACC1800100C8ED48E9073383D92E7A09 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_t811F9727E636FB4625C4862718A06FA9CE70CED5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_t12189D7CF95A07B037B54F24DD1CAE01DD849BDB },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Runtime_Serialization_CodeGenModule;
const Il2CppCodeGenModule g_System_Runtime_Serialization_CodeGenModule = 
{
	"System.Runtime.Serialization.dll",
	2480,
	s_methodPointers,
	12,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	4,
	s_rgctxIndices,
	15,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
