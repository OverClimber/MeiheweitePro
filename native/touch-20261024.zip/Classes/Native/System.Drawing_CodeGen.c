﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.String Locale::GetText(System.String)
extern void Locale_GetText_m557C0E0FDBE23EE2270326E7A98328906830D43E (void);
// 0x00000002 System.String Locale::GetText(System.String,System.Object[])
extern void Locale_GetText_mF34C321B5E8B8901DE1B0BE6EA55E0D19B68A364 (void);
// 0x00000003 System.String SR::Format(System.String,System.Object[])
extern void SR_Format_m9977F23B838724F9DA04223E0762B7AEA3AA91FC (void);
// 0x00000004 System.Void System.MonoTODOAttribute::.ctor(System.String)
extern void MonoTODOAttribute__ctor_mED3EFB328E64CEADF9764E50BC9BC0E3DC526E50 (void);
// 0x00000005 System.Int32 System.Numerics.Hashing.HashHelpers::Combine(System.Int32,System.Int32)
extern void HashHelpers_Combine_mB8E75AA81F7543BB0B05069416C485A4B8E692D8 (void);
// 0x00000006 System.Void System.Numerics.Hashing.HashHelpers::.cctor()
extern void HashHelpers__cctor_mA1680F8D1B4E1C62B6660FF8F4CB5852ED393F99 (void);
// 0x00000007 System.Void System.Drawing.KnownColorTable::EnsureColorTable()
extern void KnownColorTable_EnsureColorTable_mDA6E15087C13F589AE3A2038B16F2D7DBAF3FA83 (void);
// 0x00000008 System.Void System.Drawing.KnownColorTable::InitColorTable()
extern void KnownColorTable_InitColorTable_mC6E537EF5340F0DE473FD4D8A168D0631C38CD10 (void);
// 0x00000009 System.Void System.Drawing.KnownColorTable::EnsureColorNameTable()
extern void KnownColorTable_EnsureColorNameTable_m7D1BDA884F19A4F1AFEDA4B4CF3C59F20F612303 (void);
// 0x0000000A System.Void System.Drawing.KnownColorTable::InitColorNameTable()
extern void KnownColorTable_InitColorNameTable_mB77CC6E7FACE77180DAA58884E6EAF11865C3D83 (void);
// 0x0000000B System.Int32 System.Drawing.KnownColorTable::KnownColorToArgb(System.Drawing.KnownColor)
extern void KnownColorTable_KnownColorToArgb_m0979478F1E425ECEA80341F48B9C24AA50B36E97 (void);
// 0x0000000C System.String System.Drawing.KnownColorTable::KnownColorToName(System.Drawing.KnownColor)
extern void KnownColorTable_KnownColorToName_mEFAED2FFD4EFF6A60FA921AE11C3894880DD63BE (void);
// 0x0000000D System.Void System.Drawing.KnownColorTable::UpdateSystemColors(System.Int32[])
extern void KnownColorTable_UpdateSystemColors_mE162F51D4EB7E8842CFC3B1678801F3E3DB5DAD0 (void);
// 0x0000000E System.Void System.Drawing.SafeNativeMethods/Gdip::.cctor()
extern void Gdip__cctor_mB10136A6BD2D49A7BBBD89F5DB30FC793E9410FE (void);
// 0x0000000F System.Boolean System.Drawing.SafeNativeMethods/Gdip::get_Initialized()
extern void Gdip_get_Initialized_mD097123D3DC3700649360B388C34061EA301988E (void);
// 0x00000010 System.Void System.Drawing.SafeNativeMethods/Gdip::ClearThreadData()
extern void Gdip_ClearThreadData_mB1307AEC461B1606931393C1036F16EA746BBD77 (void);
// 0x00000011 System.Void System.Drawing.SafeNativeMethods/Gdip::Shutdown()
extern void Gdip_Shutdown_m24C188C5CCDA13D38E372FF9A24EE6483E6470C9 (void);
// 0x00000012 System.Void System.Drawing.SafeNativeMethods/Gdip::OnProcessExit(System.Object,System.EventArgs)
extern void Gdip_OnProcessExit_m1BC6AF2E4774309551204FCF42C66514B1F71130 (void);
// 0x00000013 System.Exception System.Drawing.SafeNativeMethods/Gdip::StatusException(System.Int32)
extern void Gdip_StatusException_mD30EC7E61042064F8969D20703423D558395BEE8 (void);
// 0x00000014 System.Drawing.Color System.Drawing.Color::get_White()
extern void Color_get_White_mC907A1EB3D7562346DD188F3B476C3BD3C8D44F6 (void);
// 0x00000015 System.Void System.Drawing.Color::.ctor(System.Drawing.KnownColor)
extern void Color__ctor_m5215720BE232CBB05AB92B8F558F5EE4D342D307 (void);
// 0x00000016 System.Void System.Drawing.Color::.ctor(System.Int64,System.Int16,System.String,System.Drawing.KnownColor)
extern void Color__ctor_m19020CC887E9C4F7C63526E49D6895683FA56970 (void);
// 0x00000017 System.Byte System.Drawing.Color::get_R()
extern void Color_get_R_mA69925F53F4EF7AC1A3B4A94B9F4ABEA72662951 (void);
// 0x00000018 System.Byte System.Drawing.Color::get_G()
extern void Color_get_G_m8BBF290336C0D938F2546AB296B002C9995B3BAA (void);
// 0x00000019 System.Byte System.Drawing.Color::get_B()
extern void Color_get_B_mC668C85173CDC211AC0E2FEB3E6C36E9C57DCC61 (void);
// 0x0000001A System.Byte System.Drawing.Color::get_A()
extern void Color_get_A_m20373E97C1E01A1B27CD551E4FB1CB62DD381230 (void);
// 0x0000001B System.Boolean System.Drawing.Color::get_IsKnownColor()
extern void Color_get_IsKnownColor_mDE5232E7F4367FD7055F468772188EC1C6576198 (void);
// 0x0000001C System.String System.Drawing.Color::get_Name()
extern void Color_get_Name_m82B674D6BA69AE386BB798DD78DB116307F3B876 (void);
// 0x0000001D System.Int64 System.Drawing.Color::get_Value()
extern void Color_get_Value_mEC0390B65E6E1ADA7963CDDE6ADB0AA077712574 (void);
// 0x0000001E System.Void System.Drawing.Color::CheckByte(System.Int32,System.String)
extern void Color_CheckByte_mAEC90FAB7CD6D1AB42685B47E3EDDCDD13D2FBE7 (void);
// 0x0000001F System.Int64 System.Drawing.Color::MakeArgb(System.Byte,System.Byte,System.Byte,System.Byte)
extern void Color_MakeArgb_mCFECEF91CF3C17C3992AAF04A0216E01954E3E2E (void);
// 0x00000020 System.Drawing.Color System.Drawing.Color::FromArgb(System.Int32,System.Int32,System.Int32,System.Int32)
extern void Color_FromArgb_m7855D60AB3843525C91FB2174D10238B44F2320C (void);
// 0x00000021 System.Int32 System.Drawing.Color::ToArgb()
extern void Color_ToArgb_m1782C7D79C856B95679C601C8A2AB40C8B90AFFC (void);
// 0x00000022 System.String System.Drawing.Color::ToString()
extern void Color_ToString_m5C7D9DB036E127D264B17FA528580B7BD052513F (void);
// 0x00000023 System.Boolean System.Drawing.Color::op_Equality(System.Drawing.Color,System.Drawing.Color)
extern void Color_op_Equality_m5BD270427D7DA9AF8F2C004ACA2F43F734F2EE57 (void);
// 0x00000024 System.Boolean System.Drawing.Color::Equals(System.Object)
extern void Color_Equals_m0AECC84D788C0CB1B1FB44C945705AD7BAFF603A (void);
// 0x00000025 System.Boolean System.Drawing.Color::Equals(System.Drawing.Color)
extern void Color_Equals_mCC06EC6FD579073BFC35481FA94461A70DA7B7BA (void);
// 0x00000026 System.Int32 System.Drawing.Color::GetHashCode()
extern void Color_GetHashCode_m87358396DFDAE1F14332D3AC10A83ED1060FC9BB (void);
// 0x00000027 System.Int32 System.Drawing.Point::get_X()
extern void Point_get_X_m461B51706A8EF818C163A1AED09C6B706815AC3A (void);
// 0x00000028 System.Int32 System.Drawing.Point::get_Y()
extern void Point_get_Y_m04B98946BE28DE3A88C2BA7C09236A60936D30E3 (void);
// 0x00000029 System.Boolean System.Drawing.Point::op_Equality(System.Drawing.Point,System.Drawing.Point)
extern void Point_op_Equality_m16DF80982C9BD6458336F4101DFEBFC2C958216D (void);
// 0x0000002A System.Boolean System.Drawing.Point::Equals(System.Object)
extern void Point_Equals_mC52C70909BD95B4192039FC19157003D4DB22C97 (void);
// 0x0000002B System.Boolean System.Drawing.Point::Equals(System.Drawing.Point)
extern void Point_Equals_m3818E37548CAC5B822230E60BB7C45EF569E98E4 (void);
// 0x0000002C System.Int32 System.Drawing.Point::GetHashCode()
extern void Point_GetHashCode_mDCA1B4C2AF30051D731F2B500019F35239D6E951 (void);
// 0x0000002D System.String System.Drawing.Point::ToString()
extern void Point_ToString_mA8731A1FEDC9F643E304C052B3F4285F6ABC56FF (void);
// 0x0000002E System.Single System.Drawing.PointF::get_X()
extern void PointF_get_X_mA55226AFC51F0CF910D69872A0F19BFBE1F93C9B (void);
// 0x0000002F System.Single System.Drawing.PointF::get_Y()
extern void PointF_get_Y_m4B10717E6217968D6F8946A3C77ED5D1AF93A8C3 (void);
// 0x00000030 System.Boolean System.Drawing.PointF::op_Equality(System.Drawing.PointF,System.Drawing.PointF)
extern void PointF_op_Equality_m0BD00717287326DD803FA0C9A74083A5A0114371 (void);
// 0x00000031 System.Boolean System.Drawing.PointF::Equals(System.Object)
extern void PointF_Equals_mF1B0AEFEFECC0044933D67DCC12851F941F98E1D (void);
// 0x00000032 System.Boolean System.Drawing.PointF::Equals(System.Drawing.PointF)
extern void PointF_Equals_m0EC0248A2D9522AB35E4C32DD4DE06ABAD946CE1 (void);
// 0x00000033 System.Int32 System.Drawing.PointF::GetHashCode()
extern void PointF_GetHashCode_m7128D4D9228862A2B1C6862A8E8A7971A2AFD27E (void);
// 0x00000034 System.String System.Drawing.PointF::ToString()
extern void PointF_ToString_m6D64DB31243686C6547C230BA5221BC3BC9E4EC2 (void);
// 0x00000035 System.Void System.Drawing.Rectangle::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void Rectangle__ctor_m3FB90CAD0ECE9EA19BE7EFEDCC973808070497A7 (void);
// 0x00000036 System.Int32 System.Drawing.Rectangle::get_X()
extern void Rectangle_get_X_m57216246BE34687C3100179002EA5B2A9079776D (void);
// 0x00000037 System.Int32 System.Drawing.Rectangle::get_Y()
extern void Rectangle_get_Y_m8D016239D6FA9171C75C071E6CDD3557BF8C0239 (void);
// 0x00000038 System.Int32 System.Drawing.Rectangle::get_Width()
extern void Rectangle_get_Width_m08006DBCE23A7EC1B9BA4BAE399141B529B13A52 (void);
// 0x00000039 System.Int32 System.Drawing.Rectangle::get_Height()
extern void Rectangle_get_Height_m9C3D28B6C72348677EE9EEBA616E65C90B154DB2 (void);
// 0x0000003A System.Boolean System.Drawing.Rectangle::Equals(System.Object)
extern void Rectangle_Equals_m5B125B9AE09AE711F2218BB7BF9BFE97F054A250 (void);
// 0x0000003B System.Boolean System.Drawing.Rectangle::Equals(System.Drawing.Rectangle)
extern void Rectangle_Equals_mC876A9A25614D79581F23875D17F80D1C78910FD (void);
// 0x0000003C System.Boolean System.Drawing.Rectangle::op_Equality(System.Drawing.Rectangle,System.Drawing.Rectangle)
extern void Rectangle_op_Equality_m502490E5E78505CE41D65FF3B66339074464B0B2 (void);
// 0x0000003D System.Int32 System.Drawing.Rectangle::GetHashCode()
extern void Rectangle_GetHashCode_m3B1DDBEEFEF70E4EEB5145960DED4C1A4574D574 (void);
// 0x0000003E System.String System.Drawing.Rectangle::ToString()
extern void Rectangle_ToString_m20252CB5611CF6E9F46C82F7D8068FF76AB6C508 (void);
// 0x0000003F System.Single System.Drawing.RectangleF::get_X()
extern void RectangleF_get_X_m9A2032884F510E397628C623B4A4C6F037104B98 (void);
// 0x00000040 System.Single System.Drawing.RectangleF::get_Y()
extern void RectangleF_get_Y_m37F48864D908EAC8CF080850424B28D503B5B1EF (void);
// 0x00000041 System.Single System.Drawing.RectangleF::get_Width()
extern void RectangleF_get_Width_m44AA143927197CC0337A9A4A275CCD663570531D (void);
// 0x00000042 System.Single System.Drawing.RectangleF::get_Height()
extern void RectangleF_get_Height_m1AB0E38CB2777AB1C1378765D253E79D8861118D (void);
// 0x00000043 System.Boolean System.Drawing.RectangleF::Equals(System.Object)
extern void RectangleF_Equals_m5D6DE25E3F05FB749F4D089AD8904D7FC4F0A975 (void);
// 0x00000044 System.Boolean System.Drawing.RectangleF::Equals(System.Drawing.RectangleF)
extern void RectangleF_Equals_mF6803124E9CD077B02C2E8FABF907A9D186BE7BA (void);
// 0x00000045 System.Boolean System.Drawing.RectangleF::op_Equality(System.Drawing.RectangleF,System.Drawing.RectangleF)
extern void RectangleF_op_Equality_m5269F1C1E5549CA2991FE8173BBAD6462935C990 (void);
// 0x00000046 System.Int32 System.Drawing.RectangleF::GetHashCode()
extern void RectangleF_GetHashCode_m53718FAB968C4281E4D40ABF6AF94796B345AAF8 (void);
// 0x00000047 System.String System.Drawing.RectangleF::ToString()
extern void RectangleF_ToString_m3E02FDFF099EACBADDE0A2F447656C2F283757FB (void);
// 0x00000048 System.Boolean System.Drawing.Size::op_Equality(System.Drawing.Size,System.Drawing.Size)
extern void Size_op_Equality_m1D2F397A87FCA47D38E8F5C15B947F849DD8C52A (void);
// 0x00000049 System.Int32 System.Drawing.Size::get_Width()
extern void Size_get_Width_m1CAB2903EB07A265C466DF4FE4391DA036FBB1CB (void);
// 0x0000004A System.Int32 System.Drawing.Size::get_Height()
extern void Size_get_Height_mF208E98EB927661F6D660CEC4E286B82F99D4961 (void);
// 0x0000004B System.Boolean System.Drawing.Size::Equals(System.Object)
extern void Size_Equals_m93DF80FE836459123FE02A03242CFE243564512E (void);
// 0x0000004C System.Boolean System.Drawing.Size::Equals(System.Drawing.Size)
extern void Size_Equals_mB5785092C65D4CEFD76E302B468F50AE78C10C06 (void);
// 0x0000004D System.Int32 System.Drawing.Size::GetHashCode()
extern void Size_GetHashCode_m7DA961F97C5B8F66002E60938979DA777058E424 (void);
// 0x0000004E System.String System.Drawing.Size::ToString()
extern void Size_ToString_m9A0FC3B49D251B96F12A244DC5C70C341FFFE2F2 (void);
// 0x0000004F System.Boolean System.Drawing.SizeF::op_Equality(System.Drawing.SizeF,System.Drawing.SizeF)
extern void SizeF_op_Equality_m125E91D7B2C63D963EDCA9A79B056897CFC436AD (void);
// 0x00000050 System.Single System.Drawing.SizeF::get_Width()
extern void SizeF_get_Width_mDADBBCD3AEEE06E60E11AD0837287C32A0CAA9E3 (void);
// 0x00000051 System.Single System.Drawing.SizeF::get_Height()
extern void SizeF_get_Height_m811A09B7DE3708B22CD35BA18827637E05DC4DF2 (void);
// 0x00000052 System.Boolean System.Drawing.SizeF::Equals(System.Object)
extern void SizeF_Equals_m8349658750C243186A64E059DE6602CDD809EDEE (void);
// 0x00000053 System.Boolean System.Drawing.SizeF::Equals(System.Drawing.SizeF)
extern void SizeF_Equals_m42EA81684D6B4D93EDFC4CEB6FFA6ACE9F87F6B8 (void);
// 0x00000054 System.Int32 System.Drawing.SizeF::GetHashCode()
extern void SizeF_GetHashCode_m73CD624CAC3855F1EE921AA02CAA389AEAA931CD (void);
// 0x00000055 System.String System.Drawing.SizeF::ToString()
extern void SizeF_ToString_m888741B5D1636CE8E9BF5AD6D542F57CA73B5835 (void);
// 0x00000056 System.Void System.Drawing.Bitmap::.ctor()
extern void Bitmap__ctor_m9FF6CBB4998C51AAAAC900C2FCFF805814388CFE (void);
// 0x00000057 System.Void System.Drawing.Bitmap::.ctor(System.IntPtr)
extern void Bitmap__ctor_m7820E627830016DCC5D2DBAC39458764693A001C (void);
// 0x00000058 System.Void System.Drawing.Bitmap::.ctor(System.IntPtr,System.IO.Stream)
extern void Bitmap__ctor_mFABBA6E70AE4F310CAB91F431029B92B6D54EB6E (void);
// 0x00000059 System.Void System.Drawing.Bitmap::.ctor(System.Int32,System.Int32)
extern void Bitmap__ctor_m96980DAC4296C33D9458760E12C9B6706226D689 (void);
// 0x0000005A System.Void System.Drawing.Bitmap::.ctor(System.Int32,System.Int32,System.Drawing.Imaging.PixelFormat)
extern void Bitmap__ctor_m77483AD63F33C5EC9FD46ADFE7CE0439337D946E (void);
// 0x0000005B System.Void System.Drawing.Bitmap::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Bitmap__ctor_m12AED256B2CF000C4DCF61D7368D71D248D13B6F (void);
// 0x0000005C System.Void System.Drawing.Bitmap::SetPixel(System.Int32,System.Int32,System.Drawing.Color)
extern void Bitmap_SetPixel_mF3B4CEDF071610192D8FC6064E61C4544E840E65 (void);
// 0x0000005D System.Drawing.Imaging.BitmapData System.Drawing.Bitmap::LockBits(System.Drawing.Rectangle,System.Drawing.Imaging.ImageLockMode,System.Drawing.Imaging.PixelFormat)
extern void Bitmap_LockBits_m89033E37C44870F419DE3DB287967015844F39EF (void);
// 0x0000005E System.Drawing.Imaging.BitmapData System.Drawing.Bitmap::LockBits(System.Drawing.Rectangle,System.Drawing.Imaging.ImageLockMode,System.Drawing.Imaging.PixelFormat,System.Drawing.Imaging.BitmapData)
extern void Bitmap_LockBits_mD12A94AE5CD7C2A126343DCAB7D66FE6B733026C (void);
// 0x0000005F System.Void System.Drawing.Bitmap::UnlockBits(System.Drawing.Imaging.BitmapData)
extern void Bitmap_UnlockBits_m8118CE5EFEA8E3E35F1CADAF64CBC448BBB215B8 (void);
// 0x00000060 System.Void System.Drawing.ComIStreamMarshaler::.ctor()
extern void ComIStreamMarshaler__ctor_m0CDD3B6F24F4F227C416C9B9D6013D760CAAAA65 (void);
// 0x00000061 System.Runtime.InteropServices.ICustomMarshaler System.Drawing.ComIStreamMarshaler::GetInstance(System.String)
extern void ComIStreamMarshaler_GetInstance_m1537B7223C06468BA443965F0C95F291044FB30D (void);
// 0x00000062 System.IntPtr System.Drawing.ComIStreamMarshaler::MarshalManagedToNative(System.Object)
extern void ComIStreamMarshaler_MarshalManagedToNative_mEC43636DDD13373A9C1AC076C520C06BFACC8C34 (void);
// 0x00000063 System.Void System.Drawing.ComIStreamMarshaler::CleanUpNativeData(System.IntPtr)
extern void ComIStreamMarshaler_CleanUpNativeData_m74D35E4B9FD0AF0964F6CFEBE0CA69A8AB46C7A0 (void);
// 0x00000064 System.Object System.Drawing.ComIStreamMarshaler::MarshalNativeToManaged(System.IntPtr)
extern void ComIStreamMarshaler_MarshalNativeToManaged_mF320C5A595B5546D439F43658CFFA3E27A840ED3 (void);
// 0x00000065 System.Void System.Drawing.ComIStreamMarshaler::CleanUpManagedData(System.Object)
extern void ComIStreamMarshaler_CleanUpManagedData_m870E079D381481A5B59E738E92FF88BE8DB973FA (void);
// 0x00000066 System.Int32 System.Drawing.ComIStreamMarshaler::GetNativeDataSize()
extern void ComIStreamMarshaler_GetNativeDataSize_m32DE7CFBBE56E54725B4D4C49DF15290093CEBDE (void);
// 0x00000067 System.Void System.Drawing.ComIStreamMarshaler::.cctor()
extern void ComIStreamMarshaler__cctor_m5E92636EB144190DEEE798D006C42B4591822E85 (void);
// 0x00000068 System.Void System.Drawing.ComIStreamMarshaler/QueryInterfaceDelegate::.ctor(System.Object,System.IntPtr)
extern void QueryInterfaceDelegate__ctor_m2BB1B484FCC82D82162D3F195AC393C118EECD5C (void);
// 0x00000069 System.Int32 System.Drawing.ComIStreamMarshaler/QueryInterfaceDelegate::Invoke(System.IntPtr,System.Guid&,System.IntPtr)
extern void QueryInterfaceDelegate_Invoke_mA268611866392544D16EAE700335F18AAC4319E0 (void);
// 0x0000006A System.Void System.Drawing.ComIStreamMarshaler/AddRefDelegate::.ctor(System.Object,System.IntPtr)
extern void AddRefDelegate__ctor_m87857458CB755836DAB57483CF33257B5F3965DF (void);
// 0x0000006B System.Int32 System.Drawing.ComIStreamMarshaler/AddRefDelegate::Invoke(System.IntPtr)
extern void AddRefDelegate_Invoke_mBBA9E6E4EEE1F8AE3611127005D085786D756471 (void);
// 0x0000006C System.Void System.Drawing.ComIStreamMarshaler/ReleaseDelegate::.ctor(System.Object,System.IntPtr)
extern void ReleaseDelegate__ctor_mAF9DE93D06D3B2C957BD05FF8E8D83933091BC5E (void);
// 0x0000006D System.Int32 System.Drawing.ComIStreamMarshaler/ReleaseDelegate::Invoke(System.IntPtr)
extern void ReleaseDelegate_Invoke_m9E6468BC84AC37AA86E28BF7325E8118055E9582 (void);
// 0x0000006E System.Void System.Drawing.ComIStreamMarshaler/ReadDelegate::.ctor(System.Object,System.IntPtr)
extern void ReadDelegate__ctor_mE35489D87E7C81EA9578ED3EF687E53F5D61525E (void);
// 0x0000006F System.Int32 System.Drawing.ComIStreamMarshaler/ReadDelegate::Invoke(System.IntPtr,System.Byte[],System.Int32,System.IntPtr)
extern void ReadDelegate_Invoke_mB28BA73FAFD0C473FFB5527940B19D91EA05E29C (void);
// 0x00000070 System.Void System.Drawing.ComIStreamMarshaler/WriteDelegate::.ctor(System.Object,System.IntPtr)
extern void WriteDelegate__ctor_m7F430000DBF129A640274F98DC3256182EFDEF29 (void);
// 0x00000071 System.Int32 System.Drawing.ComIStreamMarshaler/WriteDelegate::Invoke(System.IntPtr,System.Byte[],System.Int32,System.IntPtr)
extern void WriteDelegate_Invoke_m3750013F1EAD868F736D4D290F426992EE550902 (void);
// 0x00000072 System.Void System.Drawing.ComIStreamMarshaler/SeekDelegate::.ctor(System.Object,System.IntPtr)
extern void SeekDelegate__ctor_m65E3640CB8740F8EE7A09E351FC5F234709D8F98 (void);
// 0x00000073 System.Int32 System.Drawing.ComIStreamMarshaler/SeekDelegate::Invoke(System.IntPtr,System.Int64,System.Int32,System.IntPtr)
extern void SeekDelegate_Invoke_m3B7A8956E6D34007D7DEBEB350D82908ED16EAF0 (void);
// 0x00000074 System.Void System.Drawing.ComIStreamMarshaler/SetSizeDelegate::.ctor(System.Object,System.IntPtr)
extern void SetSizeDelegate__ctor_m4563575D151256F4B308DA88FE0E07BDE707132F (void);
// 0x00000075 System.Int32 System.Drawing.ComIStreamMarshaler/SetSizeDelegate::Invoke(System.IntPtr,System.Int64)
extern void SetSizeDelegate_Invoke_m6D9CB10DE619D96BA09BE44DF6FA873E6D1718B5 (void);
// 0x00000076 System.Void System.Drawing.ComIStreamMarshaler/CopyToDelegate::.ctor(System.Object,System.IntPtr)
extern void CopyToDelegate__ctor_m1B3BD4A6D074BF82F2F7A6DD583601DF497D89ED (void);
// 0x00000077 System.Int32 System.Drawing.ComIStreamMarshaler/CopyToDelegate::Invoke(System.IntPtr,System.Runtime.InteropServices.ComTypes.IStream,System.Int64,System.IntPtr,System.IntPtr)
extern void CopyToDelegate_Invoke_mED6951C0BEC807D5F7B98410C4DACAC32AAE26D8 (void);
// 0x00000078 System.Void System.Drawing.ComIStreamMarshaler/CommitDelegate::.ctor(System.Object,System.IntPtr)
extern void CommitDelegate__ctor_mACCD67FCE1D41BCE3C67AA5C40DACF6DFE2C2361 (void);
// 0x00000079 System.Int32 System.Drawing.ComIStreamMarshaler/CommitDelegate::Invoke(System.IntPtr,System.Int32)
extern void CommitDelegate_Invoke_m45CB81D89D8D581583797959BAC236B26AEDD619 (void);
// 0x0000007A System.Void System.Drawing.ComIStreamMarshaler/RevertDelegate::.ctor(System.Object,System.IntPtr)
extern void RevertDelegate__ctor_mA447BE9B3F7F8F8CEE048BA13BDBAABC3C384AF7 (void);
// 0x0000007B System.Int32 System.Drawing.ComIStreamMarshaler/RevertDelegate::Invoke(System.IntPtr)
extern void RevertDelegate_Invoke_m68BA3529162D1342667EAA782CCBB724944749DD (void);
// 0x0000007C System.Void System.Drawing.ComIStreamMarshaler/LockRegionDelegate::.ctor(System.Object,System.IntPtr)
extern void LockRegionDelegate__ctor_mA9C98E32773055DE02EE17A3D74105BEF25FA987 (void);
// 0x0000007D System.Int32 System.Drawing.ComIStreamMarshaler/LockRegionDelegate::Invoke(System.IntPtr,System.Int64,System.Int64,System.Int32)
extern void LockRegionDelegate_Invoke_m9B6F58374647FB42102BF7F0886E9380A760A797 (void);
// 0x0000007E System.Void System.Drawing.ComIStreamMarshaler/UnlockRegionDelegate::.ctor(System.Object,System.IntPtr)
extern void UnlockRegionDelegate__ctor_mE49816E213F56B09279297FCF5D2255C82885B83 (void);
// 0x0000007F System.Int32 System.Drawing.ComIStreamMarshaler/UnlockRegionDelegate::Invoke(System.IntPtr,System.Int64,System.Int64,System.Int32)
extern void UnlockRegionDelegate_Invoke_mEE5E4FF902B1DBBC5681889048930F4815369483 (void);
// 0x00000080 System.Void System.Drawing.ComIStreamMarshaler/StatDelegate::.ctor(System.Object,System.IntPtr)
extern void StatDelegate__ctor_m0ECE5FEA2F43DDC9E11C3CBB8CBFCD99FFAC3846 (void);
// 0x00000081 System.Int32 System.Drawing.ComIStreamMarshaler/StatDelegate::Invoke(System.IntPtr,System.Runtime.InteropServices.ComTypes.STATSTG&,System.Int32)
extern void StatDelegate_Invoke_mFA20CF23B1E7ED4B0ADC98CA871899D32558F618 (void);
// 0x00000082 System.Void System.Drawing.ComIStreamMarshaler/CloneDelegate::.ctor(System.Object,System.IntPtr)
extern void CloneDelegate__ctor_m989A5F60AB7C33DA7E30F67E9E95AD9E114972A5 (void);
// 0x00000083 System.Int32 System.Drawing.ComIStreamMarshaler/CloneDelegate::Invoke(System.IntPtr,System.IntPtr&)
extern void CloneDelegate_Invoke_m3482AB11DA02AF92B457F001551333D81AB6B3BC (void);
// 0x00000084 System.Void System.Drawing.ComIStreamMarshaler/IStreamInterface::.ctor()
extern void IStreamInterface__ctor_m9DAD8855D253AFE0F5A8F720F6E926E949CC4FEF (void);
// 0x00000085 System.Void System.Drawing.ComIStreamMarshaler/IStreamVtbl::.ctor()
extern void IStreamVtbl__ctor_m78628BA5D767F1983997DA04A25FA7039A25A80A (void);
// 0x00000086 System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::.cctor()
extern void ManagedToNativeWrapper__cctor_m67C323ED8CE5D9A57A0B2EEC6995EC5B8CCF877E (void);
// 0x00000087 System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::.ctor(System.Runtime.InteropServices.ComTypes.IStream)
extern void ManagedToNativeWrapper__ctor_m3AB08E1C20A5FF8A7657D0EED3547FE1D63C07B6 (void);
// 0x00000088 System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Dispose()
extern void ManagedToNativeWrapper_Dispose_m57151DF9AAFC79F9E2268F88C15030322F5E51DB (void);
// 0x00000089 System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::OnShutdown(System.Object,System.EventArgs)
extern void ManagedToNativeWrapper_OnShutdown_m5A3AFECAF2DC5B0D16ACC433ABF3871D4D565C4C (void);
// 0x0000008A System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::CreateVtable()
extern void ManagedToNativeWrapper_CreateVtable_mC28C59EDADEFEA44FA4FE0948C24FD7377605296 (void);
// 0x0000008B System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::DisposeVtable()
extern void ManagedToNativeWrapper_DisposeVtable_m0ADA603CA4717542301838D199F6C5AF8FF5E176 (void);
// 0x0000008C System.Runtime.InteropServices.ComTypes.IStream System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::GetUnderlyingInterface(System.IntPtr,System.Boolean)
extern void ManagedToNativeWrapper_GetUnderlyingInterface_mF62E71F3146835F6F057BC68EB0B52FC0700BD30 (void);
// 0x0000008D System.IntPtr System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::GetInterface(System.Runtime.InteropServices.ComTypes.IStream)
extern void ManagedToNativeWrapper_GetInterface_m7C74F84F28FE7859AD4D02B0ECD06B8326429AE0 (void);
// 0x0000008E System.Void System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::ReleaseInterface(System.IntPtr)
extern void ManagedToNativeWrapper_ReleaseInterface_mE237AF25A5B1B3F6803F14B482B2952947EFD48E (void);
// 0x0000008F System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::GetHRForException(System.Exception)
extern void ManagedToNativeWrapper_GetHRForException_m9B85B7A9DE9D918F8619A62C3F1F44B7EA8307F4 (void);
// 0x00000090 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::GetObject(System.IntPtr)
extern void ManagedToNativeWrapper_GetObject_mB1109A4126024B31181827C7B5130DF7C7CCCABB (void);
// 0x00000091 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::QueryInterface(System.IntPtr,System.Guid&,System.IntPtr)
extern void ManagedToNativeWrapper_QueryInterface_mF978DFBB321B67E156326F50E16E79DCD9A9D822 (void);
// 0x00000092 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::AddRef(System.IntPtr)
extern void ManagedToNativeWrapper_AddRef_mBB6F6BE5394D6B37FCDC544E7CAF723499943D99 (void);
// 0x00000093 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Release(System.IntPtr)
extern void ManagedToNativeWrapper_Release_m0CD30C4CF1500CF93F5F739310C20FEACF5D2BA2 (void);
// 0x00000094 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Read(System.IntPtr,System.Byte[],System.Int32,System.IntPtr)
extern void ManagedToNativeWrapper_Read_m9B4C64BF0D12A02FADFF40D8D520379066CE7435 (void);
// 0x00000095 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Write(System.IntPtr,System.Byte[],System.Int32,System.IntPtr)
extern void ManagedToNativeWrapper_Write_m84C741B580561516EC4FCF30D63757513A516FAA (void);
// 0x00000096 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Seek(System.IntPtr,System.Int64,System.Int32,System.IntPtr)
extern void ManagedToNativeWrapper_Seek_m702D19EEBB3CDC61F0B6F992493B0CC4859FDBCB (void);
// 0x00000097 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::SetSize(System.IntPtr,System.Int64)
extern void ManagedToNativeWrapper_SetSize_m6EFF1CDAE03F0FC8D26972FE7930D97223C3BF47 (void);
// 0x00000098 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::CopyTo(System.IntPtr,System.Runtime.InteropServices.ComTypes.IStream,System.Int64,System.IntPtr,System.IntPtr)
extern void ManagedToNativeWrapper_CopyTo_m7B3E95442011430670AE612EE20297A39B3A85F9 (void);
// 0x00000099 System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Commit(System.IntPtr,System.Int32)
extern void ManagedToNativeWrapper_Commit_m4F1B88077F0C74CBE5241E44D05DEB28E1F2FBE6 (void);
// 0x0000009A System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Revert(System.IntPtr)
extern void ManagedToNativeWrapper_Revert_m8C5C986C22976DE4329AF008FD8C9B1723F3E17D (void);
// 0x0000009B System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::LockRegion(System.IntPtr,System.Int64,System.Int64,System.Int32)
extern void ManagedToNativeWrapper_LockRegion_mEE06CB112FB97FD62C0CDE533D9C171F612D4887 (void);
// 0x0000009C System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::UnlockRegion(System.IntPtr,System.Int64,System.Int64,System.Int32)
extern void ManagedToNativeWrapper_UnlockRegion_m13FF5B840F34AF1B31CBC2D24FCDD53348ABE4F7 (void);
// 0x0000009D System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Stat(System.IntPtr,System.Runtime.InteropServices.ComTypes.STATSTG&,System.Int32)
extern void ManagedToNativeWrapper_Stat_m28EDEEAE0A20304D59267457D339013F03A68681 (void);
// 0x0000009E System.Int32 System.Drawing.ComIStreamMarshaler/ManagedToNativeWrapper::Clone(System.IntPtr,System.IntPtr&)
extern void ManagedToNativeWrapper_Clone_m474B079FEDB136C2E0B29C716A1DE192517507AA (void);
// 0x0000009F System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::.ctor(System.IntPtr,System.Boolean)
extern void NativeToManagedWrapper__ctor_m523C445506389156DD24E858736BE3B68C671F21 (void);
// 0x000000A0 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Finalize()
extern void NativeToManagedWrapper_Finalize_m18045FDD4057B385A351134275E1D544A10F930B (void);
// 0x000000A1 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Dispose(System.Boolean)
extern void NativeToManagedWrapper_Dispose_m011D5262A8F6D5A1D8D4E2F98EA8AE662E0EBB51 (void);
// 0x000000A2 System.IntPtr System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::GetUnderlyingInterface(System.Runtime.InteropServices.ComTypes.IStream)
extern void NativeToManagedWrapper_GetUnderlyingInterface_m6550CF3903D06C28E8BCF8DAD3A9AC0F0E71A541 (void);
// 0x000000A3 System.Runtime.InteropServices.ComTypes.IStream System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::GetInterface(System.IntPtr,System.Boolean)
extern void NativeToManagedWrapper_GetInterface_m535C881DF137D0012EA03EEF5759A0233244EA93 (void);
// 0x000000A4 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::ReleaseInterface(System.Runtime.InteropServices.ComTypes.IStream)
extern void NativeToManagedWrapper_ReleaseInterface_m97353DD01B183A3D25D0C312CCE94DDD76A3A29E (void);
// 0x000000A5 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::ThrowExceptionForHR(System.Int32)
extern void NativeToManagedWrapper_ThrowExceptionForHR_m034FB0837F238B13D5A43148301456BF3FA692AC (void);
// 0x000000A6 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Read(System.Byte[],System.Int32,System.IntPtr)
extern void NativeToManagedWrapper_Read_m92D93E15422F8E7AA6FE0970A92919F39FD5E827 (void);
// 0x000000A7 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Write(System.Byte[],System.Int32,System.IntPtr)
extern void NativeToManagedWrapper_Write_m2CC6ED3BBBB91C9B2DFF9312AB5CD200D8C7A236 (void);
// 0x000000A8 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Seek(System.Int64,System.Int32,System.IntPtr)
extern void NativeToManagedWrapper_Seek_m3F200D92D11803B2279B860F73A8CD6EEED1A7B3 (void);
// 0x000000A9 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::SetSize(System.Int64)
extern void NativeToManagedWrapper_SetSize_m0A80C7C20A343A24628B4E047EA7951625C77EA8 (void);
// 0x000000AA System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::CopyTo(System.Runtime.InteropServices.ComTypes.IStream,System.Int64,System.IntPtr,System.IntPtr)
extern void NativeToManagedWrapper_CopyTo_mEA49498C9B6A02F18A1C45AACD09F3F1FD3D6539 (void);
// 0x000000AB System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Commit(System.Int32)
extern void NativeToManagedWrapper_Commit_m1CDDE6076066A37352EC8F2E570E59E0D63C7598 (void);
// 0x000000AC System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Revert()
extern void NativeToManagedWrapper_Revert_m6CEE0B80317E4CEC07237902E8E81A076C2ACA49 (void);
// 0x000000AD System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::LockRegion(System.Int64,System.Int64,System.Int32)
extern void NativeToManagedWrapper_LockRegion_m28C5D057ACE791F074CE96598BF713A24E07A3DB (void);
// 0x000000AE System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::UnlockRegion(System.Int64,System.Int64,System.Int32)
extern void NativeToManagedWrapper_UnlockRegion_m6A59115770B8DD8C4E6AA9A9838AA89C55FC0FDF (void);
// 0x000000AF System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Stat(System.Runtime.InteropServices.ComTypes.STATSTG&,System.Int32)
extern void NativeToManagedWrapper_Stat_m34C4C16D96E7CDEFDEFB505200A102037AD5959A (void);
// 0x000000B0 System.Void System.Drawing.ComIStreamMarshaler/NativeToManagedWrapper::Clone(System.Runtime.InteropServices.ComTypes.IStream&)
extern void NativeToManagedWrapper_Clone_m6D34867528FA20C62023BCE1E029E495BA408793 (void);
// 0x000000B1 System.Void System.Drawing.ComIStreamWrapper::.ctor(System.IO.Stream)
extern void ComIStreamWrapper__ctor_mC4D561E66F1C3CEE54DFD4629C68C3B26B47D0EC (void);
// 0x000000B2 System.Void System.Drawing.ComIStreamWrapper::SetSizeToPosition()
extern void ComIStreamWrapper_SetSizeToPosition_m7E749F5E2E6224C9A4F94C8E448C76B4789F9984 (void);
// 0x000000B3 System.Void System.Drawing.ComIStreamWrapper::Read(System.Byte[],System.Int32,System.IntPtr)
extern void ComIStreamWrapper_Read_m4C6041146285EBE4CD5F6C206CB88B5EE7BB05B1 (void);
// 0x000000B4 System.Void System.Drawing.ComIStreamWrapper::Write(System.Byte[],System.Int32,System.IntPtr)
extern void ComIStreamWrapper_Write_m79D2E6B0354200D0C2CED397807CBBA33563DFB4 (void);
// 0x000000B5 System.Void System.Drawing.ComIStreamWrapper::Seek(System.Int64,System.Int32,System.IntPtr)
extern void ComIStreamWrapper_Seek_mD77B5201918637BD1B1C4BA7B43660CE851F2FED (void);
// 0x000000B6 System.Void System.Drawing.ComIStreamWrapper::SetSize(System.Int64)
extern void ComIStreamWrapper_SetSize_m5963DA1AACAFECE89C0D3E6444FD8820E6B6E528 (void);
// 0x000000B7 System.Void System.Drawing.ComIStreamWrapper::CopyTo(System.Runtime.InteropServices.ComTypes.IStream,System.Int64,System.IntPtr,System.IntPtr)
extern void ComIStreamWrapper_CopyTo_mD8F3C7CF2BD6E7D0F4F638DC677E62FA8122E1F3 (void);
// 0x000000B8 System.Void System.Drawing.ComIStreamWrapper::Commit(System.Int32)
extern void ComIStreamWrapper_Commit_mA184C65ECC3CA08CA69F1017EA135D3F1AC3E548 (void);
// 0x000000B9 System.Void System.Drawing.ComIStreamWrapper::Revert()
extern void ComIStreamWrapper_Revert_mE554C50B2B82C748F421209A0E85B51CA230AE71 (void);
// 0x000000BA System.Void System.Drawing.ComIStreamWrapper::LockRegion(System.Int64,System.Int64,System.Int32)
extern void ComIStreamWrapper_LockRegion_m87A5D50216B0524D18EBBE943C6E490767A2196D (void);
// 0x000000BB System.Void System.Drawing.ComIStreamWrapper::UnlockRegion(System.Int64,System.Int64,System.Int32)
extern void ComIStreamWrapper_UnlockRegion_mA54D33844438B038945578E3280BA28C9FEAA585 (void);
// 0x000000BC System.Void System.Drawing.ComIStreamWrapper::Stat(System.Runtime.InteropServices.ComTypes.STATSTG&,System.Int32)
extern void ComIStreamWrapper_Stat_mF4035A6DF7FE59763D440145873AC8D3FB0F7F30 (void);
// 0x000000BD System.Void System.Drawing.ComIStreamWrapper::Clone(System.Runtime.InteropServices.ComTypes.IStream&)
extern void ComIStreamWrapper_Clone_m1428D77572709186E8DC5BB0469517879A6372B3 (void);
// 0x000000BE System.Void System.Drawing.Image::.ctor()
extern void Image__ctor_mB70D540DF0B5CC02FBE9753FF3845456BD772132 (void);
// 0x000000BF System.Void System.Drawing.Image::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Image__ctor_m2A14F8899FBEB3FEA9D31BC70611759F36F71BAA (void);
// 0x000000C0 System.Void System.Drawing.Image::System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void Image_System_Runtime_Serialization_ISerializable_GetObjectData_m739E59F258268DD26AE2908349FA83722F26671A (void);
// 0x000000C1 System.Drawing.Image System.Drawing.Image::FromFile(System.String)
extern void Image_FromFile_m63F60C3C5BFFD178E135C89C0DE307D0C4A6C219 (void);
// 0x000000C2 System.Drawing.Image System.Drawing.Image::FromFile(System.String,System.Boolean)
extern void Image_FromFile_m57271AAF39B6FDCAA145270E08076C1B546460F6 (void);
// 0x000000C3 System.Drawing.Image System.Drawing.Image::FromStream(System.IO.Stream)
extern void Image_FromStream_mAF25E27B987F204F82141462B314BCA7220FFB31 (void);
// 0x000000C4 System.Drawing.Image System.Drawing.Image::LoadFromStream(System.IO.Stream,System.Boolean)
extern void Image_LoadFromStream_m1A279EF017B47602EF088E2AF2B208638A1CB455 (void);
// 0x000000C5 System.Drawing.Image System.Drawing.Image::CreateFromHandle(System.IntPtr)
extern void Image_CreateFromHandle_m3BF3B0CA74BA848750D1C39F94C5FB6F632058F1 (void);
// 0x000000C6 System.IntPtr System.Drawing.Image::InitFromStream(System.IO.Stream)
extern void Image_InitFromStream_m9E25DDFA581B0132FF24AA794D203A6AC2F4D47F (void);
// 0x000000C7 System.Drawing.Imaging.ImageCodecInfo System.Drawing.Image::findEncoderForFormat(System.Drawing.Imaging.ImageFormat)
extern void Image_findEncoderForFormat_m3A04B80F8AF57B74009B50DDF6310EA2176139A9 (void);
// 0x000000C8 System.Void System.Drawing.Image::Save(System.IO.Stream,System.Drawing.Imaging.ImageFormat)
extern void Image_Save_mE964D5A7A139307E8658AC107CA70DED6624A160 (void);
// 0x000000C9 System.Void System.Drawing.Image::Save(System.IO.Stream,System.Drawing.Imaging.ImageCodecInfo,System.Drawing.Imaging.EncoderParameters)
extern void Image_Save_mE286F474C88B4142BFD91D8EBC3BB3720EFA2590 (void);
// 0x000000CA System.Int32 System.Drawing.Image::get_Height()
extern void Image_get_Height_mE57F164E7CCED4E4A5FF5312EA85888D08CBB442 (void);
// 0x000000CB System.Drawing.Imaging.PixelFormat System.Drawing.Image::get_PixelFormat()
extern void Image_get_PixelFormat_mA200A8BEACEE8C00E652DF448FE95CA74231C65D (void);
// 0x000000CC System.Drawing.Imaging.ImageFormat System.Drawing.Image::get_RawFormat()
extern void Image_get_RawFormat_mDAC5F17B38A78F38CD7322835AD4D3342FE05818 (void);
// 0x000000CD System.Int32 System.Drawing.Image::get_Width()
extern void Image_get_Width_m3D9CC78692761DA6FC6422DA4C76D13A8AA0131A (void);
// 0x000000CE System.IntPtr System.Drawing.Image::get_NativeObject()
extern void Image_get_NativeObject_m7B065018E0ADD1DFD25346A728A586F2667AFC76 (void);
// 0x000000CF System.Void System.Drawing.Image::Dispose()
extern void Image_Dispose_m7369158A6AA39D7A90AF7DC9BCE4885E443A8F38 (void);
// 0x000000D0 System.Void System.Drawing.Image::Finalize()
extern void Image_Finalize_mA5782F29F7FAF94660260A819477DD2B0CF95A83 (void);
// 0x000000D1 System.Void System.Drawing.Image::Dispose(System.Boolean)
extern void Image_Dispose_mE0CB2A3C3CDE7AF58B7616FA3F177CFB1595DEFD (void);
// 0x000000D2 System.Object System.Drawing.Image::Clone()
extern void Image_Clone_mC4F3EB2719A5B711821627C016185CEC545A47F8 (void);
// 0x000000D3 System.Object System.Drawing.Image::CloneFromStream()
extern void Image_CloneFromStream_m6FCDB2D742E8D1BEF2844A0D83D14C6A6D8917EB (void);
// 0x000000D4 System.Void System.Drawing.ImageConverter::.ctor()
extern void ImageConverter__ctor_mAA53498CE8D7371E04D91F8CAE5077E43287E26C (void);
// 0x000000D5 System.Boolean System.Drawing.ImageConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void ImageConverter_CanConvertFrom_m626A009091535AFE3300EE77E3270C0A5D69A0EA (void);
// 0x000000D6 System.Boolean System.Drawing.ImageConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void ImageConverter_CanConvertTo_mAB258504B5B52085B36A0B1D417BDF842A37E605 (void);
// 0x000000D7 System.Object System.Drawing.ImageConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void ImageConverter_ConvertFrom_m6FCEA505AF4D528E2AD8E1E5296B8D220F558742 (void);
// 0x000000D8 System.Object System.Drawing.ImageConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void ImageConverter_ConvertTo_mC14B42F9CDE5207A0653D3A90AAAF8D59514396E (void);
// 0x000000D9 System.Void System.Drawing.ImageFormatConverter::.ctor()
extern void ImageFormatConverter__ctor_m91F80D7AE3B36C6AED6FBF413C59CF6821069D7E (void);
// 0x000000DA System.Boolean System.Drawing.ImageFormatConverter::CanConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void ImageFormatConverter_CanConvertFrom_m73821CBED02EDACBE6925D2050857FAAD5CC7854 (void);
// 0x000000DB System.Boolean System.Drawing.ImageFormatConverter::CanConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Type)
extern void ImageFormatConverter_CanConvertTo_mA60B29928C729EA50A7BBFFC1C2F090592441D9F (void);
// 0x000000DC System.Object System.Drawing.ImageFormatConverter::ConvertFrom(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object)
extern void ImageFormatConverter_ConvertFrom_mB26DBC94FB1F469AE6491C8880638C241FA8EDE3 (void);
// 0x000000DD System.Object System.Drawing.ImageFormatConverter::ConvertTo(System.ComponentModel.ITypeDescriptorContext,System.Globalization.CultureInfo,System.Object,System.Type)
extern void ImageFormatConverter_ConvertTo_m8AF8B7B31F28EA1B15D683D3B79D94E06637DAC4 (void);
// 0x000000DE System.ComponentModel.TypeConverter/StandardValuesCollection System.Drawing.ImageFormatConverter::GetStandardValues(System.ComponentModel.ITypeDescriptorContext)
extern void ImageFormatConverter_GetStandardValues_mDF4FA23BDDE6B313B3CE9CFBCEDA4B29EF6D3DE3 (void);
// 0x000000DF System.Boolean System.Drawing.ImageFormatConverter::GetStandardValuesSupported(System.ComponentModel.ITypeDescriptorContext)
extern void ImageFormatConverter_GetStandardValuesSupported_m75085D1442D12325E25AB17E2371CC23B484C30D (void);
// 0x000000E0 System.Drawing.Status System.Drawing.GDIPlus::GdiplusStartup(System.UInt64&,System.Drawing.GdiplusStartupInput&,System.Drawing.GdiplusStartupOutput&)
extern void GDIPlus_GdiplusStartup_m2F23E9377A3A8E3AAAF3ECA4D362CA252F95456B (void);
// 0x000000E1 System.Void System.Drawing.GDIPlus::ProcessExit(System.Object,System.EventArgs)
extern void GDIPlus_ProcessExit_m012C4709DC7575571F5E3AFE9CA6DD68F8079B8D (void);
// 0x000000E2 System.Void System.Drawing.GDIPlus::.cctor()
extern void GDIPlus__cctor_m2DBB1AF4187C02EF5B6EE621521BD47A74951D3C (void);
// 0x000000E3 System.Boolean System.Drawing.GDIPlus::RunningOnWindows()
extern void GDIPlus_RunningOnWindows_m30B375220E469DF062B62C4347EFF27CB8AB2EAC (void);
// 0x000000E4 System.Boolean System.Drawing.GDIPlus::RunningOnUnix()
extern void GDIPlus_RunningOnUnix_m585A9B010A804CAA1ADA2AD203DD7569B69B0F70 (void);
// 0x000000E5 System.Void System.Drawing.GDIPlus::CheckStatus(System.Drawing.Status)
extern void GDIPlus_CheckStatus_m5178D66692F3B07B0430D166BE08C1229FC6C055 (void);
// 0x000000E6 System.Drawing.Status System.Drawing.GDIPlus::GdipCreateBitmapFromScan0(System.Int32,System.Int32,System.Int32,System.Drawing.Imaging.PixelFormat,System.IntPtr,System.IntPtr&)
extern void GDIPlus_GdipCreateBitmapFromScan0_mB7998A79D6BF30C692AE8D051CCD4760759D98CD (void);
// 0x000000E7 System.Drawing.Status System.Drawing.GDIPlus::GdipBitmapLockBits(System.IntPtr,System.Drawing.Rectangle&,System.Drawing.Imaging.ImageLockMode,System.Drawing.Imaging.PixelFormat,System.Drawing.Imaging.BitmapData)
extern void GDIPlus_GdipBitmapLockBits_m741EE76EA416F7D73A3A3FCDF28BB062F1C6A5DB (void);
// 0x000000E8 System.Drawing.Status System.Drawing.GDIPlus::GdipBitmapUnlockBits(System.IntPtr,System.Drawing.Imaging.BitmapData)
extern void GDIPlus_GdipBitmapUnlockBits_m0C358C1CED5D49F193527BFBD241FEEC132A2E1E (void);
// 0x000000E9 System.Drawing.Status System.Drawing.GDIPlus::GdipBitmapSetPixel(System.IntPtr,System.Int32,System.Int32,System.Int32)
extern void GDIPlus_GdipBitmapSetPixel_mCC7F49533A6EA64AC919159F7173574CA0522133 (void);
// 0x000000EA System.Drawing.Status System.Drawing.GDIPlus::GdipLoadImageFromFile(System.String,System.IntPtr&)
extern void GDIPlus_GdipLoadImageFromFile_mB20418A73C3A49C389C8133C7F5FAA3ACE33DF3E (void);
// 0x000000EB System.Drawing.Status System.Drawing.GDIPlus::GdipLoadImageFromStream(System.Runtime.InteropServices.ComTypes.IStream,System.IntPtr&)
extern void GDIPlus_GdipLoadImageFromStream_m5CF974C5CACD6EE4719B900528DFBDBD0C78172B (void);
// 0x000000EC System.Drawing.Status System.Drawing.GDIPlus::GdipSaveImageToStream(System.Runtime.InteropServices.HandleRef,System.Runtime.InteropServices.ComTypes.IStream,System.Guid&,System.Runtime.InteropServices.HandleRef)
extern void GDIPlus_GdipSaveImageToStream_m7A20EEA4E21C7D7BEAC6F1BEB71BC09D3D2077D4 (void);
// 0x000000ED System.Drawing.Status System.Drawing.GDIPlus::GdipCloneImage(System.IntPtr,System.IntPtr&)
extern void GDIPlus_GdipCloneImage_m74D35B0CE164CABA8C28353F61E0C94620A99554 (void);
// 0x000000EE System.Drawing.Status System.Drawing.GDIPlus::GdipLoadImageFromFileICM(System.String,System.IntPtr&)
extern void GDIPlus_GdipLoadImageFromFileICM_m085A1654E6599163F7289507FAD71728EB5FEE3B (void);
// 0x000000EF System.Drawing.Status System.Drawing.GDIPlus::GdipDisposeImage(System.IntPtr)
extern void GDIPlus_GdipDisposeImage_mD4A43CCBD9933778B73B5AA371CF5E7CF5CACC64 (void);
// 0x000000F0 System.Drawing.Status System.Drawing.GDIPlus::GdipGetImageType(System.IntPtr,System.Drawing.ImageType&)
extern void GDIPlus_GdipGetImageType_m79C4045AE19886B095EE887B0D481CCA76170ECF (void);
// 0x000000F1 System.Drawing.Status System.Drawing.GDIPlus::GdipGetImageHeight(System.IntPtr,System.UInt32&)
extern void GDIPlus_GdipGetImageHeight_mFCA648FBB995DAC51A2F9D55D5A85DFFC61853DE (void);
// 0x000000F2 System.Drawing.Status System.Drawing.GDIPlus::GdipGetImagePixelFormat(System.IntPtr,System.Drawing.Imaging.PixelFormat&)
extern void GDIPlus_GdipGetImagePixelFormat_m7F933DD50BBE97ECEAB4F331DFC5E144C841D176 (void);
// 0x000000F3 System.Drawing.Status System.Drawing.GDIPlus::GdipGetImageRawFormat(System.IntPtr,System.Guid&)
extern void GDIPlus_GdipGetImageRawFormat_mD3F028410935AF1DEC46A100AD68DBFEAFE8C3B2 (void);
// 0x000000F4 System.Drawing.Status System.Drawing.GDIPlus::GdipGetImageWidth(System.IntPtr,System.UInt32&)
extern void GDIPlus_GdipGetImageWidth_mD547696BE4DD53ADD0104B834A34B2618DB3EFDF (void);
// 0x000000F5 System.Int32 System.Drawing.GDIPlus::GdipGetImageEncodersSize(System.Int32&,System.Int32&)
extern void GDIPlus_GdipGetImageEncodersSize_m77E87222F25EC6A77F48E764FEA15B14ECB0B303 (void);
// 0x000000F6 System.Int32 System.Drawing.GDIPlus::GdipGetImageEncoders(System.Int32,System.Int32,System.IntPtr)
extern void GDIPlus_GdipGetImageEncoders_m0651ACCFDBD76A70FF047478B0E7723CDCF46F9B (void);
// 0x000000F7 System.Drawing.Status System.Drawing.GDIPlus::GdipLoadImageFromDelegate_linux(System.Drawing.GDIPlus/StreamGetHeaderDelegate,System.Drawing.GDIPlus/StreamGetBytesDelegate,System.Drawing.GDIPlus/StreamPutBytesDelegate,System.Drawing.GDIPlus/StreamSeekDelegate,System.Drawing.GDIPlus/StreamCloseDelegate,System.Drawing.GDIPlus/StreamSizeDelegate,System.IntPtr&)
extern void GDIPlus_GdipLoadImageFromDelegate_linux_m2F9AD7F666107D831721E3A4960D230BB7B4182D (void);
// 0x000000F8 System.Drawing.Status System.Drawing.GDIPlus::GdipSaveImageToDelegate_linux(System.IntPtr,System.Drawing.GDIPlus/StreamGetBytesDelegate,System.Drawing.GDIPlus/StreamPutBytesDelegate,System.Drawing.GDIPlus/StreamSeekDelegate,System.Drawing.GDIPlus/StreamCloseDelegate,System.Drawing.GDIPlus/StreamSizeDelegate,System.Guid&,System.IntPtr)
extern void GDIPlus_GdipSaveImageToDelegate_linux_m3853E297A0550CD7EC4DEB58EB6AF5F16DACFD20 (void);
// 0x000000F9 System.Int32 System.Drawing.GDIPlus::uname(System.IntPtr)
extern void GDIPlus_uname_m6151FCC8883944AF1454BFA45B0412F2D46977D0 (void);
// 0x000000FA System.Void System.Drawing.GDIPlus/StreamGetHeaderDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamGetHeaderDelegate__ctor_m4D7BAE2630A0F07F62921DE8E7715404FE86C80D (void);
// 0x000000FB System.Int32 System.Drawing.GDIPlus/StreamGetHeaderDelegate::Invoke(System.IntPtr,System.Int32)
extern void StreamGetHeaderDelegate_Invoke_m8A0C3A0F08C5AEE42090D7CE796B8375485F16A3 (void);
// 0x000000FC System.Void System.Drawing.GDIPlus/StreamGetBytesDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamGetBytesDelegate__ctor_m28D518D40F24508FAD68BBA29F2046D7C0FC7C79 (void);
// 0x000000FD System.Int32 System.Drawing.GDIPlus/StreamGetBytesDelegate::Invoke(System.IntPtr,System.Int32,System.Boolean)
extern void StreamGetBytesDelegate_Invoke_m9F555BA0A1EE128A452FC0CDDC19792CF78903F7 (void);
// 0x000000FE System.Void System.Drawing.GDIPlus/StreamSeekDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamSeekDelegate__ctor_mC6347CA1F79F865457829E43FBE4AEBDD9126228 (void);
// 0x000000FF System.Int64 System.Drawing.GDIPlus/StreamSeekDelegate::Invoke(System.Int32,System.Int32)
extern void StreamSeekDelegate_Invoke_m61DB2E269A04639EB7C0AAABC81D5687B487DC91 (void);
// 0x00000100 System.Void System.Drawing.GDIPlus/StreamPutBytesDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamPutBytesDelegate__ctor_mB60957EE64990B8F2B824D18599103956B45F126 (void);
// 0x00000101 System.Int32 System.Drawing.GDIPlus/StreamPutBytesDelegate::Invoke(System.IntPtr,System.Int32)
extern void StreamPutBytesDelegate_Invoke_mE44B56DC0ECE6C1D81781EA595E625620A848947 (void);
// 0x00000102 System.Void System.Drawing.GDIPlus/StreamCloseDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamCloseDelegate__ctor_mEA042E304AC2B2D4F9AF6CA9680F08232AB4A181 (void);
// 0x00000103 System.Void System.Drawing.GDIPlus/StreamCloseDelegate::Invoke()
extern void StreamCloseDelegate_Invoke_m43F289EEFA4AAC63E034BC4C8A0E989846862DF5 (void);
// 0x00000104 System.Void System.Drawing.GDIPlus/StreamSizeDelegate::.ctor(System.Object,System.IntPtr)
extern void StreamSizeDelegate__ctor_m251E6C303DAF5DFEAA03758D2ADBFBF3A72A8E87 (void);
// 0x00000105 System.Int64 System.Drawing.GDIPlus/StreamSizeDelegate::Invoke()
extern void StreamSizeDelegate_Invoke_mA1B94185C997A3633F03B70F46AE155EA69D0F3D (void);
// 0x00000106 System.Void System.Drawing.GDIPlus/GdiPlusStreamHelper::.ctor(System.IO.Stream,System.Boolean)
extern void GdiPlusStreamHelper__ctor_mFA010382BFA2FA3FCCA5FB7057DB866C92DD9FE8 (void);
// 0x00000107 System.Int32 System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamGetHeaderImpl(System.IntPtr,System.Int32)
extern void GdiPlusStreamHelper_StreamGetHeaderImpl_mCC4B8877CC61AF361233014E6573B7D7847A5B8D (void);
// 0x00000108 System.Drawing.GDIPlus/StreamGetHeaderDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_GetHeaderDelegate()
extern void GdiPlusStreamHelper_get_GetHeaderDelegate_m9BF6D8161DA94429C1DC67B7851EB0B39B7F7374 (void);
// 0x00000109 System.Int32 System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamGetBytesImpl(System.IntPtr,System.Int32,System.Boolean)
extern void GdiPlusStreamHelper_StreamGetBytesImpl_m5158363D99DCD88FE4CCFDE8725545B00680CE82 (void);
// 0x0000010A System.Drawing.GDIPlus/StreamGetBytesDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_GetBytesDelegate()
extern void GdiPlusStreamHelper_get_GetBytesDelegate_m0DEDE4119EED81AB00E69B11AD854971EB141886 (void);
// 0x0000010B System.Int64 System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamSeekImpl(System.Int32,System.Int32)
extern void GdiPlusStreamHelper_StreamSeekImpl_m735D30896ADD1817532560DCAABA61E77446E127 (void);
// 0x0000010C System.Drawing.GDIPlus/StreamSeekDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_SeekDelegate()
extern void GdiPlusStreamHelper_get_SeekDelegate_mB27C48C626F0E3C3EAECBF88427080E2CE1102BB (void);
// 0x0000010D System.Int32 System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamPutBytesImpl(System.IntPtr,System.Int32)
extern void GdiPlusStreamHelper_StreamPutBytesImpl_m9A8C520F6283606201CB042FA5D23CE8D22B6910 (void);
// 0x0000010E System.Drawing.GDIPlus/StreamPutBytesDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_PutBytesDelegate()
extern void GdiPlusStreamHelper_get_PutBytesDelegate_m26858076A600792D8ADB422C970A0F7E52813E98 (void);
// 0x0000010F System.Void System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamCloseImpl()
extern void GdiPlusStreamHelper_StreamCloseImpl_m1549446A89AA72BB3C94DE5DDF7EBF3E19A24E14 (void);
// 0x00000110 System.Drawing.GDIPlus/StreamCloseDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_CloseDelegate()
extern void GdiPlusStreamHelper_get_CloseDelegate_m775A4C5523A4ADD0237F8E5E8DDF52881B04F8BF (void);
// 0x00000111 System.Int64 System.Drawing.GDIPlus/GdiPlusStreamHelper::StreamSizeImpl()
extern void GdiPlusStreamHelper_StreamSizeImpl_m6DC78D2C76A037DBF6DDE9D29CD5B7ED2CF8D4BB (void);
// 0x00000112 System.Drawing.GDIPlus/StreamSizeDelegate System.Drawing.GDIPlus/GdiPlusStreamHelper::get_SizeDelegate()
extern void GdiPlusStreamHelper_get_SizeDelegate_m543318ED5776EB5D393FD1C9E5CF21EC670ACA3B (void);
// 0x00000113 System.Drawing.GdiplusStartupInput System.Drawing.GdiplusStartupInput::MakeGdiplusStartupInput()
extern void GdiplusStartupInput_MakeGdiplusStartupInput_m68EAE8860755C2CC5024D7E61E495A5C7872B95D (void);
// 0x00000114 System.Drawing.GdiplusStartupOutput System.Drawing.GdiplusStartupOutput::MakeGdiplusStartupOutput()
extern void GdiplusStartupOutput_MakeGdiplusStartupOutput_m6F87218343D25FF34AE01141D0E8A959FD2E356E (void);
// 0x00000115 System.Void System.Drawing.Imaging.EncoderParameter::Dispose()
extern void EncoderParameter_Dispose_m62227C96278BBD4D15887364AFAAF5B3034A72F2 (void);
// 0x00000116 System.Void System.Drawing.Imaging.EncoderParameter::Dispose(System.Boolean)
extern void EncoderParameter_Dispose_m225C95324E8FE4663E1868F1C0A2F0693BA22E69 (void);
// 0x00000117 System.IntPtr System.Drawing.Imaging.EncoderParameters::ConvertToMemory()
extern void EncoderParameters_ConvertToMemory_m75E9F612D61C530D3BE778B9DB11F20108F303DB (void);
// 0x00000118 System.Void System.Drawing.Imaging.ImageCodecInfo::.ctor()
extern void ImageCodecInfo__ctor_mAAF1B20938221422F58BEC01C7A492C0C75FEAAF (void);
// 0x00000119 System.Guid System.Drawing.Imaging.ImageCodecInfo::get_Clsid()
extern void ImageCodecInfo_get_Clsid_m0B4302897900CA76E4CBC75092352668BDD1F899 (void);
// 0x0000011A System.Void System.Drawing.Imaging.ImageCodecInfo::set_Clsid(System.Guid)
extern void ImageCodecInfo_set_Clsid_mC16320A24C90BEF23972A1BACD81C0915B9AAB92 (void);
// 0x0000011B System.Guid System.Drawing.Imaging.ImageCodecInfo::get_FormatID()
extern void ImageCodecInfo_get_FormatID_mAA66FAF124BEF7AF3CE6E785AB414C448D7FCDDB (void);
// 0x0000011C System.Void System.Drawing.Imaging.ImageCodecInfo::set_FormatID(System.Guid)
extern void ImageCodecInfo_set_FormatID_m97551D59F457D48FFEFBB6B4DCA13BF72DB91D23 (void);
// 0x0000011D System.Void System.Drawing.Imaging.ImageCodecInfo::set_CodecName(System.String)
extern void ImageCodecInfo_set_CodecName_m39279E9CC908B7CDCDD683044394C4A8B6536FF4 (void);
// 0x0000011E System.Void System.Drawing.Imaging.ImageCodecInfo::set_DllName(System.String)
extern void ImageCodecInfo_set_DllName_mDE0AD63F9DBC28EAFD3A4A52104D8669AA126FC3 (void);
// 0x0000011F System.Void System.Drawing.Imaging.ImageCodecInfo::set_FormatDescription(System.String)
extern void ImageCodecInfo_set_FormatDescription_mC861A45BE4602C80AFD764E628CA86DF66F273CD (void);
// 0x00000120 System.Void System.Drawing.Imaging.ImageCodecInfo::set_FilenameExtension(System.String)
extern void ImageCodecInfo_set_FilenameExtension_mAAE81EA232FDE144E4E51A75D7B9B58F83800E23 (void);
// 0x00000121 System.Void System.Drawing.Imaging.ImageCodecInfo::set_MimeType(System.String)
extern void ImageCodecInfo_set_MimeType_m201C83D753E6DC95F455407BCCDB6D3F23DE1FE8 (void);
// 0x00000122 System.Void System.Drawing.Imaging.ImageCodecInfo::set_Flags(System.Drawing.Imaging.ImageCodecFlags)
extern void ImageCodecInfo_set_Flags_m3697AA16CD1E226F62092D653A61C8A502498109 (void);
// 0x00000123 System.Void System.Drawing.Imaging.ImageCodecInfo::set_Version(System.Int32)
extern void ImageCodecInfo_set_Version_m39108B3C7AB3AF6FFB70A5A7FC82F54FE7A146C9 (void);
// 0x00000124 System.Byte[][] System.Drawing.Imaging.ImageCodecInfo::get_SignaturePatterns()
extern void ImageCodecInfo_get_SignaturePatterns_mEAB0E0EA776A5374B558717EB6BFDAA6F6404F9F (void);
// 0x00000125 System.Void System.Drawing.Imaging.ImageCodecInfo::set_SignaturePatterns(System.Byte[][])
extern void ImageCodecInfo_set_SignaturePatterns_mE337F44D5265F54CF0E8CA6EC5EB3BC323585798 (void);
// 0x00000126 System.Byte[][] System.Drawing.Imaging.ImageCodecInfo::get_SignatureMasks()
extern void ImageCodecInfo_get_SignatureMasks_m645BE10A6D750E7C58FFE4CB7CBAB59D741DB982 (void);
// 0x00000127 System.Void System.Drawing.Imaging.ImageCodecInfo::set_SignatureMasks(System.Byte[][])
extern void ImageCodecInfo_set_SignatureMasks_m4798FDA3C4ECF33969C9F4C2C154C2FEAA6B466A (void);
// 0x00000128 System.Drawing.Imaging.ImageCodecInfo[] System.Drawing.Imaging.ImageCodecInfo::GetImageEncoders()
extern void ImageCodecInfo_GetImageEncoders_mFC7AEE9C5ED1F8FCC46520B37A8B1A8B24605D76 (void);
// 0x00000129 System.Drawing.Imaging.ImageCodecInfo[] System.Drawing.Imaging.ImageCodecInfo::ConvertFromMemory(System.IntPtr,System.Int32)
extern void ImageCodecInfo_ConvertFromMemory_m4013F65FAE9902F17558E52330BDB52FEAEDB822 (void);
// 0x0000012A System.Void System.Drawing.Imaging.ImageCodecInfoPrivate::.ctor()
extern void ImageCodecInfoPrivate__ctor_m58580204C69F19254EA093269B73919A595AF55E (void);
// 0x0000012B System.IntPtr System.Drawing.Imaging.BitmapData::get_Scan0()
extern void BitmapData_get_Scan0_mFBB44469E2B0D493ED3810D95F09620227859B79 (void);
// 0x0000012C System.Int32 System.Drawing.Imaging.BitmapData::get_Stride()
extern void BitmapData_get_Stride_m25BBE52017AAAE0F1C9107AD19B2E8B9B472C4B8 (void);
// 0x0000012D System.Void System.Drawing.Imaging.BitmapData::.ctor()
extern void BitmapData__ctor_mA396C17A68AD7CF14A706C9923AC67943456ABBB (void);
// 0x0000012E System.Void System.Drawing.Imaging.ImageFormat::.ctor(System.Guid)
extern void ImageFormat__ctor_m4C8FEA14886E078A2993BF64DEC24A740FB0AA31 (void);
// 0x0000012F System.Void System.Drawing.Imaging.ImageFormat::.ctor(System.String,System.String)
extern void ImageFormat__ctor_m08C541362907090B44CA065C4E797B0CAD409C36 (void);
// 0x00000130 System.Boolean System.Drawing.Imaging.ImageFormat::Equals(System.Object)
extern void ImageFormat_Equals_mF68CCE128077E139A52915441CCCA2C5946B82DA (void);
// 0x00000131 System.Int32 System.Drawing.Imaging.ImageFormat::GetHashCode()
extern void ImageFormat_GetHashCode_m4093AF1BAAA71A821000793F0C8235D849D7EB32 (void);
// 0x00000132 System.String System.Drawing.Imaging.ImageFormat::ToString()
extern void ImageFormat_ToString_mE8DAAB87989126EC8ED644A6FFE86686BEE112C6 (void);
// 0x00000133 System.Guid System.Drawing.Imaging.ImageFormat::get_Guid()
extern void ImageFormat_get_Guid_m31AFD191C23A43014AF1168D320EB7CA96831AD4 (void);
// 0x00000134 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Bmp()
extern void ImageFormat_get_Bmp_m106BDA513C0A89462D2FD82716D3B81111443C5F (void);
// 0x00000135 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Emf()
extern void ImageFormat_get_Emf_m6FE5ACC501F3843A2D628150D69B3C6AEFEBD204 (void);
// 0x00000136 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Exif()
extern void ImageFormat_get_Exif_m0D8C58373A3A977C94E90228514FFD0DFB7FD6BA (void);
// 0x00000137 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Gif()
extern void ImageFormat_get_Gif_m7CC27D1193C89CCAE6809ED68B5E70603CF23EBF (void);
// 0x00000138 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Icon()
extern void ImageFormat_get_Icon_mD53107155DEC45FA822EC59A6FBAFAFD6C77E0F7 (void);
// 0x00000139 System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Jpeg()
extern void ImageFormat_get_Jpeg_m3520E114BEC037DDF773EC50DEC12D322F3BA9F4 (void);
// 0x0000013A System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_MemoryBmp()
extern void ImageFormat_get_MemoryBmp_mD3A9767906D617DFF0253381D7B6B505014A3A7F (void);
// 0x0000013B System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Png()
extern void ImageFormat_get_Png_m383CFF995626AC9055AA44D94814D002A29984FA (void);
// 0x0000013C System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Tiff()
extern void ImageFormat_get_Tiff_mF229F0589AA48A79859D8A950841E9B1E19EA25B (void);
// 0x0000013D System.Drawing.Imaging.ImageFormat System.Drawing.Imaging.ImageFormat::get_Wmf()
extern void ImageFormat_get_Wmf_mE8AADAFF768448107EDFB0293D5C81380446428C (void);
// 0x0000013E System.Void System.Drawing.Imaging.ImageFormat::.cctor()
extern void ImageFormat__cctor_mC454B7284860A62287438ACCFE0D9C253613F157 (void);
// 0x0000013F System.Void System.Drawing.Imaging.Metafile::.ctor(System.IntPtr)
extern void Metafile__ctor_mDBBBDB08277EA2A22D2BC63D2B6020B74EC087F7 (void);
// 0x00000140 System.Void System.Drawing.Imaging.Metafile::.ctor(System.IntPtr,System.IO.Stream)
extern void Metafile__ctor_m6313C8851025E8502761E9663EFE28A829FF1C3B (void);
// 0x00000141 System.Void System.Drawing.Imaging.Metafile::Dispose(System.Boolean)
extern void Metafile_Dispose_m5B260807A4321E952F0F9F275B73F9C7916F8AE7 (void);
// 0x00000142 System.Boolean System.Drawing.Imaging.Metafile/MetafileHolder::get_Disposed()
extern void MetafileHolder_get_Disposed_m30CF8FD2131AFD089C40230D322E40B46991C597 (void);
// 0x00000143 System.Void System.Drawing.Imaging.Metafile/MetafileHolder::MetafileDisposed(System.IntPtr)
extern void MetafileHolder_MetafileDisposed_m585BC97DDE55AB7C5D09352A58E4E736498B9008 (void);
// 0x00000144 System.Void System.Drawing.Design.UITypeEditor::.cctor()
extern void UITypeEditor__cctor_mC6B804F1A6E953AE3C5B5163EC8AADF710545698 (void);
static Il2CppMethodPointer s_methodPointers[324] = 
{
	Locale_GetText_m557C0E0FDBE23EE2270326E7A98328906830D43E,
	Locale_GetText_mF34C321B5E8B8901DE1B0BE6EA55E0D19B68A364,
	SR_Format_m9977F23B838724F9DA04223E0762B7AEA3AA91FC,
	MonoTODOAttribute__ctor_mED3EFB328E64CEADF9764E50BC9BC0E3DC526E50,
	HashHelpers_Combine_mB8E75AA81F7543BB0B05069416C485A4B8E692D8,
	HashHelpers__cctor_mA1680F8D1B4E1C62B6660FF8F4CB5852ED393F99,
	KnownColorTable_EnsureColorTable_mDA6E15087C13F589AE3A2038B16F2D7DBAF3FA83,
	KnownColorTable_InitColorTable_mC6E537EF5340F0DE473FD4D8A168D0631C38CD10,
	KnownColorTable_EnsureColorNameTable_m7D1BDA884F19A4F1AFEDA4B4CF3C59F20F612303,
	KnownColorTable_InitColorNameTable_mB77CC6E7FACE77180DAA58884E6EAF11865C3D83,
	KnownColorTable_KnownColorToArgb_m0979478F1E425ECEA80341F48B9C24AA50B36E97,
	KnownColorTable_KnownColorToName_mEFAED2FFD4EFF6A60FA921AE11C3894880DD63BE,
	KnownColorTable_UpdateSystemColors_mE162F51D4EB7E8842CFC3B1678801F3E3DB5DAD0,
	Gdip__cctor_mB10136A6BD2D49A7BBBD89F5DB30FC793E9410FE,
	Gdip_get_Initialized_mD097123D3DC3700649360B388C34061EA301988E,
	Gdip_ClearThreadData_mB1307AEC461B1606931393C1036F16EA746BBD77,
	Gdip_Shutdown_m24C188C5CCDA13D38E372FF9A24EE6483E6470C9,
	Gdip_OnProcessExit_m1BC6AF2E4774309551204FCF42C66514B1F71130,
	Gdip_StatusException_mD30EC7E61042064F8969D20703423D558395BEE8,
	Color_get_White_mC907A1EB3D7562346DD188F3B476C3BD3C8D44F6,
	Color__ctor_m5215720BE232CBB05AB92B8F558F5EE4D342D307,
	Color__ctor_m19020CC887E9C4F7C63526E49D6895683FA56970,
	Color_get_R_mA69925F53F4EF7AC1A3B4A94B9F4ABEA72662951,
	Color_get_G_m8BBF290336C0D938F2546AB296B002C9995B3BAA,
	Color_get_B_mC668C85173CDC211AC0E2FEB3E6C36E9C57DCC61,
	Color_get_A_m20373E97C1E01A1B27CD551E4FB1CB62DD381230,
	Color_get_IsKnownColor_mDE5232E7F4367FD7055F468772188EC1C6576198,
	Color_get_Name_m82B674D6BA69AE386BB798DD78DB116307F3B876,
	Color_get_Value_mEC0390B65E6E1ADA7963CDDE6ADB0AA077712574,
	Color_CheckByte_mAEC90FAB7CD6D1AB42685B47E3EDDCDD13D2FBE7,
	Color_MakeArgb_mCFECEF91CF3C17C3992AAF04A0216E01954E3E2E,
	Color_FromArgb_m7855D60AB3843525C91FB2174D10238B44F2320C,
	Color_ToArgb_m1782C7D79C856B95679C601C8A2AB40C8B90AFFC,
	Color_ToString_m5C7D9DB036E127D264B17FA528580B7BD052513F,
	Color_op_Equality_m5BD270427D7DA9AF8F2C004ACA2F43F734F2EE57,
	Color_Equals_m0AECC84D788C0CB1B1FB44C945705AD7BAFF603A,
	Color_Equals_mCC06EC6FD579073BFC35481FA94461A70DA7B7BA,
	Color_GetHashCode_m87358396DFDAE1F14332D3AC10A83ED1060FC9BB,
	Point_get_X_m461B51706A8EF818C163A1AED09C6B706815AC3A,
	Point_get_Y_m04B98946BE28DE3A88C2BA7C09236A60936D30E3,
	Point_op_Equality_m16DF80982C9BD6458336F4101DFEBFC2C958216D,
	Point_Equals_mC52C70909BD95B4192039FC19157003D4DB22C97,
	Point_Equals_m3818E37548CAC5B822230E60BB7C45EF569E98E4,
	Point_GetHashCode_mDCA1B4C2AF30051D731F2B500019F35239D6E951,
	Point_ToString_mA8731A1FEDC9F643E304C052B3F4285F6ABC56FF,
	PointF_get_X_mA55226AFC51F0CF910D69872A0F19BFBE1F93C9B,
	PointF_get_Y_m4B10717E6217968D6F8946A3C77ED5D1AF93A8C3,
	PointF_op_Equality_m0BD00717287326DD803FA0C9A74083A5A0114371,
	PointF_Equals_mF1B0AEFEFECC0044933D67DCC12851F941F98E1D,
	PointF_Equals_m0EC0248A2D9522AB35E4C32DD4DE06ABAD946CE1,
	PointF_GetHashCode_m7128D4D9228862A2B1C6862A8E8A7971A2AFD27E,
	PointF_ToString_m6D64DB31243686C6547C230BA5221BC3BC9E4EC2,
	Rectangle__ctor_m3FB90CAD0ECE9EA19BE7EFEDCC973808070497A7,
	Rectangle_get_X_m57216246BE34687C3100179002EA5B2A9079776D,
	Rectangle_get_Y_m8D016239D6FA9171C75C071E6CDD3557BF8C0239,
	Rectangle_get_Width_m08006DBCE23A7EC1B9BA4BAE399141B529B13A52,
	Rectangle_get_Height_m9C3D28B6C72348677EE9EEBA616E65C90B154DB2,
	Rectangle_Equals_m5B125B9AE09AE711F2218BB7BF9BFE97F054A250,
	Rectangle_Equals_mC876A9A25614D79581F23875D17F80D1C78910FD,
	Rectangle_op_Equality_m502490E5E78505CE41D65FF3B66339074464B0B2,
	Rectangle_GetHashCode_m3B1DDBEEFEF70E4EEB5145960DED4C1A4574D574,
	Rectangle_ToString_m20252CB5611CF6E9F46C82F7D8068FF76AB6C508,
	RectangleF_get_X_m9A2032884F510E397628C623B4A4C6F037104B98,
	RectangleF_get_Y_m37F48864D908EAC8CF080850424B28D503B5B1EF,
	RectangleF_get_Width_m44AA143927197CC0337A9A4A275CCD663570531D,
	RectangleF_get_Height_m1AB0E38CB2777AB1C1378765D253E79D8861118D,
	RectangleF_Equals_m5D6DE25E3F05FB749F4D089AD8904D7FC4F0A975,
	RectangleF_Equals_mF6803124E9CD077B02C2E8FABF907A9D186BE7BA,
	RectangleF_op_Equality_m5269F1C1E5549CA2991FE8173BBAD6462935C990,
	RectangleF_GetHashCode_m53718FAB968C4281E4D40ABF6AF94796B345AAF8,
	RectangleF_ToString_m3E02FDFF099EACBADDE0A2F447656C2F283757FB,
	Size_op_Equality_m1D2F397A87FCA47D38E8F5C15B947F849DD8C52A,
	Size_get_Width_m1CAB2903EB07A265C466DF4FE4391DA036FBB1CB,
	Size_get_Height_mF208E98EB927661F6D660CEC4E286B82F99D4961,
	Size_Equals_m93DF80FE836459123FE02A03242CFE243564512E,
	Size_Equals_mB5785092C65D4CEFD76E302B468F50AE78C10C06,
	Size_GetHashCode_m7DA961F97C5B8F66002E60938979DA777058E424,
	Size_ToString_m9A0FC3B49D251B96F12A244DC5C70C341FFFE2F2,
	SizeF_op_Equality_m125E91D7B2C63D963EDCA9A79B056897CFC436AD,
	SizeF_get_Width_mDADBBCD3AEEE06E60E11AD0837287C32A0CAA9E3,
	SizeF_get_Height_m811A09B7DE3708B22CD35BA18827637E05DC4DF2,
	SizeF_Equals_m8349658750C243186A64E059DE6602CDD809EDEE,
	SizeF_Equals_m42EA81684D6B4D93EDFC4CEB6FFA6ACE9F87F6B8,
	SizeF_GetHashCode_m73CD624CAC3855F1EE921AA02CAA389AEAA931CD,
	SizeF_ToString_m888741B5D1636CE8E9BF5AD6D542F57CA73B5835,
	Bitmap__ctor_m9FF6CBB4998C51AAAAC900C2FCFF805814388CFE,
	Bitmap__ctor_m7820E627830016DCC5D2DBAC39458764693A001C,
	Bitmap__ctor_mFABBA6E70AE4F310CAB91F431029B92B6D54EB6E,
	Bitmap__ctor_m96980DAC4296C33D9458760E12C9B6706226D689,
	Bitmap__ctor_m77483AD63F33C5EC9FD46ADFE7CE0439337D946E,
	Bitmap__ctor_m12AED256B2CF000C4DCF61D7368D71D248D13B6F,
	Bitmap_SetPixel_mF3B4CEDF071610192D8FC6064E61C4544E840E65,
	Bitmap_LockBits_m89033E37C44870F419DE3DB287967015844F39EF,
	Bitmap_LockBits_mD12A94AE5CD7C2A126343DCAB7D66FE6B733026C,
	Bitmap_UnlockBits_m8118CE5EFEA8E3E35F1CADAF64CBC448BBB215B8,
	ComIStreamMarshaler__ctor_m0CDD3B6F24F4F227C416C9B9D6013D760CAAAA65,
	ComIStreamMarshaler_GetInstance_m1537B7223C06468BA443965F0C95F291044FB30D,
	ComIStreamMarshaler_MarshalManagedToNative_mEC43636DDD13373A9C1AC076C520C06BFACC8C34,
	ComIStreamMarshaler_CleanUpNativeData_m74D35E4B9FD0AF0964F6CFEBE0CA69A8AB46C7A0,
	ComIStreamMarshaler_MarshalNativeToManaged_mF320C5A595B5546D439F43658CFFA3E27A840ED3,
	ComIStreamMarshaler_CleanUpManagedData_m870E079D381481A5B59E738E92FF88BE8DB973FA,
	ComIStreamMarshaler_GetNativeDataSize_m32DE7CFBBE56E54725B4D4C49DF15290093CEBDE,
	ComIStreamMarshaler__cctor_m5E92636EB144190DEEE798D006C42B4591822E85,
	QueryInterfaceDelegate__ctor_m2BB1B484FCC82D82162D3F195AC393C118EECD5C,
	QueryInterfaceDelegate_Invoke_mA268611866392544D16EAE700335F18AAC4319E0,
	AddRefDelegate__ctor_m87857458CB755836DAB57483CF33257B5F3965DF,
	AddRefDelegate_Invoke_mBBA9E6E4EEE1F8AE3611127005D085786D756471,
	ReleaseDelegate__ctor_mAF9DE93D06D3B2C957BD05FF8E8D83933091BC5E,
	ReleaseDelegate_Invoke_m9E6468BC84AC37AA86E28BF7325E8118055E9582,
	ReadDelegate__ctor_mE35489D87E7C81EA9578ED3EF687E53F5D61525E,
	ReadDelegate_Invoke_mB28BA73FAFD0C473FFB5527940B19D91EA05E29C,
	WriteDelegate__ctor_m7F430000DBF129A640274F98DC3256182EFDEF29,
	WriteDelegate_Invoke_m3750013F1EAD868F736D4D290F426992EE550902,
	SeekDelegate__ctor_m65E3640CB8740F8EE7A09E351FC5F234709D8F98,
	SeekDelegate_Invoke_m3B7A8956E6D34007D7DEBEB350D82908ED16EAF0,
	SetSizeDelegate__ctor_m4563575D151256F4B308DA88FE0E07BDE707132F,
	SetSizeDelegate_Invoke_m6D9CB10DE619D96BA09BE44DF6FA873E6D1718B5,
	CopyToDelegate__ctor_m1B3BD4A6D074BF82F2F7A6DD583601DF497D89ED,
	CopyToDelegate_Invoke_mED6951C0BEC807D5F7B98410C4DACAC32AAE26D8,
	CommitDelegate__ctor_mACCD67FCE1D41BCE3C67AA5C40DACF6DFE2C2361,
	CommitDelegate_Invoke_m45CB81D89D8D581583797959BAC236B26AEDD619,
	RevertDelegate__ctor_mA447BE9B3F7F8F8CEE048BA13BDBAABC3C384AF7,
	RevertDelegate_Invoke_m68BA3529162D1342667EAA782CCBB724944749DD,
	LockRegionDelegate__ctor_mA9C98E32773055DE02EE17A3D74105BEF25FA987,
	LockRegionDelegate_Invoke_m9B6F58374647FB42102BF7F0886E9380A760A797,
	UnlockRegionDelegate__ctor_mE49816E213F56B09279297FCF5D2255C82885B83,
	UnlockRegionDelegate_Invoke_mEE5E4FF902B1DBBC5681889048930F4815369483,
	StatDelegate__ctor_m0ECE5FEA2F43DDC9E11C3CBB8CBFCD99FFAC3846,
	StatDelegate_Invoke_mFA20CF23B1E7ED4B0ADC98CA871899D32558F618,
	CloneDelegate__ctor_m989A5F60AB7C33DA7E30F67E9E95AD9E114972A5,
	CloneDelegate_Invoke_m3482AB11DA02AF92B457F001551333D81AB6B3BC,
	IStreamInterface__ctor_m9DAD8855D253AFE0F5A8F720F6E926E949CC4FEF,
	IStreamVtbl__ctor_m78628BA5D767F1983997DA04A25FA7039A25A80A,
	ManagedToNativeWrapper__cctor_m67C323ED8CE5D9A57A0B2EEC6995EC5B8CCF877E,
	ManagedToNativeWrapper__ctor_m3AB08E1C20A5FF8A7657D0EED3547FE1D63C07B6,
	ManagedToNativeWrapper_Dispose_m57151DF9AAFC79F9E2268F88C15030322F5E51DB,
	ManagedToNativeWrapper_OnShutdown_m5A3AFECAF2DC5B0D16ACC433ABF3871D4D565C4C,
	ManagedToNativeWrapper_CreateVtable_mC28C59EDADEFEA44FA4FE0948C24FD7377605296,
	ManagedToNativeWrapper_DisposeVtable_m0ADA603CA4717542301838D199F6C5AF8FF5E176,
	ManagedToNativeWrapper_GetUnderlyingInterface_mF62E71F3146835F6F057BC68EB0B52FC0700BD30,
	ManagedToNativeWrapper_GetInterface_m7C74F84F28FE7859AD4D02B0ECD06B8326429AE0,
	ManagedToNativeWrapper_ReleaseInterface_mE237AF25A5B1B3F6803F14B482B2952947EFD48E,
	ManagedToNativeWrapper_GetHRForException_m9B85B7A9DE9D918F8619A62C3F1F44B7EA8307F4,
	ManagedToNativeWrapper_GetObject_mB1109A4126024B31181827C7B5130DF7C7CCCABB,
	ManagedToNativeWrapper_QueryInterface_mF978DFBB321B67E156326F50E16E79DCD9A9D822,
	ManagedToNativeWrapper_AddRef_mBB6F6BE5394D6B37FCDC544E7CAF723499943D99,
	ManagedToNativeWrapper_Release_m0CD30C4CF1500CF93F5F739310C20FEACF5D2BA2,
	ManagedToNativeWrapper_Read_m9B4C64BF0D12A02FADFF40D8D520379066CE7435,
	ManagedToNativeWrapper_Write_m84C741B580561516EC4FCF30D63757513A516FAA,
	ManagedToNativeWrapper_Seek_m702D19EEBB3CDC61F0B6F992493B0CC4859FDBCB,
	ManagedToNativeWrapper_SetSize_m6EFF1CDAE03F0FC8D26972FE7930D97223C3BF47,
	ManagedToNativeWrapper_CopyTo_m7B3E95442011430670AE612EE20297A39B3A85F9,
	ManagedToNativeWrapper_Commit_m4F1B88077F0C74CBE5241E44D05DEB28E1F2FBE6,
	ManagedToNativeWrapper_Revert_m8C5C986C22976DE4329AF008FD8C9B1723F3E17D,
	ManagedToNativeWrapper_LockRegion_mEE06CB112FB97FD62C0CDE533D9C171F612D4887,
	ManagedToNativeWrapper_UnlockRegion_m13FF5B840F34AF1B31CBC2D24FCDD53348ABE4F7,
	ManagedToNativeWrapper_Stat_m28EDEEAE0A20304D59267457D339013F03A68681,
	ManagedToNativeWrapper_Clone_m474B079FEDB136C2E0B29C716A1DE192517507AA,
	NativeToManagedWrapper__ctor_m523C445506389156DD24E858736BE3B68C671F21,
	NativeToManagedWrapper_Finalize_m18045FDD4057B385A351134275E1D544A10F930B,
	NativeToManagedWrapper_Dispose_m011D5262A8F6D5A1D8D4E2F98EA8AE662E0EBB51,
	NativeToManagedWrapper_GetUnderlyingInterface_m6550CF3903D06C28E8BCF8DAD3A9AC0F0E71A541,
	NativeToManagedWrapper_GetInterface_m535C881DF137D0012EA03EEF5759A0233244EA93,
	NativeToManagedWrapper_ReleaseInterface_m97353DD01B183A3D25D0C312CCE94DDD76A3A29E,
	NativeToManagedWrapper_ThrowExceptionForHR_m034FB0837F238B13D5A43148301456BF3FA692AC,
	NativeToManagedWrapper_Read_m92D93E15422F8E7AA6FE0970A92919F39FD5E827,
	NativeToManagedWrapper_Write_m2CC6ED3BBBB91C9B2DFF9312AB5CD200D8C7A236,
	NativeToManagedWrapper_Seek_m3F200D92D11803B2279B860F73A8CD6EEED1A7B3,
	NativeToManagedWrapper_SetSize_m0A80C7C20A343A24628B4E047EA7951625C77EA8,
	NativeToManagedWrapper_CopyTo_mEA49498C9B6A02F18A1C45AACD09F3F1FD3D6539,
	NativeToManagedWrapper_Commit_m1CDDE6076066A37352EC8F2E570E59E0D63C7598,
	NativeToManagedWrapper_Revert_m6CEE0B80317E4CEC07237902E8E81A076C2ACA49,
	NativeToManagedWrapper_LockRegion_m28C5D057ACE791F074CE96598BF713A24E07A3DB,
	NativeToManagedWrapper_UnlockRegion_m6A59115770B8DD8C4E6AA9A9838AA89C55FC0FDF,
	NativeToManagedWrapper_Stat_m34C4C16D96E7CDEFDEFB505200A102037AD5959A,
	NativeToManagedWrapper_Clone_m6D34867528FA20C62023BCE1E029E495BA408793,
	ComIStreamWrapper__ctor_mC4D561E66F1C3CEE54DFD4629C68C3B26B47D0EC,
	ComIStreamWrapper_SetSizeToPosition_m7E749F5E2E6224C9A4F94C8E448C76B4789F9984,
	ComIStreamWrapper_Read_m4C6041146285EBE4CD5F6C206CB88B5EE7BB05B1,
	ComIStreamWrapper_Write_m79D2E6B0354200D0C2CED397807CBBA33563DFB4,
	ComIStreamWrapper_Seek_mD77B5201918637BD1B1C4BA7B43660CE851F2FED,
	ComIStreamWrapper_SetSize_m5963DA1AACAFECE89C0D3E6444FD8820E6B6E528,
	ComIStreamWrapper_CopyTo_mD8F3C7CF2BD6E7D0F4F638DC677E62FA8122E1F3,
	ComIStreamWrapper_Commit_mA184C65ECC3CA08CA69F1017EA135D3F1AC3E548,
	ComIStreamWrapper_Revert_mE554C50B2B82C748F421209A0E85B51CA230AE71,
	ComIStreamWrapper_LockRegion_m87A5D50216B0524D18EBBE943C6E490767A2196D,
	ComIStreamWrapper_UnlockRegion_mA54D33844438B038945578E3280BA28C9FEAA585,
	ComIStreamWrapper_Stat_mF4035A6DF7FE59763D440145873AC8D3FB0F7F30,
	ComIStreamWrapper_Clone_m1428D77572709186E8DC5BB0469517879A6372B3,
	Image__ctor_mB70D540DF0B5CC02FBE9753FF3845456BD772132,
	Image__ctor_m2A14F8899FBEB3FEA9D31BC70611759F36F71BAA,
	Image_System_Runtime_Serialization_ISerializable_GetObjectData_m739E59F258268DD26AE2908349FA83722F26671A,
	Image_FromFile_m63F60C3C5BFFD178E135C89C0DE307D0C4A6C219,
	Image_FromFile_m57271AAF39B6FDCAA145270E08076C1B546460F6,
	Image_FromStream_mAF25E27B987F204F82141462B314BCA7220FFB31,
	Image_LoadFromStream_m1A279EF017B47602EF088E2AF2B208638A1CB455,
	Image_CreateFromHandle_m3BF3B0CA74BA848750D1C39F94C5FB6F632058F1,
	Image_InitFromStream_m9E25DDFA581B0132FF24AA794D203A6AC2F4D47F,
	Image_findEncoderForFormat_m3A04B80F8AF57B74009B50DDF6310EA2176139A9,
	Image_Save_mE964D5A7A139307E8658AC107CA70DED6624A160,
	Image_Save_mE286F474C88B4142BFD91D8EBC3BB3720EFA2590,
	Image_get_Height_mE57F164E7CCED4E4A5FF5312EA85888D08CBB442,
	Image_get_PixelFormat_mA200A8BEACEE8C00E652DF448FE95CA74231C65D,
	Image_get_RawFormat_mDAC5F17B38A78F38CD7322835AD4D3342FE05818,
	Image_get_Width_m3D9CC78692761DA6FC6422DA4C76D13A8AA0131A,
	Image_get_NativeObject_m7B065018E0ADD1DFD25346A728A586F2667AFC76,
	Image_Dispose_m7369158A6AA39D7A90AF7DC9BCE4885E443A8F38,
	Image_Finalize_mA5782F29F7FAF94660260A819477DD2B0CF95A83,
	Image_Dispose_mE0CB2A3C3CDE7AF58B7616FA3F177CFB1595DEFD,
	Image_Clone_mC4F3EB2719A5B711821627C016185CEC545A47F8,
	Image_CloneFromStream_m6FCDB2D742E8D1BEF2844A0D83D14C6A6D8917EB,
	ImageConverter__ctor_mAA53498CE8D7371E04D91F8CAE5077E43287E26C,
	ImageConverter_CanConvertFrom_m626A009091535AFE3300EE77E3270C0A5D69A0EA,
	ImageConverter_CanConvertTo_mAB258504B5B52085B36A0B1D417BDF842A37E605,
	ImageConverter_ConvertFrom_m6FCEA505AF4D528E2AD8E1E5296B8D220F558742,
	ImageConverter_ConvertTo_mC14B42F9CDE5207A0653D3A90AAAF8D59514396E,
	ImageFormatConverter__ctor_m91F80D7AE3B36C6AED6FBF413C59CF6821069D7E,
	ImageFormatConverter_CanConvertFrom_m73821CBED02EDACBE6925D2050857FAAD5CC7854,
	ImageFormatConverter_CanConvertTo_mA60B29928C729EA50A7BBFFC1C2F090592441D9F,
	ImageFormatConverter_ConvertFrom_mB26DBC94FB1F469AE6491C8880638C241FA8EDE3,
	ImageFormatConverter_ConvertTo_m8AF8B7B31F28EA1B15D683D3B79D94E06637DAC4,
	ImageFormatConverter_GetStandardValues_mDF4FA23BDDE6B313B3CE9CFBCEDA4B29EF6D3DE3,
	ImageFormatConverter_GetStandardValuesSupported_m75085D1442D12325E25AB17E2371CC23B484C30D,
	GDIPlus_GdiplusStartup_m2F23E9377A3A8E3AAAF3ECA4D362CA252F95456B,
	GDIPlus_ProcessExit_m012C4709DC7575571F5E3AFE9CA6DD68F8079B8D,
	GDIPlus__cctor_m2DBB1AF4187C02EF5B6EE621521BD47A74951D3C,
	GDIPlus_RunningOnWindows_m30B375220E469DF062B62C4347EFF27CB8AB2EAC,
	GDIPlus_RunningOnUnix_m585A9B010A804CAA1ADA2AD203DD7569B69B0F70,
	GDIPlus_CheckStatus_m5178D66692F3B07B0430D166BE08C1229FC6C055,
	GDIPlus_GdipCreateBitmapFromScan0_mB7998A79D6BF30C692AE8D051CCD4760759D98CD,
	GDIPlus_GdipBitmapLockBits_m741EE76EA416F7D73A3A3FCDF28BB062F1C6A5DB,
	GDIPlus_GdipBitmapUnlockBits_m0C358C1CED5D49F193527BFBD241FEEC132A2E1E,
	GDIPlus_GdipBitmapSetPixel_mCC7F49533A6EA64AC919159F7173574CA0522133,
	GDIPlus_GdipLoadImageFromFile_mB20418A73C3A49C389C8133C7F5FAA3ACE33DF3E,
	GDIPlus_GdipLoadImageFromStream_m5CF974C5CACD6EE4719B900528DFBDBD0C78172B,
	GDIPlus_GdipSaveImageToStream_m7A20EEA4E21C7D7BEAC6F1BEB71BC09D3D2077D4,
	GDIPlus_GdipCloneImage_m74D35B0CE164CABA8C28353F61E0C94620A99554,
	GDIPlus_GdipLoadImageFromFileICM_m085A1654E6599163F7289507FAD71728EB5FEE3B,
	GDIPlus_GdipDisposeImage_mD4A43CCBD9933778B73B5AA371CF5E7CF5CACC64,
	GDIPlus_GdipGetImageType_m79C4045AE19886B095EE887B0D481CCA76170ECF,
	GDIPlus_GdipGetImageHeight_mFCA648FBB995DAC51A2F9D55D5A85DFFC61853DE,
	GDIPlus_GdipGetImagePixelFormat_m7F933DD50BBE97ECEAB4F331DFC5E144C841D176,
	GDIPlus_GdipGetImageRawFormat_mD3F028410935AF1DEC46A100AD68DBFEAFE8C3B2,
	GDIPlus_GdipGetImageWidth_mD547696BE4DD53ADD0104B834A34B2618DB3EFDF,
	GDIPlus_GdipGetImageEncodersSize_m77E87222F25EC6A77F48E764FEA15B14ECB0B303,
	GDIPlus_GdipGetImageEncoders_m0651ACCFDBD76A70FF047478B0E7723CDCF46F9B,
	GDIPlus_GdipLoadImageFromDelegate_linux_m2F9AD7F666107D831721E3A4960D230BB7B4182D,
	GDIPlus_GdipSaveImageToDelegate_linux_m3853E297A0550CD7EC4DEB58EB6AF5F16DACFD20,
	GDIPlus_uname_m6151FCC8883944AF1454BFA45B0412F2D46977D0,
	StreamGetHeaderDelegate__ctor_m4D7BAE2630A0F07F62921DE8E7715404FE86C80D,
	StreamGetHeaderDelegate_Invoke_m8A0C3A0F08C5AEE42090D7CE796B8375485F16A3,
	StreamGetBytesDelegate__ctor_m28D518D40F24508FAD68BBA29F2046D7C0FC7C79,
	StreamGetBytesDelegate_Invoke_m9F555BA0A1EE128A452FC0CDDC19792CF78903F7,
	StreamSeekDelegate__ctor_mC6347CA1F79F865457829E43FBE4AEBDD9126228,
	StreamSeekDelegate_Invoke_m61DB2E269A04639EB7C0AAABC81D5687B487DC91,
	StreamPutBytesDelegate__ctor_mB60957EE64990B8F2B824D18599103956B45F126,
	StreamPutBytesDelegate_Invoke_mE44B56DC0ECE6C1D81781EA595E625620A848947,
	StreamCloseDelegate__ctor_mEA042E304AC2B2D4F9AF6CA9680F08232AB4A181,
	StreamCloseDelegate_Invoke_m43F289EEFA4AAC63E034BC4C8A0E989846862DF5,
	StreamSizeDelegate__ctor_m251E6C303DAF5DFEAA03758D2ADBFBF3A72A8E87,
	StreamSizeDelegate_Invoke_mA1B94185C997A3633F03B70F46AE155EA69D0F3D,
	GdiPlusStreamHelper__ctor_mFA010382BFA2FA3FCCA5FB7057DB866C92DD9FE8,
	GdiPlusStreamHelper_StreamGetHeaderImpl_mCC4B8877CC61AF361233014E6573B7D7847A5B8D,
	GdiPlusStreamHelper_get_GetHeaderDelegate_m9BF6D8161DA94429C1DC67B7851EB0B39B7F7374,
	GdiPlusStreamHelper_StreamGetBytesImpl_m5158363D99DCD88FE4CCFDE8725545B00680CE82,
	GdiPlusStreamHelper_get_GetBytesDelegate_m0DEDE4119EED81AB00E69B11AD854971EB141886,
	GdiPlusStreamHelper_StreamSeekImpl_m735D30896ADD1817532560DCAABA61E77446E127,
	GdiPlusStreamHelper_get_SeekDelegate_mB27C48C626F0E3C3EAECBF88427080E2CE1102BB,
	GdiPlusStreamHelper_StreamPutBytesImpl_m9A8C520F6283606201CB042FA5D23CE8D22B6910,
	GdiPlusStreamHelper_get_PutBytesDelegate_m26858076A600792D8ADB422C970A0F7E52813E98,
	GdiPlusStreamHelper_StreamCloseImpl_m1549446A89AA72BB3C94DE5DDF7EBF3E19A24E14,
	GdiPlusStreamHelper_get_CloseDelegate_m775A4C5523A4ADD0237F8E5E8DDF52881B04F8BF,
	GdiPlusStreamHelper_StreamSizeImpl_m6DC78D2C76A037DBF6DDE9D29CD5B7ED2CF8D4BB,
	GdiPlusStreamHelper_get_SizeDelegate_m543318ED5776EB5D393FD1C9E5CF21EC670ACA3B,
	GdiplusStartupInput_MakeGdiplusStartupInput_m68EAE8860755C2CC5024D7E61E495A5C7872B95D,
	GdiplusStartupOutput_MakeGdiplusStartupOutput_m6F87218343D25FF34AE01141D0E8A959FD2E356E,
	EncoderParameter_Dispose_m62227C96278BBD4D15887364AFAAF5B3034A72F2,
	EncoderParameter_Dispose_m225C95324E8FE4663E1868F1C0A2F0693BA22E69,
	EncoderParameters_ConvertToMemory_m75E9F612D61C530D3BE778B9DB11F20108F303DB,
	ImageCodecInfo__ctor_mAAF1B20938221422F58BEC01C7A492C0C75FEAAF,
	ImageCodecInfo_get_Clsid_m0B4302897900CA76E4CBC75092352668BDD1F899,
	ImageCodecInfo_set_Clsid_mC16320A24C90BEF23972A1BACD81C0915B9AAB92,
	ImageCodecInfo_get_FormatID_mAA66FAF124BEF7AF3CE6E785AB414C448D7FCDDB,
	ImageCodecInfo_set_FormatID_m97551D59F457D48FFEFBB6B4DCA13BF72DB91D23,
	ImageCodecInfo_set_CodecName_m39279E9CC908B7CDCDD683044394C4A8B6536FF4,
	ImageCodecInfo_set_DllName_mDE0AD63F9DBC28EAFD3A4A52104D8669AA126FC3,
	ImageCodecInfo_set_FormatDescription_mC861A45BE4602C80AFD764E628CA86DF66F273CD,
	ImageCodecInfo_set_FilenameExtension_mAAE81EA232FDE144E4E51A75D7B9B58F83800E23,
	ImageCodecInfo_set_MimeType_m201C83D753E6DC95F455407BCCDB6D3F23DE1FE8,
	ImageCodecInfo_set_Flags_m3697AA16CD1E226F62092D653A61C8A502498109,
	ImageCodecInfo_set_Version_m39108B3C7AB3AF6FFB70A5A7FC82F54FE7A146C9,
	ImageCodecInfo_get_SignaturePatterns_mEAB0E0EA776A5374B558717EB6BFDAA6F6404F9F,
	ImageCodecInfo_set_SignaturePatterns_mE337F44D5265F54CF0E8CA6EC5EB3BC323585798,
	ImageCodecInfo_get_SignatureMasks_m645BE10A6D750E7C58FFE4CB7CBAB59D741DB982,
	ImageCodecInfo_set_SignatureMasks_m4798FDA3C4ECF33969C9F4C2C154C2FEAA6B466A,
	ImageCodecInfo_GetImageEncoders_mFC7AEE9C5ED1F8FCC46520B37A8B1A8B24605D76,
	ImageCodecInfo_ConvertFromMemory_m4013F65FAE9902F17558E52330BDB52FEAEDB822,
	ImageCodecInfoPrivate__ctor_m58580204C69F19254EA093269B73919A595AF55E,
	BitmapData_get_Scan0_mFBB44469E2B0D493ED3810D95F09620227859B79,
	BitmapData_get_Stride_m25BBE52017AAAE0F1C9107AD19B2E8B9B472C4B8,
	BitmapData__ctor_mA396C17A68AD7CF14A706C9923AC67943456ABBB,
	ImageFormat__ctor_m4C8FEA14886E078A2993BF64DEC24A740FB0AA31,
	ImageFormat__ctor_m08C541362907090B44CA065C4E797B0CAD409C36,
	ImageFormat_Equals_mF68CCE128077E139A52915441CCCA2C5946B82DA,
	ImageFormat_GetHashCode_m4093AF1BAAA71A821000793F0C8235D849D7EB32,
	ImageFormat_ToString_mE8DAAB87989126EC8ED644A6FFE86686BEE112C6,
	ImageFormat_get_Guid_m31AFD191C23A43014AF1168D320EB7CA96831AD4,
	ImageFormat_get_Bmp_m106BDA513C0A89462D2FD82716D3B81111443C5F,
	ImageFormat_get_Emf_m6FE5ACC501F3843A2D628150D69B3C6AEFEBD204,
	ImageFormat_get_Exif_m0D8C58373A3A977C94E90228514FFD0DFB7FD6BA,
	ImageFormat_get_Gif_m7CC27D1193C89CCAE6809ED68B5E70603CF23EBF,
	ImageFormat_get_Icon_mD53107155DEC45FA822EC59A6FBAFAFD6C77E0F7,
	ImageFormat_get_Jpeg_m3520E114BEC037DDF773EC50DEC12D322F3BA9F4,
	ImageFormat_get_MemoryBmp_mD3A9767906D617DFF0253381D7B6B505014A3A7F,
	ImageFormat_get_Png_m383CFF995626AC9055AA44D94814D002A29984FA,
	ImageFormat_get_Tiff_mF229F0589AA48A79859D8A950841E9B1E19EA25B,
	ImageFormat_get_Wmf_mE8AADAFF768448107EDFB0293D5C81380446428C,
	ImageFormat__cctor_mC454B7284860A62287438ACCFE0D9C253613F157,
	Metafile__ctor_mDBBBDB08277EA2A22D2BC63D2B6020B74EC087F7,
	Metafile__ctor_m6313C8851025E8502761E9663EFE28A829FF1C3B,
	Metafile_Dispose_m5B260807A4321E952F0F9F275B73F9C7916F8AE7,
	MetafileHolder_get_Disposed_m30CF8FD2131AFD089C40230D322E40B46991C597,
	MetafileHolder_MetafileDisposed_m585BC97DDE55AB7C5D09352A58E4E736498B9008,
	UITypeEditor__cctor_mC6B804F1A6E953AE3C5B5163EC8AADF710545698,
};
extern void Color__ctor_m5215720BE232CBB05AB92B8F558F5EE4D342D307_AdjustorThunk (void);
extern void Color__ctor_m19020CC887E9C4F7C63526E49D6895683FA56970_AdjustorThunk (void);
extern void Color_get_R_mA69925F53F4EF7AC1A3B4A94B9F4ABEA72662951_AdjustorThunk (void);
extern void Color_get_G_m8BBF290336C0D938F2546AB296B002C9995B3BAA_AdjustorThunk (void);
extern void Color_get_B_mC668C85173CDC211AC0E2FEB3E6C36E9C57DCC61_AdjustorThunk (void);
extern void Color_get_A_m20373E97C1E01A1B27CD551E4FB1CB62DD381230_AdjustorThunk (void);
extern void Color_get_IsKnownColor_mDE5232E7F4367FD7055F468772188EC1C6576198_AdjustorThunk (void);
extern void Color_get_Name_m82B674D6BA69AE386BB798DD78DB116307F3B876_AdjustorThunk (void);
extern void Color_get_Value_mEC0390B65E6E1ADA7963CDDE6ADB0AA077712574_AdjustorThunk (void);
extern void Color_ToArgb_m1782C7D79C856B95679C601C8A2AB40C8B90AFFC_AdjustorThunk (void);
extern void Color_ToString_m5C7D9DB036E127D264B17FA528580B7BD052513F_AdjustorThunk (void);
extern void Color_Equals_m0AECC84D788C0CB1B1FB44C945705AD7BAFF603A_AdjustorThunk (void);
extern void Color_Equals_mCC06EC6FD579073BFC35481FA94461A70DA7B7BA_AdjustorThunk (void);
extern void Color_GetHashCode_m87358396DFDAE1F14332D3AC10A83ED1060FC9BB_AdjustorThunk (void);
extern void Point_get_X_m461B51706A8EF818C163A1AED09C6B706815AC3A_AdjustorThunk (void);
extern void Point_get_Y_m04B98946BE28DE3A88C2BA7C09236A60936D30E3_AdjustorThunk (void);
extern void Point_Equals_mC52C70909BD95B4192039FC19157003D4DB22C97_AdjustorThunk (void);
extern void Point_Equals_m3818E37548CAC5B822230E60BB7C45EF569E98E4_AdjustorThunk (void);
extern void Point_GetHashCode_mDCA1B4C2AF30051D731F2B500019F35239D6E951_AdjustorThunk (void);
extern void Point_ToString_mA8731A1FEDC9F643E304C052B3F4285F6ABC56FF_AdjustorThunk (void);
extern void PointF_get_X_mA55226AFC51F0CF910D69872A0F19BFBE1F93C9B_AdjustorThunk (void);
extern void PointF_get_Y_m4B10717E6217968D6F8946A3C77ED5D1AF93A8C3_AdjustorThunk (void);
extern void PointF_Equals_mF1B0AEFEFECC0044933D67DCC12851F941F98E1D_AdjustorThunk (void);
extern void PointF_Equals_m0EC0248A2D9522AB35E4C32DD4DE06ABAD946CE1_AdjustorThunk (void);
extern void PointF_GetHashCode_m7128D4D9228862A2B1C6862A8E8A7971A2AFD27E_AdjustorThunk (void);
extern void PointF_ToString_m6D64DB31243686C6547C230BA5221BC3BC9E4EC2_AdjustorThunk (void);
extern void Rectangle__ctor_m3FB90CAD0ECE9EA19BE7EFEDCC973808070497A7_AdjustorThunk (void);
extern void Rectangle_get_X_m57216246BE34687C3100179002EA5B2A9079776D_AdjustorThunk (void);
extern void Rectangle_get_Y_m8D016239D6FA9171C75C071E6CDD3557BF8C0239_AdjustorThunk (void);
extern void Rectangle_get_Width_m08006DBCE23A7EC1B9BA4BAE399141B529B13A52_AdjustorThunk (void);
extern void Rectangle_get_Height_m9C3D28B6C72348677EE9EEBA616E65C90B154DB2_AdjustorThunk (void);
extern void Rectangle_Equals_m5B125B9AE09AE711F2218BB7BF9BFE97F054A250_AdjustorThunk (void);
extern void Rectangle_Equals_mC876A9A25614D79581F23875D17F80D1C78910FD_AdjustorThunk (void);
extern void Rectangle_GetHashCode_m3B1DDBEEFEF70E4EEB5145960DED4C1A4574D574_AdjustorThunk (void);
extern void Rectangle_ToString_m20252CB5611CF6E9F46C82F7D8068FF76AB6C508_AdjustorThunk (void);
extern void RectangleF_get_X_m9A2032884F510E397628C623B4A4C6F037104B98_AdjustorThunk (void);
extern void RectangleF_get_Y_m37F48864D908EAC8CF080850424B28D503B5B1EF_AdjustorThunk (void);
extern void RectangleF_get_Width_m44AA143927197CC0337A9A4A275CCD663570531D_AdjustorThunk (void);
extern void RectangleF_get_Height_m1AB0E38CB2777AB1C1378765D253E79D8861118D_AdjustorThunk (void);
extern void RectangleF_Equals_m5D6DE25E3F05FB749F4D089AD8904D7FC4F0A975_AdjustorThunk (void);
extern void RectangleF_Equals_mF6803124E9CD077B02C2E8FABF907A9D186BE7BA_AdjustorThunk (void);
extern void RectangleF_GetHashCode_m53718FAB968C4281E4D40ABF6AF94796B345AAF8_AdjustorThunk (void);
extern void RectangleF_ToString_m3E02FDFF099EACBADDE0A2F447656C2F283757FB_AdjustorThunk (void);
extern void Size_get_Width_m1CAB2903EB07A265C466DF4FE4391DA036FBB1CB_AdjustorThunk (void);
extern void Size_get_Height_mF208E98EB927661F6D660CEC4E286B82F99D4961_AdjustorThunk (void);
extern void Size_Equals_m93DF80FE836459123FE02A03242CFE243564512E_AdjustorThunk (void);
extern void Size_Equals_mB5785092C65D4CEFD76E302B468F50AE78C10C06_AdjustorThunk (void);
extern void Size_GetHashCode_m7DA961F97C5B8F66002E60938979DA777058E424_AdjustorThunk (void);
extern void Size_ToString_m9A0FC3B49D251B96F12A244DC5C70C341FFFE2F2_AdjustorThunk (void);
extern void SizeF_get_Width_mDADBBCD3AEEE06E60E11AD0837287C32A0CAA9E3_AdjustorThunk (void);
extern void SizeF_get_Height_m811A09B7DE3708B22CD35BA18827637E05DC4DF2_AdjustorThunk (void);
extern void SizeF_Equals_m8349658750C243186A64E059DE6602CDD809EDEE_AdjustorThunk (void);
extern void SizeF_Equals_m42EA81684D6B4D93EDFC4CEB6FFA6ACE9F87F6B8_AdjustorThunk (void);
extern void SizeF_GetHashCode_m73CD624CAC3855F1EE921AA02CAA389AEAA931CD_AdjustorThunk (void);
extern void SizeF_ToString_m888741B5D1636CE8E9BF5AD6D542F57CA73B5835_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[55] = 
{
	{ 0x06000015, Color__ctor_m5215720BE232CBB05AB92B8F558F5EE4D342D307_AdjustorThunk },
	{ 0x06000016, Color__ctor_m19020CC887E9C4F7C63526E49D6895683FA56970_AdjustorThunk },
	{ 0x06000017, Color_get_R_mA69925F53F4EF7AC1A3B4A94B9F4ABEA72662951_AdjustorThunk },
	{ 0x06000018, Color_get_G_m8BBF290336C0D938F2546AB296B002C9995B3BAA_AdjustorThunk },
	{ 0x06000019, Color_get_B_mC668C85173CDC211AC0E2FEB3E6C36E9C57DCC61_AdjustorThunk },
	{ 0x0600001A, Color_get_A_m20373E97C1E01A1B27CD551E4FB1CB62DD381230_AdjustorThunk },
	{ 0x0600001B, Color_get_IsKnownColor_mDE5232E7F4367FD7055F468772188EC1C6576198_AdjustorThunk },
	{ 0x0600001C, Color_get_Name_m82B674D6BA69AE386BB798DD78DB116307F3B876_AdjustorThunk },
	{ 0x0600001D, Color_get_Value_mEC0390B65E6E1ADA7963CDDE6ADB0AA077712574_AdjustorThunk },
	{ 0x06000021, Color_ToArgb_m1782C7D79C856B95679C601C8A2AB40C8B90AFFC_AdjustorThunk },
	{ 0x06000022, Color_ToString_m5C7D9DB036E127D264B17FA528580B7BD052513F_AdjustorThunk },
	{ 0x06000024, Color_Equals_m0AECC84D788C0CB1B1FB44C945705AD7BAFF603A_AdjustorThunk },
	{ 0x06000025, Color_Equals_mCC06EC6FD579073BFC35481FA94461A70DA7B7BA_AdjustorThunk },
	{ 0x06000026, Color_GetHashCode_m87358396DFDAE1F14332D3AC10A83ED1060FC9BB_AdjustorThunk },
	{ 0x06000027, Point_get_X_m461B51706A8EF818C163A1AED09C6B706815AC3A_AdjustorThunk },
	{ 0x06000028, Point_get_Y_m04B98946BE28DE3A88C2BA7C09236A60936D30E3_AdjustorThunk },
	{ 0x0600002A, Point_Equals_mC52C70909BD95B4192039FC19157003D4DB22C97_AdjustorThunk },
	{ 0x0600002B, Point_Equals_m3818E37548CAC5B822230E60BB7C45EF569E98E4_AdjustorThunk },
	{ 0x0600002C, Point_GetHashCode_mDCA1B4C2AF30051D731F2B500019F35239D6E951_AdjustorThunk },
	{ 0x0600002D, Point_ToString_mA8731A1FEDC9F643E304C052B3F4285F6ABC56FF_AdjustorThunk },
	{ 0x0600002E, PointF_get_X_mA55226AFC51F0CF910D69872A0F19BFBE1F93C9B_AdjustorThunk },
	{ 0x0600002F, PointF_get_Y_m4B10717E6217968D6F8946A3C77ED5D1AF93A8C3_AdjustorThunk },
	{ 0x06000031, PointF_Equals_mF1B0AEFEFECC0044933D67DCC12851F941F98E1D_AdjustorThunk },
	{ 0x06000032, PointF_Equals_m0EC0248A2D9522AB35E4C32DD4DE06ABAD946CE1_AdjustorThunk },
	{ 0x06000033, PointF_GetHashCode_m7128D4D9228862A2B1C6862A8E8A7971A2AFD27E_AdjustorThunk },
	{ 0x06000034, PointF_ToString_m6D64DB31243686C6547C230BA5221BC3BC9E4EC2_AdjustorThunk },
	{ 0x06000035, Rectangle__ctor_m3FB90CAD0ECE9EA19BE7EFEDCC973808070497A7_AdjustorThunk },
	{ 0x06000036, Rectangle_get_X_m57216246BE34687C3100179002EA5B2A9079776D_AdjustorThunk },
	{ 0x06000037, Rectangle_get_Y_m8D016239D6FA9171C75C071E6CDD3557BF8C0239_AdjustorThunk },
	{ 0x06000038, Rectangle_get_Width_m08006DBCE23A7EC1B9BA4BAE399141B529B13A52_AdjustorThunk },
	{ 0x06000039, Rectangle_get_Height_m9C3D28B6C72348677EE9EEBA616E65C90B154DB2_AdjustorThunk },
	{ 0x0600003A, Rectangle_Equals_m5B125B9AE09AE711F2218BB7BF9BFE97F054A250_AdjustorThunk },
	{ 0x0600003B, Rectangle_Equals_mC876A9A25614D79581F23875D17F80D1C78910FD_AdjustorThunk },
	{ 0x0600003D, Rectangle_GetHashCode_m3B1DDBEEFEF70E4EEB5145960DED4C1A4574D574_AdjustorThunk },
	{ 0x0600003E, Rectangle_ToString_m20252CB5611CF6E9F46C82F7D8068FF76AB6C508_AdjustorThunk },
	{ 0x0600003F, RectangleF_get_X_m9A2032884F510E397628C623B4A4C6F037104B98_AdjustorThunk },
	{ 0x06000040, RectangleF_get_Y_m37F48864D908EAC8CF080850424B28D503B5B1EF_AdjustorThunk },
	{ 0x06000041, RectangleF_get_Width_m44AA143927197CC0337A9A4A275CCD663570531D_AdjustorThunk },
	{ 0x06000042, RectangleF_get_Height_m1AB0E38CB2777AB1C1378765D253E79D8861118D_AdjustorThunk },
	{ 0x06000043, RectangleF_Equals_m5D6DE25E3F05FB749F4D089AD8904D7FC4F0A975_AdjustorThunk },
	{ 0x06000044, RectangleF_Equals_mF6803124E9CD077B02C2E8FABF907A9D186BE7BA_AdjustorThunk },
	{ 0x06000046, RectangleF_GetHashCode_m53718FAB968C4281E4D40ABF6AF94796B345AAF8_AdjustorThunk },
	{ 0x06000047, RectangleF_ToString_m3E02FDFF099EACBADDE0A2F447656C2F283757FB_AdjustorThunk },
	{ 0x06000049, Size_get_Width_m1CAB2903EB07A265C466DF4FE4391DA036FBB1CB_AdjustorThunk },
	{ 0x0600004A, Size_get_Height_mF208E98EB927661F6D660CEC4E286B82F99D4961_AdjustorThunk },
	{ 0x0600004B, Size_Equals_m93DF80FE836459123FE02A03242CFE243564512E_AdjustorThunk },
	{ 0x0600004C, Size_Equals_mB5785092C65D4CEFD76E302B468F50AE78C10C06_AdjustorThunk },
	{ 0x0600004D, Size_GetHashCode_m7DA961F97C5B8F66002E60938979DA777058E424_AdjustorThunk },
	{ 0x0600004E, Size_ToString_m9A0FC3B49D251B96F12A244DC5C70C341FFFE2F2_AdjustorThunk },
	{ 0x06000050, SizeF_get_Width_mDADBBCD3AEEE06E60E11AD0837287C32A0CAA9E3_AdjustorThunk },
	{ 0x06000051, SizeF_get_Height_m811A09B7DE3708B22CD35BA18827637E05DC4DF2_AdjustorThunk },
	{ 0x06000052, SizeF_Equals_m8349658750C243186A64E059DE6602CDD809EDEE_AdjustorThunk },
	{ 0x06000053, SizeF_Equals_m42EA81684D6B4D93EDFC4CEB6FFA6ACE9F87F6B8_AdjustorThunk },
	{ 0x06000054, SizeF_GetHashCode_m73CD624CAC3855F1EE921AA02CAA389AEAA931CD_AdjustorThunk },
	{ 0x06000055, SizeF_ToString_m888741B5D1636CE8E9BF5AD6D542F57CA73B5835_AdjustorThunk },
};
static const int32_t s_InvokerIndices[324] = 
{
	7669,
	7123,
	7123,
	4245,
	7035,
	8029,
	8029,
	8029,
	8029,
	8029,
	7583,
	7666,
	7897,
	8029,
	7975,
	8029,
	8029,
	7348,
	7666,
	7977,
	4227,
	1001,
	4960,
	4960,
	4960,
	4960,
	4960,
	5033,
	5014,
	7308,
	6065,
	5930,
	5013,
	5033,
	6871,
	3139,
	3071,
	5013,
	5013,
	5013,
	6917,
	3139,
	3151,
	5013,
	5033,
	5074,
	5074,
	6918,
	3139,
	3152,
	5013,
	5033,
	984,
	5013,
	5013,
	5013,
	5013,
	3139,
	3162,
	6926,
	5013,
	5033,
	5074,
	5074,
	5074,
	5074,
	3139,
	3163,
	6927,
	5013,
	5033,
	6931,
	5013,
	5013,
	3139,
	3180,
	5013,
	5033,
	6932,
	5074,
	5074,
	3139,
	3181,
	5013,
	5033,
	5143,
	4229,
	2541,
	2365,
	1457,
	2570,
	1455,
	1316,
	916,
	4245,
	5143,
	7669,
	3793,
	4229,
	3831,
	4245,
	5013,
	8029,
	2563,
	1229,
	2563,
	3619,
	2563,
	3619,
	2563,
	729,
	2563,
	729,
	2563,
	726,
	2563,
	1878,
	2563,
	365,
	2563,
	1877,
	2563,
	3619,
	2563,
	727,
	2563,
	727,
	2563,
	1228,
	2563,
	1876,
	5143,
	5143,
	8029,
	4245,
	5143,
	7348,
	8029,
	8029,
	7108,
	7618,
	7895,
	7587,
	7668,
	6454,
	7585,
	7585,
	5962,
	5962,
	5959,
	7042,
	5605,
	7041,
	7585,
	5960,
	5960,
	6453,
	7040,
	2537,
	5143,
	4174,
	7618,
	7108,
	7897,
	7893,
	1507,
	1507,
	1474,
	4228,
	1057,
	4227,
	5143,
	1475,
	1475,
	2158,
	4162,
	4245,
	5143,
	1507,
	1507,
	1474,
	4228,
	1057,
	4227,
	5143,
	1475,
	1475,
	2158,
	4162,
	5143,
	2570,
	2570,
	7669,
	7113,
	7669,
	7113,
	7668,
	7618,
	3832,
	2565,
	1526,
	5013,
	5013,
	5033,
	5013,
	5015,
	5143,
	5143,
	4174,
	5033,
	5033,
	5143,
	1686,
	1686,
	1306,
	909,
	5143,
	1686,
	1686,
	1306,
	909,
	3832,
	3139,
	6429,
	7348,
	8029,
	7975,
	7975,
	7893,
	5447,
	5599,
	7044,
	5956,
	7045,
	7045,
	5945,
	7040,
	7045,
	7585,
	7040,
	7040,
	7040,
	7040,
	7040,
	7028,
	6447,
	5362,
	5301,
	7585,
	2563,
	1877,
	2563,
	1231,
	2563,
	2013,
	2563,
	1877,
	2563,
	5143,
	2563,
	5014,
	2551,
	1877,
	5033,
	1231,
	5033,
	2013,
	5033,
	1877,
	5033,
	5143,
	5033,
	5014,
	5033,
	7987,
	7988,
	5143,
	4174,
	5015,
	5143,
	5007,
	4223,
	5007,
	4223,
	4245,
	4245,
	4245,
	4245,
	4245,
	4227,
	4227,
	5033,
	4245,
	5033,
	4245,
	8001,
	7109,
	5143,
	5015,
	5013,
	5143,
	4223,
	2565,
	3139,
	5013,
	5033,
	5007,
	8001,
	8001,
	8001,
	8001,
	8001,
	8001,
	8001,
	8001,
	8001,
	8001,
	8029,
	4229,
	2541,
	4174,
	4960,
	4229,
	8029,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_System_Drawing_CodeGenModule;
const Il2CppCodeGenModule g_System_Drawing_CodeGenModule = 
{
	"System.Drawing.dll",
	324,
	s_methodPointers,
	55,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
