﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void ICSharpCode.SharpZipLib.SharpZipBaseException::.ctor()
extern void SharpZipBaseException__ctor_m917B6575F2EF2273884AB9109302E636BF2F9777 (void);
// 0x00000002 System.Void ICSharpCode.SharpZipLib.SharpZipBaseException::.ctor(System.String)
extern void SharpZipBaseException__ctor_m07FFE4C817E577AEA017E1508D178F0654E0A81C (void);
// 0x00000003 System.Void ICSharpCode.SharpZipLib.SharpZipBaseException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void SharpZipBaseException__ctor_mF6FC2972E678A47F03291205D8701EC5FAC8FFDB (void);
// 0x00000004 System.Void ICSharpCode.SharpZipLib.StreamDecodingException::.ctor()
extern void StreamDecodingException__ctor_m067E5F5909BF4CF46CD6EB7155BF822B2B8EAAC4 (void);
// 0x00000005 System.Void ICSharpCode.SharpZipLib.StreamDecodingException::.ctor(System.String)
extern void StreamDecodingException__ctor_mB8BFA0A54799FA107F40E7524163EBFFB5311B28 (void);
// 0x00000006 System.Void ICSharpCode.SharpZipLib.StreamDecodingException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void StreamDecodingException__ctor_mD14B08FA7EF5554E8261EF11072D9528605B416A (void);
// 0x00000007 System.Void ICSharpCode.SharpZipLib.ValueOutOfRangeException::.ctor(System.String)
extern void ValueOutOfRangeException__ctor_mDE4EBB0B4E793B950A9B3EE17E3374F9B48A157D (void);
// 0x00000008 System.Void ICSharpCode.SharpZipLib.ValueOutOfRangeException::.ctor()
extern void ValueOutOfRangeException__ctor_mA916171143EED41719A2216FAF1F1054DECB2FC1 (void);
// 0x00000009 System.Void ICSharpCode.SharpZipLib.ValueOutOfRangeException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void ValueOutOfRangeException__ctor_mA022332AA1B13348C0E088A043968C1D62E02DC4 (void);
// 0x0000000A System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::.ctor(System.String,System.Int32,System.Int32,ICSharpCode.SharpZipLib.Zip.CompressionMethod)
extern void ZipEntry__ctor_mA2F6D95A2A02CBE1A3ED73F5E929B1E6D7B61D90 (void);
// 0x0000000B System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::get_IsCrypted()
extern void ZipEntry_get_IsCrypted_m9964AC67529FBB8A915ECC5F341BDC3678995913 (void);
// 0x0000000C System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_IsUnicodeText(System.Boolean)
extern void ZipEntry_set_IsUnicodeText_m47AF33BDD9C3D87111DCDF1458711CA89EC3A08A (void);
// 0x0000000D System.Byte ICSharpCode.SharpZipLib.Zip.ZipEntry::get_CryptoCheckValue()
extern void ZipEntry_get_CryptoCheckValue_mF0D80B89D7CD0B4F4B823B324A7E41CC26008681 (void);
// 0x0000000E System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_CryptoCheckValue(System.Byte)
extern void ZipEntry_set_CryptoCheckValue_m8445BDA8172F0264B5083D4C0A5F7BE824B34BBC (void);
// 0x0000000F System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Flags()
extern void ZipEntry_get_Flags_m83B0E2157A93779A649CFEEA2C7D7EFED7A39E0D (void);
// 0x00000010 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_Flags(System.Int32)
extern void ZipEntry_set_Flags_mAE99C369290F5868A62DF03A5883479B438D4336 (void);
// 0x00000011 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_ZipFileIndex()
extern void ZipEntry_get_ZipFileIndex_mC890636927241CFDA994DAE34EC585FB64D41F0F (void);
// 0x00000012 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_ZipFileIndex(System.Int64)
extern void ZipEntry_set_ZipFileIndex_mC705FDA03C22A5315F631AA5D310F3A4EE03C65D (void);
// 0x00000013 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Offset()
extern void ZipEntry_get_Offset_mE1F06BA189BC7B8E1EA7D09F69C03B1C91948EF6 (void);
// 0x00000014 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_Offset(System.Int64)
extern void ZipEntry_set_Offset_mF749F40C6D6DA373442638B9D2379741297E6D2E (void);
// 0x00000015 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_ExternalFileAttributes()
extern void ZipEntry_get_ExternalFileAttributes_mC175E99B3076782BE6EE1FC036DCEEDC771BB7CF (void);
// 0x00000016 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_ExternalFileAttributes(System.Int32)
extern void ZipEntry_set_ExternalFileAttributes_m45D5FB6D099D45FA4D355BDD4EEE8F5FFBC92FF9 (void);
// 0x00000017 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::HasDosAttributes(System.Int32)
extern void ZipEntry_HasDosAttributes_mB58626CA14BE3F3C63E59186625CA3661E22806D (void);
// 0x00000018 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_HostSystem()
extern void ZipEntry_get_HostSystem_m8D5270ED6E549FC32ED406E6FC8BE22B96BA57D5 (void);
// 0x00000019 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Version()
extern void ZipEntry_get_Version_mC771D63A8C805302DFE9F00E9DA7FA588E563065 (void);
// 0x0000001A System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::get_LocalHeaderRequiresZip64()
extern void ZipEntry_get_LocalHeaderRequiresZip64_m3B8349CA21F6FB65ED02312A8B1A35E25AC810C6 (void);
// 0x0000001B System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::get_CentralHeaderRequiresZip64()
extern void ZipEntry_get_CentralHeaderRequiresZip64_mC8C9639F59DC2945246E9A32F08579930C392A0C (void);
// 0x0000001C System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_DosTime(System.Int64)
extern void ZipEntry_set_DosTime_m2576EB221481AEA4661C1247E25F3487CAC3E8FE (void);
// 0x0000001D System.DateTime ICSharpCode.SharpZipLib.Zip.ZipEntry::get_DateTime()
extern void ZipEntry_get_DateTime_mC6EB8B16673C5BA759EF40E1C85E91EE702EBE4C (void);
// 0x0000001E System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_DateTime(System.DateTime)
extern void ZipEntry_set_DateTime_m9CFCF0F34CA7B71140253D9A8E9FFC6DF02358AD (void);
// 0x0000001F System.String ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Name()
extern void ZipEntry_get_Name_m0811DAFB11AFFE348E5CB9950CDFED26BD3A20BB (void);
// 0x00000020 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Size()
extern void ZipEntry_get_Size_m4FB58DED4BFD24CFCBD1590B03D6FB21F0E5FDFE (void);
// 0x00000021 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_Size(System.Int64)
extern void ZipEntry_set_Size_mE45497AB1946B859DAF71810B643F71FBE216560 (void);
// 0x00000022 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_CompressedSize()
extern void ZipEntry_get_CompressedSize_mE1902E60A2AEF460879B61FCBDA185DF99D00F62 (void);
// 0x00000023 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_CompressedSize(System.Int64)
extern void ZipEntry_set_CompressedSize_mD3C2375E355ED94C9A12B37D36C4D83BB2131756 (void);
// 0x00000024 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_Crc()
extern void ZipEntry_get_Crc_mD04C2F0CE0AC247282F9D7828EA97B8F32E601CF (void);
// 0x00000025 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_Crc(System.Int64)
extern void ZipEntry_set_Crc_m31E729B5B4E5D12BCC3825FD47C61C1DF9B5A8F7 (void);
// 0x00000026 ICSharpCode.SharpZipLib.Zip.CompressionMethod ICSharpCode.SharpZipLib.Zip.ZipEntry::get_CompressionMethod()
extern void ZipEntry_get_CompressionMethod_m490DAFB05E4B4A0657894555B0463D3D0DF24637 (void);
// 0x00000027 ICSharpCode.SharpZipLib.Zip.CompressionMethod ICSharpCode.SharpZipLib.Zip.ZipEntry::get_CompressionMethodForHeader()
extern void ZipEntry_get_CompressionMethodForHeader_mFC3B98F62B8620D067A7DC61C0BEF5AF9A6B74EA (void);
// 0x00000028 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_ExtraData(System.Byte[])
extern void ZipEntry_set_ExtraData_m053E959119DEF3B6C840D927980C4806670F6EDC (void);
// 0x00000029 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_AESKeySize()
extern void ZipEntry_get_AESKeySize_m9D0341DF484892E0AD8857E0ED5543BCCF49BAF5 (void);
// 0x0000002A System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_AESSaltLen()
extern void ZipEntry_get_AESSaltLen_m1C953057658B4DC26418462B90015FC99DD09037 (void);
// 0x0000002B System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_AESOverheadSize()
extern void ZipEntry_get_AESOverheadSize_m049CA637104F09123EF8EE20986CD205B573E8A5 (void);
// 0x0000002C System.Int32 ICSharpCode.SharpZipLib.Zip.ZipEntry::get_EncryptionOverheadSize()
extern void ZipEntry_get_EncryptionOverheadSize_m50EE71E8870189DC852C6A1BDF1DF2E9278B6DE1 (void);
// 0x0000002D System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::ProcessExtraData(System.Boolean)
extern void ZipEntry_ProcessExtraData_mCA8FA8A4CC003FE9DAFCE80876147D38FFDB759C (void);
// 0x0000002E System.Nullable`1<System.DateTime> ICSharpCode.SharpZipLib.Zip.ZipEntry::GetDateTime(ICSharpCode.SharpZipLib.Zip.ZipExtraData)
extern void ZipEntry_GetDateTime_m7D6395AF015FAB13FFA79A39487ABA56C38FFCAC (void);
// 0x0000002F System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::ProcessAESExtraData(ICSharpCode.SharpZipLib.Zip.ZipExtraData)
extern void ZipEntry_ProcessAESExtraData_m89A4A82749B019793C5793171451BFBCB020170A (void);
// 0x00000030 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntry::set_Comment(System.String)
extern void ZipEntry_set_Comment_m61FA5A3589EB3D6202367E2D9C92DAC541DA7E91 (void);
// 0x00000031 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::get_IsDirectory()
extern void ZipEntry_get_IsDirectory_m2390C4AE501A6A748637322CD4E21CA82FB372D0 (void);
// 0x00000032 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::get_IsFile()
extern void ZipEntry_get_IsFile_mD1B82A90A43FF2953ABC0C25F7CA5B67C6A0257F (void);
// 0x00000033 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::IsCompressionMethodSupported()
extern void ZipEntry_IsCompressionMethodSupported_mC7C3E8D9661ACE5931A56DD0217CD9F6468B748B (void);
// 0x00000034 System.String ICSharpCode.SharpZipLib.Zip.ZipEntry::ToString()
extern void ZipEntry_ToString_mE1087CDB99C31B6CCAC2E5B9F5930DC709201087 (void);
// 0x00000035 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntry::IsCompressionMethodSupported(ICSharpCode.SharpZipLib.Zip.CompressionMethod)
extern void ZipEntry_IsCompressionMethodSupported_m720EBE7CBC1CA77EC591295C09F84D64B8E0DBF5 (void);
// 0x00000036 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipEntryExtensions::HasFlag(ICSharpCode.SharpZipLib.Zip.ZipEntry,ICSharpCode.SharpZipLib.Zip.GeneralBitFlags)
extern void ZipEntryExtensions_HasFlag_m9166D026BC09A048E46269F4B3C431D96440D5E0 (void);
// 0x00000037 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntryExtensions::SetFlag(ICSharpCode.SharpZipLib.Zip.ZipEntry,ICSharpCode.SharpZipLib.Zip.GeneralBitFlags,System.Boolean)
extern void ZipEntryExtensions_SetFlag_m26C477DF4D42864FE09D119DFF807CA219B6B677 (void);
// 0x00000038 System.Void ICSharpCode.SharpZipLib.Zip.ZipEntryFactory::.ctor()
extern void ZipEntryFactory__ctor_m0AA9F161DC2643A231E5F163E9A396E4BA7A88ED (void);
// 0x00000039 System.Void ICSharpCode.SharpZipLib.Zip.ZipException::.ctor()
extern void ZipException__ctor_m74F71ACDAC5A40651768B8166B7B826B0158F4A8 (void);
// 0x0000003A System.Void ICSharpCode.SharpZipLib.Zip.ZipException::.ctor(System.String)
extern void ZipException__ctor_mDEED5E97D6904FCD3B5A7183E81AFAC479DE85C4 (void);
// 0x0000003B System.Void ICSharpCode.SharpZipLib.Zip.ZipException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void ZipException__ctor_m169C2CD6C76288EC74C9163C5C491E26E517D64B (void);
// 0x0000003C System.Int16 ICSharpCode.SharpZipLib.Zip.ITaggedData::get_TagID()
// 0x0000003D System.Void ICSharpCode.SharpZipLib.Zip.ITaggedData::SetData(System.Byte[],System.Int32,System.Int32)
// 0x0000003E System.Int16 ICSharpCode.SharpZipLib.Zip.ExtendedUnixData::get_TagID()
extern void ExtendedUnixData_get_TagID_m06EEB37AB4E97F425BF39066CD66467A662D1F23 (void);
// 0x0000003F System.Void ICSharpCode.SharpZipLib.Zip.ExtendedUnixData::SetData(System.Byte[],System.Int32,System.Int32)
extern void ExtendedUnixData_SetData_mFEF652C39B2052BB32B79AA64C151BB2904CD9D5 (void);
// 0x00000040 System.DateTime ICSharpCode.SharpZipLib.Zip.ExtendedUnixData::get_ModificationTime()
extern void ExtendedUnixData_get_ModificationTime_m54CF87A8C2F6FD9074AFBB54A55B2E3931A7EAC9 (void);
// 0x00000041 ICSharpCode.SharpZipLib.Zip.ExtendedUnixData/Flags ICSharpCode.SharpZipLib.Zip.ExtendedUnixData::get_Include()
extern void ExtendedUnixData_get_Include_mAAEFD9E616A2A9719372570AB68747C0AACFFD8E (void);
// 0x00000042 System.Void ICSharpCode.SharpZipLib.Zip.ExtendedUnixData::.ctor()
extern void ExtendedUnixData__ctor_mFD9E7F7991336A44DE1CD05F5A3E3628C54B848E (void);
// 0x00000043 System.Void ICSharpCode.SharpZipLib.Zip.ZipExtraData::.ctor(System.Byte[])
extern void ZipExtraData__ctor_m433CDFAB55E846E3875BBD4ED1857B300380C96D (void);
// 0x00000044 T ICSharpCode.SharpZipLib.Zip.ZipExtraData::GetData()
// 0x00000045 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipExtraData::get_ValueLength()
extern void ZipExtraData_get_ValueLength_m1DC56A5D95FE44EDFEC437864E0F61C76CBC5B49 (void);
// 0x00000046 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipExtraData::Find(System.Int32)
extern void ZipExtraData_Find_m88F2DC1D360EC391D0C083BEEE6824876D1FEDEA (void);
// 0x00000047 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadLong()
extern void ZipExtraData_ReadLong_m329D8BDCE6313BF2171237706F89AB949E6EBE38 (void);
// 0x00000048 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadInt()
extern void ZipExtraData_ReadInt_m41E3069C6D78C38D2F2F372A7476870A537B9390 (void);
// 0x00000049 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadShort()
extern void ZipExtraData_ReadShort_mEE2709879745A1515F19D6E273E96D64DA993ABB (void);
// 0x0000004A System.Int32 ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadByte()
extern void ZipExtraData_ReadByte_m4277BC79FF120694144690EFCC1CB3A0C293512A (void);
// 0x0000004B System.Void ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadCheck(System.Int32)
extern void ZipExtraData_ReadCheck_m4B0436FFBF6BF13320E1D83F1AFB8D6486018EE4 (void);
// 0x0000004C System.Int32 ICSharpCode.SharpZipLib.Zip.ZipExtraData::ReadShortInternal()
extern void ZipExtraData_ReadShortInternal_mC62248CC8D32C8FC2273D725641281D509ED718F (void);
// 0x0000004D System.Void ICSharpCode.SharpZipLib.Zip.ZipExtraData::Dispose()
extern void ZipExtraData_Dispose_mFA53E53AEFC1C2C59893AF651905349CD44AAD5B (void);
// 0x0000004E System.Void ICSharpCode.SharpZipLib.Zip.KeysRequiredEventArgs::.ctor(System.String,System.Byte[])
extern void KeysRequiredEventArgs__ctor_m68FA1D3EEEF06A2F06389F4C808910217AD25A4D (void);
// 0x0000004F System.Byte[] ICSharpCode.SharpZipLib.Zip.KeysRequiredEventArgs::get_Key()
extern void KeysRequiredEventArgs_get_Key_m5404067B527347FCA15825061D95B81A0BA282E7 (void);
// 0x00000050 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::OnKeysRequired(System.String)
extern void ZipFile_OnKeysRequired_mF75C1B95B8C9596214DF493C003ACC8D81D4E70F (void);
// 0x00000051 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile::get_HaveKeys()
extern void ZipFile_get_HaveKeys_m7C1155BBE5BD81F05A5D5543430D3880636A1748 (void);
// 0x00000052 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::.ctor(System.IO.Stream)
extern void ZipFile__ctor_m0B360F8515C117860A5B3B4DC34A268D82CB52FB (void);
// 0x00000053 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::.ctor(System.IO.Stream,System.Boolean)
extern void ZipFile__ctor_m7FABEC3F553E98D07F6DBF475D685D4660244D24 (void);
// 0x00000054 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::Finalize()
extern void ZipFile_Finalize_m089B07DD22F51FA0312C809AB23088B320838A62 (void);
// 0x00000055 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::Close()
extern void ZipFile_Close_m7E452C938FF93B09EC7121F19A6ABC57676EC363 (void);
// 0x00000056 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile::get_IsStreamOwner()
extern void ZipFile_get_IsStreamOwner_m2C8C56370B362EBB5170093A7DAEB6EC48595243 (void);
// 0x00000057 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::set_IsStreamOwner(System.Boolean)
extern void ZipFile_set_IsStreamOwner_mE8950E204E60677DB62D1E768EE1BA27AFE9680E (void);
// 0x00000058 System.Collections.IEnumerator ICSharpCode.SharpZipLib.Zip.ZipFile::GetEnumerator()
extern void ZipFile_GetEnumerator_m76796DA0F0D45A31AAB8A32002A013F5A7B082BA (void);
// 0x00000059 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipFile::FindEntry(System.String,System.Boolean)
extern void ZipFile_FindEntry_m814ADDBB5C17239CB7DF0F0AB17F438E9411F370 (void);
// 0x0000005A System.IO.Stream ICSharpCode.SharpZipLib.Zip.ZipFile::GetInputStream(ICSharpCode.SharpZipLib.Zip.ZipEntry)
extern void ZipFile_GetInputStream_m39CEA186797C855DCD52185FC3724BC1C1BB3270 (void);
// 0x0000005B System.IO.Stream ICSharpCode.SharpZipLib.Zip.ZipFile::GetInputStream(System.Int64)
extern void ZipFile_GetInputStream_mBB238538E4B73E4C3027ABE73011DF04EEF64931 (void);
// 0x0000005C System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile::TestLocalHeader(ICSharpCode.SharpZipLib.Zip.ZipEntry,ICSharpCode.SharpZipLib.Zip.ZipFile/HeaderTest)
extern void ZipFile_TestLocalHeader_mC2E1C141CB20E48161F2B7079985D71E010D69D4 (void);
// 0x0000005D System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::PostUpdateCleanup()
extern void ZipFile_PostUpdateCleanup_m8067972C32CD89FC1EE50E32338AED9C646128E1 (void);
// 0x0000005E System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::System.IDisposable.Dispose()
extern void ZipFile_System_IDisposable_Dispose_m65A55E3CAF561749CCAD7C2E9D9E52BC88000130 (void);
// 0x0000005F System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::DisposeInternal(System.Boolean)
extern void ZipFile_DisposeInternal_mFB041F2F00415D8F6AF08B4F05C8CEF5AD5A314A (void);
// 0x00000060 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::Dispose(System.Boolean)
extern void ZipFile_Dispose_m100C7084674B17C5596E5688D431BD70A0A50F33 (void);
// 0x00000061 System.UInt16 ICSharpCode.SharpZipLib.Zip.ZipFile::ReadLEUshort()
extern void ZipFile_ReadLEUshort_m52190F6FBF9A2221C8A2BF2B2F2B378E58C4060B (void);
// 0x00000062 System.UInt32 ICSharpCode.SharpZipLib.Zip.ZipFile::ReadLEUint()
extern void ZipFile_ReadLEUint_mFDC6397FB48B7AA2A60A7E331DD930B4981BF0C9 (void);
// 0x00000063 System.UInt64 ICSharpCode.SharpZipLib.Zip.ZipFile::ReadLEUlong()
extern void ZipFile_ReadLEUlong_m46F777C7B54B6D36038FA04DA28939600DBD8FC5 (void);
// 0x00000064 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile::LocateBlockWithSignature(System.Int32,System.Int64,System.Int32,System.Int32)
extern void ZipFile_LocateBlockWithSignature_m5213FED6617508862B1A552F38AEF87AB76B62AD (void);
// 0x00000065 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::ReadEntries()
extern void ZipFile_ReadEntries_m5AD2BB57FE326135F8F4D01E30DB9C5284249BE8 (void);
// 0x00000066 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile::LocateEntry(ICSharpCode.SharpZipLib.Zip.ZipEntry)
extern void ZipFile_LocateEntry_m1D242F5B35A263B31AB89305C3895D5E4B4102C8 (void);
// 0x00000067 System.IO.Stream ICSharpCode.SharpZipLib.Zip.ZipFile::CreateAndInitDecryptionStream(System.IO.Stream,ICSharpCode.SharpZipLib.Zip.ZipEntry)
extern void ZipFile_CreateAndInitDecryptionStream_m5D7815E727BF576DF2305C588826CD634D8EDADA (void);
// 0x00000068 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile::CheckClassicPassword(System.Security.Cryptography.CryptoStream,ICSharpCode.SharpZipLib.Zip.ZipEntry)
extern void ZipFile_CheckClassicPassword_m88CDF96ADDB66FD54E9F1F4DBA28BFAB54A0BBDC (void);
// 0x00000069 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/KeysRequiredEventHandler::.ctor(System.Object,System.IntPtr)
extern void KeysRequiredEventHandler__ctor_m7352F6F589B7E1DA34A056425102BF00FB543550 (void);
// 0x0000006A System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/KeysRequiredEventHandler::Invoke(System.Object,ICSharpCode.SharpZipLib.Zip.KeysRequiredEventArgs)
extern void KeysRequiredEventHandler_Invoke_m9A0793762B23453A18C0E171366FDAB02FE25234 (void);
// 0x0000006B System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/ZipEntryEnumerator::.ctor(ICSharpCode.SharpZipLib.Zip.ZipEntry[])
extern void ZipEntryEnumerator__ctor_m202A284BDD6D12699DED3B8D36350A35EAA899DC (void);
// 0x0000006C System.Object ICSharpCode.SharpZipLib.Zip.ZipFile/ZipEntryEnumerator::get_Current()
extern void ZipEntryEnumerator_get_Current_m79E94E144ECD21114B42EE6B82EF229946B51018 (void);
// 0x0000006D System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/ZipEntryEnumerator::Reset()
extern void ZipEntryEnumerator_Reset_mB1BFF4E28B4508D64425CFFA82C1702B5489CCBA (void);
// 0x0000006E System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile/ZipEntryEnumerator::MoveNext()
extern void ZipEntryEnumerator_MoveNext_m08DD1AB587FCBB7230A4EA1035D1F51EE15A2404 (void);
// 0x0000006F System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::.ctor(ICSharpCode.SharpZipLib.Zip.ZipFile,System.Int64,System.Int64)
extern void PartialInputStream__ctor_mD3F23321589BF0E6DBEDC92CA0AABEC40B284E42 (void);
// 0x00000070 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::ReadByte()
extern void PartialInputStream_ReadByte_mF36B1C10F96CCFE395C71890EA7BF977AD7B4182 (void);
// 0x00000071 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void PartialInputStream_Read_mE96C3236A1ED9869CD525C7AB67565574DF55E3B (void);
// 0x00000072 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void PartialInputStream_Write_m80820A7531C85C121005069D189147DA8F1A1762 (void);
// 0x00000073 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::SetLength(System.Int64)
extern void PartialInputStream_SetLength_mE24FC720F72D210AB570CCD26D3DF3F17B05E343 (void);
// 0x00000074 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void PartialInputStream_Seek_mE375CFB9FC63FFE5C79596A3672C17740AF5C75B (void);
// 0x00000075 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::Flush()
extern void PartialInputStream_Flush_m3DBE7C41C1841A3C90C9A37E975F43B5FC533DC1 (void);
// 0x00000076 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_Position()
extern void PartialInputStream_get_Position_m1C5E04F4C690732A35757E14AD2D7060C6A28D1D (void);
// 0x00000077 System.Void ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::set_Position(System.Int64)
extern void PartialInputStream_set_Position_mC8F0F844583BEE892590C1D8A79799E47D013B55 (void);
// 0x00000078 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_Length()
extern void PartialInputStream_get_Length_m2D803495BCD6BF118E4ED31584D0095F6931F494 (void);
// 0x00000079 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_CanWrite()
extern void PartialInputStream_get_CanWrite_m7CECEA09CA1AD55E668624EAA5CC6069DB501405 (void);
// 0x0000007A System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_CanSeek()
extern void PartialInputStream_get_CanSeek_mF412E07CE3DE56A243CBE2779556CAC2D382A65E (void);
// 0x0000007B System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_CanRead()
extern void PartialInputStream_get_CanRead_m7C6663730023D71EE77A0C0E108B55381D8F7D8C (void);
// 0x0000007C System.Boolean ICSharpCode.SharpZipLib.Zip.ZipFile/PartialInputStream::get_CanTimeout()
extern void PartialInputStream_get_CanTimeout_m531A11069813E68745ECC9CE42CCADB6CF31B24A (void);
// 0x0000007D System.Void ICSharpCode.SharpZipLib.Zip.IArchiveStorage::Dispose()
// 0x0000007E System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::.ctor(System.IO.Stream)
extern void ZipHelperStream__ctor_m8CA188C870FF88F064601E56264A98EB1A7C4C39 (void);
// 0x0000007F System.Boolean ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_CanRead()
extern void ZipHelperStream_get_CanRead_mE7629EC63D61207096FFE09CF3194E3B6259808E (void);
// 0x00000080 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_CanSeek()
extern void ZipHelperStream_get_CanSeek_mEFDF1F4C522804F14C3DC5C0DFB7CEE006F9500C (void);
// 0x00000081 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_CanTimeout()
extern void ZipHelperStream_get_CanTimeout_mBFE574AC234D9A7B730E3A9A1130963564632142 (void);
// 0x00000082 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_Length()
extern void ZipHelperStream_get_Length_m043CBC0CA561F52CC93FD0F4AF1BAD1908AAD856 (void);
// 0x00000083 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_Position()
extern void ZipHelperStream_get_Position_m73CB30EEDAF1461B72B87B800953919B98365794 (void);
// 0x00000084 System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::set_Position(System.Int64)
extern void ZipHelperStream_set_Position_m9B0F3857607C182BC07E77E01D32FF1C6A3C7800 (void);
// 0x00000085 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipHelperStream::get_CanWrite()
extern void ZipHelperStream_get_CanWrite_m4D8678A7E208C99F60E03F54107EF3FDF61D646F (void);
// 0x00000086 System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::Flush()
extern void ZipHelperStream_Flush_m6EE06BC18B3423B7493AF1B9899812B82E322881 (void);
// 0x00000087 System.Int64 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZipHelperStream_Seek_m295C3DE6C5B51CB78F457A7AFA8B6EBBF9D4169A (void);
// 0x00000088 System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::SetLength(System.Int64)
extern void ZipHelperStream_SetLength_m946969EAE01B1C7B1B802874052D6C28891B6561 (void);
// 0x00000089 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipHelperStream_Read_m0CF1F0FFDFF179C228CD5F1393535FC035AA9405 (void);
// 0x0000008A System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipHelperStream_Write_m7307680852F6F69D3A97D3806B3051F58B94E43B (void);
// 0x0000008B System.Void ICSharpCode.SharpZipLib.Zip.ZipHelperStream::Dispose(System.Boolean)
extern void ZipHelperStream_Dispose_m8081F8249BE876CCB82F892AED0D3893230AAD56 (void);
// 0x0000008C System.Int64 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::LocateBlockWithSignature(System.Int32,System.Int64,System.Int32,System.Int32)
extern void ZipHelperStream_LocateBlockWithSignature_m8A393778E9CDC5DF70418BE848603831CED63F54 (void);
// 0x0000008D System.Int32 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::ReadLEShort()
extern void ZipHelperStream_ReadLEShort_m03B5CFB94EA3579ED4D5C210FC868C3F383B7BE1 (void);
// 0x0000008E System.Int32 ICSharpCode.SharpZipLib.Zip.ZipHelperStream::ReadLEInt()
extern void ZipHelperStream_ReadLEInt_mCAA4804CA263C9B3BC19FB694F2B45B6420D2009 (void);
// 0x0000008F System.Void ICSharpCode.SharpZipLib.Zip.ZipNameTransform::.ctor()
extern void ZipNameTransform__ctor_m4C6DEFBF7C0A4146407BF5749432415293870C3A (void);
// 0x00000090 System.Void ICSharpCode.SharpZipLib.Zip.ZipNameTransform::.cctor()
extern void ZipNameTransform__cctor_mAC21E8A03CEB9FD58D8A1070504BC9B32F59158E (void);
// 0x00000091 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipNameTransform::IsValidName(System.String,System.Boolean)
extern void ZipNameTransform_IsValidName_m6A63FFCCA5D1F96366AE6CD562C65F85F049E223 (void);
// 0x00000092 System.Void ICSharpCode.SharpZipLib.Zip.ZipStrings::.cctor()
extern void ZipStrings__cctor_m92CBAD9CCEF67132EFACEDDC8FD5E56BB75F85A0 (void);
// 0x00000093 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipStrings::get_CodePage()
extern void ZipStrings_get_CodePage_m15D3861930EF90420BA5F4FAC6AF77932B131255 (void);
// 0x00000094 System.Int32 ICSharpCode.SharpZipLib.Zip.ZipStrings::get_SystemDefaultCodePage()
extern void ZipStrings_get_SystemDefaultCodePage_m1E29CFDE8CF4F0B413CE0E402BC43131752273A3 (void);
// 0x00000095 System.Boolean ICSharpCode.SharpZipLib.Zip.ZipStrings::get_UseUnicode()
extern void ZipStrings_get_UseUnicode_m4FB549AA0B99F86BC855867DC634401991E93F60 (void);
// 0x00000096 System.String ICSharpCode.SharpZipLib.Zip.ZipStrings::ConvertToString(System.Byte[],System.Int32)
extern void ZipStrings_ConvertToString_mABB7597E416F5FDC79C8E8DB0733656143A2DD44 (void);
// 0x00000097 System.String ICSharpCode.SharpZipLib.Zip.ZipStrings::ConvertToString(System.Byte[])
extern void ZipStrings_ConvertToString_mFD1ACC0C349147013A3E8A944997FCA34609FF3F (void);
// 0x00000098 System.Text.Encoding ICSharpCode.SharpZipLib.Zip.ZipStrings::EncodingFromFlag(System.Int32)
extern void ZipStrings_EncodingFromFlag_mF652B940D52192276B6359595B6B630C8A5BAF7C (void);
// 0x00000099 System.String ICSharpCode.SharpZipLib.Zip.ZipStrings::ConvertToStringExt(System.Int32,System.Byte[],System.Int32)
extern void ZipStrings_ConvertToStringExt_mDCEDCBD4B12D714C10E102594BAA9EFB869FD71C (void);
// 0x0000009A System.String ICSharpCode.SharpZipLib.Zip.ZipStrings::ConvertToStringExt(System.Int32,System.Byte[])
extern void ZipStrings_ConvertToStringExt_m06695786666E1DBC75EC015DD5879DDFF9022420 (void);
// 0x0000009B System.Void ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman::.cctor()
extern void DeflaterHuffman__cctor_mE41964EE4849018FBB2D8B361A389D75CC16B125 (void);
// 0x0000009C System.Int16 ICSharpCode.SharpZipLib.Zip.Compression.DeflaterHuffman::BitReverse(System.Int32)
extern void DeflaterHuffman_BitReverse_m1DC3B2DA57D89D85433499A585C3D4C0281A2608 (void);
// 0x0000009D System.Void ICSharpCode.SharpZipLib.Zip.Compression.Inflater::.ctor(System.Boolean)
extern void Inflater__ctor_m5183A7AAD2E39FFDCEE42A83E207181960B95FF9 (void);
// 0x0000009E System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::DecodeHeader()
extern void Inflater_DecodeHeader_m21080A6BC7E297636F3166EA446CCE3EFB5B8E08 (void);
// 0x0000009F System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::DecodeDict()
extern void Inflater_DecodeDict_m29336A25A6DD7C50C50255BFB893E40AEF6169AC (void);
// 0x000000A0 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::DecodeHuffman()
extern void Inflater_DecodeHuffman_m368C39466E998FB156DCCA6BEE53F5A3780D84B9 (void);
// 0x000000A1 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::DecodeChksum()
extern void Inflater_DecodeChksum_mE19C73857CF2FDFB0B54D8F0FE9D7CD46CEC77A6 (void);
// 0x000000A2 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::Decode()
extern void Inflater_Decode_m798A6AD40D5B2C63ED617294FC5EAB3F53021AAC (void);
// 0x000000A3 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Inflater::SetInput(System.Byte[],System.Int32,System.Int32)
extern void Inflater_SetInput_mD03E4341BFA7288F0E8CDA67B7D2F511EE97077A (void);
// 0x000000A4 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Inflater::Inflate(System.Byte[],System.Int32,System.Int32)
extern void Inflater_Inflate_m81859B7CD192B60897C8137AF1649556B7CA8E3D (void);
// 0x000000A5 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::get_IsNeedingInput()
extern void Inflater_get_IsNeedingInput_m379F0BEB540051929C7CC519DDCC50707890B007 (void);
// 0x000000A6 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::get_IsNeedingDictionary()
extern void Inflater_get_IsNeedingDictionary_m244394D004966CD7C5FBCFB38470134B9E76E5B4 (void);
// 0x000000A7 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Inflater::get_IsFinished()
extern void Inflater_get_IsFinished_mEB6FCF59E91599BB0DF568A190DE2A9F85CDB20E (void);
// 0x000000A8 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Inflater::.cctor()
extern void Inflater__cctor_mEE94F515458A6917DF0B4C33A32EF116AC50015B (void);
// 0x000000A9 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::AttemptRead()
extern void InflaterDynHeader_AttemptRead_mFBE94A6D0E5B612227D5B2DA49A6D8E01400D335 (void);
// 0x000000AA System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::.ctor(ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator)
extern void InflaterDynHeader__ctor_m5F813A9D034BAB8C77C901B522C0F2D94907EDC9 (void);
// 0x000000AB System.Collections.Generic.IEnumerable`1<System.Boolean> ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::CreateStateMachine()
extern void InflaterDynHeader_CreateStateMachine_m8665FA3435E162F404F1F6708DF31EC87799BD72 (void);
// 0x000000AC ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::get_LiteralLengthTree()
extern void InflaterDynHeader_get_LiteralLengthTree_mF13D9D7777DDF50F3678CDA857B6DB956ADCD62D (void);
// 0x000000AD ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::get_DistanceTree()
extern void InflaterDynHeader_get_DistanceTree_mD50173D2F3516FDCA0E8D8BDDE41818ADFE7AA29 (void);
// 0x000000AE System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader::.cctor()
extern void InflaterDynHeader__cctor_m02512A11086BFE51D71F15F586FB04FDC4E08657 (void);
// 0x000000AF System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::.ctor(System.Int32)
extern void U3CCreateStateMachineU3Ed__7__ctor_m620DE8D4A051C293555A00BCBD5484BF6A4B9C26 (void);
// 0x000000B0 System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.IDisposable.Dispose()
extern void U3CCreateStateMachineU3Ed__7_System_IDisposable_Dispose_m8F09A534D2BEEA7FB03D78DD865C6CCA914FBE3D (void);
// 0x000000B1 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::MoveNext()
extern void U3CCreateStateMachineU3Ed__7_MoveNext_mD70ACC4C2760EABCD673A7D64FC20D8142B70405 (void);
// 0x000000B2 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.Collections.Generic.IEnumerator<System.Boolean>.get_Current()
extern void U3CCreateStateMachineU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_BooleanU3E_get_Current_m34012A4CB42B42ABFCF07E0B12A766A64BE461DD (void);
// 0x000000B3 System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.Collections.IEnumerator.Reset()
extern void U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerator_Reset_m1AB8C1C43F8D81E5BA2D321E26202E91E1168F2D (void);
// 0x000000B4 System.Object ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerator_get_Current_mB1A722CCA7905D6B6E5950DC5BD6B15D0617E595 (void);
// 0x000000B5 System.Collections.Generic.IEnumerator`1<System.Boolean> ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.Collections.Generic.IEnumerable<System.Boolean>.GetEnumerator()
extern void U3CCreateStateMachineU3Ed__7_System_Collections_Generic_IEnumerableU3CSystem_BooleanU3E_GetEnumerator_m6841552AB204D0CBAA57CA5B8C426C7125266FF9 (void);
// 0x000000B6 System.Collections.IEnumerator ICSharpCode.SharpZipLib.Zip.Compression.InflaterDynHeader/<CreateStateMachine>d__7::System.Collections.IEnumerable.GetEnumerator()
extern void U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerable_GetEnumerator_mEFC76710C5C0A6583026C315FA26384752D89861 (void);
// 0x000000B7 System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree::.cctor()
extern void InflaterHuffmanTree__cctor_m6B20BC361511B333F72E142880CDC28A400AC206 (void);
// 0x000000B8 System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree::.ctor(System.Collections.Generic.IList`1<System.Byte>)
extern void InflaterHuffmanTree__ctor_m5C9D1582BE8D2227268843BE55ABD7614F12C186 (void);
// 0x000000B9 System.Void ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree::BuildTree(System.Collections.Generic.IList`1<System.Byte>)
extern void InflaterHuffmanTree_BuildTree_m8747A576B9CAD13F21A8A7F906F63246232FF5EE (void);
// 0x000000BA System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.InflaterHuffmanTree::GetSymbol(ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator)
extern void InflaterHuffmanTree_GetSymbol_mCE613B5454E254F2D041AAA28FA279B075C7677C (void);
// 0x000000BB System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer::.ctor(System.IO.Stream,System.Int32)
extern void InflaterInputBuffer__ctor_m042F879BBDA06AA51FF199DBA3B9BF798A8F8929 (void);
// 0x000000BC System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer::get_Available()
extern void InflaterInputBuffer_get_Available_m5E66CD4D88490D425B7AF3636A27538003E48169 (void);
// 0x000000BD System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer::SetInflaterInput(ICSharpCode.SharpZipLib.Zip.Compression.Inflater)
extern void InflaterInputBuffer_SetInflaterInput_m303A5BED84FD7C3C23B73448E5405F497F2542C4 (void);
// 0x000000BE System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputBuffer::Fill()
extern void InflaterInputBuffer_Fill_m29B03A52B8B5F49C784486079FDE4BA5C3C77231 (void);
// 0x000000BF System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::.ctor(System.IO.Stream,ICSharpCode.SharpZipLib.Zip.Compression.Inflater)
extern void InflaterInputStream__ctor_mAEA971E711654A0AFB588ABE8512960D41F3E3D0 (void);
// 0x000000C0 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::.ctor(System.IO.Stream,ICSharpCode.SharpZipLib.Zip.Compression.Inflater,System.Int32)
extern void InflaterInputStream__ctor_mEB11817AAD6E905924DCE2C8CF758DFFA0B15C91 (void);
// 0x000000C1 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_IsStreamOwner()
extern void InflaterInputStream_get_IsStreamOwner_mF78646DE2A962B44726310E31223230C8617F0CC (void);
// 0x000000C2 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Fill()
extern void InflaterInputStream_Fill_mBC6A8C31004A86E3363600E8307A7D5FAB29CB4A (void);
// 0x000000C3 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_CanRead()
extern void InflaterInputStream_get_CanRead_mF199AA88E5BCAD1985F2391CBC4A569D5736F3F2 (void);
// 0x000000C4 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_CanSeek()
extern void InflaterInputStream_get_CanSeek_m33C42DA85C433F162680D208EB87ADBF8DA7A883 (void);
// 0x000000C5 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_CanWrite()
extern void InflaterInputStream_get_CanWrite_m62B25F45921B271811FEC5DD261A1415255C78FB (void);
// 0x000000C6 System.Int64 ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_Length()
extern void InflaterInputStream_get_Length_m176C2D20D50FA17B06066EDF062C8CD726085155 (void);
// 0x000000C7 System.Int64 ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::get_Position()
extern void InflaterInputStream_get_Position_m949DB5C05CFCBA60155D0B20727EE54E97300459 (void);
// 0x000000C8 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::set_Position(System.Int64)
extern void InflaterInputStream_set_Position_m9BD4DF58F5220794828190502FC6DF7571554C85 (void);
// 0x000000C9 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Flush()
extern void InflaterInputStream_Flush_mEED5BE2716A9AB687387812D09DC97EDD4140BEA (void);
// 0x000000CA System.Int64 ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void InflaterInputStream_Seek_m1E1AC2C1269904300E26B29B26C132AC3B5027F5 (void);
// 0x000000CB System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::SetLength(System.Int64)
extern void InflaterInputStream_SetLength_m2524C0C1608DA18ED088244F33680146C6664C40 (void);
// 0x000000CC System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void InflaterInputStream_Write_m53ADE5F0ECCBDDA93E6EC68C863D9D478ACDA432 (void);
// 0x000000CD System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::WriteByte(System.Byte)
extern void InflaterInputStream_WriteByte_mD82CC287C483418EDFF2BFEF7F46396BA29CE728 (void);
// 0x000000CE System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Dispose(System.Boolean)
extern void InflaterInputStream_Dispose_mF6E9832286177D24F636D92F5D99C1E5DA6F32D4 (void);
// 0x000000CF System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.InflaterInputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void InflaterInputStream_Read_mFEA9B693BB50AF9EB4CBE1923C79005CB411C5FA (void);
// 0x000000D0 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::Write(System.Int32)
extern void OutputWindow_Write_m98568B7A777A909CE6738BEBC2BD050FA5EF3939 (void);
// 0x000000D1 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::SlowRepeat(System.Int32,System.Int32,System.Int32)
extern void OutputWindow_SlowRepeat_mAED2CEC54827CA0EDE654F8C012CB54D6903FE7A (void);
// 0x000000D2 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::Repeat(System.Int32,System.Int32)
extern void OutputWindow_Repeat_mF71C1109E018A243A011D3D2CDFC8A4BEA6D6E66 (void);
// 0x000000D3 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::CopyStored(ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator,System.Int32)
extern void OutputWindow_CopyStored_m4DBB3A23F88263ABDF3ED6AA234E8F21ADDD6B26 (void);
// 0x000000D4 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::GetFreeSpace()
extern void OutputWindow_GetFreeSpace_m1D7A6594FA9BD7FFE6757752EC2344E8A8D42576 (void);
// 0x000000D5 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::GetAvailable()
extern void OutputWindow_GetAvailable_m106E5803870827EA5BC8DFC4926FC2F43304CB28 (void);
// 0x000000D6 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::CopyOutput(System.Byte[],System.Int32,System.Int32)
extern void OutputWindow_CopyOutput_m908635A98F7C5A3BF1BFBA96507CF8BE64121477 (void);
// 0x000000D7 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.OutputWindow::.ctor()
extern void OutputWindow__ctor_m27D9398752C21DFE507E95A1507A2061005F9487 (void);
// 0x000000D8 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::PeekBits(System.Int32)
extern void StreamManipulator_PeekBits_mF211C8B59086D72F8836E9F4F5619102F71E149A (void);
// 0x000000D9 System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::TryGetBits(System.Int32,System.Int32&,System.Int32)
extern void StreamManipulator_TryGetBits_m5C2ABD3EBACED46DB068C323914CDA30D85B8CC1 (void);
// 0x000000DA System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::TryGetBits(System.Int32,System.Byte[]&,System.Int32)
extern void StreamManipulator_TryGetBits_m6BF0BAD1FFBBCDFCBFFA7AC58D17D03A381A65E1 (void);
// 0x000000DB System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::DropBits(System.Int32)
extern void StreamManipulator_DropBits_m094CABA3AB3B1B70D2680E4FB8962EBD6B8E0E49 (void);
// 0x000000DC System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::get_AvailableBits()
extern void StreamManipulator_get_AvailableBits_m90991A9D5E1F58AD333D717C1E1F5B6AE65C1D48 (void);
// 0x000000DD System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::get_AvailableBytes()
extern void StreamManipulator_get_AvailableBytes_m3F02851B6B30C7F729CD93D4CB6917473D45FDB4 (void);
// 0x000000DE System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::SkipToByteBoundary()
extern void StreamManipulator_SkipToByteBoundary_m11A241EB548D46A99D9E55C543FBCD9A02C11D32 (void);
// 0x000000DF System.Boolean ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::get_IsNeedingInput()
extern void StreamManipulator_get_IsNeedingInput_mEA9A2390430364EA2A84A33709CC6625C04050D9 (void);
// 0x000000E0 System.Int32 ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::CopyBytes(System.Byte[],System.Int32,System.Int32)
extern void StreamManipulator_CopyBytes_m326B46651BD903626068679C41A1ADF495A757D6 (void);
// 0x000000E1 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::SetInput(System.Byte[],System.Int32,System.Int32)
extern void StreamManipulator_SetInput_mFD2FB5325969D00CE3C052CC8D57D5B6DCF351A7 (void);
// 0x000000E2 System.Void ICSharpCode.SharpZipLib.Zip.Compression.Streams.StreamManipulator::.ctor()
extern void StreamManipulator__ctor_mABF375127B2C20DC969C50EC909C3FB0C01DF6B9 (void);
// 0x000000E3 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassic::.ctor()
extern void PkzipClassic__ctor_m9725AEEB72479F55DFDB5AB212437BE7E938A1E5 (void);
// 0x000000E4 System.Byte ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase::TransformByte()
extern void PkzipClassicCryptoBase_TransformByte_m562E81B3284793B00040A9B1DE61B5D96DF443E1 (void);
// 0x000000E5 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase::SetKeys(System.Byte[])
extern void PkzipClassicCryptoBase_SetKeys_m0444E777B325A95CB7E8922D431D84E413B91469 (void);
// 0x000000E6 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase::UpdateKeys(System.Byte)
extern void PkzipClassicCryptoBase_UpdateKeys_mBBDD4941427951A62A21C2CDD8FDE31A5F1A0441 (void);
// 0x000000E7 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase::Reset()
extern void PkzipClassicCryptoBase_Reset_m4AAF69726582F9C9EA9F8109D32B13CA661C703B (void);
// 0x000000E8 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicCryptoBase::.ctor()
extern void PkzipClassicCryptoBase__ctor_m013F4376CF64AA2B5D5DE9BB20A19A6AA2842D86 (void);
// 0x000000E9 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::.ctor(System.Byte[])
extern void PkzipClassicEncryptCryptoTransform__ctor_mF6FEC4C002E888A7742B7476D0370407CE8F85E3 (void);
// 0x000000EA System.Byte[] ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::TransformFinalBlock(System.Byte[],System.Int32,System.Int32)
extern void PkzipClassicEncryptCryptoTransform_TransformFinalBlock_m78CDB5E4992629BAD696B6335D0E077B205D839B (void);
// 0x000000EB System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::TransformBlock(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void PkzipClassicEncryptCryptoTransform_TransformBlock_mF6ED7F17496AAC2E4E709EB95FA246055A962A4B (void);
// 0x000000EC System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::get_InputBlockSize()
extern void PkzipClassicEncryptCryptoTransform_get_InputBlockSize_mC9DAB908DC4A334418A34914C8E7D01B233ED184 (void);
// 0x000000ED System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::get_OutputBlockSize()
extern void PkzipClassicEncryptCryptoTransform_get_OutputBlockSize_m5AB9717309C40D8B119371E21F66D179BECCCB29 (void);
// 0x000000EE System.Boolean ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::get_CanTransformMultipleBlocks()
extern void PkzipClassicEncryptCryptoTransform_get_CanTransformMultipleBlocks_m2E8C4BF7A6C7509D0CDB129C99FDB5ABC58BA219 (void);
// 0x000000EF System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicEncryptCryptoTransform::Dispose()
extern void PkzipClassicEncryptCryptoTransform_Dispose_m9D379C9BBA4689CDDF82A1516C0E9A89D7126524 (void);
// 0x000000F0 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::.ctor(System.Byte[])
extern void PkzipClassicDecryptCryptoTransform__ctor_m71FE21D85A22418C575FA90E0BAC63B2F0B4E931 (void);
// 0x000000F1 System.Byte[] ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::TransformFinalBlock(System.Byte[],System.Int32,System.Int32)
extern void PkzipClassicDecryptCryptoTransform_TransformFinalBlock_m8E7C6D63545A316F41372EC5212F0C5EE5320F65 (void);
// 0x000000F2 System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::TransformBlock(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void PkzipClassicDecryptCryptoTransform_TransformBlock_m4F754CB891277C9DA593C40BBCCB13BE9DDB0E1C (void);
// 0x000000F3 System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::get_InputBlockSize()
extern void PkzipClassicDecryptCryptoTransform_get_InputBlockSize_mE6D4842AC8ABE61D209A999A4421F0C3E43BB726 (void);
// 0x000000F4 System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::get_OutputBlockSize()
extern void PkzipClassicDecryptCryptoTransform_get_OutputBlockSize_m8FA4498E4181D3BF050FDF281CF61E1B5F406B5F (void);
// 0x000000F5 System.Boolean ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::get_CanTransformMultipleBlocks()
extern void PkzipClassicDecryptCryptoTransform_get_CanTransformMultipleBlocks_mBB377F96020A7E02990B7A88CA245516C017C722 (void);
// 0x000000F6 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicDecryptCryptoTransform::Dispose()
extern void PkzipClassicDecryptCryptoTransform_Dispose_mD8DB144E991017437DAFE09F8C6992B6500352BA (void);
// 0x000000F7 System.Int32 ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::get_BlockSize()
extern void PkzipClassicManaged_get_BlockSize_m2844CE869EFCC7F73A2C668AE30DAD618A299F67 (void);
// 0x000000F8 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::set_BlockSize(System.Int32)
extern void PkzipClassicManaged_set_BlockSize_m49688514B12E14C0D7E5D0789D735D31DA14D040 (void);
// 0x000000F9 System.Security.Cryptography.KeySizes[] ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::get_LegalKeySizes()
extern void PkzipClassicManaged_get_LegalKeySizes_m9E37F8F53F055769D0DFBF0389A5BD8C868815A4 (void);
// 0x000000FA System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::GenerateIV()
extern void PkzipClassicManaged_GenerateIV_m68E82697BF5AAA6F0E3D2788515F171FE489970D (void);
// 0x000000FB System.Byte[] ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::get_Key()
extern void PkzipClassicManaged_get_Key_m578035169EF71DC6AF23C0EB935D98D1285E8FD9 (void);
// 0x000000FC System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::set_Key(System.Byte[])
extern void PkzipClassicManaged_set_Key_m51DEB0FE186DC44DA5F64C57C157F614E49A5CE4 (void);
// 0x000000FD System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::GenerateKey()
extern void PkzipClassicManaged_GenerateKey_m3346E68C2652740113A979D2EE7CAC132E952BDF (void);
// 0x000000FE System.Security.Cryptography.ICryptoTransform ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::CreateEncryptor(System.Byte[],System.Byte[])
extern void PkzipClassicManaged_CreateEncryptor_m9F436CE33B3438787BFE4503376CBA298C33B6E5 (void);
// 0x000000FF System.Security.Cryptography.ICryptoTransform ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::CreateDecryptor(System.Byte[],System.Byte[])
extern void PkzipClassicManaged_CreateDecryptor_mF6D61B13DC8DF5A308BFDF28216E65105D2A4940 (void);
// 0x00000100 System.Void ICSharpCode.SharpZipLib.Encryption.PkzipClassicManaged::.ctor()
extern void PkzipClassicManaged__ctor_m4A04A8B6C4B44BD96DB38D12624D14F9C9819593 (void);
// 0x00000101 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESStream::.ctor(System.IO.Stream,ICSharpCode.SharpZipLib.Encryption.ZipAESTransform,System.Security.Cryptography.CryptoStreamMode)
extern void ZipAESStream__ctor_mBE431878A503B03F92D14E1DD44248516628D483 (void);
// 0x00000102 System.Boolean ICSharpCode.SharpZipLib.Encryption.ZipAESStream::get_HasBufferedData()
extern void ZipAESStream_get_HasBufferedData_mEFAA3542F9B6A9DD396EFD7C24E494E7A7E658E6 (void);
// 0x00000103 System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipAESStream_Read_m39852704A0F6EA98DBD68B9DA5E6AE7395614129 (void);
// 0x00000104 System.Threading.Tasks.Task`1<System.Int32> ICSharpCode.SharpZipLib.Encryption.ZipAESStream::ReadAsync(System.Byte[],System.Int32,System.Int32,System.Threading.CancellationToken)
extern void ZipAESStream_ReadAsync_mC1421BB0229E8300598E25E9E5EE7DB37BF34569 (void);
// 0x00000105 System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESStream::ReadAndTransform(System.Byte[],System.Int32,System.Int32)
extern void ZipAESStream_ReadAndTransform_mBB994079CAFA0957CA1EEF16B7D4ABE6567EDD93 (void);
// 0x00000106 System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESStream::ReadBufferedData(System.Byte[],System.Int32,System.Int32)
extern void ZipAESStream_ReadBufferedData_mA2E55A04EC90833054995728FF1D7E53D45F4FCA (void);
// 0x00000107 System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESStream::TransformAndBufferBlock(System.Byte[],System.Int32,System.Int32,System.Int32)
extern void ZipAESStream_TransformAndBufferBlock_m096433E20FEE76C760F58390E290A1FCBF6AFB92 (void);
// 0x00000108 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipAESStream_Write_mCC1EA1542CEFC06FBC64C09A072D89D1DE644FBC (void);
// 0x00000109 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::.ctor(System.String,System.Byte[],System.Int32,System.Boolean)
extern void ZipAESTransform__ctor_m159186BF570F35F6E144B4AA90E162FC2FDF7BE9 (void);
// 0x0000010A System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::TransformBlock(System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32)
extern void ZipAESTransform_TransformBlock_m36C6662BD0F182056F2D71AB0B3FB6E9F70FB31D (void);
// 0x0000010B System.Byte[] ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::get_PwdVerifier()
extern void ZipAESTransform_get_PwdVerifier_m2393389FFB045BFA21D9B61ACAC24D33B5F1DA7F (void);
// 0x0000010C System.Byte[] ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::GetAuthCode()
extern void ZipAESTransform_GetAuthCode_m30147C4C3EB8C4777CE236DEC81012EB3AA959A4 (void);
// 0x0000010D System.Byte[] ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::TransformFinalBlock(System.Byte[],System.Int32,System.Int32)
extern void ZipAESTransform_TransformFinalBlock_m3DE69A3BAA81D1D9EE5BF2D1F8439B9C0C6AE16C (void);
// 0x0000010E System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::get_InputBlockSize()
extern void ZipAESTransform_get_InputBlockSize_m9A8406CBACC812E83421309C67EE73569C849D13 (void);
// 0x0000010F System.Int32 ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::get_OutputBlockSize()
extern void ZipAESTransform_get_OutputBlockSize_m38533860E91CC2404B000E5916806D0B0CFF4F26 (void);
// 0x00000110 System.Boolean ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::get_CanTransformMultipleBlocks()
extern void ZipAESTransform_get_CanTransformMultipleBlocks_m737240ABDEA6735087A7298A8496705CF4C83628 (void);
// 0x00000111 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESTransform::Dispose()
extern void ZipAESTransform_Dispose_mE2E4C43496564375DC2137699A482667AD0527B4 (void);
// 0x00000112 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESTransform/IncrementalHash::.ctor(System.Byte[])
extern void IncrementalHash__ctor_m003F4679A8353E2349F9BE72A6E16C283DD2204B (void);
// 0x00000113 ICSharpCode.SharpZipLib.Encryption.ZipAESTransform/IncrementalHash ICSharpCode.SharpZipLib.Encryption.ZipAESTransform/IncrementalHash::CreateHMAC(System.String,System.Byte[])
extern void IncrementalHash_CreateHMAC_m6AB0E73046CF53361E9A37494BB6FAAEFC592952 (void);
// 0x00000114 System.Void ICSharpCode.SharpZipLib.Encryption.ZipAESTransform/IncrementalHash::AppendData(System.Byte[],System.Int32,System.Int32)
extern void IncrementalHash_AppendData_mEA0F42AF0C7B6F1D0BC969F4C03FAC0EF3AFEFC3 (void);
// 0x00000115 System.Byte[] ICSharpCode.SharpZipLib.Encryption.ZipAESTransform/IncrementalHash::GetHashAndReset()
extern void IncrementalHash_GetHashAndReset_mBFC9BE40AE371BC6B56E84C8D2C09B09963F4D47 (void);
// 0x00000116 T[] ICSharpCode.SharpZipLib.Core.Empty::Array()
// 0x00000117 System.Void ICSharpCode.SharpZipLib.Core.Empty/EmptyArray`1::.cctor()
// 0x00000118 System.Void ICSharpCode.SharpZipLib.Core.StreamUtils::ReadFully(System.IO.Stream,System.Byte[])
extern void StreamUtils_ReadFully_mF6B59768A0970CC76B5008B448FDEB5A1D05D212 (void);
// 0x00000119 System.Void ICSharpCode.SharpZipLib.Core.StreamUtils::ReadFully(System.IO.Stream,System.Byte[],System.Int32,System.Int32)
extern void StreamUtils_ReadFully_m199F7FEA7225E4EB325F8B5EDB61253B5B132C9F (void);
// 0x0000011A System.Int32 ICSharpCode.SharpZipLib.Core.StreamUtils::ReadRequestedBytes(System.IO.Stream,System.Byte[],System.Int32,System.Int32)
extern void StreamUtils_ReadRequestedBytes_mAF78D6227FFD4186DDA382A862BD4BEBE70344DC (void);
// 0x0000011B System.Void ICSharpCode.SharpZipLib.Core.StreamUtils::Copy(System.IO.Stream,System.IO.Stream,System.Byte[])
extern void StreamUtils_Copy_mA675A1AD49A23709CB18CC9A25B5C76C85AE45DE (void);
// 0x0000011C System.Void ICSharpCode.SharpZipLib.Checksum.Adler32::.ctor()
extern void Adler32__ctor_mB60FEE1C35C49DBD391DE8F67BAAAA7DFA5C5F37 (void);
// 0x0000011D System.Void ICSharpCode.SharpZipLib.Checksum.Adler32::Reset()
extern void Adler32_Reset_mF1FC2116EC33946831C0658FFA208CB33E8984D5 (void);
// 0x0000011E System.Int64 ICSharpCode.SharpZipLib.Checksum.Adler32::get_Value()
extern void Adler32_get_Value_mFA327307664CBD7FFA6BF7A903FDB6D8F76E59D2 (void);
// 0x0000011F System.Void ICSharpCode.SharpZipLib.Checksum.Adler32::Update(System.Int32)
extern void Adler32_Update_m705E9898BE9687D03682E5663A34E04B0BC68285 (void);
// 0x00000120 System.Void ICSharpCode.SharpZipLib.Checksum.Adler32::Update(System.ArraySegment`1<System.Byte>)
extern void Adler32_Update_m35F6DD4EB74B942CEA83976C6B2047622C812A56 (void);
// 0x00000121 System.Void ICSharpCode.SharpZipLib.Checksum.Adler32::.cctor()
extern void Adler32__cctor_m93FC2DC1974CC6D434198A2144B0C3D919C32D04 (void);
// 0x00000122 System.Void ICSharpCode.SharpZipLib.Checksum.BZip2Crc::.ctor()
extern void BZip2Crc__ctor_m44988A7ABB1C4BE9641ACB2A5DD3C80E3A964030 (void);
// 0x00000123 System.Void ICSharpCode.SharpZipLib.Checksum.BZip2Crc::Reset()
extern void BZip2Crc_Reset_m87F6B17ACA701341C626E80DE772BA9BE55072B5 (void);
// 0x00000124 System.Int64 ICSharpCode.SharpZipLib.Checksum.BZip2Crc::get_Value()
extern void BZip2Crc_get_Value_m6B8F672C0C299C475E3DA047EFBE8FA8403B4885 (void);
// 0x00000125 System.Void ICSharpCode.SharpZipLib.Checksum.BZip2Crc::Update(System.Int32)
extern void BZip2Crc_Update_m4F502295AE57FF154C672C06889B58FD0182A94A (void);
// 0x00000126 System.Void ICSharpCode.SharpZipLib.Checksum.BZip2Crc::.cctor()
extern void BZip2Crc__cctor_mF1009734FF7DEC652AB076D7AB6E46CDD197462D (void);
// 0x00000127 System.UInt32 ICSharpCode.SharpZipLib.Checksum.Crc32::ComputeCrc32(System.UInt32,System.Byte)
extern void Crc32_ComputeCrc32_m36E74AEF7EDB3709D328DE5DB1AC688F95940440 (void);
// 0x00000128 System.Void ICSharpCode.SharpZipLib.Checksum.Crc32::.cctor()
extern void Crc32__cctor_m12717CFF41D0DC6FF78B05A9D56C853057631EE8 (void);
// 0x00000129 System.UInt32[] ICSharpCode.SharpZipLib.Checksum.CrcUtilities::GenerateSlicingLookupTable(System.UInt32,System.Boolean)
extern void CrcUtilities_GenerateSlicingLookupTable_m0CE4789B52FA496BBD62C43B72D9BA9CCEB34C00 (void);
// 0x0000012A System.Void ICSharpCode.SharpZipLib.Checksum.IChecksum::Reset()
// 0x0000012B System.Int64 ICSharpCode.SharpZipLib.Checksum.IChecksum::get_Value()
// 0x0000012C System.Void ICSharpCode.SharpZipLib.Checksum.IChecksum::Update(System.Int32)
// 0x0000012D System.Void ICSharpCode.SharpZipLib.BZip2.BZip2Constants::.cctor()
extern void BZip2Constants__cctor_mA75F3BC0C9FA741D73B4EEC475AE30BBE374FCF2 (void);
// 0x0000012E System.Void ICSharpCode.SharpZipLib.BZip2.BZip2Exception::.ctor()
extern void BZip2Exception__ctor_m0090C4098824A1E60315DB97BDAE5F7C9112BB5F (void);
// 0x0000012F System.Void ICSharpCode.SharpZipLib.BZip2.BZip2Exception::.ctor(System.String)
extern void BZip2Exception__ctor_m8D0263A2BD0CCC9CB6D2886ABBE2539671EE4F1C (void);
// 0x00000130 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2Exception::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void BZip2Exception__ctor_mAAA63BA512BBAED21D0F4094DDA88F8280B934A3 (void);
// 0x00000131 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::.ctor(System.IO.Stream)
extern void BZip2InputStream__ctor_m6C9F56BFE47945DB0B943D840AE4AA01DACE4E62 (void);
// 0x00000132 System.Boolean ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_IsStreamOwner()
extern void BZip2InputStream_get_IsStreamOwner_m41E5817E414E2FDDB0153B6F3AEC091B7242A0BA (void);
// 0x00000133 System.Boolean ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_CanRead()
extern void BZip2InputStream_get_CanRead_mC71680334D1938D45301B259CA7E588483CEAD70 (void);
// 0x00000134 System.Boolean ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_CanSeek()
extern void BZip2InputStream_get_CanSeek_mFCABA926A11F94A5E024CA3EAEC5D07BD7C8B4BD (void);
// 0x00000135 System.Boolean ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_CanWrite()
extern void BZip2InputStream_get_CanWrite_m8909CABE27E39FED0157DCCC228BC41A9EC42CC0 (void);
// 0x00000136 System.Int64 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_Length()
extern void BZip2InputStream_get_Length_mC3857DC2D4282B9D95E013CCA0E3EBD4501CDF17 (void);
// 0x00000137 System.Int64 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::get_Position()
extern void BZip2InputStream_get_Position_m8BC28258E50DD14E58AF4EA3E7A41908B621F5FB (void);
// 0x00000138 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::set_Position(System.Int64)
extern void BZip2InputStream_set_Position_m975849119963BADC4183A3C36133B71EDE7DEC67 (void);
// 0x00000139 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Flush()
extern void BZip2InputStream_Flush_m517332FC2D7406124E0682B071A67F919FE716F4 (void);
// 0x0000013A System.Int64 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void BZip2InputStream_Seek_mA22AD11F85D0056A2E138E17B20C37D6B3300044 (void);
// 0x0000013B System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetLength(System.Int64)
extern void BZip2InputStream_SetLength_m96E6B9141C7F2EAB2267ACFF4282CFCFC2974A3F (void);
// 0x0000013C System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void BZip2InputStream_Write_m9626911E5C2E721FC4AD501A8E59CDAC271C6DAC (void);
// 0x0000013D System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::WriteByte(System.Byte)
extern void BZip2InputStream_WriteByte_mD0625FA4615D5B50D2F1482F6197441676AE8312 (void);
// 0x0000013E System.Int32 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void BZip2InputStream_Read_mD2420F9C7066D844712E272C5084BA84457AACCB (void);
// 0x0000013F System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Dispose(System.Boolean)
extern void BZip2InputStream_Dispose_m5458CBF478321D6F775CADACE45D35C509A216FC (void);
// 0x00000140 System.Int32 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::ReadByte()
extern void BZip2InputStream_ReadByte_m798D4995D0F5F1AAF60B1A202DF1A8E5F2D214C1 (void);
// 0x00000141 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::MakeMaps()
extern void BZip2InputStream_MakeMaps_mC38259B3DCBDF7DBD8433CAF6715D6EFFBAE733A (void);
// 0x00000142 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Initialize()
extern void BZip2InputStream_Initialize_mAAF7F4BBF0284BF55CFC5E6ED87F734318B794B9 (void);
// 0x00000143 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::InitBlock()
extern void BZip2InputStream_InitBlock_m93DD86F9271DBEA5811A33CE8D386E812176780D (void);
// 0x00000144 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::EndBlock()
extern void BZip2InputStream_EndBlock_m9857538948902F7DCE49A785F03A7D491A567AC6 (void);
// 0x00000145 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::Complete()
extern void BZip2InputStream_Complete_m5BECD99C71E964108C3F2765F27BD37710F7F5E3 (void);
// 0x00000146 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::FillBuffer()
extern void BZip2InputStream_FillBuffer_mD7CB990F9178525D296153D04BD375E9E72FD83A (void);
// 0x00000147 System.Int32 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BsR(System.Int32)
extern void BZip2InputStream_BsR_m87FC44F178D98623119D75BDBA011BEF72BB1613 (void);
// 0x00000148 System.Char ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BsGetUChar()
extern void BZip2InputStream_BsGetUChar_m2111337E4BE1CE4C11D5840121B92DBFA6377CB7 (void);
// 0x00000149 System.Int32 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BsGetIntVS(System.Int32)
extern void BZip2InputStream_BsGetIntVS_m7C0246D84E52E09EE51B2A1ED96671BCB885B405 (void);
// 0x0000014A System.Int32 ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BsGetInt32()
extern void BZip2InputStream_BsGetInt32_mA476E857090B44576F9629C2265B0390CC8C95BA (void);
// 0x0000014B System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::RecvDecodingTables()
extern void BZip2InputStream_RecvDecodingTables_m7DF3E08211C27893B36E83BC49A3045DCF864DB1 (void);
// 0x0000014C System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::GetAndMoveToFrontDecode()
extern void BZip2InputStream_GetAndMoveToFrontDecode_m3D99019D7E95B8396077B35582E99F86092EF526 (void);
// 0x0000014D System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupBlock()
extern void BZip2InputStream_SetupBlock_m899C33F44F1838D4BFDE4C069AE652BA1EDF36E5 (void);
// 0x0000014E System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupRandPartA()
extern void BZip2InputStream_SetupRandPartA_mB668B399E66AA4E0EED64DCF6307A082EAF61D8C (void);
// 0x0000014F System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupNoRandPartA()
extern void BZip2InputStream_SetupNoRandPartA_mC524B2897F62558926C7D06C0B66153ABACAAE20 (void);
// 0x00000150 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupRandPartB()
extern void BZip2InputStream_SetupRandPartB_m5535A0A3843EE09F4B8BC02B25A2C784F90A702D (void);
// 0x00000151 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupRandPartC()
extern void BZip2InputStream_SetupRandPartC_m6A32047DE375216D8C6B48E14DD852F3C33C1052 (void);
// 0x00000152 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupNoRandPartB()
extern void BZip2InputStream_SetupNoRandPartB_m316C6311888936B36E70C7E57870F804E1F90A49 (void);
// 0x00000153 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetupNoRandPartC()
extern void BZip2InputStream_SetupNoRandPartC_mD0FDD6E542ACD8D986F0EE98FB4C465ED8ED14FD (void);
// 0x00000154 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::SetDecompressStructureSizes(System.Int32)
extern void BZip2InputStream_SetDecompressStructureSizes_m527B6A7D7A0905BC26CFD176F11B44D32C1A417F (void);
// 0x00000155 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::CompressedStreamEOF()
extern void BZip2InputStream_CompressedStreamEOF_m3A9F39AFD660A341B4B96FF5DB0CAB7A8892009A (void);
// 0x00000156 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BlockOverrun()
extern void BZip2InputStream_BlockOverrun_m90E13E18817131DD8A9EDD4D1457B30343C6E27F (void);
// 0x00000157 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::BadBlockHeader()
extern void BZip2InputStream_BadBlockHeader_m3E3D3D8F1F6F893EC4F3FC013B12385B03A844C5 (void);
// 0x00000158 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::CrcError()
extern void BZip2InputStream_CrcError_m4DB7B3D663A9FF6C888D37AB9F0C8B430DABDFB1 (void);
// 0x00000159 System.Void ICSharpCode.SharpZipLib.BZip2.BZip2InputStream::HbCreateDecodeTables(System.Int32[],System.Int32[],System.Int32[],System.Char[],System.Int32,System.Int32,System.Int32)
extern void BZip2InputStream_HbCreateDecodeTables_m2FC2A29567A1EF7C38981C38DCF98A6027197DED (void);
static Il2CppMethodPointer s_methodPointers[345] = 
{
	SharpZipBaseException__ctor_m917B6575F2EF2273884AB9109302E636BF2F9777,
	SharpZipBaseException__ctor_m07FFE4C817E577AEA017E1508D178F0654E0A81C,
	SharpZipBaseException__ctor_mF6FC2972E678A47F03291205D8701EC5FAC8FFDB,
	StreamDecodingException__ctor_m067E5F5909BF4CF46CD6EB7155BF822B2B8EAAC4,
	StreamDecodingException__ctor_mB8BFA0A54799FA107F40E7524163EBFFB5311B28,
	StreamDecodingException__ctor_mD14B08FA7EF5554E8261EF11072D9528605B416A,
	ValueOutOfRangeException__ctor_mDE4EBB0B4E793B950A9B3EE17E3374F9B48A157D,
	ValueOutOfRangeException__ctor_mA916171143EED41719A2216FAF1F1054DECB2FC1,
	ValueOutOfRangeException__ctor_mA022332AA1B13348C0E088A043968C1D62E02DC4,
	ZipEntry__ctor_mA2F6D95A2A02CBE1A3ED73F5E929B1E6D7B61D90,
	ZipEntry_get_IsCrypted_m9964AC67529FBB8A915ECC5F341BDC3678995913,
	ZipEntry_set_IsUnicodeText_m47AF33BDD9C3D87111DCDF1458711CA89EC3A08A,
	ZipEntry_get_CryptoCheckValue_mF0D80B89D7CD0B4F4B823B324A7E41CC26008681,
	ZipEntry_set_CryptoCheckValue_m8445BDA8172F0264B5083D4C0A5F7BE824B34BBC,
	ZipEntry_get_Flags_m83B0E2157A93779A649CFEEA2C7D7EFED7A39E0D,
	ZipEntry_set_Flags_mAE99C369290F5868A62DF03A5883479B438D4336,
	ZipEntry_get_ZipFileIndex_mC890636927241CFDA994DAE34EC585FB64D41F0F,
	ZipEntry_set_ZipFileIndex_mC705FDA03C22A5315F631AA5D310F3A4EE03C65D,
	ZipEntry_get_Offset_mE1F06BA189BC7B8E1EA7D09F69C03B1C91948EF6,
	ZipEntry_set_Offset_mF749F40C6D6DA373442638B9D2379741297E6D2E,
	ZipEntry_get_ExternalFileAttributes_mC175E99B3076782BE6EE1FC036DCEEDC771BB7CF,
	ZipEntry_set_ExternalFileAttributes_m45D5FB6D099D45FA4D355BDD4EEE8F5FFBC92FF9,
	ZipEntry_HasDosAttributes_mB58626CA14BE3F3C63E59186625CA3661E22806D,
	ZipEntry_get_HostSystem_m8D5270ED6E549FC32ED406E6FC8BE22B96BA57D5,
	ZipEntry_get_Version_mC771D63A8C805302DFE9F00E9DA7FA588E563065,
	ZipEntry_get_LocalHeaderRequiresZip64_m3B8349CA21F6FB65ED02312A8B1A35E25AC810C6,
	ZipEntry_get_CentralHeaderRequiresZip64_mC8C9639F59DC2945246E9A32F08579930C392A0C,
	ZipEntry_set_DosTime_m2576EB221481AEA4661C1247E25F3487CAC3E8FE,
	ZipEntry_get_DateTime_mC6EB8B16673C5BA759EF40E1C85E91EE702EBE4C,
	ZipEntry_set_DateTime_m9CFCF0F34CA7B71140253D9A8E9FFC6DF02358AD,
	ZipEntry_get_Name_m0811DAFB11AFFE348E5CB9950CDFED26BD3A20BB,
	ZipEntry_get_Size_m4FB58DED4BFD24CFCBD1590B03D6FB21F0E5FDFE,
	ZipEntry_set_Size_mE45497AB1946B859DAF71810B643F71FBE216560,
	ZipEntry_get_CompressedSize_mE1902E60A2AEF460879B61FCBDA185DF99D00F62,
	ZipEntry_set_CompressedSize_mD3C2375E355ED94C9A12B37D36C4D83BB2131756,
	ZipEntry_get_Crc_mD04C2F0CE0AC247282F9D7828EA97B8F32E601CF,
	ZipEntry_set_Crc_m31E729B5B4E5D12BCC3825FD47C61C1DF9B5A8F7,
	ZipEntry_get_CompressionMethod_m490DAFB05E4B4A0657894555B0463D3D0DF24637,
	ZipEntry_get_CompressionMethodForHeader_mFC3B98F62B8620D067A7DC61C0BEF5AF9A6B74EA,
	ZipEntry_set_ExtraData_m053E959119DEF3B6C840D927980C4806670F6EDC,
	ZipEntry_get_AESKeySize_m9D0341DF484892E0AD8857E0ED5543BCCF49BAF5,
	ZipEntry_get_AESSaltLen_m1C953057658B4DC26418462B90015FC99DD09037,
	ZipEntry_get_AESOverheadSize_m049CA637104F09123EF8EE20986CD205B573E8A5,
	ZipEntry_get_EncryptionOverheadSize_m50EE71E8870189DC852C6A1BDF1DF2E9278B6DE1,
	ZipEntry_ProcessExtraData_mCA8FA8A4CC003FE9DAFCE80876147D38FFDB759C,
	ZipEntry_GetDateTime_m7D6395AF015FAB13FFA79A39487ABA56C38FFCAC,
	ZipEntry_ProcessAESExtraData_m89A4A82749B019793C5793171451BFBCB020170A,
	ZipEntry_set_Comment_m61FA5A3589EB3D6202367E2D9C92DAC541DA7E91,
	ZipEntry_get_IsDirectory_m2390C4AE501A6A748637322CD4E21CA82FB372D0,
	ZipEntry_get_IsFile_mD1B82A90A43FF2953ABC0C25F7CA5B67C6A0257F,
	ZipEntry_IsCompressionMethodSupported_mC7C3E8D9661ACE5931A56DD0217CD9F6468B748B,
	ZipEntry_ToString_mE1087CDB99C31B6CCAC2E5B9F5930DC709201087,
	ZipEntry_IsCompressionMethodSupported_m720EBE7CBC1CA77EC591295C09F84D64B8E0DBF5,
	ZipEntryExtensions_HasFlag_m9166D026BC09A048E46269F4B3C431D96440D5E0,
	ZipEntryExtensions_SetFlag_m26C477DF4D42864FE09D119DFF807CA219B6B677,
	ZipEntryFactory__ctor_m0AA9F161DC2643A231E5F163E9A396E4BA7A88ED,
	ZipException__ctor_m74F71ACDAC5A40651768B8166B7B826B0158F4A8,
	ZipException__ctor_mDEED5E97D6904FCD3B5A7183E81AFAC479DE85C4,
	ZipException__ctor_m169C2CD6C76288EC74C9163C5C491E26E517D64B,
	NULL,
	NULL,
	ExtendedUnixData_get_TagID_m06EEB37AB4E97F425BF39066CD66467A662D1F23,
	ExtendedUnixData_SetData_mFEF652C39B2052BB32B79AA64C151BB2904CD9D5,
	ExtendedUnixData_get_ModificationTime_m54CF87A8C2F6FD9074AFBB54A55B2E3931A7EAC9,
	ExtendedUnixData_get_Include_mAAEFD9E616A2A9719372570AB68747C0AACFFD8E,
	ExtendedUnixData__ctor_mFD9E7F7991336A44DE1CD05F5A3E3628C54B848E,
	ZipExtraData__ctor_m433CDFAB55E846E3875BBD4ED1857B300380C96D,
	NULL,
	ZipExtraData_get_ValueLength_m1DC56A5D95FE44EDFEC437864E0F61C76CBC5B49,
	ZipExtraData_Find_m88F2DC1D360EC391D0C083BEEE6824876D1FEDEA,
	ZipExtraData_ReadLong_m329D8BDCE6313BF2171237706F89AB949E6EBE38,
	ZipExtraData_ReadInt_m41E3069C6D78C38D2F2F372A7476870A537B9390,
	ZipExtraData_ReadShort_mEE2709879745A1515F19D6E273E96D64DA993ABB,
	ZipExtraData_ReadByte_m4277BC79FF120694144690EFCC1CB3A0C293512A,
	ZipExtraData_ReadCheck_m4B0436FFBF6BF13320E1D83F1AFB8D6486018EE4,
	ZipExtraData_ReadShortInternal_mC62248CC8D32C8FC2273D725641281D509ED718F,
	ZipExtraData_Dispose_mFA53E53AEFC1C2C59893AF651905349CD44AAD5B,
	KeysRequiredEventArgs__ctor_m68FA1D3EEEF06A2F06389F4C808910217AD25A4D,
	KeysRequiredEventArgs_get_Key_m5404067B527347FCA15825061D95B81A0BA282E7,
	ZipFile_OnKeysRequired_mF75C1B95B8C9596214DF493C003ACC8D81D4E70F,
	ZipFile_get_HaveKeys_m7C1155BBE5BD81F05A5D5543430D3880636A1748,
	ZipFile__ctor_m0B360F8515C117860A5B3B4DC34A268D82CB52FB,
	ZipFile__ctor_m7FABEC3F553E98D07F6DBF475D685D4660244D24,
	ZipFile_Finalize_m089B07DD22F51FA0312C809AB23088B320838A62,
	ZipFile_Close_m7E452C938FF93B09EC7121F19A6ABC57676EC363,
	ZipFile_get_IsStreamOwner_m2C8C56370B362EBB5170093A7DAEB6EC48595243,
	ZipFile_set_IsStreamOwner_mE8950E204E60677DB62D1E768EE1BA27AFE9680E,
	ZipFile_GetEnumerator_m76796DA0F0D45A31AAB8A32002A013F5A7B082BA,
	ZipFile_FindEntry_m814ADDBB5C17239CB7DF0F0AB17F438E9411F370,
	ZipFile_GetInputStream_m39CEA186797C855DCD52185FC3724BC1C1BB3270,
	ZipFile_GetInputStream_mBB238538E4B73E4C3027ABE73011DF04EEF64931,
	ZipFile_TestLocalHeader_mC2E1C141CB20E48161F2B7079985D71E010D69D4,
	ZipFile_PostUpdateCleanup_m8067972C32CD89FC1EE50E32338AED9C646128E1,
	ZipFile_System_IDisposable_Dispose_m65A55E3CAF561749CCAD7C2E9D9E52BC88000130,
	ZipFile_DisposeInternal_mFB041F2F00415D8F6AF08B4F05C8CEF5AD5A314A,
	ZipFile_Dispose_m100C7084674B17C5596E5688D431BD70A0A50F33,
	ZipFile_ReadLEUshort_m52190F6FBF9A2221C8A2BF2B2F2B378E58C4060B,
	ZipFile_ReadLEUint_mFDC6397FB48B7AA2A60A7E331DD930B4981BF0C9,
	ZipFile_ReadLEUlong_m46F777C7B54B6D36038FA04DA28939600DBD8FC5,
	ZipFile_LocateBlockWithSignature_m5213FED6617508862B1A552F38AEF87AB76B62AD,
	ZipFile_ReadEntries_m5AD2BB57FE326135F8F4D01E30DB9C5284249BE8,
	ZipFile_LocateEntry_m1D242F5B35A263B31AB89305C3895D5E4B4102C8,
	ZipFile_CreateAndInitDecryptionStream_m5D7815E727BF576DF2305C588826CD634D8EDADA,
	ZipFile_CheckClassicPassword_m88CDF96ADDB66FD54E9F1F4DBA28BFAB54A0BBDC,
	KeysRequiredEventHandler__ctor_m7352F6F589B7E1DA34A056425102BF00FB543550,
	KeysRequiredEventHandler_Invoke_m9A0793762B23453A18C0E171366FDAB02FE25234,
	ZipEntryEnumerator__ctor_m202A284BDD6D12699DED3B8D36350A35EAA899DC,
	ZipEntryEnumerator_get_Current_m79E94E144ECD21114B42EE6B82EF229946B51018,
	ZipEntryEnumerator_Reset_mB1BFF4E28B4508D64425CFFA82C1702B5489CCBA,
	ZipEntryEnumerator_MoveNext_m08DD1AB587FCBB7230A4EA1035D1F51EE15A2404,
	PartialInputStream__ctor_mD3F23321589BF0E6DBEDC92CA0AABEC40B284E42,
	PartialInputStream_ReadByte_mF36B1C10F96CCFE395C71890EA7BF977AD7B4182,
	PartialInputStream_Read_mE96C3236A1ED9869CD525C7AB67565574DF55E3B,
	PartialInputStream_Write_m80820A7531C85C121005069D189147DA8F1A1762,
	PartialInputStream_SetLength_mE24FC720F72D210AB570CCD26D3DF3F17B05E343,
	PartialInputStream_Seek_mE375CFB9FC63FFE5C79596A3672C17740AF5C75B,
	PartialInputStream_Flush_m3DBE7C41C1841A3C90C9A37E975F43B5FC533DC1,
	PartialInputStream_get_Position_m1C5E04F4C690732A35757E14AD2D7060C6A28D1D,
	PartialInputStream_set_Position_mC8F0F844583BEE892590C1D8A79799E47D013B55,
	PartialInputStream_get_Length_m2D803495BCD6BF118E4ED31584D0095F6931F494,
	PartialInputStream_get_CanWrite_m7CECEA09CA1AD55E668624EAA5CC6069DB501405,
	PartialInputStream_get_CanSeek_mF412E07CE3DE56A243CBE2779556CAC2D382A65E,
	PartialInputStream_get_CanRead_m7C6663730023D71EE77A0C0E108B55381D8F7D8C,
	PartialInputStream_get_CanTimeout_m531A11069813E68745ECC9CE42CCADB6CF31B24A,
	NULL,
	ZipHelperStream__ctor_m8CA188C870FF88F064601E56264A98EB1A7C4C39,
	ZipHelperStream_get_CanRead_mE7629EC63D61207096FFE09CF3194E3B6259808E,
	ZipHelperStream_get_CanSeek_mEFDF1F4C522804F14C3DC5C0DFB7CEE006F9500C,
	ZipHelperStream_get_CanTimeout_mBFE574AC234D9A7B730E3A9A1130963564632142,
	ZipHelperStream_get_Length_m043CBC0CA561F52CC93FD0F4AF1BAD1908AAD856,
	ZipHelperStream_get_Position_m73CB30EEDAF1461B72B87B800953919B98365794,
	ZipHelperStream_set_Position_m9B0F3857607C182BC07E77E01D32FF1C6A3C7800,
	ZipHelperStream_get_CanWrite_m4D8678A7E208C99F60E03F54107EF3FDF61D646F,
	ZipHelperStream_Flush_m6EE06BC18B3423B7493AF1B9899812B82E322881,
	ZipHelperStream_Seek_m295C3DE6C5B51CB78F457A7AFA8B6EBBF9D4169A,
	ZipHelperStream_SetLength_m946969EAE01B1C7B1B802874052D6C28891B6561,
	ZipHelperStream_Read_m0CF1F0FFDFF179C228CD5F1393535FC035AA9405,
	ZipHelperStream_Write_m7307680852F6F69D3A97D3806B3051F58B94E43B,
	ZipHelperStream_Dispose_m8081F8249BE876CCB82F892AED0D3893230AAD56,
	ZipHelperStream_LocateBlockWithSignature_m8A393778E9CDC5DF70418BE848603831CED63F54,
	ZipHelperStream_ReadLEShort_m03B5CFB94EA3579ED4D5C210FC868C3F383B7BE1,
	ZipHelperStream_ReadLEInt_mCAA4804CA263C9B3BC19FB694F2B45B6420D2009,
	ZipNameTransform__ctor_m4C6DEFBF7C0A4146407BF5749432415293870C3A,
	ZipNameTransform__cctor_mAC21E8A03CEB9FD58D8A1070504BC9B32F59158E,
	ZipNameTransform_IsValidName_m6A63FFCCA5D1F96366AE6CD562C65F85F049E223,
	ZipStrings__cctor_m92CBAD9CCEF67132EFACEDDC8FD5E56BB75F85A0,
	ZipStrings_get_CodePage_m15D3861930EF90420BA5F4FAC6AF77932B131255,
	ZipStrings_get_SystemDefaultCodePage_m1E29CFDE8CF4F0B413CE0E402BC43131752273A3,
	ZipStrings_get_UseUnicode_m4FB549AA0B99F86BC855867DC634401991E93F60,
	ZipStrings_ConvertToString_mABB7597E416F5FDC79C8E8DB0733656143A2DD44,
	ZipStrings_ConvertToString_mFD1ACC0C349147013A3E8A944997FCA34609FF3F,
	ZipStrings_EncodingFromFlag_mF652B940D52192276B6359595B6B630C8A5BAF7C,
	ZipStrings_ConvertToStringExt_mDCEDCBD4B12D714C10E102594BAA9EFB869FD71C,
	ZipStrings_ConvertToStringExt_m06695786666E1DBC75EC015DD5879DDFF9022420,
	DeflaterHuffman__cctor_mE41964EE4849018FBB2D8B361A389D75CC16B125,
	DeflaterHuffman_BitReverse_m1DC3B2DA57D89D85433499A585C3D4C0281A2608,
	Inflater__ctor_m5183A7AAD2E39FFDCEE42A83E207181960B95FF9,
	Inflater_DecodeHeader_m21080A6BC7E297636F3166EA446CCE3EFB5B8E08,
	Inflater_DecodeDict_m29336A25A6DD7C50C50255BFB893E40AEF6169AC,
	Inflater_DecodeHuffman_m368C39466E998FB156DCCA6BEE53F5A3780D84B9,
	Inflater_DecodeChksum_mE19C73857CF2FDFB0B54D8F0FE9D7CD46CEC77A6,
	Inflater_Decode_m798A6AD40D5B2C63ED617294FC5EAB3F53021AAC,
	Inflater_SetInput_mD03E4341BFA7288F0E8CDA67B7D2F511EE97077A,
	Inflater_Inflate_m81859B7CD192B60897C8137AF1649556B7CA8E3D,
	Inflater_get_IsNeedingInput_m379F0BEB540051929C7CC519DDCC50707890B007,
	Inflater_get_IsNeedingDictionary_m244394D004966CD7C5FBCFB38470134B9E76E5B4,
	Inflater_get_IsFinished_mEB6FCF59E91599BB0DF568A190DE2A9F85CDB20E,
	Inflater__cctor_mEE94F515458A6917DF0B4C33A32EF116AC50015B,
	InflaterDynHeader_AttemptRead_mFBE94A6D0E5B612227D5B2DA49A6D8E01400D335,
	InflaterDynHeader__ctor_m5F813A9D034BAB8C77C901B522C0F2D94907EDC9,
	InflaterDynHeader_CreateStateMachine_m8665FA3435E162F404F1F6708DF31EC87799BD72,
	InflaterDynHeader_get_LiteralLengthTree_mF13D9D7777DDF50F3678CDA857B6DB956ADCD62D,
	InflaterDynHeader_get_DistanceTree_mD50173D2F3516FDCA0E8D8BDDE41818ADFE7AA29,
	InflaterDynHeader__cctor_m02512A11086BFE51D71F15F586FB04FDC4E08657,
	U3CCreateStateMachineU3Ed__7__ctor_m620DE8D4A051C293555A00BCBD5484BF6A4B9C26,
	U3CCreateStateMachineU3Ed__7_System_IDisposable_Dispose_m8F09A534D2BEEA7FB03D78DD865C6CCA914FBE3D,
	U3CCreateStateMachineU3Ed__7_MoveNext_mD70ACC4C2760EABCD673A7D64FC20D8142B70405,
	U3CCreateStateMachineU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_BooleanU3E_get_Current_m34012A4CB42B42ABFCF07E0B12A766A64BE461DD,
	U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerator_Reset_m1AB8C1C43F8D81E5BA2D321E26202E91E1168F2D,
	U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerator_get_Current_mB1A722CCA7905D6B6E5950DC5BD6B15D0617E595,
	U3CCreateStateMachineU3Ed__7_System_Collections_Generic_IEnumerableU3CSystem_BooleanU3E_GetEnumerator_m6841552AB204D0CBAA57CA5B8C426C7125266FF9,
	U3CCreateStateMachineU3Ed__7_System_Collections_IEnumerable_GetEnumerator_mEFC76710C5C0A6583026C315FA26384752D89861,
	InflaterHuffmanTree__cctor_m6B20BC361511B333F72E142880CDC28A400AC206,
	InflaterHuffmanTree__ctor_m5C9D1582BE8D2227268843BE55ABD7614F12C186,
	InflaterHuffmanTree_BuildTree_m8747A576B9CAD13F21A8A7F906F63246232FF5EE,
	InflaterHuffmanTree_GetSymbol_mCE613B5454E254F2D041AAA28FA279B075C7677C,
	InflaterInputBuffer__ctor_m042F879BBDA06AA51FF199DBA3B9BF798A8F8929,
	InflaterInputBuffer_get_Available_m5E66CD4D88490D425B7AF3636A27538003E48169,
	InflaterInputBuffer_SetInflaterInput_m303A5BED84FD7C3C23B73448E5405F497F2542C4,
	InflaterInputBuffer_Fill_m29B03A52B8B5F49C784486079FDE4BA5C3C77231,
	InflaterInputStream__ctor_mAEA971E711654A0AFB588ABE8512960D41F3E3D0,
	InflaterInputStream__ctor_mEB11817AAD6E905924DCE2C8CF758DFFA0B15C91,
	InflaterInputStream_get_IsStreamOwner_mF78646DE2A962B44726310E31223230C8617F0CC,
	InflaterInputStream_Fill_mBC6A8C31004A86E3363600E8307A7D5FAB29CB4A,
	InflaterInputStream_get_CanRead_mF199AA88E5BCAD1985F2391CBC4A569D5736F3F2,
	InflaterInputStream_get_CanSeek_m33C42DA85C433F162680D208EB87ADBF8DA7A883,
	InflaterInputStream_get_CanWrite_m62B25F45921B271811FEC5DD261A1415255C78FB,
	InflaterInputStream_get_Length_m176C2D20D50FA17B06066EDF062C8CD726085155,
	InflaterInputStream_get_Position_m949DB5C05CFCBA60155D0B20727EE54E97300459,
	InflaterInputStream_set_Position_m9BD4DF58F5220794828190502FC6DF7571554C85,
	InflaterInputStream_Flush_mEED5BE2716A9AB687387812D09DC97EDD4140BEA,
	InflaterInputStream_Seek_m1E1AC2C1269904300E26B29B26C132AC3B5027F5,
	InflaterInputStream_SetLength_m2524C0C1608DA18ED088244F33680146C6664C40,
	InflaterInputStream_Write_m53ADE5F0ECCBDDA93E6EC68C863D9D478ACDA432,
	InflaterInputStream_WriteByte_mD82CC287C483418EDFF2BFEF7F46396BA29CE728,
	InflaterInputStream_Dispose_mF6E9832286177D24F636D92F5D99C1E5DA6F32D4,
	InflaterInputStream_Read_mFEA9B693BB50AF9EB4CBE1923C79005CB411C5FA,
	OutputWindow_Write_m98568B7A777A909CE6738BEBC2BD050FA5EF3939,
	OutputWindow_SlowRepeat_mAED2CEC54827CA0EDE654F8C012CB54D6903FE7A,
	OutputWindow_Repeat_mF71C1109E018A243A011D3D2CDFC8A4BEA6D6E66,
	OutputWindow_CopyStored_m4DBB3A23F88263ABDF3ED6AA234E8F21ADDD6B26,
	OutputWindow_GetFreeSpace_m1D7A6594FA9BD7FFE6757752EC2344E8A8D42576,
	OutputWindow_GetAvailable_m106E5803870827EA5BC8DFC4926FC2F43304CB28,
	OutputWindow_CopyOutput_m908635A98F7C5A3BF1BFBA96507CF8BE64121477,
	OutputWindow__ctor_m27D9398752C21DFE507E95A1507A2061005F9487,
	StreamManipulator_PeekBits_mF211C8B59086D72F8836E9F4F5619102F71E149A,
	StreamManipulator_TryGetBits_m5C2ABD3EBACED46DB068C323914CDA30D85B8CC1,
	StreamManipulator_TryGetBits_m6BF0BAD1FFBBCDFCBFFA7AC58D17D03A381A65E1,
	StreamManipulator_DropBits_m094CABA3AB3B1B70D2680E4FB8962EBD6B8E0E49,
	StreamManipulator_get_AvailableBits_m90991A9D5E1F58AD333D717C1E1F5B6AE65C1D48,
	StreamManipulator_get_AvailableBytes_m3F02851B6B30C7F729CD93D4CB6917473D45FDB4,
	StreamManipulator_SkipToByteBoundary_m11A241EB548D46A99D9E55C543FBCD9A02C11D32,
	StreamManipulator_get_IsNeedingInput_mEA9A2390430364EA2A84A33709CC6625C04050D9,
	StreamManipulator_CopyBytes_m326B46651BD903626068679C41A1ADF495A757D6,
	StreamManipulator_SetInput_mFD2FB5325969D00CE3C052CC8D57D5B6DCF351A7,
	StreamManipulator__ctor_mABF375127B2C20DC969C50EC909C3FB0C01DF6B9,
	PkzipClassic__ctor_m9725AEEB72479F55DFDB5AB212437BE7E938A1E5,
	PkzipClassicCryptoBase_TransformByte_m562E81B3284793B00040A9B1DE61B5D96DF443E1,
	PkzipClassicCryptoBase_SetKeys_m0444E777B325A95CB7E8922D431D84E413B91469,
	PkzipClassicCryptoBase_UpdateKeys_mBBDD4941427951A62A21C2CDD8FDE31A5F1A0441,
	PkzipClassicCryptoBase_Reset_m4AAF69726582F9C9EA9F8109D32B13CA661C703B,
	PkzipClassicCryptoBase__ctor_m013F4376CF64AA2B5D5DE9BB20A19A6AA2842D86,
	PkzipClassicEncryptCryptoTransform__ctor_mF6FEC4C002E888A7742B7476D0370407CE8F85E3,
	PkzipClassicEncryptCryptoTransform_TransformFinalBlock_m78CDB5E4992629BAD696B6335D0E077B205D839B,
	PkzipClassicEncryptCryptoTransform_TransformBlock_mF6ED7F17496AAC2E4E709EB95FA246055A962A4B,
	PkzipClassicEncryptCryptoTransform_get_InputBlockSize_mC9DAB908DC4A334418A34914C8E7D01B233ED184,
	PkzipClassicEncryptCryptoTransform_get_OutputBlockSize_m5AB9717309C40D8B119371E21F66D179BECCCB29,
	PkzipClassicEncryptCryptoTransform_get_CanTransformMultipleBlocks_m2E8C4BF7A6C7509D0CDB129C99FDB5ABC58BA219,
	PkzipClassicEncryptCryptoTransform_Dispose_m9D379C9BBA4689CDDF82A1516C0E9A89D7126524,
	PkzipClassicDecryptCryptoTransform__ctor_m71FE21D85A22418C575FA90E0BAC63B2F0B4E931,
	PkzipClassicDecryptCryptoTransform_TransformFinalBlock_m8E7C6D63545A316F41372EC5212F0C5EE5320F65,
	PkzipClassicDecryptCryptoTransform_TransformBlock_m4F754CB891277C9DA593C40BBCCB13BE9DDB0E1C,
	PkzipClassicDecryptCryptoTransform_get_InputBlockSize_mE6D4842AC8ABE61D209A999A4421F0C3E43BB726,
	PkzipClassicDecryptCryptoTransform_get_OutputBlockSize_m8FA4498E4181D3BF050FDF281CF61E1B5F406B5F,
	PkzipClassicDecryptCryptoTransform_get_CanTransformMultipleBlocks_mBB377F96020A7E02990B7A88CA245516C017C722,
	PkzipClassicDecryptCryptoTransform_Dispose_mD8DB144E991017437DAFE09F8C6992B6500352BA,
	PkzipClassicManaged_get_BlockSize_m2844CE869EFCC7F73A2C668AE30DAD618A299F67,
	PkzipClassicManaged_set_BlockSize_m49688514B12E14C0D7E5D0789D735D31DA14D040,
	PkzipClassicManaged_get_LegalKeySizes_m9E37F8F53F055769D0DFBF0389A5BD8C868815A4,
	PkzipClassicManaged_GenerateIV_m68E82697BF5AAA6F0E3D2788515F171FE489970D,
	PkzipClassicManaged_get_Key_m578035169EF71DC6AF23C0EB935D98D1285E8FD9,
	PkzipClassicManaged_set_Key_m51DEB0FE186DC44DA5F64C57C157F614E49A5CE4,
	PkzipClassicManaged_GenerateKey_m3346E68C2652740113A979D2EE7CAC132E952BDF,
	PkzipClassicManaged_CreateEncryptor_m9F436CE33B3438787BFE4503376CBA298C33B6E5,
	PkzipClassicManaged_CreateDecryptor_mF6D61B13DC8DF5A308BFDF28216E65105D2A4940,
	PkzipClassicManaged__ctor_m4A04A8B6C4B44BD96DB38D12624D14F9C9819593,
	ZipAESStream__ctor_mBE431878A503B03F92D14E1DD44248516628D483,
	ZipAESStream_get_HasBufferedData_mEFAA3542F9B6A9DD396EFD7C24E494E7A7E658E6,
	ZipAESStream_Read_m39852704A0F6EA98DBD68B9DA5E6AE7395614129,
	ZipAESStream_ReadAsync_mC1421BB0229E8300598E25E9E5EE7DB37BF34569,
	ZipAESStream_ReadAndTransform_mBB994079CAFA0957CA1EEF16B7D4ABE6567EDD93,
	ZipAESStream_ReadBufferedData_mA2E55A04EC90833054995728FF1D7E53D45F4FCA,
	ZipAESStream_TransformAndBufferBlock_m096433E20FEE76C760F58390E290A1FCBF6AFB92,
	ZipAESStream_Write_mCC1EA1542CEFC06FBC64C09A072D89D1DE644FBC,
	ZipAESTransform__ctor_m159186BF570F35F6E144B4AA90E162FC2FDF7BE9,
	ZipAESTransform_TransformBlock_m36C6662BD0F182056F2D71AB0B3FB6E9F70FB31D,
	ZipAESTransform_get_PwdVerifier_m2393389FFB045BFA21D9B61ACAC24D33B5F1DA7F,
	ZipAESTransform_GetAuthCode_m30147C4C3EB8C4777CE236DEC81012EB3AA959A4,
	ZipAESTransform_TransformFinalBlock_m3DE69A3BAA81D1D9EE5BF2D1F8439B9C0C6AE16C,
	ZipAESTransform_get_InputBlockSize_m9A8406CBACC812E83421309C67EE73569C849D13,
	ZipAESTransform_get_OutputBlockSize_m38533860E91CC2404B000E5916806D0B0CFF4F26,
	ZipAESTransform_get_CanTransformMultipleBlocks_m737240ABDEA6735087A7298A8496705CF4C83628,
	ZipAESTransform_Dispose_mE2E4C43496564375DC2137699A482667AD0527B4,
	IncrementalHash__ctor_m003F4679A8353E2349F9BE72A6E16C283DD2204B,
	IncrementalHash_CreateHMAC_m6AB0E73046CF53361E9A37494BB6FAAEFC592952,
	IncrementalHash_AppendData_mEA0F42AF0C7B6F1D0BC969F4C03FAC0EF3AFEFC3,
	IncrementalHash_GetHashAndReset_mBFC9BE40AE371BC6B56E84C8D2C09B09963F4D47,
	NULL,
	NULL,
	StreamUtils_ReadFully_mF6B59768A0970CC76B5008B448FDEB5A1D05D212,
	StreamUtils_ReadFully_m199F7FEA7225E4EB325F8B5EDB61253B5B132C9F,
	StreamUtils_ReadRequestedBytes_mAF78D6227FFD4186DDA382A862BD4BEBE70344DC,
	StreamUtils_Copy_mA675A1AD49A23709CB18CC9A25B5C76C85AE45DE,
	Adler32__ctor_mB60FEE1C35C49DBD391DE8F67BAAAA7DFA5C5F37,
	Adler32_Reset_mF1FC2116EC33946831C0658FFA208CB33E8984D5,
	Adler32_get_Value_mFA327307664CBD7FFA6BF7A903FDB6D8F76E59D2,
	Adler32_Update_m705E9898BE9687D03682E5663A34E04B0BC68285,
	Adler32_Update_m35F6DD4EB74B942CEA83976C6B2047622C812A56,
	Adler32__cctor_m93FC2DC1974CC6D434198A2144B0C3D919C32D04,
	BZip2Crc__ctor_m44988A7ABB1C4BE9641ACB2A5DD3C80E3A964030,
	BZip2Crc_Reset_m87F6B17ACA701341C626E80DE772BA9BE55072B5,
	BZip2Crc_get_Value_m6B8F672C0C299C475E3DA047EFBE8FA8403B4885,
	BZip2Crc_Update_m4F502295AE57FF154C672C06889B58FD0182A94A,
	BZip2Crc__cctor_mF1009734FF7DEC652AB076D7AB6E46CDD197462D,
	Crc32_ComputeCrc32_m36E74AEF7EDB3709D328DE5DB1AC688F95940440,
	Crc32__cctor_m12717CFF41D0DC6FF78B05A9D56C853057631EE8,
	CrcUtilities_GenerateSlicingLookupTable_m0CE4789B52FA496BBD62C43B72D9BA9CCEB34C00,
	NULL,
	NULL,
	NULL,
	BZip2Constants__cctor_mA75F3BC0C9FA741D73B4EEC475AE30BBE374FCF2,
	BZip2Exception__ctor_m0090C4098824A1E60315DB97BDAE5F7C9112BB5F,
	BZip2Exception__ctor_m8D0263A2BD0CCC9CB6D2886ABBE2539671EE4F1C,
	BZip2Exception__ctor_mAAA63BA512BBAED21D0F4094DDA88F8280B934A3,
	BZip2InputStream__ctor_m6C9F56BFE47945DB0B943D840AE4AA01DACE4E62,
	BZip2InputStream_get_IsStreamOwner_m41E5817E414E2FDDB0153B6F3AEC091B7242A0BA,
	BZip2InputStream_get_CanRead_mC71680334D1938D45301B259CA7E588483CEAD70,
	BZip2InputStream_get_CanSeek_mFCABA926A11F94A5E024CA3EAEC5D07BD7C8B4BD,
	BZip2InputStream_get_CanWrite_m8909CABE27E39FED0157DCCC228BC41A9EC42CC0,
	BZip2InputStream_get_Length_mC3857DC2D4282B9D95E013CCA0E3EBD4501CDF17,
	BZip2InputStream_get_Position_m8BC28258E50DD14E58AF4EA3E7A41908B621F5FB,
	BZip2InputStream_set_Position_m975849119963BADC4183A3C36133B71EDE7DEC67,
	BZip2InputStream_Flush_m517332FC2D7406124E0682B071A67F919FE716F4,
	BZip2InputStream_Seek_mA22AD11F85D0056A2E138E17B20C37D6B3300044,
	BZip2InputStream_SetLength_m96E6B9141C7F2EAB2267ACFF4282CFCFC2974A3F,
	BZip2InputStream_Write_m9626911E5C2E721FC4AD501A8E59CDAC271C6DAC,
	BZip2InputStream_WriteByte_mD0625FA4615D5B50D2F1482F6197441676AE8312,
	BZip2InputStream_Read_mD2420F9C7066D844712E272C5084BA84457AACCB,
	BZip2InputStream_Dispose_m5458CBF478321D6F775CADACE45D35C509A216FC,
	BZip2InputStream_ReadByte_m798D4995D0F5F1AAF60B1A202DF1A8E5F2D214C1,
	BZip2InputStream_MakeMaps_mC38259B3DCBDF7DBD8433CAF6715D6EFFBAE733A,
	BZip2InputStream_Initialize_mAAF7F4BBF0284BF55CFC5E6ED87F734318B794B9,
	BZip2InputStream_InitBlock_m93DD86F9271DBEA5811A33CE8D386E812176780D,
	BZip2InputStream_EndBlock_m9857538948902F7DCE49A785F03A7D491A567AC6,
	BZip2InputStream_Complete_m5BECD99C71E964108C3F2765F27BD37710F7F5E3,
	BZip2InputStream_FillBuffer_mD7CB990F9178525D296153D04BD375E9E72FD83A,
	BZip2InputStream_BsR_m87FC44F178D98623119D75BDBA011BEF72BB1613,
	BZip2InputStream_BsGetUChar_m2111337E4BE1CE4C11D5840121B92DBFA6377CB7,
	BZip2InputStream_BsGetIntVS_m7C0246D84E52E09EE51B2A1ED96671BCB885B405,
	BZip2InputStream_BsGetInt32_mA476E857090B44576F9629C2265B0390CC8C95BA,
	BZip2InputStream_RecvDecodingTables_m7DF3E08211C27893B36E83BC49A3045DCF864DB1,
	BZip2InputStream_GetAndMoveToFrontDecode_m3D99019D7E95B8396077B35582E99F86092EF526,
	BZip2InputStream_SetupBlock_m899C33F44F1838D4BFDE4C069AE652BA1EDF36E5,
	BZip2InputStream_SetupRandPartA_mB668B399E66AA4E0EED64DCF6307A082EAF61D8C,
	BZip2InputStream_SetupNoRandPartA_mC524B2897F62558926C7D06C0B66153ABACAAE20,
	BZip2InputStream_SetupRandPartB_m5535A0A3843EE09F4B8BC02B25A2C784F90A702D,
	BZip2InputStream_SetupRandPartC_m6A32047DE375216D8C6B48E14DD852F3C33C1052,
	BZip2InputStream_SetupNoRandPartB_m316C6311888936B36E70C7E57870F804E1F90A49,
	BZip2InputStream_SetupNoRandPartC_mD0FDD6E542ACD8D986F0EE98FB4C465ED8ED14FD,
	BZip2InputStream_SetDecompressStructureSizes_m527B6A7D7A0905BC26CFD176F11B44D32C1A417F,
	BZip2InputStream_CompressedStreamEOF_m3A9F39AFD660A341B4B96FF5DB0CAB7A8892009A,
	BZip2InputStream_BlockOverrun_m90E13E18817131DD8A9EDD4D1457B30343C6E27F,
	BZip2InputStream_BadBlockHeader_m3E3D3D8F1F6F893EC4F3FC013B12385B03A844C5,
	BZip2InputStream_CrcError_m4DB7B3D663A9FF6C888D37AB9F0C8B430DABDFB1,
	BZip2InputStream_HbCreateDecodeTables_m2FC2A29567A1EF7C38981C38DCF98A6027197DED,
};
static const int32_t s_InvokerIndices[345] = 
{
	5143,
	4245,
	2570,
	5143,
	4245,
	2570,
	4245,
	5143,
	2570,
	1045,
	4960,
	4174,
	4960,
	4174,
	5013,
	4227,
	5014,
	4228,
	5014,
	4228,
	5013,
	4227,
	3118,
	5013,
	5013,
	4960,
	4960,
	4228,
	4977,
	4196,
	5033,
	5014,
	4228,
	5014,
	4228,
	5014,
	4228,
	5013,
	5013,
	4245,
	5013,
	5013,
	5013,
	5013,
	4174,
	7391,
	4245,
	4245,
	4960,
	4960,
	4960,
	5033,
	7477,
	6909,
	6761,
	5143,
	5143,
	4245,
	2570,
	0,
	0,
	5012,
	1505,
	4977,
	4960,
	5143,
	4245,
	0,
	5013,
	3118,
	5014,
	5013,
	5013,
	5013,
	4227,
	5013,
	5143,
	2565,
	5033,
	4245,
	4960,
	4245,
	2551,
	5143,
	5143,
	4960,
	4174,
	5033,
	1886,
	3832,
	3830,
	2018,
	5143,
	5143,
	4174,
	4174,
	5129,
	5130,
	5131,
	852,
	5143,
	3789,
	2064,
	7348,
	2563,
	2565,
	4245,
	5033,
	5143,
	4960,
	1517,
	5013,
	1242,
	1505,
	4228,
	2015,
	5143,
	5014,
	4228,
	5014,
	4960,
	4960,
	4960,
	4960,
	0,
	4245,
	4960,
	4960,
	4960,
	5014,
	5014,
	4228,
	4960,
	5143,
	2015,
	4228,
	1242,
	1505,
	4174,
	852,
	5013,
	5013,
	5143,
	8029,
	6908,
	8029,
	7993,
	7993,
	7975,
	7120,
	7669,
	7666,
	6539,
	7104,
	8029,
	7562,
	4174,
	4960,
	4960,
	4960,
	4960,
	4960,
	1505,
	1242,
	4960,
	4960,
	4960,
	8029,
	4960,
	4245,
	5033,
	5033,
	5033,
	8029,
	4227,
	5143,
	4960,
	4960,
	5143,
	5033,
	5033,
	5033,
	8029,
	4245,
	4245,
	3633,
	2561,
	5013,
	4245,
	5143,
	2565,
	1524,
	4960,
	5143,
	4960,
	4960,
	4960,
	5014,
	5014,
	4228,
	5143,
	2015,
	4228,
	1505,
	4174,
	4174,
	1242,
	4227,
	1457,
	2365,
	1889,
	5013,
	5013,
	1242,
	5143,
	3617,
	1139,
	1139,
	4227,
	5013,
	5013,
	5143,
	4960,
	1242,
	1505,
	5143,
	5143,
	4960,
	4245,
	4174,
	5143,
	5143,
	4245,
	1300,
	391,
	5013,
	5013,
	4960,
	5143,
	4245,
	1300,
	391,
	5013,
	5013,
	4960,
	5143,
	5013,
	4227,
	5033,
	5143,
	5033,
	4245,
	5143,
	2064,
	2064,
	5143,
	1524,
	4960,
	1242,
	891,
	1242,
	1242,
	764,
	1505,
	1068,
	391,
	5033,
	5033,
	1300,
	5013,
	5013,
	4960,
	5143,
	4245,
	7123,
	1505,
	5033,
	0,
	0,
	7348,
	6274,
	5996,
	6776,
	5143,
	5143,
	5014,
	4227,
	3989,
	8029,
	5143,
	5143,
	5014,
	4227,
	8029,
	7244,
	8029,
	7144,
	0,
	0,
	0,
	8029,
	5143,
	4245,
	2570,
	4245,
	4960,
	4960,
	4960,
	4960,
	5014,
	5014,
	4228,
	5143,
	2015,
	4228,
	1505,
	4174,
	1242,
	4174,
	5013,
	5143,
	5143,
	5143,
	5143,
	5143,
	5143,
	3617,
	5129,
	3617,
	5013,
	5143,
	5143,
	5143,
	5143,
	5143,
	5143,
	5143,
	5143,
	5143,
	4227,
	8029,
	8029,
	8029,
	8029,
	5403,
};
static const Il2CppTokenRangePair s_rgctxIndices[3] = 
{
	{ 0x02000031, { 3, 2 } },
	{ 0x06000044, { 0, 2 } },
	{ 0x06000116, { 2, 1 } },
};
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t380598F6C1A7A8EEBFA1B5F80BC00FD5FD42E681_m8491B525E29B1828B0000A740169EB042FA5E087;
extern const uint32_t g_rgctx_T_t380598F6C1A7A8EEBFA1B5F80BC00FD5FD42E681;
extern const uint32_t g_rgctx_EmptyArray_1_t89D581588D20ECC21BD8D66C59ED1A28700FD08F;
extern const uint32_t g_rgctx_TU5BU5D_tDB48CDB136012145E4E092EE4CB215654D2522FB;
extern const uint32_t g_rgctx_EmptyArray_1_tBA22C8C125CB6F87AD65E0170A92A047223F5BBE;
static const Il2CppRGCTXDefinition s_rgctxValues[5] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_t380598F6C1A7A8EEBFA1B5F80BC00FD5FD42E681_m8491B525E29B1828B0000A740169EB042FA5E087 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t380598F6C1A7A8EEBFA1B5F80BC00FD5FD42E681 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EmptyArray_1_t89D581588D20ECC21BD8D66C59ED1A28700FD08F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tDB48CDB136012145E4E092EE4CB215654D2522FB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EmptyArray_1_tBA22C8C125CB6F87AD65E0170A92A047223F5BBE },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_ICSharpCode_SharpZipLib_CodeGenModule;
const Il2CppCodeGenModule g_ICSharpCode_SharpZipLib_CodeGenModule = 
{
	"ICSharpCode.SharpZipLib.dll",
	345,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	3,
	s_rgctxIndices,
	5,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
