﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Ionic.Zip.WriteDelegate::.ctor(System.Object,System.IntPtr)
extern void WriteDelegate__ctor_m362F97AB96E4E7C5458DE2788098EC0AAB8AF284 (void);
// 0x00000002 System.Void Ionic.Zip.WriteDelegate::Invoke(System.String,System.IO.Stream)
extern void WriteDelegate_Invoke_mE589D11BB539F22634E11CA29C44BFCAC28C8ABD (void);
// 0x00000003 System.Void Ionic.Zip.OpenDelegate::.ctor(System.Object,System.IntPtr)
extern void OpenDelegate__ctor_m205D2CF40B14BE3009CA80A4E3D1024B62D07370 (void);
// 0x00000004 System.IO.Stream Ionic.Zip.OpenDelegate::Invoke(System.String)
extern void OpenDelegate_Invoke_mDBDEA099AC017F1FACF297B5B69324A823C34F3D (void);
// 0x00000005 System.Void Ionic.Zip.CloseDelegate::.ctor(System.Object,System.IntPtr)
extern void CloseDelegate__ctor_m464F32515E748AFF431413EAFD6F56521A3E49F3 (void);
// 0x00000006 System.Void Ionic.Zip.CloseDelegate::Invoke(System.String,System.IO.Stream)
extern void CloseDelegate_Invoke_m0E5D550E08AF9F4B3264FC491A730B13C38F0F64 (void);
// 0x00000007 System.Void Ionic.Zip.SetCompressionCallback::.ctor(System.Object,System.IntPtr)
extern void SetCompressionCallback__ctor_m1C4F299773605AC70CBCAF2151ED7AF153E97175 (void);
// 0x00000008 Ionic.Zlib.CompressionLevel Ionic.Zip.SetCompressionCallback::Invoke(System.String,System.String)
extern void SetCompressionCallback_Invoke_mEBF215E7AE202561290B5F5E71011FE9153DEA44 (void);
// 0x00000009 System.Void Ionic.Zip.ZipProgressEventArgs::.ctor()
extern void ZipProgressEventArgs__ctor_m04F4FBF8B06280136DB077B8DE0219F1CAEC3D0D (void);
// 0x0000000A System.Void Ionic.Zip.ZipProgressEventArgs::.ctor(System.String,Ionic.Zip.ZipProgressEventType)
extern void ZipProgressEventArgs__ctor_mF64AB157E5188BC18ADDBCC06A55E6CFBB55CC2A (void);
// 0x0000000B System.Void Ionic.Zip.ZipProgressEventArgs::set_EntriesTotal(System.Int32)
extern void ZipProgressEventArgs_set_EntriesTotal_m15CA9C283E7B54B8527A72D7807F845071C694E7 (void);
// 0x0000000C System.Void Ionic.Zip.ZipProgressEventArgs::set_CurrentEntry(Ionic.Zip.ZipEntry)
extern void ZipProgressEventArgs_set_CurrentEntry_m869D80F2DBF904069D7305B7F9DA9A4457A4D01E (void);
// 0x0000000D System.Boolean Ionic.Zip.ZipProgressEventArgs::get_Cancel()
extern void ZipProgressEventArgs_get_Cancel_mE996AE2B28FE69EEC649494924908E9D22E1B678 (void);
// 0x0000000E System.Void Ionic.Zip.ZipProgressEventArgs::set_EventType(Ionic.Zip.ZipProgressEventType)
extern void ZipProgressEventArgs_set_EventType_m60E1D539D78A39D6B0E5619B8C6B9AC5B811856D (void);
// 0x0000000F System.Void Ionic.Zip.ZipProgressEventArgs::set_ArchiveName(System.String)
extern void ZipProgressEventArgs_set_ArchiveName_m44B9688C1A6BAAB38026FE5C6731F19DF1E81659 (void);
// 0x00000010 System.Void Ionic.Zip.ZipProgressEventArgs::set_BytesTransferred(System.Int64)
extern void ZipProgressEventArgs_set_BytesTransferred_mA29625B11BC5FFF4F346FDDCAF2C3A7496E62CFD (void);
// 0x00000011 System.Void Ionic.Zip.ZipProgressEventArgs::set_TotalBytesToTransfer(System.Int64)
extern void ZipProgressEventArgs_set_TotalBytesToTransfer_mCAB9EE4392E96AAD74D0F1820C542F3925C45F22 (void);
// 0x00000012 System.Void Ionic.Zip.ReadProgressEventArgs::.ctor(System.String,Ionic.Zip.ZipProgressEventType)
extern void ReadProgressEventArgs__ctor_mEFCC125C9A00B495F28C59B9728736C3E628411B (void);
// 0x00000013 Ionic.Zip.ReadProgressEventArgs Ionic.Zip.ReadProgressEventArgs::Before(System.String,System.Int32)
extern void ReadProgressEventArgs_Before_m78B9B4D24CCD8C0AB1BEE83CE789376CFF1CEF8A (void);
// 0x00000014 Ionic.Zip.ReadProgressEventArgs Ionic.Zip.ReadProgressEventArgs::After(System.String,Ionic.Zip.ZipEntry,System.Int32)
extern void ReadProgressEventArgs_After_m517C33A00BB0AC085C184950720828BEA3A5326B (void);
// 0x00000015 Ionic.Zip.ReadProgressEventArgs Ionic.Zip.ReadProgressEventArgs::Started(System.String)
extern void ReadProgressEventArgs_Started_mCECDE8A6F7360706892908B9A9DDC5FBCC51B1C0 (void);
// 0x00000016 Ionic.Zip.ReadProgressEventArgs Ionic.Zip.ReadProgressEventArgs::ByteUpdate(System.String,Ionic.Zip.ZipEntry,System.Int64,System.Int64)
extern void ReadProgressEventArgs_ByteUpdate_m299B3280742449D30B14E3EDC035A30CD2E4287F (void);
// 0x00000017 Ionic.Zip.ReadProgressEventArgs Ionic.Zip.ReadProgressEventArgs::Completed(System.String)
extern void ReadProgressEventArgs_Completed_mCCF64E8115B7256132599ECD96E5D5B978A2E5D5 (void);
// 0x00000018 System.Void Ionic.Zip.AddProgressEventArgs::.ctor(System.String,Ionic.Zip.ZipProgressEventType)
extern void AddProgressEventArgs__ctor_m8A72C16956B77A3D147F62229F238094E36AE0B1 (void);
// 0x00000019 Ionic.Zip.AddProgressEventArgs Ionic.Zip.AddProgressEventArgs::AfterEntry(System.String,Ionic.Zip.ZipEntry,System.Int32)
extern void AddProgressEventArgs_AfterEntry_mA7FCB7AC1CE81A1B200907E0756EE5959B317C6D (void);
// 0x0000001A System.Void Ionic.Zip.SaveProgressEventArgs::.ctor(System.String,System.Boolean,System.Int32,System.Int32,Ionic.Zip.ZipEntry)
extern void SaveProgressEventArgs__ctor_m4EB6CFF3900048F21E2DFEB1455E0FE3A470586F (void);
// 0x0000001B System.Void Ionic.Zip.SaveProgressEventArgs::.ctor(System.String,Ionic.Zip.ZipProgressEventType)
extern void SaveProgressEventArgs__ctor_m0EB678B0E583730FF782AF8A9DC0E978DFCAB3A9 (void);
// 0x0000001C Ionic.Zip.SaveProgressEventArgs Ionic.Zip.SaveProgressEventArgs::ByteUpdate(System.String,Ionic.Zip.ZipEntry,System.Int64,System.Int64)
extern void SaveProgressEventArgs_ByteUpdate_m50922FD89E5730126315A75C56945D52EF68977F (void);
// 0x0000001D Ionic.Zip.SaveProgressEventArgs Ionic.Zip.SaveProgressEventArgs::Started(System.String)
extern void SaveProgressEventArgs_Started_mF3AF36093FD14E1820D77969415334B484284890 (void);
// 0x0000001E Ionic.Zip.SaveProgressEventArgs Ionic.Zip.SaveProgressEventArgs::Completed(System.String)
extern void SaveProgressEventArgs_Completed_mE85F89302CA5CF7EAB092FD4689E22DC683EE8E3 (void);
// 0x0000001F System.Void Ionic.Zip.ExtractProgressEventArgs::.ctor(System.String,System.Boolean,System.Int32,System.Int32,Ionic.Zip.ZipEntry,System.String)
extern void ExtractProgressEventArgs__ctor_m9669902EFD937537DF024E7B9F5D23B50C3C7B0C (void);
// 0x00000020 System.Void Ionic.Zip.ExtractProgressEventArgs::.ctor(System.String,Ionic.Zip.ZipProgressEventType)
extern void ExtractProgressEventArgs__ctor_m1DFB16D8C75F60B74AD9430CB52E9F0A62F6935E (void);
// 0x00000021 System.Void Ionic.Zip.ExtractProgressEventArgs::.ctor()
extern void ExtractProgressEventArgs__ctor_m2C0DF3CF5665A0A593B2CA22ABBE4128794FCFE5 (void);
// 0x00000022 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::BeforeExtractEntry(System.String,Ionic.Zip.ZipEntry,System.String)
extern void ExtractProgressEventArgs_BeforeExtractEntry_m4A53397E7B04439595CE7D8179CBD3C8ACDDFEA9 (void);
// 0x00000023 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::ExtractExisting(System.String,Ionic.Zip.ZipEntry,System.String)
extern void ExtractProgressEventArgs_ExtractExisting_mFCB6EFEA305915C2D62CD934366E97982042BCEA (void);
// 0x00000024 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::AfterExtractEntry(System.String,Ionic.Zip.ZipEntry,System.String)
extern void ExtractProgressEventArgs_AfterExtractEntry_mB45B054E68EA6B3DD1004541245C5E5547671ACE (void);
// 0x00000025 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::ExtractAllStarted(System.String,System.String)
extern void ExtractProgressEventArgs_ExtractAllStarted_m91746F043DC450CE17A1A6C1AC40311577D01B6A (void);
// 0x00000026 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::ExtractAllCompleted(System.String,System.String)
extern void ExtractProgressEventArgs_ExtractAllCompleted_m7270F1E6E5BE075A516E1F1EFD78D9F1FADB7061 (void);
// 0x00000027 Ionic.Zip.ExtractProgressEventArgs Ionic.Zip.ExtractProgressEventArgs::ByteUpdate(System.String,Ionic.Zip.ZipEntry,System.Int64,System.Int64)
extern void ExtractProgressEventArgs_ByteUpdate_mFF546F169B7F3ACEB7710BCFDAA7BB71B220EB99 (void);
// 0x00000028 System.Void Ionic.Zip.ZipErrorEventArgs::.ctor()
extern void ZipErrorEventArgs__ctor_m2CD31930435309EFE87E3DDCA37529832C6C62FB (void);
// 0x00000029 Ionic.Zip.ZipErrorEventArgs Ionic.Zip.ZipErrorEventArgs::Saving(System.String,Ionic.Zip.ZipEntry,System.Exception)
extern void ZipErrorEventArgs_Saving_m3AA26DB32D03C3A09593B1A2A7D4555C0CDF6F9B (void);
// 0x0000002A System.Void Ionic.Zip.ZipException::.ctor()
extern void ZipException__ctor_m76A20C39E1EA5E6F664968AA695959A5C2A049B7 (void);
// 0x0000002B System.Void Ionic.Zip.ZipException::.ctor(System.String)
extern void ZipException__ctor_m0E3950E7747F3CB055136C1A5FB783D52357476A (void);
// 0x0000002C System.Void Ionic.Zip.ZipException::.ctor(System.String,System.Exception)
extern void ZipException__ctor_m741945E255987FB056D783BAFFE38BF8472CE5E6 (void);
// 0x0000002D System.Void Ionic.Zip.BadPasswordException::.ctor()
extern void BadPasswordException__ctor_m2D696AD57515D92E832420AAAF2EB761FB5421BD (void);
// 0x0000002E System.Void Ionic.Zip.BadPasswordException::.ctor(System.String)
extern void BadPasswordException__ctor_mB652887F01CF67531733BC1197EB64B3BBAC6C90 (void);
// 0x0000002F System.Void Ionic.Zip.BadReadException::.ctor(System.String)
extern void BadReadException__ctor_m651821049CAF3236EEB20336FD3A6EB01542924F (void);
// 0x00000030 System.Void Ionic.Zip.BadCrcException::.ctor(System.String)
extern void BadCrcException__ctor_m1F98E314260F08E6FD033957226E45CFB0119730 (void);
// 0x00000031 System.Void Ionic.Zip.BadStateException::.ctor(System.String)
extern void BadStateException__ctor_mC61C0C85A98C5D6B3038ACFD36DACB66AE8F0D90 (void);
// 0x00000032 System.Void Ionic.Zip.BadStateException::.ctor(System.String,System.Exception)
extern void BadStateException__ctor_m0E1547A0DC818FCD1061DDA54CFE903B6430E338 (void);
// 0x00000033 System.Int64 Ionic.Zip.SharedUtilities::GetFileLength(System.String)
extern void SharedUtilities_GetFileLength_m52BCFA4F16DAE0A22EDEC201FF7AF17151F155C9 (void);
// 0x00000034 System.String Ionic.Zip.SharedUtilities::SimplifyFwdSlashPath(System.String)
extern void SharedUtilities_SimplifyFwdSlashPath_m9997F056DCE37D8B78A1CC9EF29D0668997472D6 (void);
// 0x00000035 System.String Ionic.Zip.SharedUtilities::NormalizePathForUseInZipFile(System.String)
extern void SharedUtilities_NormalizePathForUseInZipFile_m92139AB12253230B34462263C7AC6D112A86B75F (void);
// 0x00000036 System.Byte[] Ionic.Zip.SharedUtilities::StringToByteArray(System.String,System.Text.Encoding)
extern void SharedUtilities_StringToByteArray_m76EF1B460101585935285211BD74718DD7558B6A (void);
// 0x00000037 System.Byte[] Ionic.Zip.SharedUtilities::StringToByteArray(System.String)
extern void SharedUtilities_StringToByteArray_m4DEF1BD7E9BF03EBD5B98F39A80C2F7C271191F5 (void);
// 0x00000038 System.String Ionic.Zip.SharedUtilities::Utf8StringFromBuffer(System.Byte[])
extern void SharedUtilities_Utf8StringFromBuffer_m919A16BBB1F96E074F5C4FD6EA9DBF1468DBBBA0 (void);
// 0x00000039 System.String Ionic.Zip.SharedUtilities::StringFromBuffer(System.Byte[],System.Text.Encoding)
extern void SharedUtilities_StringFromBuffer_m29EA6B7D44E5B4602E350A0397A3A50320DB069F (void);
// 0x0000003A System.Int32 Ionic.Zip.SharedUtilities::ReadSignature(System.IO.Stream)
extern void SharedUtilities_ReadSignature_mEC34968DA65E1E98229658D13D06DD298B715589 (void);
// 0x0000003B System.Int32 Ionic.Zip.SharedUtilities::ReadEntrySignature(System.IO.Stream)
extern void SharedUtilities_ReadEntrySignature_m6785F532D030A3A548FB8A944386EBD54AE689B5 (void);
// 0x0000003C System.Int32 Ionic.Zip.SharedUtilities::ReadInt(System.IO.Stream)
extern void SharedUtilities_ReadInt_mF293A3F8623E35FF50F76A019D1A3B2C3E2328C0 (void);
// 0x0000003D System.Int32 Ionic.Zip.SharedUtilities::_ReadFourBytes(System.IO.Stream,System.String)
extern void SharedUtilities__ReadFourBytes_mE8E24E19530F117D20526845420EA5DFD1344B03 (void);
// 0x0000003E System.Int64 Ionic.Zip.SharedUtilities::FindSignature(System.IO.Stream,System.Int32)
extern void SharedUtilities_FindSignature_m23E09586F5B323521366CA9D5982C651E5396E26 (void);
// 0x0000003F System.DateTime Ionic.Zip.SharedUtilities::PackedToDateTime(System.Int32)
extern void SharedUtilities_PackedToDateTime_m30871A6C29E0E1C95A1E2B49D0B202F1050FB8CB (void);
// 0x00000040 System.Int32 Ionic.Zip.SharedUtilities::DateTimeToPacked(System.DateTime)
extern void SharedUtilities_DateTimeToPacked_m76EBF9271FA90A2F74125A8D8F9EB45325E4EE82 (void);
// 0x00000041 System.Void Ionic.Zip.SharedUtilities::CreateAndOpenUniqueTempFile(System.String,System.IO.Stream&,System.String&)
extern void SharedUtilities_CreateAndOpenUniqueTempFile_mA65AA77AE58BCA5F8D1E15FD7A3960EE20864B4D (void);
// 0x00000042 System.String Ionic.Zip.SharedUtilities::InternalGetTempFileName()
extern void SharedUtilities_InternalGetTempFileName_mC45C85E3D5651792535E4926F4BC6A55D5ADFF6B (void);
// 0x00000043 System.String Ionic.Zip.SharedUtilities::GenerateRandomStringImpl(System.Int32,System.Int32)
extern void SharedUtilities_GenerateRandomStringImpl_m7EC30498CB6B886AF5CD45CE489FDE6D7294EB08 (void);
// 0x00000044 System.Int32 Ionic.Zip.SharedUtilities::ReadWithRetry(System.IO.Stream,System.Byte[],System.Int32,System.Int32,System.String)
extern void SharedUtilities_ReadWithRetry_mF8136271DDD542A54FAC4969C9904D4678E369A2 (void);
// 0x00000045 System.Void Ionic.Zip.SharedUtilities::.cctor()
extern void SharedUtilities__cctor_m8764CFEBED7B7EDEC94DA9E0E1700FF644F19F06 (void);
// 0x00000046 System.Void Ionic.Zip.CountingStream::.ctor(System.IO.Stream)
extern void CountingStream__ctor_mB1D3BFD82AEC5FA402093E430ADF1735511E88E3 (void);
// 0x00000047 System.Int64 Ionic.Zip.CountingStream::get_BytesWritten()
extern void CountingStream_get_BytesWritten_mC6BC8AA819894349F81CF043AAA40A9FCA41AB29 (void);
// 0x00000048 System.Int64 Ionic.Zip.CountingStream::get_BytesRead()
extern void CountingStream_get_BytesRead_m3A26420FE4989A29D1E68D69603FBD7E74C5E717 (void);
// 0x00000049 System.Void Ionic.Zip.CountingStream::Adjust(System.Int64)
extern void CountingStream_Adjust_m139414D83AEC74B11238870A775095A25088974B (void);
// 0x0000004A System.Int32 Ionic.Zip.CountingStream::Read(System.Byte[],System.Int32,System.Int32)
extern void CountingStream_Read_m97CF074050FF34951C3427FDE9BEA23F2CAEC91E (void);
// 0x0000004B System.Void Ionic.Zip.CountingStream::Write(System.Byte[],System.Int32,System.Int32)
extern void CountingStream_Write_mACBA1738C20DDB98817EEEB7D2EE52F448D693D0 (void);
// 0x0000004C System.Boolean Ionic.Zip.CountingStream::get_CanRead()
extern void CountingStream_get_CanRead_m1BFB811C9632363F61425A1E5F752011A44600CE (void);
// 0x0000004D System.Boolean Ionic.Zip.CountingStream::get_CanSeek()
extern void CountingStream_get_CanSeek_mA6951D3C29ECC68DBD52253F2DF5459EEB5C9EC2 (void);
// 0x0000004E System.Boolean Ionic.Zip.CountingStream::get_CanWrite()
extern void CountingStream_get_CanWrite_m92CF233F73B0D14B77F0813F69E2E732C3D46D94 (void);
// 0x0000004F System.Void Ionic.Zip.CountingStream::Flush()
extern void CountingStream_Flush_m309F79117222A730E5116AED8675186B666764F8 (void);
// 0x00000050 System.Int64 Ionic.Zip.CountingStream::get_Length()
extern void CountingStream_get_Length_mD4399D05BC1A4E3B2F7489A1821717A51A9CBCB9 (void);
// 0x00000051 System.Int64 Ionic.Zip.CountingStream::get_ComputedPosition()
extern void CountingStream_get_ComputedPosition_m8F28E26D2B4AB3B0387DB330BC154028CB11E0CB (void);
// 0x00000052 System.Int64 Ionic.Zip.CountingStream::get_Position()
extern void CountingStream_get_Position_m34B5820E011C7BAE9ABBFD87FA90449E934F90BB (void);
// 0x00000053 System.Void Ionic.Zip.CountingStream::set_Position(System.Int64)
extern void CountingStream_set_Position_m498FA27C3C65B280425760B12D4927886D14C052 (void);
// 0x00000054 System.Int64 Ionic.Zip.CountingStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void CountingStream_Seek_m20C088D7380008EBBE5632BB3814769BA257D02B (void);
// 0x00000055 System.Void Ionic.Zip.CountingStream::SetLength(System.Int64)
extern void CountingStream_SetLength_m46463D20EF012391D485428B90F89A7968CF8603 (void);
// 0x00000056 System.Void Ionic.Zip.WinZipAesCrypto::.ctor(System.String,System.Int32)
extern void WinZipAesCrypto__ctor_m156438B476206EADBBEBDDF6F8B33DE16E3DD298 (void);
// 0x00000057 Ionic.Zip.WinZipAesCrypto Ionic.Zip.WinZipAesCrypto::Generate(System.String,System.Int32)
extern void WinZipAesCrypto_Generate_m1D28E83A91B4583BA04EB6564D4F034C4C21E7BE (void);
// 0x00000058 Ionic.Zip.WinZipAesCrypto Ionic.Zip.WinZipAesCrypto::ReadFromStream(System.String,System.Int32,System.IO.Stream)
extern void WinZipAesCrypto_ReadFromStream_m920C37A863FAB4BE78E3F25B086E50E62A4703C6 (void);
// 0x00000059 System.Byte[] Ionic.Zip.WinZipAesCrypto::get_GeneratedPV()
extern void WinZipAesCrypto_get_GeneratedPV_mEDA3219F124AE129CA04AA8E8D0BDADAE0875087 (void);
// 0x0000005A System.Byte[] Ionic.Zip.WinZipAesCrypto::get_Salt()
extern void WinZipAesCrypto_get_Salt_mE1A6403AD8D733D7C0DB3DD470AB0655F1A451A5 (void);
// 0x0000005B System.Int32 Ionic.Zip.WinZipAesCrypto::get__KeyStrengthInBytes()
extern void WinZipAesCrypto_get__KeyStrengthInBytes_m071D49D785A65A40012FE3498A5901EC51B656D2 (void);
// 0x0000005C System.Int32 Ionic.Zip.WinZipAesCrypto::get_SizeOfEncryptionMetadata()
extern void WinZipAesCrypto_get_SizeOfEncryptionMetadata_m53461AAC0778009C6134AD4639D511DC3F56599B (void);
// 0x0000005D System.Void Ionic.Zip.WinZipAesCrypto::set_Password(System.String)
extern void WinZipAesCrypto_set_Password_mD0B9AB23BD20C87E17F9D550B6FE5CC53A37C431 (void);
// 0x0000005E System.Void Ionic.Zip.WinZipAesCrypto::_GenerateCryptoBytes()
extern void WinZipAesCrypto__GenerateCryptoBytes_m21B73A15D79C14003E9CBFF05960B08E3F9A30F8 (void);
// 0x0000005F System.Byte[] Ionic.Zip.WinZipAesCrypto::get_KeyBytes()
extern void WinZipAesCrypto_get_KeyBytes_m71AE0A00A84F487AA31A27F7910780C7237F9591 (void);
// 0x00000060 System.Byte[] Ionic.Zip.WinZipAesCrypto::get_MacIv()
extern void WinZipAesCrypto_get_MacIv_m86D8251BA50DD1E925BFE8C8594D4E7E1FBDF345 (void);
// 0x00000061 System.Void Ionic.Zip.WinZipAesCrypto::ReadAndVerifyMac(System.IO.Stream)
extern void WinZipAesCrypto_ReadAndVerifyMac_mF835FE006322125375F0B9D7E690E443C7C96F1E (void);
// 0x00000062 System.Void Ionic.Zip.WinZipAesCipherStream::.ctor(System.IO.Stream,Ionic.Zip.WinZipAesCrypto,System.Int64,Ionic.Zip.CryptoMode)
extern void WinZipAesCipherStream__ctor_m8A21B4A2D88E087E8E92147595F8C550DFD15F5B (void);
// 0x00000063 System.Void Ionic.Zip.WinZipAesCipherStream::.ctor(System.IO.Stream,Ionic.Zip.WinZipAesCrypto,Ionic.Zip.CryptoMode)
extern void WinZipAesCipherStream__ctor_m3DFA94FD97730CDBD39C5FADFDE73E1F0EA7AFDA (void);
// 0x00000064 System.Void Ionic.Zip.WinZipAesCipherStream::XorInPlace(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_XorInPlace_mA4C805A060DE8FC2B39C068FD3661E0F9720EAA8 (void);
// 0x00000065 System.Void Ionic.Zip.WinZipAesCipherStream::WriteTransformOneBlock(System.Byte[],System.Int32)
extern void WinZipAesCipherStream_WriteTransformOneBlock_m9F3E4A4405785CFD7C2893862E7BBCB7C7AC9D35 (void);
// 0x00000066 System.Void Ionic.Zip.WinZipAesCipherStream::WriteTransformBlocks(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_WriteTransformBlocks_m68851DFBBB94ABDBA7FBAC097553ECF6EA9883FA (void);
// 0x00000067 System.Void Ionic.Zip.WinZipAesCipherStream::WriteTransformFinalBlock()
extern void WinZipAesCipherStream_WriteTransformFinalBlock_m4D71B53395D30F28FD51ADC8FB4B63880B636B7B (void);
// 0x00000068 System.Int32 Ionic.Zip.WinZipAesCipherStream::ReadTransformOneBlock(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_ReadTransformOneBlock_m008A92516FA87B4733333912E147CEACCF259C97 (void);
// 0x00000069 System.Void Ionic.Zip.WinZipAesCipherStream::ReadTransformBlocks(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_ReadTransformBlocks_mB16230490DEF2635DC14ADB9DB58A9470EB758C3 (void);
// 0x0000006A System.Int32 Ionic.Zip.WinZipAesCipherStream::Read(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_Read_m7A9A5B45A935D1FFAD41DBD3724F80A5A650E509 (void);
// 0x0000006B System.Byte[] Ionic.Zip.WinZipAesCipherStream::get_FinalAuthentication()
extern void WinZipAesCipherStream_get_FinalAuthentication_m54F35D40E16C96B60343072C3F04836E7BE14013 (void);
// 0x0000006C System.Void Ionic.Zip.WinZipAesCipherStream::Write(System.Byte[],System.Int32,System.Int32)
extern void WinZipAesCipherStream_Write_mD631C75F3E9157C1BC5615E20BDBF1E153DAB631 (void);
// 0x0000006D System.Void Ionic.Zip.WinZipAesCipherStream::Close()
extern void WinZipAesCipherStream_Close_m034D8089F886BA0A5035FCE8E43D83BF6EB0F80F (void);
// 0x0000006E System.Boolean Ionic.Zip.WinZipAesCipherStream::get_CanRead()
extern void WinZipAesCipherStream_get_CanRead_mD21202A1E9CB6A1F7C1D7C7C89CC5B12E2B9A6F6 (void);
// 0x0000006F System.Boolean Ionic.Zip.WinZipAesCipherStream::get_CanSeek()
extern void WinZipAesCipherStream_get_CanSeek_m40ECEC160A6EB5637A2D929FB9F1E735617C9A26 (void);
// 0x00000070 System.Boolean Ionic.Zip.WinZipAesCipherStream::get_CanWrite()
extern void WinZipAesCipherStream_get_CanWrite_mFF24FE0C976B4AB4642669B49D777F26A83B9B76 (void);
// 0x00000071 System.Void Ionic.Zip.WinZipAesCipherStream::Flush()
extern void WinZipAesCipherStream_Flush_m9C3EDD758A868E36F6C6F7832E74A868D20217A5 (void);
// 0x00000072 System.Int64 Ionic.Zip.WinZipAesCipherStream::get_Length()
extern void WinZipAesCipherStream_get_Length_mD09820E41573AE89FE31D1F15EE498455BD34046 (void);
// 0x00000073 System.Int64 Ionic.Zip.WinZipAesCipherStream::get_Position()
extern void WinZipAesCipherStream_get_Position_m24D3A4DA8735A06B4AEF2A7B5370A58E6DCACBB6 (void);
// 0x00000074 System.Void Ionic.Zip.WinZipAesCipherStream::set_Position(System.Int64)
extern void WinZipAesCipherStream_set_Position_mEE15C45E714BED7EA8A1741B99E3AFB2D3FA9312 (void);
// 0x00000075 System.Int64 Ionic.Zip.WinZipAesCipherStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void WinZipAesCipherStream_Seek_m01C1AC3CE8AAE76944E54AFE91F418A080745EFC (void);
// 0x00000076 System.Void Ionic.Zip.WinZipAesCipherStream::SetLength(System.Int64)
extern void WinZipAesCipherStream_SetLength_m7BFC24CE0DD54F937C5397C1524B9CD36B3D6496 (void);
// 0x00000077 System.Void Ionic.Zip.ZipCrypto::.ctor()
extern void ZipCrypto__ctor_mA72667EF060E4EBF021A82BD486EF98C86428263 (void);
// 0x00000078 Ionic.Zip.ZipCrypto Ionic.Zip.ZipCrypto::ForWrite(System.String)
extern void ZipCrypto_ForWrite_m959B012C63EF05A354BCAF9679E4C46950A1DA6A (void);
// 0x00000079 Ionic.Zip.ZipCrypto Ionic.Zip.ZipCrypto::ForRead(System.String,Ionic.Zip.ZipEntry)
extern void ZipCrypto_ForRead_m25D3B5D55B0C6EF8E23CE7860DAEA90C45C5FACA (void);
// 0x0000007A System.Byte Ionic.Zip.ZipCrypto::get_MagicByte()
extern void ZipCrypto_get_MagicByte_m83251A0890973EBB88E62D7690ABBBED47A3C0C7 (void);
// 0x0000007B System.Byte[] Ionic.Zip.ZipCrypto::DecryptMessage(System.Byte[],System.Int32)
extern void ZipCrypto_DecryptMessage_m7033AB2856A4E0CBB828843A2D3E4B3D35CB57F5 (void);
// 0x0000007C System.Byte[] Ionic.Zip.ZipCrypto::EncryptMessage(System.Byte[],System.Int32)
extern void ZipCrypto_EncryptMessage_m0CB62E523AEAC62D8664683C524324A47B78CC72 (void);
// 0x0000007D System.Void Ionic.Zip.ZipCrypto::InitCipher(System.String)
extern void ZipCrypto_InitCipher_m92EAE35C8ABF3CB4EA83F5A3A6FB3474BCF8AAE5 (void);
// 0x0000007E System.Void Ionic.Zip.ZipCrypto::UpdateKeys(System.Byte)
extern void ZipCrypto_UpdateKeys_mB9ED11648A463CB8D9D7DE36CDD09B0B6FB5B892 (void);
// 0x0000007F System.Void Ionic.Zip.ZipCipherStream::.ctor(System.IO.Stream,Ionic.Zip.ZipCrypto,Ionic.Zip.CryptoMode)
extern void ZipCipherStream__ctor_m46BC9512787ADA77D21CF7D4F682D1DA2A8719E3 (void);
// 0x00000080 System.Int32 Ionic.Zip.ZipCipherStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipCipherStream_Read_m4630188F51081410A1CE2B37FD0F3AC1EAAC77F2 (void);
// 0x00000081 System.Void Ionic.Zip.ZipCipherStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipCipherStream_Write_m6F40C1C12F562D2F43CE8A7A87952D053CC86191 (void);
// 0x00000082 System.Boolean Ionic.Zip.ZipCipherStream::get_CanRead()
extern void ZipCipherStream_get_CanRead_mB58BCE6BEC7466E362A30AE577FDAED88E6E1F05 (void);
// 0x00000083 System.Boolean Ionic.Zip.ZipCipherStream::get_CanSeek()
extern void ZipCipherStream_get_CanSeek_m3EE862C3AD8EC4CEAC494892C1CDBE14C7635F96 (void);
// 0x00000084 System.Boolean Ionic.Zip.ZipCipherStream::get_CanWrite()
extern void ZipCipherStream_get_CanWrite_m99F172A52502A5CD99980AB4F74C832E80143603 (void);
// 0x00000085 System.Void Ionic.Zip.ZipCipherStream::Flush()
extern void ZipCipherStream_Flush_m3FC2D039280759A01826B1C01D92F30F5A7DF6E2 (void);
// 0x00000086 System.Int64 Ionic.Zip.ZipCipherStream::get_Length()
extern void ZipCipherStream_get_Length_m567565D0F06DA527F9BBBACD99BF8F8BC9301C72 (void);
// 0x00000087 System.Int64 Ionic.Zip.ZipCipherStream::get_Position()
extern void ZipCipherStream_get_Position_mA115C176883CEB3CA8311A0CC3CA0F04B7B84E9D (void);
// 0x00000088 System.Void Ionic.Zip.ZipCipherStream::set_Position(System.Int64)
extern void ZipCipherStream_set_Position_mBC174FB190D123161CAD299679F209FCC6CB2BBF (void);
// 0x00000089 System.Int64 Ionic.Zip.ZipCipherStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZipCipherStream_Seek_mB73F2E811127324768784CA1D5E492C80141A70F (void);
// 0x0000008A System.Void Ionic.Zip.ZipCipherStream::SetLength(System.Int64)
extern void ZipCipherStream_SetLength_m4E03D99E76EB6C9AAD2736FDA0C45F5C3CA364CC (void);
// 0x0000008B System.Boolean Ionic.Zip.ZipEntry::get_AttributesIndicateDirectory()
extern void ZipEntry_get_AttributesIndicateDirectory_mFC9A596F6A62F1A66A837247100689D22434823D (void);
// 0x0000008C System.Void Ionic.Zip.ZipEntry::ResetDirEntry()
extern void ZipEntry_ResetDirEntry_mA0AA243AD75A4FC71D020BDEA3A37A93C04D1FB1 (void);
// 0x0000008D Ionic.Zip.ZipEntry Ionic.Zip.ZipEntry::ReadDirEntry(Ionic.Zip.ZipFile,System.Collections.Generic.Dictionary`2<System.String,System.Object>)
extern void ZipEntry_ReadDirEntry_mC803809F96F9F59B4D6853EE019ACF6260B54130 (void);
// 0x0000008E System.Boolean Ionic.Zip.ZipEntry::IsNotValidZipDirEntrySig(System.Int32)
extern void ZipEntry_IsNotValidZipDirEntrySig_m879B2FDD1122D56549F7234FDBD7B1A0C6E0A29D (void);
// 0x0000008F System.Void Ionic.Zip.ZipEntry::.ctor()
extern void ZipEntry__ctor_m4B0D9F955EBAC6ABA29550BF878891358A51AA51 (void);
// 0x00000090 System.DateTime Ionic.Zip.ZipEntry::get_LastModified()
extern void ZipEntry_get_LastModified_m492D436EE451489577644F70B65A6DEB64F5DF4A (void);
// 0x00000091 System.Int32 Ionic.Zip.ZipEntry::get_BufferSize()
extern void ZipEntry_get_BufferSize_mF84EF1748B8352F8A562AA094E6EE339257F442F (void);
// 0x00000092 System.Void Ionic.Zip.ZipEntry::SetEntryTimes(System.DateTime,System.DateTime,System.DateTime)
extern void ZipEntry_SetEntryTimes_mBC80BE3B794F8853AAAFF170514ABA28520BDF8D (void);
// 0x00000093 System.Void Ionic.Zip.ZipEntry::set_EmitTimesInWindowsFormatWhenSaving(System.Boolean)
extern void ZipEntry_set_EmitTimesInWindowsFormatWhenSaving_m0D7189AB9B74FD9C2926F1DF4B68B50313557D63 (void);
// 0x00000094 System.Void Ionic.Zip.ZipEntry::set_EmitTimesInUnixFormatWhenSaving(System.Boolean)
extern void ZipEntry_set_EmitTimesInUnixFormatWhenSaving_m1AC5F6779ACF4EA024006FA113BD837761474C97 (void);
// 0x00000095 System.String Ionic.Zip.ZipEntry::get_LocalFileName()
extern void ZipEntry_get_LocalFileName_m1AA6225E71223F4F71249AC5C4CBB874E0A03FFB (void);
// 0x00000096 System.String Ionic.Zip.ZipEntry::get_FileName()
extern void ZipEntry_get_FileName_mF864C6D4828CA38DE69ABF009AD151E0529F718D (void);
// 0x00000097 System.Int16 Ionic.Zip.ZipEntry::get_VersionNeeded()
extern void ZipEntry_get_VersionNeeded_m537192D2F24384B72734A85885B3EA604CB04ECE (void);
// 0x00000098 System.String Ionic.Zip.ZipEntry::get_Comment()
extern void ZipEntry_get_Comment_mBC0C80D72F7F02065309C35B6C8450B0FE623B4E (void);
// 0x00000099 System.Nullable`1<System.Boolean> Ionic.Zip.ZipEntry::get_OutputUsedZip64()
extern void ZipEntry_get_OutputUsedZip64_m391A1A87DE657C76DC034318795234B3178A9B2B (void);
// 0x0000009A Ionic.Zip.CompressionMethod Ionic.Zip.ZipEntry::get_CompressionMethod()
extern void ZipEntry_get_CompressionMethod_m9103CA4DA4B7C29E491B2CFFFD8B8019DECD2A8A (void);
// 0x0000009B System.Void Ionic.Zip.ZipEntry::set_CompressionMethod(Ionic.Zip.CompressionMethod)
extern void ZipEntry_set_CompressionMethod_m91A2FE22B638804DA03560E6B499E0B70B60B11A (void);
// 0x0000009C Ionic.Zlib.CompressionLevel Ionic.Zip.ZipEntry::get_CompressionLevel()
extern void ZipEntry_get_CompressionLevel_mB46B7F1EB23FE0EB8FAC99EE94DB16BFF287F8B2 (void);
// 0x0000009D System.Void Ionic.Zip.ZipEntry::set_CompressionLevel(Ionic.Zlib.CompressionLevel)
extern void ZipEntry_set_CompressionLevel_m911503BDC9F8B6C66B0D29BEF3AAB19DF0206DED (void);
// 0x0000009E System.Int64 Ionic.Zip.ZipEntry::get_CompressedSize()
extern void ZipEntry_get_CompressedSize_mE1904DF19A834DC7DE7FFD8F6AE34860C21A2631 (void);
// 0x0000009F System.Int64 Ionic.Zip.ZipEntry::get_UncompressedSize()
extern void ZipEntry_get_UncompressedSize_mDF07EF7542F807FF694B82A9037EAB56FF7F1FFF (void);
// 0x000000A0 System.Double Ionic.Zip.ZipEntry::get_CompressionRatio()
extern void ZipEntry_get_CompressionRatio_mC08E8E8C9475A35D2E8AAC2966D0E1A45588FA81 (void);
// 0x000000A1 System.Boolean Ionic.Zip.ZipEntry::get_IsDirectory()
extern void ZipEntry_get_IsDirectory_mD095F7213A78A00F82A4C3147E3A44CB8FF96F05 (void);
// 0x000000A2 Ionic.Zip.EncryptionAlgorithm Ionic.Zip.ZipEntry::get_Encryption()
extern void ZipEntry_get_Encryption_m9F5C55393A212CF88F46B98863CE98A1CDE12BB4 (void);
// 0x000000A3 System.Void Ionic.Zip.ZipEntry::set_Encryption(Ionic.Zip.EncryptionAlgorithm)
extern void ZipEntry_set_Encryption_mA432E3E028F788879017F78B28D5FC537E4C036C (void);
// 0x000000A4 System.Void Ionic.Zip.ZipEntry::set_Password(System.String)
extern void ZipEntry_set_Password_m7E08A3DC1FEFA6C149440AB546C1DB4340D6DA5B (void);
// 0x000000A5 Ionic.Zip.ExtractExistingFileAction Ionic.Zip.ZipEntry::get_ExtractExistingFile()
extern void ZipEntry_get_ExtractExistingFile_m71B71C1DBBC32A399E3FB26EDC6DA11262839A81 (void);
// 0x000000A6 System.Void Ionic.Zip.ZipEntry::set_ExtractExistingFile(Ionic.Zip.ExtractExistingFileAction)
extern void ZipEntry_set_ExtractExistingFile_m6399CAAD7D6A73431CFAFB9C01C390849F810E64 (void);
// 0x000000A7 Ionic.Zip.ZipErrorAction Ionic.Zip.ZipEntry::get_ZipErrorAction()
extern void ZipEntry_get_ZipErrorAction_m2804B08E54643DA5C34B0C63B49CC6375B9788AD (void);
// 0x000000A8 System.Void Ionic.Zip.ZipEntry::set_ZipErrorAction(Ionic.Zip.ZipErrorAction)
extern void ZipEntry_set_ZipErrorAction_m7F80D92F3B2F28D440FC55AB88CAD7552C14C55D (void);
// 0x000000A9 System.Boolean Ionic.Zip.ZipEntry::get_IncludedInMostRecentSave()
extern void ZipEntry_get_IncludedInMostRecentSave_m3A8DDAB7B8C4059050E5E118644FC7F5A2AF4998 (void);
// 0x000000AA Ionic.Zip.SetCompressionCallback Ionic.Zip.ZipEntry::get_SetCompression()
extern void ZipEntry_get_SetCompression_m53E48CA6B4277C0FF58586DA9A19C0319B14B9BC (void);
// 0x000000AB System.Void Ionic.Zip.ZipEntry::set_SetCompression(Ionic.Zip.SetCompressionCallback)
extern void ZipEntry_set_SetCompression_mAB90EF22F487AEC7E26325C6B3CA71ECDB96F368 (void);
// 0x000000AC System.Text.Encoding Ionic.Zip.ZipEntry::get_AlternateEncoding()
extern void ZipEntry_get_AlternateEncoding_m5A0CBE5ACED3D4B08F99F7E0E4C3F18603063574 (void);
// 0x000000AD System.Void Ionic.Zip.ZipEntry::set_AlternateEncoding(System.Text.Encoding)
extern void ZipEntry_set_AlternateEncoding_mFD7FDF5DF2F9F02B75A69359EF7D19E7EF4E80F9 (void);
// 0x000000AE Ionic.Zip.ZipOption Ionic.Zip.ZipEntry::get_AlternateEncodingUsage()
extern void ZipEntry_get_AlternateEncodingUsage_m6A17179B91F451A97E9FC0EB42C2D39FEDBF590F (void);
// 0x000000AF System.Void Ionic.Zip.ZipEntry::set_AlternateEncodingUsage(Ionic.Zip.ZipOption)
extern void ZipEntry_set_AlternateEncodingUsage_m28B464A9E329FE90299C8B8BE862C93D0BFD6DC6 (void);
// 0x000000B0 System.String Ionic.Zip.ZipEntry::NameInArchive(System.String,System.String)
extern void ZipEntry_NameInArchive_m083F2E6D4F9A430196F108C267A7BE5BA04B1327 (void);
// 0x000000B1 Ionic.Zip.ZipEntry Ionic.Zip.ZipEntry::CreateForStream(System.String,System.IO.Stream)
extern void ZipEntry_CreateForStream_mCBB4544AD70796680C146DEBA5F2685ED005C00A (void);
// 0x000000B2 Ionic.Zip.ZipEntry Ionic.Zip.ZipEntry::Create(System.String,Ionic.Zip.ZipEntrySource,System.Object,System.Object)
extern void ZipEntry_Create_mE2A5BA68E922BF6850D221FF6AE80DC362682CBF (void);
// 0x000000B3 System.Void Ionic.Zip.ZipEntry::MarkAsDirectory()
extern void ZipEntry_MarkAsDirectory_m023FF50C21CC9A80AADD74038DA4927039173BF5 (void);
// 0x000000B4 System.Void Ionic.Zip.ZipEntry::set_IsText(System.Boolean)
extern void ZipEntry_set_IsText_mF40B5FC07BD3D7E5365C51E4E9FB35ED94A0DBC6 (void);
// 0x000000B5 System.String Ionic.Zip.ZipEntry::ToString()
extern void ZipEntry_ToString_m1D5BB7398C978F630EBC20996BE67468106ABB19 (void);
// 0x000000B6 System.IO.Stream Ionic.Zip.ZipEntry::get_ArchiveStream()
extern void ZipEntry_get_ArchiveStream_mFC7C43F8EB896D5AE5C9ACC387145BF6D4B565BD (void);
// 0x000000B7 System.Void Ionic.Zip.ZipEntry::SetFdpLoh()
extern void ZipEntry_SetFdpLoh_m4818A6FC83DDA4B589D3F315CF214A80D2FD8A93 (void);
// 0x000000B8 System.Int32 Ionic.Zip.ZipEntry::GetKeyStrengthInBits(Ionic.Zip.EncryptionAlgorithm)
extern void ZipEntry_GetKeyStrengthInBits_m7FEE948F3F05896EFCF86737F5D0294E5AB93166 (void);
// 0x000000B9 System.Int32 Ionic.Zip.ZipEntry::GetLengthOfCryptoHeaderBytes(Ionic.Zip.EncryptionAlgorithm)
extern void ZipEntry_GetLengthOfCryptoHeaderBytes_m1267B98F8D67E15B701377FA9988137636D03774 (void);
// 0x000000BA System.Int64 Ionic.Zip.ZipEntry::get_FileDataPosition()
extern void ZipEntry_get_FileDataPosition_m619A0566DCDE69A6E7D2BA4B4B1ED797DE7FBF6F (void);
// 0x000000BB System.Int32 Ionic.Zip.ZipEntry::get_LengthOfHeader()
extern void ZipEntry_get_LengthOfHeader_mA9321B2AC1E70C199103687D64E7DF0BEA1861CA (void);
// 0x000000BC System.Void Ionic.Zip.ZipEntry::Extract(System.IO.Stream)
extern void ZipEntry_Extract_mEF265E0A8D3AA6028B89F77EE2BA785A5255C627 (void);
// 0x000000BD System.Void Ionic.Zip.ZipEntry::Extract(System.String)
extern void ZipEntry_Extract_m8251FCC30872C4A78CDF9ACEAFC99268391D6F96 (void);
// 0x000000BE System.Void Ionic.Zip.ZipEntry::Extract(System.String,Ionic.Zip.ExtractExistingFileAction)
extern void ZipEntry_Extract_m2F376CD7D7F1DBC5BFE7AE53EF18E341CD32ADE1 (void);
// 0x000000BF Ionic.Crc.CrcCalculatorStream Ionic.Zip.ZipEntry::InternalOpenReader(System.String)
extern void ZipEntry_InternalOpenReader_mD959076F0EEE41920CE90343018BF20E3D3CD412 (void);
// 0x000000C0 System.Void Ionic.Zip.ZipEntry::OnExtractProgress(System.Int64,System.Int64)
extern void ZipEntry_OnExtractProgress_mC2F0481E7E28C48CCC1AD8A9422BD1B318F2D315 (void);
// 0x000000C1 System.Void Ionic.Zip.ZipEntry::OnBeforeExtract(System.String)
extern void ZipEntry_OnBeforeExtract_m6AB24EBB0DCC836E336E738D9B03BD8615E83344 (void);
// 0x000000C2 System.Void Ionic.Zip.ZipEntry::OnAfterExtract(System.String)
extern void ZipEntry_OnAfterExtract_m33FE34C7FBE56F3ACB128488D093175600ADA776 (void);
// 0x000000C3 System.Void Ionic.Zip.ZipEntry::OnExtractExisting(System.String)
extern void ZipEntry_OnExtractExisting_mFF4D4F1267284A961721A6E5B1412EE11B53BFED (void);
// 0x000000C4 System.Void Ionic.Zip.ZipEntry::ReallyDelete(System.String)
extern void ZipEntry_ReallyDelete_m52E0CA04B580019CD9408CFD5BF11BF986D49294 (void);
// 0x000000C5 System.Void Ionic.Zip.ZipEntry::WriteStatus(System.String,System.Object[])
extern void ZipEntry_WriteStatus_m53934C557721CA5BF943DF88DA96A10D85C6F1D4 (void);
// 0x000000C6 System.Void Ionic.Zip.ZipEntry::InternalExtract(System.String,System.IO.Stream,System.String)
extern void ZipEntry_InternalExtract_m4577204ADAD1F6AA1F00FEE78C1B1AC9B2ECE06C (void);
// 0x000000C7 System.Void Ionic.Zip.ZipEntry::VerifyCrcAfterExtract(System.Int32)
extern void ZipEntry_VerifyCrcAfterExtract_mA66FA7B962ECDFC81AAF8F6399EF51F67DD2B042 (void);
// 0x000000C8 System.Int32 Ionic.Zip.ZipEntry::CheckExtractExistingFile(System.String,System.String)
extern void ZipEntry_CheckExtractExistingFile_mFE2B41B02FABE7A7C6F3C60971A0F2DC4DCD6C73 (void);
// 0x000000C9 System.Void Ionic.Zip.ZipEntry::_CheckRead(System.Int32)
extern void ZipEntry__CheckRead_m38A90D3B714A2B5D61A8014DEEDF5C677F1CCF26 (void);
// 0x000000CA System.Int32 Ionic.Zip.ZipEntry::ExtractOne(System.IO.Stream)
extern void ZipEntry_ExtractOne_m50295EC44E4CFDD666CA7BA5E379FC5178CEE266 (void);
// 0x000000CB System.IO.Stream Ionic.Zip.ZipEntry::GetExtractDecompressor(System.IO.Stream)
extern void ZipEntry_GetExtractDecompressor_m1E524EFE427C1EF2E0072DF87DC933E273471F21 (void);
// 0x000000CC System.IO.Stream Ionic.Zip.ZipEntry::GetExtractDecryptor(System.IO.Stream)
extern void ZipEntry_GetExtractDecryptor_m254A11D6A6CB2D66FF978D72F39652D1DD75C81A (void);
// 0x000000CD System.Void Ionic.Zip.ZipEntry::_SetTimes(System.String,System.Boolean)
extern void ZipEntry__SetTimes_m01B415BA31D56F1D85802CB0042304C685D277ED (void);
// 0x000000CE System.String Ionic.Zip.ZipEntry::get_UnsupportedAlgorithm()
extern void ZipEntry_get_UnsupportedAlgorithm_m978B1B04883E7453FB7110E1FFD316692F63B87C (void);
// 0x000000CF System.String Ionic.Zip.ZipEntry::get_UnsupportedCompressionMethod()
extern void ZipEntry_get_UnsupportedCompressionMethod_mBB1041C60DE8DA7AFD2541B10E48CF455EF1A42E (void);
// 0x000000D0 System.Void Ionic.Zip.ZipEntry::ValidateEncryption()
extern void ZipEntry_ValidateEncryption_m334587E1BC96C603850EAB1252F564717FA20BF2 (void);
// 0x000000D1 System.Void Ionic.Zip.ZipEntry::ValidateCompression()
extern void ZipEntry_ValidateCompression_mF6828EB22F5B51BB21C0117C9D74660F92275C85 (void);
// 0x000000D2 System.Void Ionic.Zip.ZipEntry::SetupCryptoForExtract(System.String)
extern void ZipEntry_SetupCryptoForExtract_m1E4AD1ECBBB64272D24911B98FBE4DBA0B6EB096 (void);
// 0x000000D3 System.Boolean Ionic.Zip.ZipEntry::ValidateOutput(System.String,System.IO.Stream,System.String&)
extern void ZipEntry_ValidateOutput_m35E8368C1681D6DDE9AC3CA71618A463F4CE5840 (void);
// 0x000000D4 System.Boolean Ionic.Zip.ZipEntry::ReadHeader(Ionic.Zip.ZipEntry,System.Text.Encoding)
extern void ZipEntry_ReadHeader_m5526CF5930E2C0714C477D106F20A8BE581A5CBF (void);
// 0x000000D5 System.Int32 Ionic.Zip.ZipEntry::ReadWeakEncryptionHeader(System.IO.Stream,System.Byte[])
extern void ZipEntry_ReadWeakEncryptionHeader_mFBEB24A14C0E6DADAEE7E608C6710F8D3ACE58BC (void);
// 0x000000D6 System.Boolean Ionic.Zip.ZipEntry::IsNotValidSig(System.Int32)
extern void ZipEntry_IsNotValidSig_m252AB903E61F7EC562A17176447283A477620AF7 (void);
// 0x000000D7 Ionic.Zip.ZipEntry Ionic.Zip.ZipEntry::ReadEntry(Ionic.Zip.ZipContainer,System.Boolean)
extern void ZipEntry_ReadEntry_m8253287E3CB97C368CEFA0C961101B91208DA6D7 (void);
// 0x000000D8 System.Void Ionic.Zip.ZipEntry::HandlePK00Prefix(System.IO.Stream)
extern void ZipEntry_HandlePK00Prefix_m39B3957E6A68FB2994F5AF8AC9153A0987EA74EB (void);
// 0x000000D9 System.Void Ionic.Zip.ZipEntry::HandleUnexpectedDataDescriptor(Ionic.Zip.ZipEntry)
extern void ZipEntry_HandleUnexpectedDataDescriptor_mDA8FF46E6530D9756F61FEF3ACD7974C1AE2C8B2 (void);
// 0x000000DA System.Int32 Ionic.Zip.ZipEntry::FindExtraFieldSegment(System.Byte[],System.Int32,System.UInt16)
extern void ZipEntry_FindExtraFieldSegment_mF7B9D9D1AE4E650378E5DF44502CB2579C2C5917 (void);
// 0x000000DB System.Int32 Ionic.Zip.ZipEntry::ProcessExtraField(System.IO.Stream,System.Int16)
extern void ZipEntry_ProcessExtraField_m3C73F6D001397600594E6B99917FBCFB26455C1D (void);
// 0x000000DC System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldPkwareStrongEncryption(System.Byte[],System.Int32)
extern void ZipEntry_ProcessExtraFieldPkwareStrongEncryption_m62C3C9E44A031F779E4A47FF4E59C31FC617E528 (void);
// 0x000000DD System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldWinZipAes(System.Byte[],System.Int32,System.Int16,System.Int64)
extern void ZipEntry_ProcessExtraFieldWinZipAes_mA75A7627245C3918548737D8DE6805302A80E560 (void);
// 0x000000DE System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldZip64(System.Byte[],System.Int32,System.Int16,System.Int64)
extern void ZipEntry_ProcessExtraFieldZip64_m18BED0DDE91C4D4228C109AE98298C0B1C46A91E (void);
// 0x000000DF System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldInfoZipTimes(System.Byte[],System.Int32,System.Int16,System.Int64)
extern void ZipEntry_ProcessExtraFieldInfoZipTimes_m4E6C2D3283FCD3B94CB20AF7ABDEB6F065DA0F06 (void);
// 0x000000E0 System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldUnixTimes(System.Byte[],System.Int32,System.Int16,System.Int64)
extern void ZipEntry_ProcessExtraFieldUnixTimes_m0F503E3CFFC6DFF638A735F00A82160B3D1DDCBF (void);
// 0x000000E1 System.Int32 Ionic.Zip.ZipEntry::ProcessExtraFieldWindowsTimes(System.Byte[],System.Int32,System.Int16,System.Int64)
extern void ZipEntry_ProcessExtraFieldWindowsTimes_mC82846A976F09349F93144AEE27088DBB557707B (void);
// 0x000000E2 System.Void Ionic.Zip.ZipEntry::WriteCentralDirectoryEntry(System.IO.Stream)
extern void ZipEntry_WriteCentralDirectoryEntry_m28D978F34726D5D3F1203D388567889FCC528D66 (void);
// 0x000000E3 System.Byte[] Ionic.Zip.ZipEntry::ConstructExtraField(System.Boolean)
extern void ZipEntry_ConstructExtraField_m47CE516895694DE58AA3B6292DE241307A0FC72F (void);
// 0x000000E4 System.String Ionic.Zip.ZipEntry::NormalizeFileName()
extern void ZipEntry_NormalizeFileName_m79BD412794DDADBB3461F9C006AC50B9F800F1F2 (void);
// 0x000000E5 System.Byte[] Ionic.Zip.ZipEntry::GetEncodedFileNameBytes()
extern void ZipEntry_GetEncodedFileNameBytes_m890697761B0C4EC4F61BE63C53780E4A710A96A7 (void);
// 0x000000E6 System.Boolean Ionic.Zip.ZipEntry::WantReadAgain()
extern void ZipEntry_WantReadAgain_m02A4EBA91B4F0D70FDB9A7FFE6EF6BB96D453770 (void);
// 0x000000E7 System.Void Ionic.Zip.ZipEntry::MaybeUnsetCompressionMethodForWriting(System.Int32)
extern void ZipEntry_MaybeUnsetCompressionMethodForWriting_m243D98E14BCE459584D7EAA27A7F29F1AAAE0039 (void);
// 0x000000E8 System.Void Ionic.Zip.ZipEntry::WriteHeader(System.IO.Stream,System.Int32)
extern void ZipEntry_WriteHeader_m72BC73EBA6F0541529A38B5ADB3D647305DA0641 (void);
// 0x000000E9 System.Int32 Ionic.Zip.ZipEntry::FigureCrc32()
extern void ZipEntry_FigureCrc32_m329549EA0BD2FDDB1A623DD0E00ADD845B64BA96 (void);
// 0x000000EA System.Void Ionic.Zip.ZipEntry::PrepSourceStream()
extern void ZipEntry_PrepSourceStream_m559CBDA0AB777E4B7392CDD68DF84B4879C2BAB6 (void);
// 0x000000EB System.Void Ionic.Zip.ZipEntry::CopyMetaData(Ionic.Zip.ZipEntry)
extern void ZipEntry_CopyMetaData_m1F69BF1C1E642E5668ED7349647AAB5DA9626481 (void);
// 0x000000EC System.Void Ionic.Zip.ZipEntry::OnWriteBlock(System.Int64,System.Int64)
extern void ZipEntry_OnWriteBlock_mE9B5F4596A87DC8E7F8D8FD3DE7D97A3CEAC37D6 (void);
// 0x000000ED System.Void Ionic.Zip.ZipEntry::_WriteEntryData(System.IO.Stream)
extern void ZipEntry__WriteEntryData_m6AF2C4008879EC789171B544878F6603E563D8C8 (void);
// 0x000000EE System.Int64 Ionic.Zip.ZipEntry::SetInputAndFigureFileLength(System.IO.Stream&)
extern void ZipEntry_SetInputAndFigureFileLength_m1394875FCBE51E8629A14CE0F2E314F087C27E2D (void);
// 0x000000EF System.Void Ionic.Zip.ZipEntry::FinishOutputStream(System.IO.Stream,Ionic.Zip.CountingStream,System.IO.Stream,System.IO.Stream,Ionic.Crc.CrcCalculatorStream)
extern void ZipEntry_FinishOutputStream_mB63DE3F0840433073E6887D5512B877C64F2C8EE (void);
// 0x000000F0 System.Void Ionic.Zip.ZipEntry::PostProcessOutput(System.IO.Stream)
extern void ZipEntry_PostProcessOutput_m401371735AC7FAD33F5D36D60E2B50545A57F37E (void);
// 0x000000F1 System.Void Ionic.Zip.ZipEntry::SetZip64Flags()
extern void ZipEntry_SetZip64Flags_m72F8E2FF0746785523F2F4B063D592187A75CE06 (void);
// 0x000000F2 System.Void Ionic.Zip.ZipEntry::PrepOutputStream(System.IO.Stream,System.Int64,Ionic.Zip.CountingStream&,System.IO.Stream&,System.IO.Stream&,Ionic.Crc.CrcCalculatorStream&)
extern void ZipEntry_PrepOutputStream_mEE3B14268304C8646C7259115569382EABBD2125 (void);
// 0x000000F3 System.IO.Stream Ionic.Zip.ZipEntry::MaybeApplyCompression(System.IO.Stream,System.Int64)
extern void ZipEntry_MaybeApplyCompression_mA1C357D1D67B19ABD35A0E43007D88D9C544D831 (void);
// 0x000000F4 System.IO.Stream Ionic.Zip.ZipEntry::MaybeApplyEncryption(System.IO.Stream)
extern void ZipEntry_MaybeApplyEncryption_mB91522584465152E6FB45A5D4BDEEE1E5F2C676B (void);
// 0x000000F5 System.Void Ionic.Zip.ZipEntry::OnZipErrorWhileSaving(System.Exception)
extern void ZipEntry_OnZipErrorWhileSaving_m7CAEF7F8517DC2E22346C6AE368794E86A1ABCEF (void);
// 0x000000F6 System.Void Ionic.Zip.ZipEntry::Write(System.IO.Stream)
extern void ZipEntry_Write_m757F1528731A5928C31EE68AC19581D555D886FF (void);
// 0x000000F7 System.Void Ionic.Zip.ZipEntry::StoreRelativeOffset()
extern void ZipEntry_StoreRelativeOffset_m7D262CFC3591DFBD516255516F511092EF6237CF (void);
// 0x000000F8 System.Void Ionic.Zip.ZipEntry::NotifySaveComplete()
extern void ZipEntry_NotifySaveComplete_m40A69C513BE2B90F277E99F8AC2C27FBE246AB42 (void);
// 0x000000F9 System.Void Ionic.Zip.ZipEntry::WriteSecurityMetadata(System.IO.Stream)
extern void ZipEntry_WriteSecurityMetadata_m412C9B0E4C709FD4C44E67D9532BC8BD2AD6CEDE (void);
// 0x000000FA System.Void Ionic.Zip.ZipEntry::CopyThroughOneEntry(System.IO.Stream)
extern void ZipEntry_CopyThroughOneEntry_mDD3A2D35EF165F915BD930240DF565A045D686EB (void);
// 0x000000FB System.Void Ionic.Zip.ZipEntry::CopyThroughWithRecompute(System.IO.Stream)
extern void ZipEntry_CopyThroughWithRecompute_m5915D9E74E338EFBAF3BB48631ABCF4BCCCB0180 (void);
// 0x000000FC System.Void Ionic.Zip.ZipEntry::CopyThroughWithNoChange(System.IO.Stream)
extern void ZipEntry_CopyThroughWithNoChange_m6E7D6DBFD1E8C194726BDD334324FA4CD96BC00E (void);
// 0x000000FD System.Void Ionic.Zip.ZipEntry::.cctor()
extern void ZipEntry__cctor_m3CB3CC35A8EA5E4D565EBF71A9946FBCC61028B1 (void);
// 0x000000FE System.String Ionic.Zip.ZipEntry/CopyHelper::AppendCopyToFileName(System.String)
extern void CopyHelper_AppendCopyToFileName_m32D7A2D4D460A4A1851011B62B02F0FB4D11CB18 (void);
// 0x000000FF System.Void Ionic.Zip.ZipEntry/CopyHelper::.cctor()
extern void CopyHelper__cctor_m8EAFCE3B04BC0284D151346A0394319A7BF35B33 (void);
// 0x00000100 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile::AddEntry(System.String,System.IO.Stream)
extern void ZipFile_AddEntry_m5C8DF150E6C4A4D34EA26B9B17B03CEB192C2F74 (void);
// 0x00000101 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile::_InternalAddEntry(Ionic.Zip.ZipEntry)
extern void ZipFile__InternalAddEntry_m66E2FF10373B2668773C8FEEDEE457D3FF133054 (void);
// 0x00000102 System.Void Ionic.Zip.ZipFile::RemoveEntryForUpdate(System.String)
extern void ZipFile_RemoveEntryForUpdate_m462B4737D2FC9C64DA4EC2CCC9990A3FA34A12B4 (void);
// 0x00000103 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile::AddEntry(System.String,System.Byte[])
extern void ZipFile_AddEntry_m76C9BB5A8341218BF6FCAB95D2FEDE0B50593D5E (void);
// 0x00000104 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile::UpdateEntry(System.String,System.Byte[])
extern void ZipFile_UpdateEntry_mE68A5DCFBA4D6D34E62D716E4D1F6E65C12CD413 (void);
// 0x00000105 System.Void Ionic.Zip.ZipFile::InternalAddEntry(System.String,Ionic.Zip.ZipEntry)
extern void ZipFile_InternalAddEntry_m374D1FBB03D4A3E33277DE9503601C49DFD470B2 (void);
// 0x00000106 System.Boolean Ionic.Zip.ZipFile::get_FullScan()
extern void ZipFile_get_FullScan_m56FC88EA212A59AAD4EA7A7D91638FA0D291A261 (void);
// 0x00000107 System.Boolean Ionic.Zip.ZipFile::get_SortEntriesBeforeSaving()
extern void ZipFile_get_SortEntriesBeforeSaving_m32122C5AEADD8AE29BC1307FCE8593F7508ECC96 (void);
// 0x00000108 System.Void Ionic.Zip.ZipFile::set_AddDirectoryWillTraverseReparsePoints(System.Boolean)
extern void ZipFile_set_AddDirectoryWillTraverseReparsePoints_m1CA5EABC26AF5FE28B2F87747A673205250BDCC5 (void);
// 0x00000109 System.Int32 Ionic.Zip.ZipFile::get_BufferSize()
extern void ZipFile_get_BufferSize_mD5BAAC3EF248B7FFEF04C99A40A1E78ECE23A8F5 (void);
// 0x0000010A System.Int32 Ionic.Zip.ZipFile::get_CodecBufferSize()
extern void ZipFile_get_CodecBufferSize_m7D3A2DC36BDAB3308C9A1BCA831EFDE6083B3F3D (void);
// 0x0000010B System.Boolean Ionic.Zip.ZipFile::get_FlattenFoldersOnExtract()
extern void ZipFile_get_FlattenFoldersOnExtract_m6D084AC18EA08F8E776E001F6268279E1E8410B1 (void);
// 0x0000010C Ionic.Zlib.CompressionStrategy Ionic.Zip.ZipFile::get_Strategy()
extern void ZipFile_get_Strategy_m8DAF51BCC2920965C8DCA54219E5C18C42F907F9 (void);
// 0x0000010D System.String Ionic.Zip.ZipFile::get_Name()
extern void ZipFile_get_Name_m35A6AD543F5766356CB54FEBAB20AB74DE9106D8 (void);
// 0x0000010E Ionic.Zlib.CompressionLevel Ionic.Zip.ZipFile::get_CompressionLevel()
extern void ZipFile_get_CompressionLevel_mC806EE30F6A83C37BF8CA02B7E38E827C97B1FD8 (void);
// 0x0000010F System.Void Ionic.Zip.ZipFile::set_CompressionLevel(Ionic.Zlib.CompressionLevel)
extern void ZipFile_set_CompressionLevel_m1AD5D1AA48FAF931ABDE2FE8E10E60DE5F6EAC2E (void);
// 0x00000110 Ionic.Zip.CompressionMethod Ionic.Zip.ZipFile::get_CompressionMethod()
extern void ZipFile_get_CompressionMethod_mBCC6031F9A1D522F814195E2C8D2D4C3FABFF7FC (void);
// 0x00000111 System.String Ionic.Zip.ZipFile::get_Comment()
extern void ZipFile_get_Comment_mD5F70A277404A786069BEBAA81B9418A3F682844 (void);
// 0x00000112 System.Void Ionic.Zip.ZipFile::set_Comment(System.String)
extern void ZipFile_set_Comment_m53DFE8807492E99FF17CFB25EE9D9D0450CEAF3A (void);
// 0x00000113 System.Boolean Ionic.Zip.ZipFile::get_Verbose()
extern void ZipFile_get_Verbose_m67C5BB684540D4E34A2B46FC89BCB1D4C820160D (void);
// 0x00000114 System.Boolean Ionic.Zip.ZipFile::ContainsEntry(System.String)
extern void ZipFile_ContainsEntry_m4BE8AA6A5587314A95F2B4C8BC6F49A139FE4CFE (void);
// 0x00000115 System.Boolean Ionic.Zip.ZipFile::get_CaseSensitiveRetrieval()
extern void ZipFile_get_CaseSensitiveRetrieval_m1859960FF9C52C2226B4E8BC00E9833BD8E95D0C (void);
// 0x00000116 Ionic.Zip.Zip64Option Ionic.Zip.ZipFile::get_UseZip64WhenSaving()
extern void ZipFile_get_UseZip64WhenSaving_m3D0791F610F7D41F8A1FBA1A67AD5E89ACF92058 (void);
// 0x00000117 System.Void Ionic.Zip.ZipFile::set_UseZip64WhenSaving(Ionic.Zip.Zip64Option)
extern void ZipFile_set_UseZip64WhenSaving_m771CA27C243EE6446FDAC76B385EBF5AA9BF605B (void);
// 0x00000118 System.Text.Encoding Ionic.Zip.ZipFile::get_AlternateEncoding()
extern void ZipFile_get_AlternateEncoding_mAAB7764D2CC1EC03EDA0F9FA6D6369CDA36B6E09 (void);
// 0x00000119 System.Void Ionic.Zip.ZipFile::set_AlternateEncoding(System.Text.Encoding)
extern void ZipFile_set_AlternateEncoding_m79ABABDA2A98050A4F529A34E9D09B9D9A1198D2 (void);
// 0x0000011A Ionic.Zip.ZipOption Ionic.Zip.ZipFile::get_AlternateEncodingUsage()
extern void ZipFile_get_AlternateEncodingUsage_m04EDE069296587D3651B258DD1C528E002FD186D (void);
// 0x0000011B System.Void Ionic.Zip.ZipFile::set_AlternateEncodingUsage(Ionic.Zip.ZipOption)
extern void ZipFile_set_AlternateEncodingUsage_m726776935EA6DCA142B9B94DC7F6CB94921C43FF (void);
// 0x0000011C System.Text.Encoding Ionic.Zip.ZipFile::get_DefaultEncoding()
extern void ZipFile_get_DefaultEncoding_m39FD24A80083B54502DD970277E1FD3BA83BE88E (void);
// 0x0000011D System.IO.TextWriter Ionic.Zip.ZipFile::get_StatusMessageTextWriter()
extern void ZipFile_get_StatusMessageTextWriter_m3E38DE3A49BDA26FF671E18E2D5334F230D23B84 (void);
// 0x0000011E System.String Ionic.Zip.ZipFile::get_TempFileFolder()
extern void ZipFile_get_TempFileFolder_m88E95D34A159A6966477D73C065C29ACDAD35468 (void);
// 0x0000011F Ionic.Zip.ExtractExistingFileAction Ionic.Zip.ZipFile::get_ExtractExistingFile()
extern void ZipFile_get_ExtractExistingFile_mA106092322B045D5AF9BA751FF67E2C27D68DB31 (void);
// 0x00000120 System.Void Ionic.Zip.ZipFile::set_ExtractExistingFile(Ionic.Zip.ExtractExistingFileAction)
extern void ZipFile_set_ExtractExistingFile_mB1C917B618CCC6ECC2F62D3C57C92D6FEC4D0A99 (void);
// 0x00000121 Ionic.Zip.ZipErrorAction Ionic.Zip.ZipFile::get_ZipErrorAction()
extern void ZipFile_get_ZipErrorAction_mB87A88CD0116F76268D59DC36ED222971FC5D3A3 (void);
// 0x00000122 Ionic.Zip.EncryptionAlgorithm Ionic.Zip.ZipFile::get_Encryption()
extern void ZipFile_get_Encryption_m66CDE7A8F65BB5E442D33913D1B103473AE6FA15 (void);
// 0x00000123 Ionic.Zip.SetCompressionCallback Ionic.Zip.ZipFile::get_SetCompression()
extern void ZipFile_get_SetCompression_m664DF931C08C010B35FB10D79C5FCBE2B7A21A80 (void);
// 0x00000124 System.Int32 Ionic.Zip.ZipFile::get_MaxOutputSegmentSize()
extern void ZipFile_get_MaxOutputSegmentSize_mB85F836219E4FD137C870B8968B0208E680B11F8 (void);
// 0x00000125 System.Void Ionic.Zip.ZipFile::set_ParallelDeflateThreshold(System.Int64)
extern void ZipFile_set_ParallelDeflateThreshold_m91D73ABD864893EBF1A3402DC84B0869CB259100 (void);
// 0x00000126 System.Int64 Ionic.Zip.ZipFile::get_ParallelDeflateThreshold()
extern void ZipFile_get_ParallelDeflateThreshold_mC112AE1F60762D205B873E29F0BA7FD5BC5B0BBE (void);
// 0x00000127 System.Int32 Ionic.Zip.ZipFile::get_ParallelDeflateMaxBufferPairs()
extern void ZipFile_get_ParallelDeflateMaxBufferPairs_mE68481FB480DD5119BDF5758CBF75A7EBB090B84 (void);
// 0x00000128 System.String Ionic.Zip.ZipFile::ToString()
extern void ZipFile_ToString_m34BB30432FC52C64D12C4827E1226D5C7CD55BEC (void);
// 0x00000129 System.Void Ionic.Zip.ZipFile::NotifyEntryChanged()
extern void ZipFile_NotifyEntryChanged_m8B8E812D922DB2D8E1543B65ADB8660CB54F59B9 (void);
// 0x0000012A System.IO.Stream Ionic.Zip.ZipFile::StreamForDiskNumber(System.UInt32)
extern void ZipFile_StreamForDiskNumber_m227D92EFB214FECD881D0A567EEE7CDACB91DA51 (void);
// 0x0000012B System.Void Ionic.Zip.ZipFile::Reset(System.Boolean)
extern void ZipFile_Reset_m5345493F9FFE7C0359CE2D6F8A3B7ABD03805AF2 (void);
// 0x0000012C System.Void Ionic.Zip.ZipFile::.ctor(System.String)
extern void ZipFile__ctor_m8C05FB020FF05D50C59AF6E63E4F03E977F1FB4A (void);
// 0x0000012D System.Void Ionic.Zip.ZipFile::.ctor()
extern void ZipFile__ctor_m4029126C04BBB52462BDA2309D0C94FF9380D3DB (void);
// 0x0000012E System.Void Ionic.Zip.ZipFile::_initEntriesDictionary()
extern void ZipFile__initEntriesDictionary_m4993A3198F8E878F999DBB6F0AE4CB19930E95E6 (void);
// 0x0000012F System.Void Ionic.Zip.ZipFile::_InitInstance(System.String,System.IO.TextWriter)
extern void ZipFile__InitInstance_m3EA40BD97F2A17EE6A341AE5800A82E6FFD5FC52 (void);
// 0x00000130 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile::get_Item(System.String)
extern void ZipFile_get_Item_m1B630E7CA89B4706288F10839F167CB2FC80962C (void);
// 0x00000131 System.Collections.Generic.ICollection`1<System.String> Ionic.Zip.ZipFile::get_EntryFileNames()
extern void ZipFile_get_EntryFileNames_mB28E74DC79FF849E8A99B72781F25C866A3C8D45 (void);
// 0x00000132 System.Collections.Generic.ICollection`1<Ionic.Zip.ZipEntry> Ionic.Zip.ZipFile::get_Entries()
extern void ZipFile_get_Entries_mAD5BF3E82B8C1D729E5B625583B4542B13A4A258 (void);
// 0x00000133 System.Collections.Generic.ICollection`1<Ionic.Zip.ZipEntry> Ionic.Zip.ZipFile::get_EntriesSorted()
extern void ZipFile_get_EntriesSorted_mF23C866CA97D53CFA246DE762D4B29C26B426AF0 (void);
// 0x00000134 System.Int32 Ionic.Zip.ZipFile::get_Count()
extern void ZipFile_get_Count_m89CF208B330281B9B97FC2533AFF9B5A85F18091 (void);
// 0x00000135 System.Void Ionic.Zip.ZipFile::RemoveEntry(Ionic.Zip.ZipEntry)
extern void ZipFile_RemoveEntry_m52173831ECF996C7E45789EF28CC02BEA9067353 (void);
// 0x00000136 System.Void Ionic.Zip.ZipFile::RemoveEntry(System.String)
extern void ZipFile_RemoveEntry_m712BFF66CECE8AFAAED507AFC4E8BFC63A6EE097 (void);
// 0x00000137 System.Void Ionic.Zip.ZipFile::Dispose()
extern void ZipFile_Dispose_m643DE5B626370EF273FF02724EAB808A41B33576 (void);
// 0x00000138 System.Void Ionic.Zip.ZipFile::Dispose(System.Boolean)
extern void ZipFile_Dispose_m1CF3A8A63FACACAE9109897F89FD7CD25BF0B094 (void);
// 0x00000139 System.IO.Stream Ionic.Zip.ZipFile::get_ReadStream()
extern void ZipFile_get_ReadStream_mD6D6B9C60C1F056AC167E92890EBE0BE28D61B3B (void);
// 0x0000013A System.IO.Stream Ionic.Zip.ZipFile::get_WriteStream()
extern void ZipFile_get_WriteStream_mF5DFE8750B50A9E04EC949C07825E0765C73F9A4 (void);
// 0x0000013B System.String Ionic.Zip.ZipFile::get_ArchiveNameForEvent()
extern void ZipFile_get_ArchiveNameForEvent_m1525603669F9D370F49D4962B948686686EF61BE (void);
// 0x0000013C System.Boolean Ionic.Zip.ZipFile::OnSaveBlock(Ionic.Zip.ZipEntry,System.Int64,System.Int64)
extern void ZipFile_OnSaveBlock_m8FB1DB6753A88EE0E7720A7563A9C56A0278984A (void);
// 0x0000013D System.Void Ionic.Zip.ZipFile::OnSaveEntry(System.Int32,Ionic.Zip.ZipEntry,System.Boolean)
extern void ZipFile_OnSaveEntry_m415AC17B27CD4BA7954EBB94BBB2346764C1C3E7 (void);
// 0x0000013E System.Void Ionic.Zip.ZipFile::OnSaveEvent(Ionic.Zip.ZipProgressEventType)
extern void ZipFile_OnSaveEvent_m78D8BC071F4FB894ED0EB050F2721393039BC213 (void);
// 0x0000013F System.Void Ionic.Zip.ZipFile::OnSaveStarted()
extern void ZipFile_OnSaveStarted_m1806BA368685710267A7C2B5370BA2EE05E49124 (void);
// 0x00000140 System.Void Ionic.Zip.ZipFile::OnSaveCompleted()
extern void ZipFile_OnSaveCompleted_m5E2F51454ED46C00A12EBDA6AC1CDB16B911291B (void);
// 0x00000141 System.Void Ionic.Zip.ZipFile::OnReadStarted()
extern void ZipFile_OnReadStarted_m88758C77D9219D285B0D32E4E1E86A91F9F746E6 (void);
// 0x00000142 System.Void Ionic.Zip.ZipFile::OnReadCompleted()
extern void ZipFile_OnReadCompleted_m8C6EC409A34C457F3653850B2DDD252C0B7C3A40 (void);
// 0x00000143 System.Void Ionic.Zip.ZipFile::OnReadBytes(Ionic.Zip.ZipEntry)
extern void ZipFile_OnReadBytes_mBA6149EB64232E9518FAF635AC27C682CC24718A (void);
// 0x00000144 System.Void Ionic.Zip.ZipFile::OnReadEntry(System.Boolean,Ionic.Zip.ZipEntry)
extern void ZipFile_OnReadEntry_mD1736034A5B5E2557B4F6AEA32463C460412FA71 (void);
// 0x00000145 System.Int64 Ionic.Zip.ZipFile::get_LengthOfReadStream()
extern void ZipFile_get_LengthOfReadStream_m9B68037D45329BEB1813A1D6AF353087C090D3FD (void);
// 0x00000146 System.Void Ionic.Zip.ZipFile::OnExtractEntry(System.Int32,System.Boolean,Ionic.Zip.ZipEntry,System.String)
extern void ZipFile_OnExtractEntry_m77384FD04EB04D20C3026051E92336ACEE0F46BC (void);
// 0x00000147 System.Boolean Ionic.Zip.ZipFile::OnExtractBlock(Ionic.Zip.ZipEntry,System.Int64,System.Int64)
extern void ZipFile_OnExtractBlock_mBFFE29CCD4B7ECB7D82363CB83B3EAD059A2F53B (void);
// 0x00000148 System.Boolean Ionic.Zip.ZipFile::OnSingleEntryExtract(Ionic.Zip.ZipEntry,System.String,System.Boolean)
extern void ZipFile_OnSingleEntryExtract_m6C883AE7B8E115F27839D5E59A36D16C22BFA3A8 (void);
// 0x00000149 System.Boolean Ionic.Zip.ZipFile::OnExtractExisting(Ionic.Zip.ZipEntry,System.String)
extern void ZipFile_OnExtractExisting_mC8090D76970A278A02B5170BDC1BBD9BD778BC5C (void);
// 0x0000014A System.Void Ionic.Zip.ZipFile::OnExtractAllCompleted(System.String)
extern void ZipFile_OnExtractAllCompleted_m002555A62FFCB150A9F4275B845BB4513D815777 (void);
// 0x0000014B System.Void Ionic.Zip.ZipFile::OnExtractAllStarted(System.String)
extern void ZipFile_OnExtractAllStarted_m32F90ADE0959A32815A99E66B1F889A54A208C19 (void);
// 0x0000014C System.Void Ionic.Zip.ZipFile::AfterAddEntry(Ionic.Zip.ZipEntry)
extern void ZipFile_AfterAddEntry_mE28AF504C2761ECFBAC5622AB2A29D05CCCF12A9 (void);
// 0x0000014D System.Boolean Ionic.Zip.ZipFile::OnZipErrorSaving(Ionic.Zip.ZipEntry,System.Exception)
extern void ZipFile_OnZipErrorSaving_mEB4CE51F16D77A794C7270569E029AEADA5EA825 (void);
// 0x0000014E System.Void Ionic.Zip.ZipFile::ExtractAll(System.String,Ionic.Zip.ExtractExistingFileAction)
extern void ZipFile_ExtractAll_m4A8116DBB7E725C28680A3A369A57B71887BED9F (void);
// 0x0000014F System.Void Ionic.Zip.ZipFile::_InternalExtractAll(System.String,System.Boolean)
extern void ZipFile__InternalExtractAll_m77901F2BF8642A1B8E75DE972018DE90238AECBE (void);
// 0x00000150 Ionic.Zip.ZipFile Ionic.Zip.ZipFile::Read(System.String)
extern void ZipFile_Read_m1F3D9C9E25412191AE32CD36BCFBC33FCB27BD28 (void);
// 0x00000151 Ionic.Zip.ZipFile Ionic.Zip.ZipFile::Read(System.String,System.IO.TextWriter,System.Text.Encoding,System.EventHandler`1<Ionic.Zip.ReadProgressEventArgs>)
extern void ZipFile_Read_mF0503CE972C02F7A6A68D05EFEF563B472E8D011 (void);
// 0x00000152 System.Void Ionic.Zip.ZipFile::ReadIntoInstance(Ionic.Zip.ZipFile)
extern void ZipFile_ReadIntoInstance_m3E332DA71272B6417EBCA65E51436318A67B1573 (void);
// 0x00000153 System.Void Ionic.Zip.ZipFile::Zip64SeekToCentralDirectory(Ionic.Zip.ZipFile)
extern void ZipFile_Zip64SeekToCentralDirectory_m41317754BF098F95A09E545AA672E359EA7BCBBF (void);
// 0x00000154 System.UInt32 Ionic.Zip.ZipFile::ReadFirstFourBytes(System.IO.Stream)
extern void ZipFile_ReadFirstFourBytes_m05843DBEFBD566CEE965B0DB834E057106D7148E (void);
// 0x00000155 System.Void Ionic.Zip.ZipFile::ReadCentralDirectory(Ionic.Zip.ZipFile)
extern void ZipFile_ReadCentralDirectory_m7804D0A479D6F8BBC8B5B1FD3AE8645BF2722375 (void);
// 0x00000156 System.Void Ionic.Zip.ZipFile::ReadIntoInstance_Orig(Ionic.Zip.ZipFile)
extern void ZipFile_ReadIntoInstance_Orig_m0EDEDE0CC1EF5BE8A719CFE797174398FC1CED2C (void);
// 0x00000157 System.Void Ionic.Zip.ZipFile::ReadCentralDirectoryFooter(Ionic.Zip.ZipFile)
extern void ZipFile_ReadCentralDirectoryFooter_m251B5ED3D04C84B6F4084D3AE5EB4C7658DEF795 (void);
// 0x00000158 System.Void Ionic.Zip.ZipFile::ReadZipFileComment(Ionic.Zip.ZipFile)
extern void ZipFile_ReadZipFileComment_m5C2D8D0FF724DB2C1EFA11796113D7FA300E549C (void);
// 0x00000159 System.Void Ionic.Zip.ZipFile::DeleteFileWithRetry(System.String)
extern void ZipFile_DeleteFileWithRetry_mF39D69F44BA7E6F8D5F4BBF642D5C5D169324E27 (void);
// 0x0000015A System.Void Ionic.Zip.ZipFile::Save()
extern void ZipFile_Save_mE1B9385A35CE3E8AB50A1A3259C163F567688731 (void);
// 0x0000015B System.Void Ionic.Zip.ZipFile::NotifyEntriesSaveComplete(System.Collections.Generic.ICollection`1<Ionic.Zip.ZipEntry>)
extern void ZipFile_NotifyEntriesSaveComplete_m6EB5EF93655176899630CB6B2FCE49AE6455A361 (void);
// 0x0000015C System.Void Ionic.Zip.ZipFile::RemoveTempFile()
extern void ZipFile_RemoveTempFile_m9EB75DD161FB7242348858B69B378D8D89E5292A (void);
// 0x0000015D System.Void Ionic.Zip.ZipFile::CleanupAfterSaveOperation()
extern void ZipFile_CleanupAfterSaveOperation_mEFBB4D1CA5F3AE347854EE7364CF193F47C87D10 (void);
// 0x0000015E System.Void Ionic.Zip.ZipFile::Save(System.String)
extern void ZipFile_Save_mE38B65B2D42796C38A3396B643F3ACE61C4B1EB2 (void);
// 0x0000015F System.Collections.Generic.IEnumerator`1<Ionic.Zip.ZipEntry> Ionic.Zip.ZipFile::GetEnumerator()
extern void ZipFile_GetEnumerator_m39988F80C45B430022BF74689FBC73143BBF4DEC (void);
// 0x00000160 System.Collections.IEnumerator Ionic.Zip.ZipFile::System.Collections.IEnumerable.GetEnumerator()
extern void ZipFile_System_Collections_IEnumerable_GetEnumerator_m2ECFD2E9F3FED4418BEB16D1C2825C2CD99EB24D (void);
// 0x00000161 System.Void Ionic.Zip.ZipFile::.cctor()
extern void ZipFile__cctor_m6375D953EA9EDFD8C84173363350C3EB906BB70D (void);
// 0x00000162 System.Void Ionic.Zip.ZipFile/ExtractorSettings::.ctor()
extern void ExtractorSettings__ctor_mD4A4DC0F074D52BBDAE423C7F2FC645DED21379C (void);
// 0x00000163 System.Boolean Ionic.Zip.ZipFile/<GetEnumerator>d__1::MoveNext()
extern void U3CGetEnumeratorU3Ed__1_MoveNext_m0B5498D59FF60C9C9CE9C6BAB61736BAEFCECDDC (void);
// 0x00000164 Ionic.Zip.ZipEntry Ionic.Zip.ZipFile/<GetEnumerator>d__1::System.Collections.Generic.IEnumerator<Ionic.Zip.ZipEntry>.get_Current()
extern void U3CGetEnumeratorU3Ed__1_System_Collections_Generic_IEnumeratorU3CIonic_Zip_ZipEntryU3E_get_Current_m0C6A9722F217ACE457C5D80697AE933D97223588 (void);
// 0x00000165 System.Void Ionic.Zip.ZipFile/<GetEnumerator>d__1::System.Collections.IEnumerator.Reset()
extern void U3CGetEnumeratorU3Ed__1_System_Collections_IEnumerator_Reset_m5A599D1BC06E35C87010A62845E6E89D67E15EC1 (void);
// 0x00000166 System.Void Ionic.Zip.ZipFile/<GetEnumerator>d__1::System.IDisposable.Dispose()
extern void U3CGetEnumeratorU3Ed__1_System_IDisposable_Dispose_m110CE69100293B836646549612BD25B7D67FA6DF (void);
// 0x00000167 System.Object Ionic.Zip.ZipFile/<GetEnumerator>d__1::System.Collections.IEnumerator.get_Current()
extern void U3CGetEnumeratorU3Ed__1_System_Collections_IEnumerator_get_Current_mFB6092110F543DA051421346DDC478A216B80135 (void);
// 0x00000168 System.Void Ionic.Zip.ZipFile/<GetEnumerator>d__1::.ctor(System.Int32)
extern void U3CGetEnumeratorU3Ed__1__ctor_mA9AC25368224C0A1EA44FA4CB772B406FD7FACC2 (void);
// 0x00000169 System.Void Ionic.Zip.ZipFile/<GetEnumerator>d__1::<>m__Finally4()
extern void U3CGetEnumeratorU3Ed__1_U3CU3Em__Finally4_m648093EFEBC23909B975D728EF686E9995B402A8 (void);
// 0x0000016A System.Boolean Ionic.Zip.ZipOutput::WriteCentralDirectoryStructure(System.IO.Stream,System.Collections.Generic.ICollection`1<Ionic.Zip.ZipEntry>,System.UInt32,Ionic.Zip.Zip64Option,System.String,Ionic.Zip.ZipContainer)
extern void ZipOutput_WriteCentralDirectoryStructure_mC72F15EE5BAC97568773B88E3CF6EB3681E37DAD (void);
// 0x0000016B System.Text.Encoding Ionic.Zip.ZipOutput::GetEncoding(Ionic.Zip.ZipContainer,System.String)
extern void ZipOutput_GetEncoding_mB84366DA807215970BF399E8AD277F9A923AB51B (void);
// 0x0000016C System.Byte[] Ionic.Zip.ZipOutput::GenCentralDirectoryFooter(System.Int64,System.Int64,Ionic.Zip.Zip64Option,System.Int32,System.String,Ionic.Zip.ZipContainer)
extern void ZipOutput_GenCentralDirectoryFooter_m99F47FAF7B7F9317F4879EFAF2BEC8C7E8DFA7A9 (void);
// 0x0000016D System.Byte[] Ionic.Zip.ZipOutput::GenZip64EndOfCentralDirectory(System.Int64,System.Int64,System.Int32,System.UInt32)
extern void ZipOutput_GenZip64EndOfCentralDirectory_mED9C1CCB2FAB1E950BC64B8288057D278C920365 (void);
// 0x0000016E System.Int32 Ionic.Zip.ZipOutput::CountEntries(System.Collections.Generic.ICollection`1<Ionic.Zip.ZipEntry>)
extern void ZipOutput_CountEntries_mAB2C43F3482FCA385CA2A1123106B07FE98EBD0A (void);
// 0x0000016F System.Int32 Ionic.Zip.ZipInputStream::get_CodecBufferSize()
extern void ZipInputStream_get_CodecBufferSize_mFB52EF563E16449408107D06D1C7D8C30991876B (void);
// 0x00000170 System.Void Ionic.Zip.ZipInputStream::SetupStream()
extern void ZipInputStream_SetupStream_mABA5D5F4C54C80333E54F04477C4E49A4B4F91B6 (void);
// 0x00000171 System.IO.Stream Ionic.Zip.ZipInputStream::get_ReadStream()
extern void ZipInputStream_get_ReadStream_m243DB11E65F261DD283ABAD2271D38B667590967 (void);
// 0x00000172 System.Int32 Ionic.Zip.ZipInputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipInputStream_Read_m30113A6102D07F1BC5E7F3901E7AA2A6F15C3AB2 (void);
// 0x00000173 System.Boolean Ionic.Zip.ZipInputStream::get_CanRead()
extern void ZipInputStream_get_CanRead_mAEE964544E587ED755BAA13C5B327433A9FA629A (void);
// 0x00000174 System.Boolean Ionic.Zip.ZipInputStream::get_CanSeek()
extern void ZipInputStream_get_CanSeek_m9DD042221479A385A7D50514C375BB96CA7A92D9 (void);
// 0x00000175 System.Boolean Ionic.Zip.ZipInputStream::get_CanWrite()
extern void ZipInputStream_get_CanWrite_m12665C7A78676A53C64C8A5970BAB337EF6FA0CA (void);
// 0x00000176 System.Int64 Ionic.Zip.ZipInputStream::get_Length()
extern void ZipInputStream_get_Length_mFC566D263ACADB1DD0955C33F2097696C00108E2 (void);
// 0x00000177 System.Int64 Ionic.Zip.ZipInputStream::get_Position()
extern void ZipInputStream_get_Position_m7D57F06E8F6975CFE18AF1E21CA5F42EC9C88DBF (void);
// 0x00000178 System.Void Ionic.Zip.ZipInputStream::set_Position(System.Int64)
extern void ZipInputStream_set_Position_m2BDF5800F0FD457A227CB0DAA7C5AB5BB5F691A1 (void);
// 0x00000179 System.Void Ionic.Zip.ZipInputStream::Flush()
extern void ZipInputStream_Flush_m03E37C5318A618E5C35A72965A8299D7AAC1EBE6 (void);
// 0x0000017A System.Void Ionic.Zip.ZipInputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipInputStream_Write_mAFD74BF2843480F9DBF3EE348DB73F80A9407606 (void);
// 0x0000017B System.Int64 Ionic.Zip.ZipInputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZipInputStream_Seek_m80861C5DEE88AEBED7820AECB6A3ABF5811463F9 (void);
// 0x0000017C System.Void Ionic.Zip.ZipInputStream::SetLength(System.Int64)
extern void ZipInputStream_SetLength_m9F418A7C7C42CF3399A4C140A0361F2DD24F8C94 (void);
// 0x0000017D System.Int32 Ionic.Zip.ZipOutputStream::get_CodecBufferSize()
extern void ZipOutputStream_get_CodecBufferSize_mC467B796DD76833D00AD4A359464046473AB2A2E (void);
// 0x0000017E Ionic.Zlib.CompressionStrategy Ionic.Zip.ZipOutputStream::get_Strategy()
extern void ZipOutputStream_get_Strategy_m5E2EE33B9638110DDC7C751D925E7F491D488B76 (void);
// 0x0000017F Ionic.Zip.Zip64Option Ionic.Zip.ZipOutputStream::get_EnableZip64()
extern void ZipOutputStream_get_EnableZip64_m6A1838FAFBD8CBBA706F48E43867839CF049C450 (void);
// 0x00000180 System.Text.Encoding Ionic.Zip.ZipOutputStream::get_AlternateEncoding()
extern void ZipOutputStream_get_AlternateEncoding_m6DAA08CC1B904F3AB17D2441B53AD9A17FCB877D (void);
// 0x00000181 Ionic.Zip.ZipOption Ionic.Zip.ZipOutputStream::get_AlternateEncodingUsage()
extern void ZipOutputStream_get_AlternateEncodingUsage_m6A2F602F01975B88F4908EF2293FFFA0372AD907 (void);
// 0x00000182 System.Text.Encoding Ionic.Zip.ZipOutputStream::get_DefaultEncoding()
extern void ZipOutputStream_get_DefaultEncoding_mF03E2C099E12AD02187B802AA41B89BD4491E75D (void);
// 0x00000183 System.Int64 Ionic.Zip.ZipOutputStream::get_ParallelDeflateThreshold()
extern void ZipOutputStream_get_ParallelDeflateThreshold_mDDA551B240D6B41DAB7F4B7BBCAC4DA3C83A0D52 (void);
// 0x00000184 System.Int32 Ionic.Zip.ZipOutputStream::get_ParallelDeflateMaxBufferPairs()
extern void ZipOutputStream_get_ParallelDeflateMaxBufferPairs_m69733555F5ACFEAB77659CDEBE187C3522E5E222 (void);
// 0x00000185 System.IO.Stream Ionic.Zip.ZipOutputStream::get_OutputStream()
extern void ZipOutputStream_get_OutputStream_mE2F565CA1C859B39623DEE4F9562E8E4DB9F8CF0 (void);
// 0x00000186 System.Void Ionic.Zip.ZipOutputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipOutputStream_Write_m5912944330053A5D5CF21FFE34B5BACE09BC9BFC (void);
// 0x00000187 System.Void Ionic.Zip.ZipOutputStream::_InitiateCurrentEntry(System.Boolean)
extern void ZipOutputStream__InitiateCurrentEntry_mBF682F55D71B080CFB83D2FCAA94D1F2CF3B9314 (void);
// 0x00000188 System.Boolean Ionic.Zip.ZipOutputStream::get_CanRead()
extern void ZipOutputStream_get_CanRead_m0EBD2C7D07784D87EBBD592CBBE2A85D1BD1C270 (void);
// 0x00000189 System.Boolean Ionic.Zip.ZipOutputStream::get_CanSeek()
extern void ZipOutputStream_get_CanSeek_m407B068D62FFE6E4F0095B07628105CD3FBC8052 (void);
// 0x0000018A System.Boolean Ionic.Zip.ZipOutputStream::get_CanWrite()
extern void ZipOutputStream_get_CanWrite_m132F4249556519271A33AD4E9A05652EBF0CE886 (void);
// 0x0000018B System.Int64 Ionic.Zip.ZipOutputStream::get_Length()
extern void ZipOutputStream_get_Length_m9D0B489A3E1EA45F8E51FF0E288C5AB2D5E63E7C (void);
// 0x0000018C System.Int64 Ionic.Zip.ZipOutputStream::get_Position()
extern void ZipOutputStream_get_Position_mD71BC216EFA212E20816A4D884BE160B09CA9CCE (void);
// 0x0000018D System.Void Ionic.Zip.ZipOutputStream::set_Position(System.Int64)
extern void ZipOutputStream_set_Position_mC24632338E3A337B6ADA3EA616D657BBEF47F77F (void);
// 0x0000018E System.Void Ionic.Zip.ZipOutputStream::Flush()
extern void ZipOutputStream_Flush_mEF22F8F1C599A16418A190F47689624C61A71773 (void);
// 0x0000018F System.Int32 Ionic.Zip.ZipOutputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipOutputStream_Read_m588E63A8F3A2C551958D5899D9AA0AD356EFDBAC (void);
// 0x00000190 System.Int64 Ionic.Zip.ZipOutputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZipOutputStream_Seek_m88A9BA7601CBD050C3EE7FCA8B50F749E92DD348 (void);
// 0x00000191 System.Void Ionic.Zip.ZipOutputStream::SetLength(System.Int64)
extern void ZipOutputStream_SetLength_mAC780B284B8BF82206954695906969B571300462 (void);
// 0x00000192 System.Void Ionic.Zip.ZipContainer::.ctor(System.Object)
extern void ZipContainer__ctor_m29C10250A9BD529D65AAD20BE5EABE046B0AEBDA (void);
// 0x00000193 Ionic.Zip.ZipFile Ionic.Zip.ZipContainer::get_ZipFile()
extern void ZipContainer_get_ZipFile_m40E15ECAF80FBEB5720A6FF557ED569A4FABF16A (void);
// 0x00000194 Ionic.Zip.ZipOutputStream Ionic.Zip.ZipContainer::get_ZipOutputStream()
extern void ZipContainer_get_ZipOutputStream_mCD4B9A35F35EF36AEF03A8D3292948BD11B833A5 (void);
// 0x00000195 System.String Ionic.Zip.ZipContainer::get_Password()
extern void ZipContainer_get_Password_mCC3DC17E355DBCC8B27F12B37399D4B35C9F90B9 (void);
// 0x00000196 Ionic.Zip.Zip64Option Ionic.Zip.ZipContainer::get_Zip64()
extern void ZipContainer_get_Zip64_m6B929978F95B38CEBC8018A2000363027175D07E (void);
// 0x00000197 System.Int32 Ionic.Zip.ZipContainer::get_BufferSize()
extern void ZipContainer_get_BufferSize_mF79DEFFD46F1DFC471B953433E6C5D94EE6289F0 (void);
// 0x00000198 Ionic.Zlib.ParallelDeflateOutputStream Ionic.Zip.ZipContainer::get_ParallelDeflater()
extern void ZipContainer_get_ParallelDeflater_mC9840E3BCF2559B99456ADF7B93A34E32C9E9114 (void);
// 0x00000199 System.Void Ionic.Zip.ZipContainer::set_ParallelDeflater(Ionic.Zlib.ParallelDeflateOutputStream)
extern void ZipContainer_set_ParallelDeflater_m52406617BD48B694CAE12220BF3F25985C357AFF (void);
// 0x0000019A System.Int64 Ionic.Zip.ZipContainer::get_ParallelDeflateThreshold()
extern void ZipContainer_get_ParallelDeflateThreshold_mDC50668C2AC11CDB53F477CA0ED0086F38723A94 (void);
// 0x0000019B System.Int32 Ionic.Zip.ZipContainer::get_ParallelDeflateMaxBufferPairs()
extern void ZipContainer_get_ParallelDeflateMaxBufferPairs_m49B9819F99249207C689A1E5C947B8F5B22AACCA (void);
// 0x0000019C System.Int32 Ionic.Zip.ZipContainer::get_CodecBufferSize()
extern void ZipContainer_get_CodecBufferSize_m84F4AE6D8135043129350BD64DBE8F49760B8DA6 (void);
// 0x0000019D Ionic.Zlib.CompressionStrategy Ionic.Zip.ZipContainer::get_Strategy()
extern void ZipContainer_get_Strategy_m1DCBF366F4CA22131207CA5F3B985A1180CD5D9D (void);
// 0x0000019E Ionic.Zip.Zip64Option Ionic.Zip.ZipContainer::get_UseZip64WhenSaving()
extern void ZipContainer_get_UseZip64WhenSaving_m5FA9CD96FDA984B6FB57E3465ABB5B4ED1700F45 (void);
// 0x0000019F System.Text.Encoding Ionic.Zip.ZipContainer::get_AlternateEncoding()
extern void ZipContainer_get_AlternateEncoding_mDDA135489EAEE3D3E0AF57AE8613EB7FC64B2FC6 (void);
// 0x000001A0 System.Text.Encoding Ionic.Zip.ZipContainer::get_DefaultEncoding()
extern void ZipContainer_get_DefaultEncoding_m8384EADCD56E3870E694C7494D06578B51E078BB (void);
// 0x000001A1 Ionic.Zip.ZipOption Ionic.Zip.ZipContainer::get_AlternateEncodingUsage()
extern void ZipContainer_get_AlternateEncodingUsage_mA1C47C7A43CE7C616E90CFB4BEC4D2A4FF13476C (void);
// 0x000001A2 System.IO.Stream Ionic.Zip.ZipContainer::get_ReadStream()
extern void ZipContainer_get_ReadStream_m9E7D0C3B49247A0A2507A85AD774E4ACB31551E1 (void);
// 0x000001A3 System.Void Ionic.Zip.ZipSegmentedStream::.ctor()
extern void ZipSegmentedStream__ctor_mC5734EA0ECEB42173D28664EF02BDF2F390BC126 (void);
// 0x000001A4 Ionic.Zip.ZipSegmentedStream Ionic.Zip.ZipSegmentedStream::ForReading(System.String,System.UInt32,System.UInt32)
extern void ZipSegmentedStream_ForReading_mD3A3F1C42D70F2F4EE2913F6CA5AE5C72319D4D3 (void);
// 0x000001A5 Ionic.Zip.ZipSegmentedStream Ionic.Zip.ZipSegmentedStream::ForWriting(System.String,System.Int32)
extern void ZipSegmentedStream_ForWriting_m6FB644C3AD6D24DBCC6174C8F596781CA168ACD7 (void);
// 0x000001A6 System.IO.Stream Ionic.Zip.ZipSegmentedStream::ForUpdate(System.String,System.UInt32)
extern void ZipSegmentedStream_ForUpdate_m30A319B4F4D486DB33CBC34C179AFCD9231144A5 (void);
// 0x000001A7 System.Boolean Ionic.Zip.ZipSegmentedStream::get_ContiguousWrite()
extern void ZipSegmentedStream_get_ContiguousWrite_mEFF8E4AFC70727B90119530FFAC979495D8E2F42 (void);
// 0x000001A8 System.Void Ionic.Zip.ZipSegmentedStream::set_ContiguousWrite(System.Boolean)
extern void ZipSegmentedStream_set_ContiguousWrite_m80534DA515842D1E5634A8D4DDC32F3526B536CA (void);
// 0x000001A9 System.UInt32 Ionic.Zip.ZipSegmentedStream::get_CurrentSegment()
extern void ZipSegmentedStream_get_CurrentSegment_m3B7715B0022FD9EA6CF7F0BED060ACE4A675F14E (void);
// 0x000001AA System.Void Ionic.Zip.ZipSegmentedStream::set_CurrentSegment(System.UInt32)
extern void ZipSegmentedStream_set_CurrentSegment_mB25D54DADAC398D5A992B62B3F40ADB5CE68513A (void);
// 0x000001AB System.String Ionic.Zip.ZipSegmentedStream::get_CurrentName()
extern void ZipSegmentedStream_get_CurrentName_m27452D37C34B7DD659879AF595383D006CE1F1E2 (void);
// 0x000001AC System.String Ionic.Zip.ZipSegmentedStream::get_CurrentTempName()
extern void ZipSegmentedStream_get_CurrentTempName_mABCA88BA46E4A3D5A31CA83ABF48F82560A5F9D5 (void);
// 0x000001AD System.String Ionic.Zip.ZipSegmentedStream::_NameForSegment(System.UInt32)
extern void ZipSegmentedStream__NameForSegment_m14145CFD1562C3977E7F0128B424D13F53C95429 (void);
// 0x000001AE System.UInt32 Ionic.Zip.ZipSegmentedStream::ComputeSegment(System.Int32)
extern void ZipSegmentedStream_ComputeSegment_m6885F3B077AAE46E6BC7B0858DB7AEF84A89B54A (void);
// 0x000001AF System.String Ionic.Zip.ZipSegmentedStream::ToString()
extern void ZipSegmentedStream_ToString_m8824E743037A5B0AC077106DD13848E451B57006 (void);
// 0x000001B0 System.Void Ionic.Zip.ZipSegmentedStream::_SetReadStream()
extern void ZipSegmentedStream__SetReadStream_mDA59AB5037C93B7EDEF166B64A3721C5928245B3 (void);
// 0x000001B1 System.Int32 Ionic.Zip.ZipSegmentedStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZipSegmentedStream_Read_m32581082E352026A63DF6BC647C40EA817301B0B (void);
// 0x000001B2 System.Void Ionic.Zip.ZipSegmentedStream::_SetWriteStream(System.UInt32)
extern void ZipSegmentedStream__SetWriteStream_m2BD8C02F97394E59F36DDE97E034B7DA7B210EB4 (void);
// 0x000001B3 System.Void Ionic.Zip.ZipSegmentedStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZipSegmentedStream_Write_m413A5DB6847BE81051303251FE3ECF08EB0972A2 (void);
// 0x000001B4 System.Int64 Ionic.Zip.ZipSegmentedStream::TruncateBackward(System.UInt32,System.Int64)
extern void ZipSegmentedStream_TruncateBackward_mF0A3D448EC9E17745A2478CCE5C919342DFD0236 (void);
// 0x000001B5 System.Boolean Ionic.Zip.ZipSegmentedStream::get_CanRead()
extern void ZipSegmentedStream_get_CanRead_m301EDA0A443547A1CADF0D51B52E30E5C9C88FDA (void);
// 0x000001B6 System.Boolean Ionic.Zip.ZipSegmentedStream::get_CanSeek()
extern void ZipSegmentedStream_get_CanSeek_mC1C6164A6E3B1C559A173B64D898008D0CB0F431 (void);
// 0x000001B7 System.Boolean Ionic.Zip.ZipSegmentedStream::get_CanWrite()
extern void ZipSegmentedStream_get_CanWrite_m2923512C61F4ECB341F44F9F4D9C0EA5D8B8E629 (void);
// 0x000001B8 System.Void Ionic.Zip.ZipSegmentedStream::Flush()
extern void ZipSegmentedStream_Flush_mB204CCF208000BECA4BD2FAEBFDAD558DCDF1E30 (void);
// 0x000001B9 System.Int64 Ionic.Zip.ZipSegmentedStream::get_Length()
extern void ZipSegmentedStream_get_Length_mEBB69E62DF0390BDBCB010A312145430011D4A80 (void);
// 0x000001BA System.Int64 Ionic.Zip.ZipSegmentedStream::get_Position()
extern void ZipSegmentedStream_get_Position_m43BD3FB5F349B6C6BCBE01F9731D38CF208B7F97 (void);
// 0x000001BB System.Void Ionic.Zip.ZipSegmentedStream::set_Position(System.Int64)
extern void ZipSegmentedStream_set_Position_mA0D0CD86FE7C7444F5926B44313BD0CF1EA1708E (void);
// 0x000001BC System.Int64 Ionic.Zip.ZipSegmentedStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZipSegmentedStream_Seek_m900EBFFBDBE88A285FC99E708DBA3E61E1FB9DD8 (void);
// 0x000001BD System.Void Ionic.Zip.ZipSegmentedStream::SetLength(System.Int64)
extern void ZipSegmentedStream_SetLength_m40262EA09BB8373F27A68C59272CC1D8607378DB (void);
// 0x000001BE System.Void Ionic.Zip.ZipSegmentedStream::Dispose(System.Boolean)
extern void ZipSegmentedStream_Dispose_mCAB353F553FFB24B4EA7D8487AF02B150CC1DCB3 (void);
// 0x000001BF System.Void Ionic.BZip2.BitWriter::.ctor(System.IO.Stream)
extern void BitWriter__ctor_m63CFBDD75DDBD25EC642FBEC7FDFF78FE5C24676 (void);
// 0x000001C0 System.Byte Ionic.BZip2.BitWriter::get_RemainingBits()
extern void BitWriter_get_RemainingBits_mE990E20067678E6BFAFFA3725C55A33FE0BF7EEC (void);
// 0x000001C1 System.Int32 Ionic.BZip2.BitWriter::get_NumRemainingBits()
extern void BitWriter_get_NumRemainingBits_m72882230618C2494CEAC57EBBCE79CAD83B40F13 (void);
// 0x000001C2 System.Int32 Ionic.BZip2.BitWriter::get_TotalBytesWrittenOut()
extern void BitWriter_get_TotalBytesWrittenOut_mA8C36A034DF378DD397D425903E53892683F8990 (void);
// 0x000001C3 System.Void Ionic.BZip2.BitWriter::Reset()
extern void BitWriter_Reset_m89AC034FBDAC09AE3EAC1CAFEBDE8C96258405BA (void);
// 0x000001C4 System.Void Ionic.BZip2.BitWriter::WriteBits(System.Int32,System.UInt32)
extern void BitWriter_WriteBits_mE9A99C8336CD1B1983518E775385669BB933C2DF (void);
// 0x000001C5 System.Void Ionic.BZip2.BitWriter::WriteByte(System.Byte)
extern void BitWriter_WriteByte_m2F874181E743C267F1456F26AF39965E35CAF248 (void);
// 0x000001C6 System.Void Ionic.BZip2.BitWriter::WriteInt(System.UInt32)
extern void BitWriter_WriteInt_m4CE89EAE14DFC560A84BB702CFED559B65012B42 (void);
// 0x000001C7 System.Void Ionic.BZip2.BitWriter::Flush()
extern void BitWriter_Flush_mD45AA96F3B25557F45F23D6F36387573401242D5 (void);
// 0x000001C8 System.Void Ionic.BZip2.BitWriter::FinishAndPad()
extern void BitWriter_FinishAndPad_mC2327BC5B749624AD27947344D5114FADC85C7F9 (void);
// 0x000001C9 System.Void Ionic.BZip2.BZip2Compressor::.ctor(Ionic.BZip2.BitWriter,System.Int32)
extern void BZip2Compressor__ctor_m02EA949E772FA6ABE212E1A2BBAE36E7AE7B81A1 (void);
// 0x000001CA System.Void Ionic.BZip2.BZip2Compressor::Reset()
extern void BZip2Compressor_Reset_m9D9DF9464D496026459D09DF060AC79C8D5F32CD (void);
// 0x000001CB System.UInt32 Ionic.BZip2.BZip2Compressor::get_Crc32()
extern void BZip2Compressor_get_Crc32_m6A5C0081C6CE1A92C536004F1AD3B8D33DB3110B (void);
// 0x000001CC System.Void Ionic.BZip2.BZip2Compressor::set_Crc32(System.UInt32)
extern void BZip2Compressor_set_Crc32_mAC44DBB6D2381E38182BB24D4AEC8F922471F604 (void);
// 0x000001CD System.Int32 Ionic.BZip2.BZip2Compressor::Fill(System.Byte[],System.Int32,System.Int32)
extern void BZip2Compressor_Fill_mE2AB23B05823D64877BB7A1887D49334458E6BAE (void);
// 0x000001CE System.Int32 Ionic.BZip2.BZip2Compressor::write0(System.Byte)
extern void BZip2Compressor_write0_m4A4D72C2D9E0F4613D7B3A6410BDB9CEB596845F (void);
// 0x000001CF System.Boolean Ionic.BZip2.BZip2Compressor::AddRunToOutputBlock(System.Boolean)
extern void BZip2Compressor_AddRunToOutputBlock_mA73B4897CE9369C60A0817F1AE08C6EA420CD59A (void);
// 0x000001D0 System.Void Ionic.BZip2.BZip2Compressor::CompressAndWrite()
extern void BZip2Compressor_CompressAndWrite_m1FA3139B8F88831493B479C742E76B2CBB715886 (void);
// 0x000001D1 System.Void Ionic.BZip2.BZip2Compressor::randomiseBlock()
extern void BZip2Compressor_randomiseBlock_mB29BB166FF6C3C1550CD9580A32C25ACBBD8C15E (void);
// 0x000001D2 System.Void Ionic.BZip2.BZip2Compressor::mainSort()
extern void BZip2Compressor_mainSort_m8ECC932F1594397EBF9514199CAF1D4FAE10571B (void);
// 0x000001D3 System.Void Ionic.BZip2.BZip2Compressor::blockSort()
extern void BZip2Compressor_blockSort_m8738396E19B0205CF55CCC5F3680330712F230E5 (void);
// 0x000001D4 System.Boolean Ionic.BZip2.BZip2Compressor::mainSimpleSort(Ionic.BZip2.BZip2Compressor/CompressionState,System.Int32,System.Int32,System.Int32)
extern void BZip2Compressor_mainSimpleSort_mABF96757D4BD8024C3BA754463021F34C8E84C0B (void);
// 0x000001D5 System.Void Ionic.BZip2.BZip2Compressor::vswap(System.Int32[],System.Int32,System.Int32,System.Int32)
extern void BZip2Compressor_vswap_mF0E8F1BFCDFA81C7DCE878EF1A2A5CBC652BA9A6 (void);
// 0x000001D6 System.Byte Ionic.BZip2.BZip2Compressor::med3(System.Byte,System.Byte,System.Byte)
extern void BZip2Compressor_med3_mECD1D2AA2A7226606E702868EC51AD760C3D7461 (void);
// 0x000001D7 System.Void Ionic.BZip2.BZip2Compressor::mainQSort3(Ionic.BZip2.BZip2Compressor/CompressionState,System.Int32,System.Int32,System.Int32)
extern void BZip2Compressor_mainQSort3_m35C7FD1713C931424C9DF2173906DE3D96A7A969 (void);
// 0x000001D8 System.Void Ionic.BZip2.BZip2Compressor::generateMTFValues()
extern void BZip2Compressor_generateMTFValues_mF1E319881F382F621FABF213C6DA92F58E6EAB3B (void);
// 0x000001D9 System.Void Ionic.BZip2.BZip2Compressor::hbAssignCodes(System.Int32[],System.Byte[],System.Int32,System.Int32,System.Int32)
extern void BZip2Compressor_hbAssignCodes_m59E16FA69E6653F2D9F0A2F67E62F938B37C538B (void);
// 0x000001DA System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues()
extern void BZip2Compressor_sendMTFValues_m028EF067A8FDDEF7361BA8DE22779ACC55B9B65D (void);
// 0x000001DB System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues0(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues0_mDB0E8428985EF61E9C97247E490ED6ADAC552D51 (void);
// 0x000001DC System.Void Ionic.BZip2.BZip2Compressor::hbMakeCodeLengths(System.Byte[],System.Int32[],Ionic.BZip2.BZip2Compressor/CompressionState,System.Int32,System.Int32)
extern void BZip2Compressor_hbMakeCodeLengths_mBF792140B8410D91B356F64BDA1511BC5EA7B458 (void);
// 0x000001DD System.Int32 Ionic.BZip2.BZip2Compressor::sendMTFValues1(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues1_m55D0E0C492C2D3AC29C6100117C80CE1467790E7 (void);
// 0x000001DE System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues2(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues2_m93E6390C0005D7D9A1CF8C9A1F1B8A5FF5697DCE (void);
// 0x000001DF System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues3(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues3_m83FD3C5A2F359EBC1173E94CC08CCBFF293CFFEA (void);
// 0x000001E0 System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues4()
extern void BZip2Compressor_sendMTFValues4_m630FD0217BD736A4306A74F27FF9C7115044B93C (void);
// 0x000001E1 System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues5(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues5_m41BE7178B9C5E6AA375DFDA094401B728D92E2C8 (void);
// 0x000001E2 System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues6(System.Int32,System.Int32)
extern void BZip2Compressor_sendMTFValues6_m0D0AA4D2B5DC2D8B80E65829C1D60D2FFC39836E (void);
// 0x000001E3 System.Void Ionic.BZip2.BZip2Compressor::sendMTFValues7(System.Int32)
extern void BZip2Compressor_sendMTFValues7_m00CB975B0350D5391D4828607E8D7280DA8B961F (void);
// 0x000001E4 System.Void Ionic.BZip2.BZip2Compressor::moveToFrontCodeAndSend()
extern void BZip2Compressor_moveToFrontCodeAndSend_m8CE1772ADBEA93A3D01C7A12800F8522F8E2D794 (void);
// 0x000001E5 System.Void Ionic.BZip2.BZip2Compressor::.cctor()
extern void BZip2Compressor__cctor_m7409D6662398C8A6DBBCABFD9701ECD4AC55CDE0 (void);
// 0x000001E6 System.Void Ionic.BZip2.BZip2Compressor/CompressionState::.ctor(System.Int32)
extern void CompressionState__ctor_mCB1623CFDB2449BE6AD4E1E349FA3443EACC35D6 (void);
// 0x000001E7 System.Void Ionic.BZip2.BZip2InputStream::.ctor(System.IO.Stream,System.Boolean)
extern void BZip2InputStream__ctor_m960BFFDF1709936C69387F2CE195F904A9D16295 (void);
// 0x000001E8 System.Int32 Ionic.BZip2.BZip2InputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void BZip2InputStream_Read_m4B5A314335719881E72712F8142C979396B41291 (void);
// 0x000001E9 System.Void Ionic.BZip2.BZip2InputStream::MakeMaps()
extern void BZip2InputStream_MakeMaps_m08743EE6451C8E4D41AB20D7BB021D8253746C09 (void);
// 0x000001EA System.Int32 Ionic.BZip2.BZip2InputStream::ReadByte()
extern void BZip2InputStream_ReadByte_m928A2C60985BEB81098851A1CD53A912BDC5CFC9 (void);
// 0x000001EB System.Boolean Ionic.BZip2.BZip2InputStream::get_CanRead()
extern void BZip2InputStream_get_CanRead_mE2E6D7BCA3B88A7BF8AAC90A95BBA2D4F7EAE548 (void);
// 0x000001EC System.Boolean Ionic.BZip2.BZip2InputStream::get_CanSeek()
extern void BZip2InputStream_get_CanSeek_m2C72ABE3319FA63F4EA41831141F74A148CC3E70 (void);
// 0x000001ED System.Boolean Ionic.BZip2.BZip2InputStream::get_CanWrite()
extern void BZip2InputStream_get_CanWrite_mE4418F7B94B8E9396C65F269E22A5A7E1AF4ADA3 (void);
// 0x000001EE System.Void Ionic.BZip2.BZip2InputStream::Flush()
extern void BZip2InputStream_Flush_mE1FEE2E4B4C94BBACDA541A7703B6B6E2AF5D02A (void);
// 0x000001EF System.Int64 Ionic.BZip2.BZip2InputStream::get_Length()
extern void BZip2InputStream_get_Length_m4C52257D69E92CD8A0FF274D99ECAF9915B86CFB (void);
// 0x000001F0 System.Int64 Ionic.BZip2.BZip2InputStream::get_Position()
extern void BZip2InputStream_get_Position_m66484EAF05A64277574156ED86169A606DB160BA (void);
// 0x000001F1 System.Void Ionic.BZip2.BZip2InputStream::set_Position(System.Int64)
extern void BZip2InputStream_set_Position_m5B2742F41FEFBD68768286BCCE4C8BA18C14ABAB (void);
// 0x000001F2 System.Int64 Ionic.BZip2.BZip2InputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void BZip2InputStream_Seek_mF3C8579B8E2EEDA1925CF706205063F86E8FF7EE (void);
// 0x000001F3 System.Void Ionic.BZip2.BZip2InputStream::SetLength(System.Int64)
extern void BZip2InputStream_SetLength_mB49DE9AAC35F91DC9758B3DA4B74368F97119A1C (void);
// 0x000001F4 System.Void Ionic.BZip2.BZip2InputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void BZip2InputStream_Write_mAE1D18E318616955B91D251775F9835FD47D5273 (void);
// 0x000001F5 System.Void Ionic.BZip2.BZip2InputStream::Dispose(System.Boolean)
extern void BZip2InputStream_Dispose_m70C3672FC397801DDBE844BC7E58C4AD151A5CDE (void);
// 0x000001F6 System.Void Ionic.BZip2.BZip2InputStream::init()
extern void BZip2InputStream_init_m733F6F47E24E6CFFC0AE1C7FC39FB3BA043560D3 (void);
// 0x000001F7 System.Void Ionic.BZip2.BZip2InputStream::CheckMagicChar(System.Char,System.Int32)
extern void BZip2InputStream_CheckMagicChar_mBA29F7441EB9507DB2F784B0B0E006576BDC9D2B (void);
// 0x000001F8 System.Void Ionic.BZip2.BZip2InputStream::InitBlock()
extern void BZip2InputStream_InitBlock_m12DF45C0D6464E96F5F5818248D42932F53D1509 (void);
// 0x000001F9 System.Void Ionic.BZip2.BZip2InputStream::EndBlock()
extern void BZip2InputStream_EndBlock_mE9B019E88DF2286E656CBDBAADB29B2A7C67A5A2 (void);
// 0x000001FA System.Void Ionic.BZip2.BZip2InputStream::complete()
extern void BZip2InputStream_complete_mD7A3806E4C552975FEE528324D97D3D491981277 (void);
// 0x000001FB System.Void Ionic.BZip2.BZip2InputStream::Close()
extern void BZip2InputStream_Close_mE1BF85ACF149D85197A1266805072938A40EFE48 (void);
// 0x000001FC System.Int32 Ionic.BZip2.BZip2InputStream::GetBits(System.Int32)
extern void BZip2InputStream_GetBits_mA876456FDC327E6610990B0F7AE3076DB4E4FDD4 (void);
// 0x000001FD System.Boolean Ionic.BZip2.BZip2InputStream::bsGetBit()
extern void BZip2InputStream_bsGetBit_m96011A71412F48D08EE0AA0E9F287F62332317C9 (void);
// 0x000001FE System.Char Ionic.BZip2.BZip2InputStream::bsGetUByte()
extern void BZip2InputStream_bsGetUByte_m1DF7B32A4A7B87383A11972DADC6147E5C8904E3 (void);
// 0x000001FF System.UInt32 Ionic.BZip2.BZip2InputStream::bsGetInt()
extern void BZip2InputStream_bsGetInt_mB9A50C3A090EC184CFD2E1F6F9CCCC41D2F03615 (void);
// 0x00000200 System.Void Ionic.BZip2.BZip2InputStream::hbCreateDecodeTables(System.Int32[],System.Int32[],System.Int32[],System.Char[],System.Int32,System.Int32,System.Int32)
extern void BZip2InputStream_hbCreateDecodeTables_m9C66E442DBEC805F22C30B40534D626BE53B24C3 (void);
// 0x00000201 System.Void Ionic.BZip2.BZip2InputStream::recvDecodingTables()
extern void BZip2InputStream_recvDecodingTables_m2F44567BEAB3B2AF4B9AF63CE4BAC8FEAE7C3DB4 (void);
// 0x00000202 System.Void Ionic.BZip2.BZip2InputStream::createHuffmanDecodingTables(System.Int32,System.Int32)
extern void BZip2InputStream_createHuffmanDecodingTables_mC7858C3C6FE3C2F51F66190E23667D353888BACB (void);
// 0x00000203 System.Void Ionic.BZip2.BZip2InputStream::getAndMoveToFrontDecode()
extern void BZip2InputStream_getAndMoveToFrontDecode_mADAC2520A5EA0656F747F57409A17C3838531124 (void);
// 0x00000204 System.Int32 Ionic.BZip2.BZip2InputStream::getAndMoveToFrontDecode0(System.Int32)
extern void BZip2InputStream_getAndMoveToFrontDecode0_m6F23B1945231A9632AB83A3CF10C0C316359EDF1 (void);
// 0x00000205 System.Void Ionic.BZip2.BZip2InputStream::SetupBlock()
extern void BZip2InputStream_SetupBlock_mE898DDFD7F41C7079DC60F4328333707418F8238 (void);
// 0x00000206 System.Void Ionic.BZip2.BZip2InputStream::SetupRandPartA()
extern void BZip2InputStream_SetupRandPartA_m99509EF9D2DCEFE1FC7079F2DBE1583E12976772 (void);
// 0x00000207 System.Void Ionic.BZip2.BZip2InputStream::SetupNoRandPartA()
extern void BZip2InputStream_SetupNoRandPartA_mF913A6950F5218DCFE33E4BA633B8F277B8A19B1 (void);
// 0x00000208 System.Void Ionic.BZip2.BZip2InputStream::SetupRandPartB()
extern void BZip2InputStream_SetupRandPartB_m90E0CAA173C920B68D5E008CB71BE1A21C075F2A (void);
// 0x00000209 System.Void Ionic.BZip2.BZip2InputStream::SetupRandPartC()
extern void BZip2InputStream_SetupRandPartC_m9E0B695F62D3A86BEDB5A9489D875585DDB5A631 (void);
// 0x0000020A System.Void Ionic.BZip2.BZip2InputStream::SetupNoRandPartB()
extern void BZip2InputStream_SetupNoRandPartB_m58943FE8F5671BBBAF45E96D76098AAC5CF1B312 (void);
// 0x0000020B System.Void Ionic.BZip2.BZip2InputStream::SetupNoRandPartC()
extern void BZip2InputStream_SetupNoRandPartC_m5C2E44C6A48F2E8FD26EA71F1676543B1A9E19F7 (void);
// 0x0000020C System.Void Ionic.BZip2.BZip2InputStream/DecompressionState::.ctor(System.Int32)
extern void DecompressionState__ctor_m18C1A285FBBE5F86742FE7DD8C5C4F91D3877914 (void);
// 0x0000020D System.Int32[] Ionic.BZip2.BZip2InputStream/DecompressionState::initTT(System.Int32)
extern void DecompressionState_initTT_mCE35C3EAB11A7BDD797AF66E76E716A81822D91A (void);
// 0x0000020E T[][] Ionic.BZip2.BZip2::InitRectangularArray(System.Int32,System.Int32)
// 0x0000020F System.Void Ionic.BZip2.BZip2::.cctor()
extern void BZip2__cctor_mBB3F8069B24A99CB13EC4078D78AC08057D61FBB (void);
// 0x00000210 System.Void Ionic.BZip2.BZip2OutputStream::.ctor(System.IO.Stream,System.Boolean)
extern void BZip2OutputStream__ctor_m0BE5AA0484757CCEC16A7772C4B174E1232C6BA6 (void);
// 0x00000211 System.Void Ionic.BZip2.BZip2OutputStream::.ctor(System.IO.Stream,System.Int32,System.Boolean)
extern void BZip2OutputStream__ctor_m63AE4F0ABF96E85810D40601EE49E2FB51F4AE30 (void);
// 0x00000212 System.Void Ionic.BZip2.BZip2OutputStream::Close()
extern void BZip2OutputStream_Close_m5BA776801881BF87DA49CA90306F834DD4ACD8AF (void);
// 0x00000213 System.Void Ionic.BZip2.BZip2OutputStream::Flush()
extern void BZip2OutputStream_Flush_m1612E02D74AC00C31757E7BDD5C144C63C56EBC0 (void);
// 0x00000214 System.Void Ionic.BZip2.BZip2OutputStream::EmitHeader()
extern void BZip2OutputStream_EmitHeader_m1DE3B95D04B77A91D717E383EF2CC18556BE25B1 (void);
// 0x00000215 System.Void Ionic.BZip2.BZip2OutputStream::EmitTrailer()
extern void BZip2OutputStream_EmitTrailer_m7C6E9A7F9D2D648F6EB69FFC8E7598759203FE75 (void);
// 0x00000216 System.Void Ionic.BZip2.BZip2OutputStream::Finish()
extern void BZip2OutputStream_Finish_m3B32B8628B960470E2E13205E9258BA0697963EE (void);
// 0x00000217 System.Void Ionic.BZip2.BZip2OutputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void BZip2OutputStream_Write_m69A9CC3A956638BD7020EE679BCD14A93E9B1FD8 (void);
// 0x00000218 System.Boolean Ionic.BZip2.BZip2OutputStream::get_CanRead()
extern void BZip2OutputStream_get_CanRead_mFD3895BED8B7C2F8AEF84BFF5597EB01A9A933B9 (void);
// 0x00000219 System.Boolean Ionic.BZip2.BZip2OutputStream::get_CanSeek()
extern void BZip2OutputStream_get_CanSeek_m07F87067A043FF4197675E64933438603A5A5474 (void);
// 0x0000021A System.Boolean Ionic.BZip2.BZip2OutputStream::get_CanWrite()
extern void BZip2OutputStream_get_CanWrite_mC11066D3B70CA57DBDDF5F10F6A8F4565C7477EF (void);
// 0x0000021B System.Int64 Ionic.BZip2.BZip2OutputStream::get_Length()
extern void BZip2OutputStream_get_Length_m7FA19E9C827AAD7E3E3173C769617820A4F75A4D (void);
// 0x0000021C System.Int64 Ionic.BZip2.BZip2OutputStream::get_Position()
extern void BZip2OutputStream_get_Position_mC8D689E873F49FA7590754A768F25F425E936033 (void);
// 0x0000021D System.Void Ionic.BZip2.BZip2OutputStream::set_Position(System.Int64)
extern void BZip2OutputStream_set_Position_mE3DD27BC7F1276696A4968D044F3CFCCA24982F9 (void);
// 0x0000021E System.Int64 Ionic.BZip2.BZip2OutputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void BZip2OutputStream_Seek_mBA1A267B5BDA4970C52DDA6AA7A9D986B7AD339D (void);
// 0x0000021F System.Void Ionic.BZip2.BZip2OutputStream::SetLength(System.Int64)
extern void BZip2OutputStream_SetLength_mE7B4879C2A890F5598849A42317E1FAF9B96C800 (void);
// 0x00000220 System.Int32 Ionic.BZip2.BZip2OutputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void BZip2OutputStream_Read_m06FED714C84512E7E34329A74EDCEF809CB0FE3E (void);
// 0x00000221 Ionic.BZip2.BZip2Compressor Ionic.BZip2.WorkItem::get_Compressor()
extern void WorkItem_get_Compressor_m046F4CCB162F349FBEBD80C60A959C36F3B51CBC (void);
// 0x00000222 System.Void Ionic.BZip2.WorkItem::set_Compressor(Ionic.BZip2.BZip2Compressor)
extern void WorkItem_set_Compressor_m621D715A0CAA78C46272DFB6DB2750DCDFAD5C30 (void);
// 0x00000223 System.Void Ionic.BZip2.WorkItem::.ctor(System.Int32,System.Int32)
extern void WorkItem__ctor_mE01970ABA1DF70EEA04D6190F4631CBB7E5FE7AB (void);
// 0x00000224 System.Void Ionic.BZip2.ParallelBZip2OutputStream::.ctor(System.IO.Stream,System.Boolean)
extern void ParallelBZip2OutputStream__ctor_m4D272F339AA90F3038C97554FC1F65BB6A6BC2B8 (void);
// 0x00000225 System.Void Ionic.BZip2.ParallelBZip2OutputStream::.ctor(System.IO.Stream,System.Int32,System.Boolean)
extern void ParallelBZip2OutputStream__ctor_m6B2CA1D2468FAFB177D4F85908271E794AA9460E (void);
// 0x00000226 System.Void Ionic.BZip2.ParallelBZip2OutputStream::InitializePoolOfWorkItems()
extern void ParallelBZip2OutputStream_InitializePoolOfWorkItems_m5E49B6D3B89837A512B4F59EA511758F97F96B0E (void);
// 0x00000227 System.Int32 Ionic.BZip2.ParallelBZip2OutputStream::get_MaxWorkers()
extern void ParallelBZip2OutputStream_get_MaxWorkers_m84F03253BBAF1857FCF24C96D6A068A8BECC9609 (void);
// 0x00000228 System.Void Ionic.BZip2.ParallelBZip2OutputStream::set_MaxWorkers(System.Int32)
extern void ParallelBZip2OutputStream_set_MaxWorkers_mA99061B20A342D5D7207E033DEB5612B686BF12B (void);
// 0x00000229 System.Void Ionic.BZip2.ParallelBZip2OutputStream::Close()
extern void ParallelBZip2OutputStream_Close_m6A0752BA1389DF390B077F13375B86920E8A1AFA (void);
// 0x0000022A System.Void Ionic.BZip2.ParallelBZip2OutputStream::FlushOutput(System.Boolean)
extern void ParallelBZip2OutputStream_FlushOutput_m827F5DBC0380FEC2BAD2D7656198913C34DA0FE8 (void);
// 0x0000022B System.Void Ionic.BZip2.ParallelBZip2OutputStream::Flush()
extern void ParallelBZip2OutputStream_Flush_m65B3107DCA9BDDD19F4E68449C2FB97D596E596A (void);
// 0x0000022C System.Void Ionic.BZip2.ParallelBZip2OutputStream::EmitHeader()
extern void ParallelBZip2OutputStream_EmitHeader_m7534D339E5D4E834429D0633B8977F57FCC8AA07 (void);
// 0x0000022D System.Void Ionic.BZip2.ParallelBZip2OutputStream::EmitTrailer()
extern void ParallelBZip2OutputStream_EmitTrailer_mE7B8E278F3B8369F52742194542D8D30E8A63EFA (void);
// 0x0000022E System.Void Ionic.BZip2.ParallelBZip2OutputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ParallelBZip2OutputStream_Write_mC018C4DD4CEE06D5D43D29A6175AE390EEE25477 (void);
// 0x0000022F System.Void Ionic.BZip2.ParallelBZip2OutputStream::EmitPendingBuffers(System.Boolean,System.Boolean)
extern void ParallelBZip2OutputStream_EmitPendingBuffers_m353C7F4EF2E1822DFE99B207A105DFC5C077AC79 (void);
// 0x00000230 System.Void Ionic.BZip2.ParallelBZip2OutputStream::CompressOne(System.Object)
extern void ParallelBZip2OutputStream_CompressOne_m8B35672163D97EAC6587123142D095C9E656ACCC (void);
// 0x00000231 System.Boolean Ionic.BZip2.ParallelBZip2OutputStream::get_CanRead()
extern void ParallelBZip2OutputStream_get_CanRead_m74080BAA5ED89DEA03BACEAB1ABB0B15F04E02F5 (void);
// 0x00000232 System.Boolean Ionic.BZip2.ParallelBZip2OutputStream::get_CanSeek()
extern void ParallelBZip2OutputStream_get_CanSeek_m1A963665DEFD7C39E2F7AE93E39FF7DA14704B98 (void);
// 0x00000233 System.Boolean Ionic.BZip2.ParallelBZip2OutputStream::get_CanWrite()
extern void ParallelBZip2OutputStream_get_CanWrite_m7557B78AC42B592370E47C2BC33E3D62D178EE09 (void);
// 0x00000234 System.Int64 Ionic.BZip2.ParallelBZip2OutputStream::get_Length()
extern void ParallelBZip2OutputStream_get_Length_m4E81ADF75FD9AE4543D4C1EC96B8C40E45168631 (void);
// 0x00000235 System.Int64 Ionic.BZip2.ParallelBZip2OutputStream::get_Position()
extern void ParallelBZip2OutputStream_get_Position_m6ACD1E658A6BA27721C8FC43CA0F953E7558E29E (void);
// 0x00000236 System.Void Ionic.BZip2.ParallelBZip2OutputStream::set_Position(System.Int64)
extern void ParallelBZip2OutputStream_set_Position_m7A4A0D74A410FC67932F42FD5C637D0C03E009CF (void);
// 0x00000237 System.Int64 Ionic.BZip2.ParallelBZip2OutputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ParallelBZip2OutputStream_Seek_mB2D1552FCDB742449C560B6489B5F3211E9AAFFB (void);
// 0x00000238 System.Void Ionic.BZip2.ParallelBZip2OutputStream::SetLength(System.Int64)
extern void ParallelBZip2OutputStream_SetLength_m65E872BEB22C11D54ED9E901BE9D0ACCA95C95A0 (void);
// 0x00000239 System.Int32 Ionic.BZip2.ParallelBZip2OutputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ParallelBZip2OutputStream_Read_m638098749482D48700F859B6D46D3D90DDA50388 (void);
// 0x0000023A System.Void Ionic.BZip2.ParallelBZip2OutputStream::.cctor()
extern void ParallelBZip2OutputStream__cctor_m7211795BEB5E16622AD18960471D307775E92B9F (void);
// 0x0000023B System.Int32 Ionic.BZip2.Rand::Rnums(System.Int32)
extern void Rand_Rnums_mEAB7E40B4850FAD5F4DB376EC10D6A4851AB2534 (void);
// 0x0000023C System.Void Ionic.BZip2.Rand::.cctor()
extern void Rand__cctor_m315115DD4682AFFA5A5DCCEEBA269E4E364CD79E (void);
// 0x0000023D System.Void Ionic.Zlib.DeflateManager::.ctor()
extern void DeflateManager__ctor_m673892FC3A1CBD9A29E22BD172E6A3692FAC15E7 (void);
// 0x0000023E System.Void Ionic.Zlib.DeflateManager::_InitializeLazyMatch()
extern void DeflateManager__InitializeLazyMatch_m379A2C533AE8525D2A42DC770DBADCB0C594D34F (void);
// 0x0000023F System.Void Ionic.Zlib.DeflateManager::_InitializeTreeData()
extern void DeflateManager__InitializeTreeData_m2A45CA9A1F1BC4F6B9AED230EA244AAD4A7D26C4 (void);
// 0x00000240 System.Void Ionic.Zlib.DeflateManager::_InitializeBlocks()
extern void DeflateManager__InitializeBlocks_mCAC5916D44A421E7EF0C2EDB28B39ECDAA662E5F (void);
// 0x00000241 System.Void Ionic.Zlib.DeflateManager::pqdownheap(System.Int16[],System.Int32)
extern void DeflateManager_pqdownheap_mB0C0AD8B852586766E8387BA14206891CFF92C6D (void);
// 0x00000242 System.Boolean Ionic.Zlib.DeflateManager::_IsSmaller(System.Int16[],System.Int32,System.Int32,System.SByte[])
extern void DeflateManager__IsSmaller_m3B82488927899FCD2D88365B45B41C9CE16F03AF (void);
// 0x00000243 System.Void Ionic.Zlib.DeflateManager::scan_tree(System.Int16[],System.Int32)
extern void DeflateManager_scan_tree_m308FDA1D0515F89450B31218EA55C140A5A1A268 (void);
// 0x00000244 System.Int32 Ionic.Zlib.DeflateManager::build_bl_tree()
extern void DeflateManager_build_bl_tree_m2F4844B7317C947DD017E8F51FD46D6814F38A49 (void);
// 0x00000245 System.Void Ionic.Zlib.DeflateManager::send_all_trees(System.Int32,System.Int32,System.Int32)
extern void DeflateManager_send_all_trees_mA1A3534DD25E2E8DB24DACA29C388C2961AEB637 (void);
// 0x00000246 System.Void Ionic.Zlib.DeflateManager::send_tree(System.Int16[],System.Int32)
extern void DeflateManager_send_tree_mCAAC63E9C5AD0123CDE36C26366532DE354DF671 (void);
// 0x00000247 System.Void Ionic.Zlib.DeflateManager::put_bytes(System.Byte[],System.Int32,System.Int32)
extern void DeflateManager_put_bytes_mCF4CDD1CFE05B85A2EC5AC85A2D5CED672E65A31 (void);
// 0x00000248 System.Void Ionic.Zlib.DeflateManager::send_code(System.Int32,System.Int16[])
extern void DeflateManager_send_code_m65824D5B4571BCB54AD634B232B3AE571D836A53 (void);
// 0x00000249 System.Void Ionic.Zlib.DeflateManager::send_bits(System.Int32,System.Int32)
extern void DeflateManager_send_bits_mFE0FD7593E4F2FA302F28397B38C49E871145C39 (void);
// 0x0000024A System.Void Ionic.Zlib.DeflateManager::_tr_align()
extern void DeflateManager__tr_align_m13E65833D07DFB16BB3EB984634A8A7E46CDF7E3 (void);
// 0x0000024B System.Boolean Ionic.Zlib.DeflateManager::_tr_tally(System.Int32,System.Int32)
extern void DeflateManager__tr_tally_m6A6E27AEFB338D384B61101C43250183A64A39A7 (void);
// 0x0000024C System.Void Ionic.Zlib.DeflateManager::send_compressed_block(System.Int16[],System.Int16[])
extern void DeflateManager_send_compressed_block_m6939DB771E1E1D4E99972E7D771443CB1ED89085 (void);
// 0x0000024D System.Void Ionic.Zlib.DeflateManager::set_data_type()
extern void DeflateManager_set_data_type_m20652FD813E4D17285CBA2B02B3FE31410134BC4 (void);
// 0x0000024E System.Void Ionic.Zlib.DeflateManager::bi_flush()
extern void DeflateManager_bi_flush_m88D27CF5101646EB5B6AED63ACC49B421617B96C (void);
// 0x0000024F System.Void Ionic.Zlib.DeflateManager::bi_windup()
extern void DeflateManager_bi_windup_mB45A42D9FEFD7BD94726C605D8C4F5A1652FA263 (void);
// 0x00000250 System.Void Ionic.Zlib.DeflateManager::copy_block(System.Int32,System.Int32,System.Boolean)
extern void DeflateManager_copy_block_mD225B994AA8BFC0041EF7F95568CE75C47684D71 (void);
// 0x00000251 System.Void Ionic.Zlib.DeflateManager::flush_block_only(System.Boolean)
extern void DeflateManager_flush_block_only_mF828E18744E6601044F2BAB54537D69337111A40 (void);
// 0x00000252 Ionic.Zlib.BlockState Ionic.Zlib.DeflateManager::DeflateNone(Ionic.Zlib.FlushType)
extern void DeflateManager_DeflateNone_m6D5C001FBAAC4A844BDDD1DB8535AA1C14AF620B (void);
// 0x00000253 System.Void Ionic.Zlib.DeflateManager::_tr_stored_block(System.Int32,System.Int32,System.Boolean)
extern void DeflateManager__tr_stored_block_mCE0E5C5ED44FED65F2D0AC296E3A7DFD3C4A5AB7 (void);
// 0x00000254 System.Void Ionic.Zlib.DeflateManager::_tr_flush_block(System.Int32,System.Int32,System.Boolean)
extern void DeflateManager__tr_flush_block_m3B6D356E6FF874EA1EF5CE880FBAB96D2A49B237 (void);
// 0x00000255 System.Void Ionic.Zlib.DeflateManager::_fillWindow()
extern void DeflateManager__fillWindow_m93275F98D8823C7C41047B7C987A2C58BE7E71D0 (void);
// 0x00000256 Ionic.Zlib.BlockState Ionic.Zlib.DeflateManager::DeflateFast(Ionic.Zlib.FlushType)
extern void DeflateManager_DeflateFast_mCB6BB716ABA82E871C3A3BBE050826B68BF227FA (void);
// 0x00000257 Ionic.Zlib.BlockState Ionic.Zlib.DeflateManager::DeflateSlow(Ionic.Zlib.FlushType)
extern void DeflateManager_DeflateSlow_m62B70384CC6D843507EDF296C347D638CD972B81 (void);
// 0x00000258 System.Int32 Ionic.Zlib.DeflateManager::longest_match(System.Int32)
extern void DeflateManager_longest_match_m3C308D51E77F9ED7A88835CA76B34338FD21482A (void);
// 0x00000259 System.Boolean Ionic.Zlib.DeflateManager::get_WantRfc1950HeaderBytes()
extern void DeflateManager_get_WantRfc1950HeaderBytes_m272EAEFE3BA2E1F77DC32034977C57BE27DEDFCF (void);
// 0x0000025A System.Void Ionic.Zlib.DeflateManager::set_WantRfc1950HeaderBytes(System.Boolean)
extern void DeflateManager_set_WantRfc1950HeaderBytes_mABBB4B9D8368738D4FF5922D1215907F1AAAB85F (void);
// 0x0000025B System.Int32 Ionic.Zlib.DeflateManager::Initialize(Ionic.Zlib.ZlibCodec,Ionic.Zlib.CompressionLevel,System.Int32,Ionic.Zlib.CompressionStrategy)
extern void DeflateManager_Initialize_m88BD2C811B3894FD301B6A5B809C5D4A82CE22BB (void);
// 0x0000025C System.Int32 Ionic.Zlib.DeflateManager::Initialize(Ionic.Zlib.ZlibCodec,Ionic.Zlib.CompressionLevel,System.Int32,System.Int32,Ionic.Zlib.CompressionStrategy)
extern void DeflateManager_Initialize_mADCBBFBB6D546DE532FBF769C0F1166F5966EDEC (void);
// 0x0000025D System.Void Ionic.Zlib.DeflateManager::Reset()
extern void DeflateManager_Reset_mB94032B5B8797C2376107C683C39A8E412C059B5 (void);
// 0x0000025E System.Void Ionic.Zlib.DeflateManager::SetDeflater()
extern void DeflateManager_SetDeflater_mB433E7050024976AE53A06D7F36E597D70E6C893 (void);
// 0x0000025F System.Int32 Ionic.Zlib.DeflateManager::Deflate(Ionic.Zlib.FlushType)
extern void DeflateManager_Deflate_m1EB192C0188EF1F10925E173193F3F2A64711CFE (void);
// 0x00000260 System.Void Ionic.Zlib.DeflateManager::.cctor()
extern void DeflateManager__cctor_mDDB46D27E997AB2407ADCF4E2951A5F980032534 (void);
// 0x00000261 System.Void Ionic.Zlib.DeflateManager/CompressFunc::.ctor(System.Object,System.IntPtr)
extern void CompressFunc__ctor_m4AA09C64C193D6F880A9E9D274E32E57121FBEAE (void);
// 0x00000262 Ionic.Zlib.BlockState Ionic.Zlib.DeflateManager/CompressFunc::Invoke(Ionic.Zlib.FlushType)
extern void CompressFunc_Invoke_mFFD4FF3455F7139A4D2E8FE2783945530C50A8EC (void);
// 0x00000263 System.Void Ionic.Zlib.DeflateManager/Config::.ctor(System.Int32,System.Int32,System.Int32,System.Int32,Ionic.Zlib.DeflateFlavor)
extern void Config__ctor_m8CC004E99CC83462780C4A8F4BD6343535FE8E20 (void);
// 0x00000264 Ionic.Zlib.DeflateManager/Config Ionic.Zlib.DeflateManager/Config::Lookup(Ionic.Zlib.CompressionLevel)
extern void Config_Lookup_mD4BC48A84B374131891BB93F4B00EAEAFD4808FD (void);
// 0x00000265 System.Void Ionic.Zlib.DeflateManager/Config::.cctor()
extern void Config__cctor_m192786F448884B2CD2445D0AD037A8CECD74CF61 (void);
// 0x00000266 System.Void Ionic.Zlib.DeflateStream::.ctor(System.IO.Stream,Ionic.Zlib.CompressionMode,System.Boolean)
extern void DeflateStream__ctor_m526D853A68218A6BEB24BD85F05E935357919959 (void);
// 0x00000267 System.Void Ionic.Zlib.DeflateStream::.ctor(System.IO.Stream,Ionic.Zlib.CompressionMode,Ionic.Zlib.CompressionLevel,System.Boolean)
extern void DeflateStream__ctor_mD0A2C65F467BDE8A2BDE997287A2DB9745422F2E (void);
// 0x00000268 System.Void Ionic.Zlib.DeflateStream::set_BufferSize(System.Int32)
extern void DeflateStream_set_BufferSize_m34A2182A2275B8C42D1612BDB72F066250A2889B (void);
// 0x00000269 System.Void Ionic.Zlib.DeflateStream::set_Strategy(Ionic.Zlib.CompressionStrategy)
extern void DeflateStream_set_Strategy_mBCF4C5B63CF6F14A6222CF4A56C2D8FBFAAFF2B1 (void);
// 0x0000026A System.Void Ionic.Zlib.DeflateStream::Dispose(System.Boolean)
extern void DeflateStream_Dispose_mBA9F1D0B90214CC7AC4763A616DED39A2051C450 (void);
// 0x0000026B System.Boolean Ionic.Zlib.DeflateStream::get_CanRead()
extern void DeflateStream_get_CanRead_mD636DAD1BDC5C986C172B222A935E8838A4CCC7E (void);
// 0x0000026C System.Boolean Ionic.Zlib.DeflateStream::get_CanSeek()
extern void DeflateStream_get_CanSeek_m7B70CE6446B31A4CFCEF16A6B5D30062750776A8 (void);
// 0x0000026D System.Boolean Ionic.Zlib.DeflateStream::get_CanWrite()
extern void DeflateStream_get_CanWrite_mD8E8DB6A601B51FD7212CDE605ADE2AD29527404 (void);
// 0x0000026E System.Void Ionic.Zlib.DeflateStream::Flush()
extern void DeflateStream_Flush_mB07003845E043821D30C24733FCD10927E208C14 (void);
// 0x0000026F System.Int64 Ionic.Zlib.DeflateStream::get_Length()
extern void DeflateStream_get_Length_m1672C559C9CFBF3A3F1381F9AA80232F51F0CA65 (void);
// 0x00000270 System.Int64 Ionic.Zlib.DeflateStream::get_Position()
extern void DeflateStream_get_Position_m93D6C073E3273CC87FDF87EA8C3837ECFA225306 (void);
// 0x00000271 System.Void Ionic.Zlib.DeflateStream::set_Position(System.Int64)
extern void DeflateStream_set_Position_m7373C8D9F3C3D6BCAEBC5819E6CA0429A26BF2A7 (void);
// 0x00000272 System.Int32 Ionic.Zlib.DeflateStream::Read(System.Byte[],System.Int32,System.Int32)
extern void DeflateStream_Read_mAC2FA09753A1F2DA73D6C6125315B67DF029EA7D (void);
// 0x00000273 System.Int64 Ionic.Zlib.DeflateStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void DeflateStream_Seek_m2E56224D609B67EF11F27866C502ED89A845D644 (void);
// 0x00000274 System.Void Ionic.Zlib.DeflateStream::SetLength(System.Int64)
extern void DeflateStream_SetLength_m1EC3B46D6C3C2BE8F3B95C7B8597BE0B9D18CAE0 (void);
// 0x00000275 System.Void Ionic.Zlib.DeflateStream::Write(System.Byte[],System.Int32,System.Int32)
extern void DeflateStream_Write_m8F4B88D3DFE5FE3B8DF74C54FE0D1E2B68B0FE17 (void);
// 0x00000276 System.String Ionic.Zlib.GZipStream::get_Comment()
extern void GZipStream_get_Comment_m7CD30C891BABC13DADA6FEEE7D981059476D0E32 (void);
// 0x00000277 System.Void Ionic.Zlib.GZipStream::set_Comment(System.String)
extern void GZipStream_set_Comment_m9474C9EDC6CF3149558AF67F49EE27BF8D8D9E27 (void);
// 0x00000278 System.String Ionic.Zlib.GZipStream::get_FileName()
extern void GZipStream_get_FileName_m3E62EF49DC029D39C08FD8CB2F9E4F866EC7F7EF (void);
// 0x00000279 System.Void Ionic.Zlib.GZipStream::set_FileName(System.String)
extern void GZipStream_set_FileName_m12C70BD5813D0300EC2BD4738ABC02E6A93410B3 (void);
// 0x0000027A System.Boolean Ionic.Zlib.GZipStream::get_CanRead()
extern void GZipStream_get_CanRead_m6E965039A3D74CD1D27B354EB33548952F20AA98 (void);
// 0x0000027B System.Boolean Ionic.Zlib.GZipStream::get_CanSeek()
extern void GZipStream_get_CanSeek_m0F9A02066DDF200C2704E753B4AECC3A7C31B847 (void);
// 0x0000027C System.Boolean Ionic.Zlib.GZipStream::get_CanWrite()
extern void GZipStream_get_CanWrite_mE9AE609702DC0EFD7A79587711F94ACF5C17F798 (void);
// 0x0000027D System.Void Ionic.Zlib.GZipStream::Flush()
extern void GZipStream_Flush_mB063080933544FC4897E4A0B531AF83F481AEBA5 (void);
// 0x0000027E System.Int64 Ionic.Zlib.GZipStream::get_Length()
extern void GZipStream_get_Length_m0497BF443DC8BB48A09884D278A2C72B4B294AD8 (void);
// 0x0000027F System.Int64 Ionic.Zlib.GZipStream::get_Position()
extern void GZipStream_get_Position_m65C03842613D053AA4B85B3690FBF74D10F70894 (void);
// 0x00000280 System.Void Ionic.Zlib.GZipStream::set_Position(System.Int64)
extern void GZipStream_set_Position_mF31070FC48ED0B0A455EBE0470A8C146931CAA3D (void);
// 0x00000281 System.Int32 Ionic.Zlib.GZipStream::Read(System.Byte[],System.Int32,System.Int32)
extern void GZipStream_Read_mB53A305B4FDE06EE66BF99DC27D952E33E74928F (void);
// 0x00000282 System.Int64 Ionic.Zlib.GZipStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void GZipStream_Seek_mD4E31CD4CF4EC5767B98D31D7F7DB2963B200A9B (void);
// 0x00000283 System.Void Ionic.Zlib.GZipStream::SetLength(System.Int64)
extern void GZipStream_SetLength_m19F98C9C154588E3D6D100BCD9B5BA063022FF7C (void);
// 0x00000284 System.Void Ionic.Zlib.GZipStream::Write(System.Byte[],System.Int32,System.Int32)
extern void GZipStream_Write_m4BB9F116E2AB14242924C9243229F3A223E11B98 (void);
// 0x00000285 System.Int32 Ionic.Zlib.GZipStream::EmitHeader()
extern void GZipStream_EmitHeader_mB6AC12AA7DA11B53251570D2DF4177848ACCC347 (void);
// 0x00000286 System.Void Ionic.Zlib.GZipStream::.cctor()
extern void GZipStream__cctor_mA0AF0F21978757B76A302CC4083DFF43AF36C8B0 (void);
// 0x00000287 System.Void Ionic.Zlib.InflateBlocks::.ctor(Ionic.Zlib.ZlibCodec,System.Object,System.Int32)
extern void InflateBlocks__ctor_mBD83187E515C1662163E80CE84E600B4BBF1E1A9 (void);
// 0x00000288 System.UInt32 Ionic.Zlib.InflateBlocks::Reset()
extern void InflateBlocks_Reset_mC62260B568FCC7B5C6E375E996074D24216F49DB (void);
// 0x00000289 System.Int32 Ionic.Zlib.InflateBlocks::Process(System.Int32)
extern void InflateBlocks_Process_mEC4507D32AE3CFF3A3C8F5423539E093245D1B19 (void);
// 0x0000028A System.Void Ionic.Zlib.InflateBlocks::Free()
extern void InflateBlocks_Free_m7B9C1A78B3DB023A09527BC17672191F51BB9DC8 (void);
// 0x0000028B System.Int32 Ionic.Zlib.InflateBlocks::Flush(System.Int32)
extern void InflateBlocks_Flush_m82377F0E2FB5B7DB9346CD475443F4FDEF97E03E (void);
// 0x0000028C System.Void Ionic.Zlib.InflateBlocks::.cctor()
extern void InflateBlocks__cctor_m2C16853FAF2D4F4253B3B80A83D87CE3F2A91287 (void);
// 0x0000028D System.Void Ionic.Zlib.InternalInflateConstants::.cctor()
extern void InternalInflateConstants__cctor_m4A8E1B064AFEF4BC891D3CC2198C2B105A78FD54 (void);
// 0x0000028E System.Void Ionic.Zlib.InflateCodes::.ctor()
extern void InflateCodes__ctor_m45BAF7B545F633FF622E70663867CF3F88BDCB77 (void);
// 0x0000028F System.Void Ionic.Zlib.InflateCodes::Init(System.Int32,System.Int32,System.Int32[],System.Int32,System.Int32[],System.Int32)
extern void InflateCodes_Init_m053AB0454E9975AA50F25A2FB0717429AD3E98EA (void);
// 0x00000290 System.Int32 Ionic.Zlib.InflateCodes::Process(Ionic.Zlib.InflateBlocks,System.Int32)
extern void InflateCodes_Process_m4249FD5D2910A102F371910F0467779F7387933C (void);
// 0x00000291 System.Int32 Ionic.Zlib.InflateCodes::InflateFast(System.Int32,System.Int32,System.Int32[],System.Int32,System.Int32[],System.Int32,Ionic.Zlib.InflateBlocks,Ionic.Zlib.ZlibCodec)
extern void InflateCodes_InflateFast_mE5B0513DDEB93922CE88B74A87D1E1AB13964ECE (void);
// 0x00000292 System.Boolean Ionic.Zlib.InflateManager::get_HandleRfc1950HeaderBytes()
extern void InflateManager_get_HandleRfc1950HeaderBytes_m7BEA6F6A7B1198443E61DD6571AFD8E590ADE2C7 (void);
// 0x00000293 System.Void Ionic.Zlib.InflateManager::.ctor(System.Boolean)
extern void InflateManager__ctor_m4449199BB4F2A4519FC54B43AE5CE853A6B5B758 (void);
// 0x00000294 System.Int32 Ionic.Zlib.InflateManager::Reset()
extern void InflateManager_Reset_mEC3AE288F09C96AEB6C089E65924B62F9D55856D (void);
// 0x00000295 System.Int32 Ionic.Zlib.InflateManager::End()
extern void InflateManager_End_m208F730D247B703035CE2DEADDFEA8B499466B77 (void);
// 0x00000296 System.Int32 Ionic.Zlib.InflateManager::Initialize(Ionic.Zlib.ZlibCodec,System.Int32)
extern void InflateManager_Initialize_m277BD686D0CDC51E687E558211D2B2AB049266B6 (void);
// 0x00000297 System.Int32 Ionic.Zlib.InflateManager::Inflate(Ionic.Zlib.FlushType)
extern void InflateManager_Inflate_mA1862D22D7D8FF6D4D69516F331D9C8D81CB850D (void);
// 0x00000298 System.Void Ionic.Zlib.InflateManager::.cctor()
extern void InflateManager__cctor_mE04E0A27D33EFBF0B84C7437DF7F861F9EE48DD8 (void);
// 0x00000299 System.Int32 Ionic.Zlib.InfTree::huft_build(System.Int32[],System.Int32,System.Int32,System.Int32,System.Int32[],System.Int32[],System.Int32[],System.Int32[],System.Int32[],System.Int32[],System.Int32[])
extern void InfTree_huft_build_m2468529E1E944A048AECF9A398B0FA00B9300B5B (void);
// 0x0000029A System.Int32 Ionic.Zlib.InfTree::inflate_trees_bits(System.Int32[],System.Int32[],System.Int32[],System.Int32[],Ionic.Zlib.ZlibCodec)
extern void InfTree_inflate_trees_bits_m5935E854D400B7C9D4775C3E4BB5E3E3F9F52E3D (void);
// 0x0000029B System.Int32 Ionic.Zlib.InfTree::inflate_trees_dynamic(System.Int32,System.Int32,System.Int32[],System.Int32[],System.Int32[],System.Int32[],System.Int32[],System.Int32[],Ionic.Zlib.ZlibCodec)
extern void InfTree_inflate_trees_dynamic_m635E3DE846E6C42287BCF4E6FEC97812720B594A (void);
// 0x0000029C System.Int32 Ionic.Zlib.InfTree::inflate_trees_fixed(System.Int32[],System.Int32[],System.Int32[][],System.Int32[][],Ionic.Zlib.ZlibCodec)
extern void InfTree_inflate_trees_fixed_m061BDCEAA821B2ABC96E2E719180545662C1B49F (void);
// 0x0000029D System.Void Ionic.Zlib.InfTree::initWorkArea(System.Int32)
extern void InfTree_initWorkArea_m92F4D89818B4BC8822FC0E8C280374B8837B5092 (void);
// 0x0000029E System.Void Ionic.Zlib.InfTree::.ctor()
extern void InfTree__ctor_mE10403441546396BCDD4C5BA558149D1793B7660 (void);
// 0x0000029F System.Void Ionic.Zlib.InfTree::.cctor()
extern void InfTree__cctor_m7FFB7AB8BF2FE19A163715BF7D18CAA206839A36 (void);
// 0x000002A0 System.Void Ionic.Zlib.WorkItem::.ctor(System.Int32,Ionic.Zlib.CompressionLevel,Ionic.Zlib.CompressionStrategy,System.Int32)
extern void WorkItem__ctor_mE90C0B5F4D1B5267E4A2ABDF393F2F5AA7484AFA (void);
// 0x000002A1 System.Void Ionic.Zlib.ParallelDeflateOutputStream::.ctor(System.IO.Stream,Ionic.Zlib.CompressionLevel,Ionic.Zlib.CompressionStrategy,System.Boolean)
extern void ParallelDeflateOutputStream__ctor_m12A5E40C0EE7176A17CFED55B6BF864823D10E5E (void);
// 0x000002A2 Ionic.Zlib.CompressionStrategy Ionic.Zlib.ParallelDeflateOutputStream::get_Strategy()
extern void ParallelDeflateOutputStream_get_Strategy_m6B656B8ED562A795E602FBE9318D562497A809E2 (void);
// 0x000002A3 System.Void Ionic.Zlib.ParallelDeflateOutputStream::set_Strategy(Ionic.Zlib.CompressionStrategy)
extern void ParallelDeflateOutputStream_set_Strategy_m69949937485EF93C043D4100425063CD9B79B434 (void);
// 0x000002A4 System.Void Ionic.Zlib.ParallelDeflateOutputStream::set_MaxBufferPairs(System.Int32)
extern void ParallelDeflateOutputStream_set_MaxBufferPairs_m5FC76A706C345D1663E12798F3E6A58434C85310 (void);
// 0x000002A5 System.Void Ionic.Zlib.ParallelDeflateOutputStream::set_BufferSize(System.Int32)
extern void ParallelDeflateOutputStream_set_BufferSize_m93A54C256C068E0F3373E5F6A40F81349B58F20C (void);
// 0x000002A6 System.Void Ionic.Zlib.ParallelDeflateOutputStream::_InitializePoolOfWorkItems()
extern void ParallelDeflateOutputStream__InitializePoolOfWorkItems_mD0DB6E3BA62AFEEBF1EB5535642D120F786335C0 (void);
// 0x000002A7 System.Void Ionic.Zlib.ParallelDeflateOutputStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ParallelDeflateOutputStream_Write_m7E845633ED8BA36F1812AAA4D66D53B92A4A1EF4 (void);
// 0x000002A8 System.Void Ionic.Zlib.ParallelDeflateOutputStream::_FlushFinish()
extern void ParallelDeflateOutputStream__FlushFinish_m2F906333DC2C4141DB816FD57C07BA4B9E5E1822 (void);
// 0x000002A9 System.Void Ionic.Zlib.ParallelDeflateOutputStream::_Flush(System.Boolean)
extern void ParallelDeflateOutputStream__Flush_mCC8D0791FB4B9025A9A83F1599B41544DDDF9DF9 (void);
// 0x000002AA System.Void Ionic.Zlib.ParallelDeflateOutputStream::Flush()
extern void ParallelDeflateOutputStream_Flush_mDFD512CCD5174225D4940B32B56A104C87F673CF (void);
// 0x000002AB System.Void Ionic.Zlib.ParallelDeflateOutputStream::Close()
extern void ParallelDeflateOutputStream_Close_m5C0B62B952804D7069545477BB19A9ACA1C0D31F (void);
// 0x000002AC System.Void Ionic.Zlib.ParallelDeflateOutputStream::Dispose()
extern void ParallelDeflateOutputStream_Dispose_m411A16D85461D71930E94DC098E027EF8CF5685E (void);
// 0x000002AD System.Void Ionic.Zlib.ParallelDeflateOutputStream::Dispose(System.Boolean)
extern void ParallelDeflateOutputStream_Dispose_m6F6D3D8EF785A9D9031ADC26B371EBB18FC6BC7F (void);
// 0x000002AE System.Void Ionic.Zlib.ParallelDeflateOutputStream::Reset(System.IO.Stream)
extern void ParallelDeflateOutputStream_Reset_mBB61A43C4FD5349085B1D33208DEEC5E8D0BAC5D (void);
// 0x000002AF System.Void Ionic.Zlib.ParallelDeflateOutputStream::EmitPendingBuffers(System.Boolean,System.Boolean)
extern void ParallelDeflateOutputStream_EmitPendingBuffers_mCE92EAA554C53986C1C5271291F98DA90FB6ABAE (void);
// 0x000002B0 System.Void Ionic.Zlib.ParallelDeflateOutputStream::_DeflateOne(System.Object)
extern void ParallelDeflateOutputStream__DeflateOne_mECB7A876BF3A253004F121471CF30EAC6675DF65 (void);
// 0x000002B1 System.Boolean Ionic.Zlib.ParallelDeflateOutputStream::DeflateOneSegment(Ionic.Zlib.WorkItem)
extern void ParallelDeflateOutputStream_DeflateOneSegment_mEB1E8827E8852767FC842A213D6E631117CF5728 (void);
// 0x000002B2 System.Boolean Ionic.Zlib.ParallelDeflateOutputStream::get_CanSeek()
extern void ParallelDeflateOutputStream_get_CanSeek_m423C8B56A1F1F4A4839A820DB8A45FC5BE76D8A6 (void);
// 0x000002B3 System.Boolean Ionic.Zlib.ParallelDeflateOutputStream::get_CanRead()
extern void ParallelDeflateOutputStream_get_CanRead_mCA32F79CCF594EF3EB58B7F2C696E729535EBD9A (void);
// 0x000002B4 System.Boolean Ionic.Zlib.ParallelDeflateOutputStream::get_CanWrite()
extern void ParallelDeflateOutputStream_get_CanWrite_mAD779F56A239D94344618D982D0D6F3069A6FA63 (void);
// 0x000002B5 System.Int64 Ionic.Zlib.ParallelDeflateOutputStream::get_Length()
extern void ParallelDeflateOutputStream_get_Length_m6117775A9864B01769CB8A672E68BD63EA800C6B (void);
// 0x000002B6 System.Int64 Ionic.Zlib.ParallelDeflateOutputStream::get_Position()
extern void ParallelDeflateOutputStream_get_Position_mD69F8A38F0588E2A4D2A6699D7FC71055C74DDC8 (void);
// 0x000002B7 System.Void Ionic.Zlib.ParallelDeflateOutputStream::set_Position(System.Int64)
extern void ParallelDeflateOutputStream_set_Position_m04BCDB79F1953130820C34128FE40B3C83C4BED2 (void);
// 0x000002B8 System.Int32 Ionic.Zlib.ParallelDeflateOutputStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ParallelDeflateOutputStream_Read_m72977CD5DBB3CAA51771DB5BB638FCC381DE7366 (void);
// 0x000002B9 System.Int64 Ionic.Zlib.ParallelDeflateOutputStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ParallelDeflateOutputStream_Seek_m9E6E476D9974B398F04D36F46C817338179398E1 (void);
// 0x000002BA System.Void Ionic.Zlib.ParallelDeflateOutputStream::SetLength(System.Int64)
extern void ParallelDeflateOutputStream_SetLength_mA984F3E4617685A2794C37EB1E0472E9AB1FAAD7 (void);
// 0x000002BB System.Void Ionic.Zlib.ParallelDeflateOutputStream::.cctor()
extern void ParallelDeflateOutputStream__cctor_m5FAA66A8DAE4B0AE99BDE8DB5946AFD048E83A0B (void);
// 0x000002BC System.Int32 Ionic.Zlib.Tree::DistanceCode(System.Int32)
extern void Tree_DistanceCode_m06F87C001CF0FAF7ED49003FBEE47562E607B39F (void);
// 0x000002BD System.Void Ionic.Zlib.Tree::gen_bitlen(Ionic.Zlib.DeflateManager)
extern void Tree_gen_bitlen_mCC71BCD509A61D07F941EB86A9A075A889B60771 (void);
// 0x000002BE System.Void Ionic.Zlib.Tree::build_tree(Ionic.Zlib.DeflateManager)
extern void Tree_build_tree_mAEE538DA0D5EED419717CACF229B2D0E35060CDF (void);
// 0x000002BF System.Void Ionic.Zlib.Tree::gen_codes(System.Int16[],System.Int32,System.Int16[])
extern void Tree_gen_codes_mDEC80E66B5FA7690A2A32357A9D19C3B8E35944D (void);
// 0x000002C0 System.Int32 Ionic.Zlib.Tree::bi_reverse(System.Int32,System.Int32)
extern void Tree_bi_reverse_mA9C60E73353A2B344E0694C607D17682FA786FF9 (void);
// 0x000002C1 System.Void Ionic.Zlib.Tree::.ctor()
extern void Tree__ctor_m8E621E185B9BCE2BB6D047D590C12191A7CB958E (void);
// 0x000002C2 System.Void Ionic.Zlib.Tree::.cctor()
extern void Tree__cctor_m20513C9268E561B565EED07A55622EAE33156032 (void);
// 0x000002C3 System.Void Ionic.Zlib.ZlibException::.ctor(System.String)
extern void ZlibException__ctor_m9FE554ECDEC43FD140C35A6F9C78A93A47AE3350 (void);
// 0x000002C4 System.Int32 Ionic.Zlib.SharedUtils::URShift(System.Int32,System.Int32)
extern void SharedUtils_URShift_m0482D2C4CDA787119DA7305843F3F0CA6F5997E5 (void);
// 0x000002C5 System.Void Ionic.Zlib.InternalConstants::.cctor()
extern void InternalConstants__cctor_m6F7987484D109F716A8DA1D9B1BBB39C7B818B05 (void);
// 0x000002C6 System.Void Ionic.Zlib.StaticTree::.ctor(System.Int16[],System.Int32[],System.Int32,System.Int32,System.Int32)
extern void StaticTree__ctor_mAE9DE8E891ED7E618C9D5CB3F7975AC0ADACBE63 (void);
// 0x000002C7 System.Void Ionic.Zlib.StaticTree::.cctor()
extern void StaticTree__cctor_m09C0EC75C160555983A95C222379D122F38D46D6 (void);
// 0x000002C8 System.UInt32 Ionic.Zlib.Adler::Adler32(System.UInt32,System.Byte[],System.Int32,System.Int32)
extern void Adler_Adler32_m947780F20CB573583D7638E892490EA9ADAD7375 (void);
// 0x000002C9 System.Void Ionic.Zlib.Adler::.cctor()
extern void Adler__cctor_m9B56D29B6DCB878488C01D8F0B61B699E1E1AB30 (void);
// 0x000002CA System.Void Ionic.Zlib.ZlibBaseStream::.ctor(System.IO.Stream,Ionic.Zlib.CompressionMode,Ionic.Zlib.CompressionLevel,Ionic.Zlib.ZlibStreamFlavor,System.Boolean)
extern void ZlibBaseStream__ctor_m473F51C96FFF5488FB504F4F17912A932CAB30DF (void);
// 0x000002CB System.Boolean Ionic.Zlib.ZlibBaseStream::get__wantCompress()
extern void ZlibBaseStream_get__wantCompress_mC2244093FB3C970FF3866F695F07C4549ACD3E8D (void);
// 0x000002CC Ionic.Zlib.ZlibCodec Ionic.Zlib.ZlibBaseStream::get_z()
extern void ZlibBaseStream_get_z_m65B6F59B0C7BD6028E377FF0378C44E696665EE7 (void);
// 0x000002CD System.Byte[] Ionic.Zlib.ZlibBaseStream::get_workingBuffer()
extern void ZlibBaseStream_get_workingBuffer_mFD7482A91E26AD2DB3EFF93129FE67CDBECEBE0B (void);
// 0x000002CE System.Void Ionic.Zlib.ZlibBaseStream::Write(System.Byte[],System.Int32,System.Int32)
extern void ZlibBaseStream_Write_m18B6467CBD0555A50EF7376C9983D2CC9EDDCCCB (void);
// 0x000002CF System.Void Ionic.Zlib.ZlibBaseStream::finish()
extern void ZlibBaseStream_finish_m5EFCDFBB8635255492C8769E0EF3BADA483856A4 (void);
// 0x000002D0 System.Void Ionic.Zlib.ZlibBaseStream::end()
extern void ZlibBaseStream_end_m3FD7DE7CE07E34A574985CE1FD6C1CCA9B533434 (void);
// 0x000002D1 System.Void Ionic.Zlib.ZlibBaseStream::Close()
extern void ZlibBaseStream_Close_m2F14725EE6E24AF3BD89F6ADC757065F1E20BE8E (void);
// 0x000002D2 System.Void Ionic.Zlib.ZlibBaseStream::Flush()
extern void ZlibBaseStream_Flush_m62F96160EE8AC94CD1BC9A9FA4195CFF54782999 (void);
// 0x000002D3 System.Int64 Ionic.Zlib.ZlibBaseStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void ZlibBaseStream_Seek_m9E64D7F8CB93A687B6243482B990BB9912F4C22F (void);
// 0x000002D4 System.Void Ionic.Zlib.ZlibBaseStream::SetLength(System.Int64)
extern void ZlibBaseStream_SetLength_mC991E6EF1DF425D06BF93D55F0818984B6AE07EA (void);
// 0x000002D5 System.String Ionic.Zlib.ZlibBaseStream::ReadZeroTerminatedString()
extern void ZlibBaseStream_ReadZeroTerminatedString_m38106BA5D9FCAA697A2978CEF98B09D1A74CBD07 (void);
// 0x000002D6 System.Int32 Ionic.Zlib.ZlibBaseStream::_ReadAndValidateGzipHeader()
extern void ZlibBaseStream__ReadAndValidateGzipHeader_mB9F06457369A9D52B00E2E40DDB55DBB7E60A8E3 (void);
// 0x000002D7 System.Int32 Ionic.Zlib.ZlibBaseStream::Read(System.Byte[],System.Int32,System.Int32)
extern void ZlibBaseStream_Read_m493B5ADF22D628DCF2CBC711BABF759B0BA9CE36 (void);
// 0x000002D8 System.Boolean Ionic.Zlib.ZlibBaseStream::get_CanRead()
extern void ZlibBaseStream_get_CanRead_mA16C880B5C83CF7B4DD616C4EF05D10CF23364EE (void);
// 0x000002D9 System.Boolean Ionic.Zlib.ZlibBaseStream::get_CanSeek()
extern void ZlibBaseStream_get_CanSeek_mE860B962F6513FA5661FB447640697AB339DBCCD (void);
// 0x000002DA System.Boolean Ionic.Zlib.ZlibBaseStream::get_CanWrite()
extern void ZlibBaseStream_get_CanWrite_m23ACD1627EB5171B3DC028D41B2265EBB5AE1F83 (void);
// 0x000002DB System.Int64 Ionic.Zlib.ZlibBaseStream::get_Length()
extern void ZlibBaseStream_get_Length_m3282FE1F6934B5E3BC01FD27F870BDCD52981178 (void);
// 0x000002DC System.Int64 Ionic.Zlib.ZlibBaseStream::get_Position()
extern void ZlibBaseStream_get_Position_mFC09E906DCEEE606216D8D4DA85ED8BEC1EA6CF5 (void);
// 0x000002DD System.Void Ionic.Zlib.ZlibBaseStream::set_Position(System.Int64)
extern void ZlibBaseStream_set_Position_m240A06F95FA8443B0E744BF9881B0D8165D37A82 (void);
// 0x000002DE System.Void Ionic.Zlib.ZlibCodec::.ctor()
extern void ZlibCodec__ctor_m0718287035AA71815837591F65FF7C951F5F4DB4 (void);
// 0x000002DF System.Int32 Ionic.Zlib.ZlibCodec::InitializeInflate(System.Boolean)
extern void ZlibCodec_InitializeInflate_mB1FA0B26D37EEB00E29428A3996AD74D32E432F4 (void);
// 0x000002E0 System.Int32 Ionic.Zlib.ZlibCodec::InitializeInflate(System.Int32,System.Boolean)
extern void ZlibCodec_InitializeInflate_m0303067E504917DDE66930E1C301677F7EEDD758 (void);
// 0x000002E1 System.Int32 Ionic.Zlib.ZlibCodec::Inflate(Ionic.Zlib.FlushType)
extern void ZlibCodec_Inflate_mB221058BC92D4A95CBB27322CB337A94CCD5CEA1 (void);
// 0x000002E2 System.Int32 Ionic.Zlib.ZlibCodec::EndInflate()
extern void ZlibCodec_EndInflate_mA4A36AE96F6D466469F7122C5380BB19BE74646D (void);
// 0x000002E3 System.Int32 Ionic.Zlib.ZlibCodec::InitializeDeflate(Ionic.Zlib.CompressionLevel,System.Boolean)
extern void ZlibCodec_InitializeDeflate_m729D8104F6BD0D51CD6D00F1A9F2B08FD79F2A1A (void);
// 0x000002E4 System.Int32 Ionic.Zlib.ZlibCodec::_InternalInitializeDeflate(System.Boolean)
extern void ZlibCodec__InternalInitializeDeflate_m57D3371F48C6B3E608FA6F865C3E20EA64C4751B (void);
// 0x000002E5 System.Int32 Ionic.Zlib.ZlibCodec::Deflate(Ionic.Zlib.FlushType)
extern void ZlibCodec_Deflate_m46CCA2A0844A185891FF67BEF783130D614776C7 (void);
// 0x000002E6 System.Int32 Ionic.Zlib.ZlibCodec::EndDeflate()
extern void ZlibCodec_EndDeflate_m60C1C8B560560FC994F35F7BCDA41D9D07BDACEE (void);
// 0x000002E7 System.Void Ionic.Zlib.ZlibCodec::ResetDeflate()
extern void ZlibCodec_ResetDeflate_m3C5D1A0CDA778011C0EA720C7D7AE7E74F56BB90 (void);
// 0x000002E8 System.Void Ionic.Zlib.ZlibCodec::flush_pending()
extern void ZlibCodec_flush_pending_m7280670338BAB991E9A6664E99DBE25D101BC486 (void);
// 0x000002E9 System.Int32 Ionic.Zlib.ZlibCodec::read_buf(System.Byte[],System.Int32,System.Int32)
extern void ZlibCodec_read_buf_m5841F0EB4E6823028ADF7C126315C9CCD7D7ED8E (void);
// 0x000002EA System.Int64 Ionic.Crc.CRC32::get_TotalBytesRead()
extern void CRC32_get_TotalBytesRead_mCE5485999DE49DBB25751117A6633AEC01C1B76F (void);
// 0x000002EB System.Int32 Ionic.Crc.CRC32::get_Crc32Result()
extern void CRC32_get_Crc32Result_m3414F3DC7FA048EE9EE934E6302B7CD7CE4DD16F (void);
// 0x000002EC System.Int32 Ionic.Crc.CRC32::GetCrc32(System.IO.Stream)
extern void CRC32_GetCrc32_m0C4F7501E77C727B7C533C31C0257370DCE6DC6F (void);
// 0x000002ED System.Int32 Ionic.Crc.CRC32::GetCrc32AndCopy(System.IO.Stream,System.IO.Stream)
extern void CRC32_GetCrc32AndCopy_mEDD977C21D00296019953B1A482552068590654E (void);
// 0x000002EE System.Int32 Ionic.Crc.CRC32::ComputeCrc32(System.Int32,System.Byte)
extern void CRC32_ComputeCrc32_m120F6B0AD46EC92A2D1C579EC9D252AED427515F (void);
// 0x000002EF System.Int32 Ionic.Crc.CRC32::_InternalComputeCrc32(System.UInt32,System.Byte)
extern void CRC32__InternalComputeCrc32_m705391AF4E6DF3F3D0BF2878653794DFDCCCF2AE (void);
// 0x000002F0 System.Void Ionic.Crc.CRC32::SlurpBlock(System.Byte[],System.Int32,System.Int32)
extern void CRC32_SlurpBlock_m6E04B167CAEBF451DD9888598C039A8784D20026 (void);
// 0x000002F1 System.Void Ionic.Crc.CRC32::UpdateCRC(System.Byte)
extern void CRC32_UpdateCRC_mB0956C9175240EC27355097E030D4F26D39E80C4 (void);
// 0x000002F2 System.Void Ionic.Crc.CRC32::UpdateCRC(System.Byte,System.Int32)
extern void CRC32_UpdateCRC_mDD142F29A46720BC9D7B260BFB89B4D87C1D6C75 (void);
// 0x000002F3 System.UInt32 Ionic.Crc.CRC32::ReverseBits(System.UInt32)
extern void CRC32_ReverseBits_m993847E8C60E50B8A615B72FAEA220FDB4CF83AC (void);
// 0x000002F4 System.Byte Ionic.Crc.CRC32::ReverseBits(System.Byte)
extern void CRC32_ReverseBits_mD9629CBB759884993C1DBDB412C6149DFBDFB8A3 (void);
// 0x000002F5 System.Void Ionic.Crc.CRC32::GenerateLookupTable()
extern void CRC32_GenerateLookupTable_m28A5BD23480B63629FCFCCC328EDC3C159588E3E (void);
// 0x000002F6 System.UInt32 Ionic.Crc.CRC32::gf2_matrix_times(System.UInt32[],System.UInt32)
extern void CRC32_gf2_matrix_times_mA3E565E89504C6675621BD4C736FA59F28CA85D3 (void);
// 0x000002F7 System.Void Ionic.Crc.CRC32::gf2_matrix_square(System.UInt32[],System.UInt32[])
extern void CRC32_gf2_matrix_square_m7CDE486A0712FB3FD207E4CD790C504F73F91D7C (void);
// 0x000002F8 System.Void Ionic.Crc.CRC32::Combine(System.Int32,System.Int32)
extern void CRC32_Combine_m24482D5EC824A642B6AC44D94118D948FD797C8C (void);
// 0x000002F9 System.Void Ionic.Crc.CRC32::.ctor()
extern void CRC32__ctor_m08C46EBBE184F2D28A22B17418AA34195C039AAB (void);
// 0x000002FA System.Void Ionic.Crc.CRC32::.ctor(System.Boolean)
extern void CRC32__ctor_m4B43E4FA3D15DD0B9AD5EA1B2DA3A44CAB998596 (void);
// 0x000002FB System.Void Ionic.Crc.CRC32::.ctor(System.Int32,System.Boolean)
extern void CRC32__ctor_m0DDD4836F8593CB29059C0036D9C2F0AB6E2D68E (void);
// 0x000002FC System.Void Ionic.Crc.CRC32::Reset()
extern void CRC32_Reset_m625CD52712D35477B9C364EAB71F0A2E213E373A (void);
// 0x000002FD System.Void Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream)
extern void CrcCalculatorStream__ctor_mC70A833A26464858289A61B575C30250B590DBAA (void);
// 0x000002FE System.Void Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream,System.Boolean)
extern void CrcCalculatorStream__ctor_m34C2935207C76CAF1D4EE3B9FFB7CE48BFF2D143 (void);
// 0x000002FF System.Void Ionic.Crc.CrcCalculatorStream::.ctor(System.IO.Stream,System.Int64)
extern void CrcCalculatorStream__ctor_m241DA2C21BB810DA26A6071A5A94EF9B1E41FB0A (void);
// 0x00000300 System.Void Ionic.Crc.CrcCalculatorStream::.ctor(System.Boolean,System.Int64,System.IO.Stream,Ionic.Crc.CRC32)
extern void CrcCalculatorStream__ctor_mC93C5CA32CF5B77FFAB9883DA5FBC9E8042E7FF0 (void);
// 0x00000301 System.Int64 Ionic.Crc.CrcCalculatorStream::get_TotalBytesSlurped()
extern void CrcCalculatorStream_get_TotalBytesSlurped_m03D6F7B0DD5A8ADC19171DAE6AA150E6908B140A (void);
// 0x00000302 System.Int32 Ionic.Crc.CrcCalculatorStream::get_Crc()
extern void CrcCalculatorStream_get_Crc_mD3ACB9E50C411928F1C39187F4FF9517B9F6D4F5 (void);
// 0x00000303 System.Int32 Ionic.Crc.CrcCalculatorStream::Read(System.Byte[],System.Int32,System.Int32)
extern void CrcCalculatorStream_Read_mD43A97825AA2F78E4E4E87A2F52258018A0458CB (void);
// 0x00000304 System.Void Ionic.Crc.CrcCalculatorStream::Write(System.Byte[],System.Int32,System.Int32)
extern void CrcCalculatorStream_Write_m5710BDD2BD09D2CFA709A087B007D2C58170AF35 (void);
// 0x00000305 System.Boolean Ionic.Crc.CrcCalculatorStream::get_CanRead()
extern void CrcCalculatorStream_get_CanRead_m13C8434CFA76E2F06CB7DC69BB5DADC4F1017F39 (void);
// 0x00000306 System.Boolean Ionic.Crc.CrcCalculatorStream::get_CanSeek()
extern void CrcCalculatorStream_get_CanSeek_mD042303467188CCDBD93F41014AE8260956E30D0 (void);
// 0x00000307 System.Boolean Ionic.Crc.CrcCalculatorStream::get_CanWrite()
extern void CrcCalculatorStream_get_CanWrite_mE5DD7610D2C0DCE98B67FA423B0B1CD35F691FA2 (void);
// 0x00000308 System.Void Ionic.Crc.CrcCalculatorStream::Flush()
extern void CrcCalculatorStream_Flush_mD2C630AC66394DB2A0D98B8B64C98E4C831DE029 (void);
// 0x00000309 System.Int64 Ionic.Crc.CrcCalculatorStream::get_Length()
extern void CrcCalculatorStream_get_Length_m46CD5AFA6CC157CA551FD693611CFB60E2DD82B4 (void);
// 0x0000030A System.Int64 Ionic.Crc.CrcCalculatorStream::get_Position()
extern void CrcCalculatorStream_get_Position_mA9DB434B0B622C74DEA5B5B3F3E2CB63CA7B08D7 (void);
// 0x0000030B System.Void Ionic.Crc.CrcCalculatorStream::set_Position(System.Int64)
extern void CrcCalculatorStream_set_Position_m7BA832B15D1249618D4331AD02082402AD4C07B7 (void);
// 0x0000030C System.Int64 Ionic.Crc.CrcCalculatorStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void CrcCalculatorStream_Seek_m6D58DDDFBEDDD327EF9FC274E4C05A616DB0AAD9 (void);
// 0x0000030D System.Void Ionic.Crc.CrcCalculatorStream::SetLength(System.Int64)
extern void CrcCalculatorStream_SetLength_mC1FC04AFFEA7559B27C92605812632512CDBA79B (void);
// 0x0000030E System.Void Ionic.Crc.CrcCalculatorStream::System.IDisposable.Dispose()
extern void CrcCalculatorStream_System_IDisposable_Dispose_m18FB18113D14694C7A539A64A844AE5F8B7952D3 (void);
// 0x0000030F System.Void Ionic.Crc.CrcCalculatorStream::Close()
extern void CrcCalculatorStream_Close_mD2F75686BE984E6FCC7D3A944D70B9733F44D9D4 (void);
// 0x00000310 System.Void Ionic.Crc.CrcCalculatorStream::.cctor()
extern void CrcCalculatorStream__cctor_m106295F1C274972A86693CC6C2DC857F5C5C83F2 (void);
static Il2CppMethodPointer s_methodPointers[784] = 
{
	WriteDelegate__ctor_m362F97AB96E4E7C5458DE2788098EC0AAB8AF284,
	WriteDelegate_Invoke_mE589D11BB539F22634E11CA29C44BFCAC28C8ABD,
	OpenDelegate__ctor_m205D2CF40B14BE3009CA80A4E3D1024B62D07370,
	OpenDelegate_Invoke_mDBDEA099AC017F1FACF297B5B69324A823C34F3D,
	CloseDelegate__ctor_m464F32515E748AFF431413EAFD6F56521A3E49F3,
	CloseDelegate_Invoke_m0E5D550E08AF9F4B3264FC491A730B13C38F0F64,
	SetCompressionCallback__ctor_m1C4F299773605AC70CBCAF2151ED7AF153E97175,
	SetCompressionCallback_Invoke_mEBF215E7AE202561290B5F5E71011FE9153DEA44,
	ZipProgressEventArgs__ctor_m04F4FBF8B06280136DB077B8DE0219F1CAEC3D0D,
	ZipProgressEventArgs__ctor_mF64AB157E5188BC18ADDBCC06A55E6CFBB55CC2A,
	ZipProgressEventArgs_set_EntriesTotal_m15CA9C283E7B54B8527A72D7807F845071C694E7,
	ZipProgressEventArgs_set_CurrentEntry_m869D80F2DBF904069D7305B7F9DA9A4457A4D01E,
	ZipProgressEventArgs_get_Cancel_mE996AE2B28FE69EEC649494924908E9D22E1B678,
	ZipProgressEventArgs_set_EventType_m60E1D539D78A39D6B0E5619B8C6B9AC5B811856D,
	ZipProgressEventArgs_set_ArchiveName_m44B9688C1A6BAAB38026FE5C6731F19DF1E81659,
	ZipProgressEventArgs_set_BytesTransferred_mA29625B11BC5FFF4F346FDDCAF2C3A7496E62CFD,
	ZipProgressEventArgs_set_TotalBytesToTransfer_mCAB9EE4392E96AAD74D0F1820C542F3925C45F22,
	ReadProgressEventArgs__ctor_mEFCC125C9A00B495F28C59B9728736C3E628411B,
	ReadProgressEventArgs_Before_m78B9B4D24CCD8C0AB1BEE83CE789376CFF1CEF8A,
	ReadProgressEventArgs_After_m517C33A00BB0AC085C184950720828BEA3A5326B,
	ReadProgressEventArgs_Started_mCECDE8A6F7360706892908B9A9DDC5FBCC51B1C0,
	ReadProgressEventArgs_ByteUpdate_m299B3280742449D30B14E3EDC035A30CD2E4287F,
	ReadProgressEventArgs_Completed_mCCF64E8115B7256132599ECD96E5D5B978A2E5D5,
	AddProgressEventArgs__ctor_m8A72C16956B77A3D147F62229F238094E36AE0B1,
	AddProgressEventArgs_AfterEntry_mA7FCB7AC1CE81A1B200907E0756EE5959B317C6D,
	SaveProgressEventArgs__ctor_m4EB6CFF3900048F21E2DFEB1455E0FE3A470586F,
	SaveProgressEventArgs__ctor_m0EB678B0E583730FF782AF8A9DC0E978DFCAB3A9,
	SaveProgressEventArgs_ByteUpdate_m50922FD89E5730126315A75C56945D52EF68977F,
	SaveProgressEventArgs_Started_mF3AF36093FD14E1820D77969415334B484284890,
	SaveProgressEventArgs_Completed_mE85F89302CA5CF7EAB092FD4689E22DC683EE8E3,
	ExtractProgressEventArgs__ctor_m9669902EFD937537DF024E7B9F5D23B50C3C7B0C,
	ExtractProgressEventArgs__ctor_m1DFB16D8C75F60B74AD9430CB52E9F0A62F6935E,
	ExtractProgressEventArgs__ctor_m2C0DF3CF5665A0A593B2CA22ABBE4128794FCFE5,
	ExtractProgressEventArgs_BeforeExtractEntry_m4A53397E7B04439595CE7D8179CBD3C8ACDDFEA9,
	ExtractProgressEventArgs_ExtractExisting_mFCB6EFEA305915C2D62CD934366E97982042BCEA,
	ExtractProgressEventArgs_AfterExtractEntry_mB45B054E68EA6B3DD1004541245C5E5547671ACE,
	ExtractProgressEventArgs_ExtractAllStarted_m91746F043DC450CE17A1A6C1AC40311577D01B6A,
	ExtractProgressEventArgs_ExtractAllCompleted_m7270F1E6E5BE075A516E1F1EFD78D9F1FADB7061,
	ExtractProgressEventArgs_ByteUpdate_mFF546F169B7F3ACEB7710BCFDAA7BB71B220EB99,
	ZipErrorEventArgs__ctor_m2CD31930435309EFE87E3DDCA37529832C6C62FB,
	ZipErrorEventArgs_Saving_m3AA26DB32D03C3A09593B1A2A7D4555C0CDF6F9B,
	ZipException__ctor_m76A20C39E1EA5E6F664968AA695959A5C2A049B7,
	ZipException__ctor_m0E3950E7747F3CB055136C1A5FB783D52357476A,
	ZipException__ctor_m741945E255987FB056D783BAFFE38BF8472CE5E6,
	BadPasswordException__ctor_m2D696AD57515D92E832420AAAF2EB761FB5421BD,
	BadPasswordException__ctor_mB652887F01CF67531733BC1197EB64B3BBAC6C90,
	BadReadException__ctor_m651821049CAF3236EEB20336FD3A6EB01542924F,
	BadCrcException__ctor_m1F98E314260F08E6FD033957226E45CFB0119730,
	BadStateException__ctor_mC61C0C85A98C5D6B3038ACFD36DACB66AE8F0D90,
	BadStateException__ctor_m0E1547A0DC818FCD1061DDA54CFE903B6430E338,
	SharedUtilities_GetFileLength_m52BCFA4F16DAE0A22EDEC201FF7AF17151F155C9,
	SharedUtilities_SimplifyFwdSlashPath_m9997F056DCE37D8B78A1CC9EF29D0668997472D6,
	SharedUtilities_NormalizePathForUseInZipFile_m92139AB12253230B34462263C7AC6D112A86B75F,
	SharedUtilities_StringToByteArray_m76EF1B460101585935285211BD74718DD7558B6A,
	SharedUtilities_StringToByteArray_m4DEF1BD7E9BF03EBD5B98F39A80C2F7C271191F5,
	SharedUtilities_Utf8StringFromBuffer_m919A16BBB1F96E074F5C4FD6EA9DBF1468DBBBA0,
	SharedUtilities_StringFromBuffer_m29EA6B7D44E5B4602E350A0397A3A50320DB069F,
	SharedUtilities_ReadSignature_mEC34968DA65E1E98229658D13D06DD298B715589,
	SharedUtilities_ReadEntrySignature_m6785F532D030A3A548FB8A944386EBD54AE689B5,
	SharedUtilities_ReadInt_mF293A3F8623E35FF50F76A019D1A3B2C3E2328C0,
	SharedUtilities__ReadFourBytes_mE8E24E19530F117D20526845420EA5DFD1344B03,
	SharedUtilities_FindSignature_m23E09586F5B323521366CA9D5982C651E5396E26,
	SharedUtilities_PackedToDateTime_m30871A6C29E0E1C95A1E2B49D0B202F1050FB8CB,
	SharedUtilities_DateTimeToPacked_m76EBF9271FA90A2F74125A8D8F9EB45325E4EE82,
	SharedUtilities_CreateAndOpenUniqueTempFile_mA65AA77AE58BCA5F8D1E15FD7A3960EE20864B4D,
	SharedUtilities_InternalGetTempFileName_mC45C85E3D5651792535E4926F4BC6A55D5ADFF6B,
	SharedUtilities_GenerateRandomStringImpl_m7EC30498CB6B886AF5CD45CE489FDE6D7294EB08,
	SharedUtilities_ReadWithRetry_mF8136271DDD542A54FAC4969C9904D4678E369A2,
	SharedUtilities__cctor_m8764CFEBED7B7EDEC94DA9E0E1700FF644F19F06,
	CountingStream__ctor_mB1D3BFD82AEC5FA402093E430ADF1735511E88E3,
	CountingStream_get_BytesWritten_mC6BC8AA819894349F81CF043AAA40A9FCA41AB29,
	CountingStream_get_BytesRead_m3A26420FE4989A29D1E68D69603FBD7E74C5E717,
	CountingStream_Adjust_m139414D83AEC74B11238870A775095A25088974B,
	CountingStream_Read_m97CF074050FF34951C3427FDE9BEA23F2CAEC91E,
	CountingStream_Write_mACBA1738C20DDB98817EEEB7D2EE52F448D693D0,
	CountingStream_get_CanRead_m1BFB811C9632363F61425A1E5F752011A44600CE,
	CountingStream_get_CanSeek_mA6951D3C29ECC68DBD52253F2DF5459EEB5C9EC2,
	CountingStream_get_CanWrite_m92CF233F73B0D14B77F0813F69E2E732C3D46D94,
	CountingStream_Flush_m309F79117222A730E5116AED8675186B666764F8,
	CountingStream_get_Length_mD4399D05BC1A4E3B2F7489A1821717A51A9CBCB9,
	CountingStream_get_ComputedPosition_m8F28E26D2B4AB3B0387DB330BC154028CB11E0CB,
	CountingStream_get_Position_m34B5820E011C7BAE9ABBFD87FA90449E934F90BB,
	CountingStream_set_Position_m498FA27C3C65B280425760B12D4927886D14C052,
	CountingStream_Seek_m20C088D7380008EBBE5632BB3814769BA257D02B,
	CountingStream_SetLength_m46463D20EF012391D485428B90F89A7968CF8603,
	WinZipAesCrypto__ctor_m156438B476206EADBBEBDDF6F8B33DE16E3DD298,
	WinZipAesCrypto_Generate_m1D28E83A91B4583BA04EB6564D4F034C4C21E7BE,
	WinZipAesCrypto_ReadFromStream_m920C37A863FAB4BE78E3F25B086E50E62A4703C6,
	WinZipAesCrypto_get_GeneratedPV_mEDA3219F124AE129CA04AA8E8D0BDADAE0875087,
	WinZipAesCrypto_get_Salt_mE1A6403AD8D733D7C0DB3DD470AB0655F1A451A5,
	WinZipAesCrypto_get__KeyStrengthInBytes_m071D49D785A65A40012FE3498A5901EC51B656D2,
	WinZipAesCrypto_get_SizeOfEncryptionMetadata_m53461AAC0778009C6134AD4639D511DC3F56599B,
	WinZipAesCrypto_set_Password_mD0B9AB23BD20C87E17F9D550B6FE5CC53A37C431,
	WinZipAesCrypto__GenerateCryptoBytes_m21B73A15D79C14003E9CBFF05960B08E3F9A30F8,
	WinZipAesCrypto_get_KeyBytes_m71AE0A00A84F487AA31A27F7910780C7237F9591,
	WinZipAesCrypto_get_MacIv_m86D8251BA50DD1E925BFE8C8594D4E7E1FBDF345,
	WinZipAesCrypto_ReadAndVerifyMac_mF835FE006322125375F0B9D7E690E443C7C96F1E,
	WinZipAesCipherStream__ctor_m8A21B4A2D88E087E8E92147595F8C550DFD15F5B,
	WinZipAesCipherStream__ctor_m3DFA94FD97730CDBD39C5FADFDE73E1F0EA7AFDA,
	WinZipAesCipherStream_XorInPlace_mA4C805A060DE8FC2B39C068FD3661E0F9720EAA8,
	WinZipAesCipherStream_WriteTransformOneBlock_m9F3E4A4405785CFD7C2893862E7BBCB7C7AC9D35,
	WinZipAesCipherStream_WriteTransformBlocks_m68851DFBBB94ABDBA7FBAC097553ECF6EA9883FA,
	WinZipAesCipherStream_WriteTransformFinalBlock_m4D71B53395D30F28FD51ADC8FB4B63880B636B7B,
	WinZipAesCipherStream_ReadTransformOneBlock_m008A92516FA87B4733333912E147CEACCF259C97,
	WinZipAesCipherStream_ReadTransformBlocks_mB16230490DEF2635DC14ADB9DB58A9470EB758C3,
	WinZipAesCipherStream_Read_m7A9A5B45A935D1FFAD41DBD3724F80A5A650E509,
	WinZipAesCipherStream_get_FinalAuthentication_m54F35D40E16C96B60343072C3F04836E7BE14013,
	WinZipAesCipherStream_Write_mD631C75F3E9157C1BC5615E20BDBF1E153DAB631,
	WinZipAesCipherStream_Close_m034D8089F886BA0A5035FCE8E43D83BF6EB0F80F,
	WinZipAesCipherStream_get_CanRead_mD21202A1E9CB6A1F7C1D7C7C89CC5B12E2B9A6F6,
	WinZipAesCipherStream_get_CanSeek_m40ECEC160A6EB5637A2D929FB9F1E735617C9A26,
	WinZipAesCipherStream_get_CanWrite_mFF24FE0C976B4AB4642669B49D777F26A83B9B76,
	WinZipAesCipherStream_Flush_m9C3EDD758A868E36F6C6F7832E74A868D20217A5,
	WinZipAesCipherStream_get_Length_mD09820E41573AE89FE31D1F15EE498455BD34046,
	WinZipAesCipherStream_get_Position_m24D3A4DA8735A06B4AEF2A7B5370A58E6DCACBB6,
	WinZipAesCipherStream_set_Position_mEE15C45E714BED7EA8A1741B99E3AFB2D3FA9312,
	WinZipAesCipherStream_Seek_m01C1AC3CE8AAE76944E54AFE91F418A080745EFC,
	WinZipAesCipherStream_SetLength_m7BFC24CE0DD54F937C5397C1524B9CD36B3D6496,
	ZipCrypto__ctor_mA72667EF060E4EBF021A82BD486EF98C86428263,
	ZipCrypto_ForWrite_m959B012C63EF05A354BCAF9679E4C46950A1DA6A,
	ZipCrypto_ForRead_m25D3B5D55B0C6EF8E23CE7860DAEA90C45C5FACA,
	ZipCrypto_get_MagicByte_m83251A0890973EBB88E62D7690ABBBED47A3C0C7,
	ZipCrypto_DecryptMessage_m7033AB2856A4E0CBB828843A2D3E4B3D35CB57F5,
	ZipCrypto_EncryptMessage_m0CB62E523AEAC62D8664683C524324A47B78CC72,
	ZipCrypto_InitCipher_m92EAE35C8ABF3CB4EA83F5A3A6FB3474BCF8AAE5,
	ZipCrypto_UpdateKeys_mB9ED11648A463CB8D9D7DE36CDD09B0B6FB5B892,
	ZipCipherStream__ctor_m46BC9512787ADA77D21CF7D4F682D1DA2A8719E3,
	ZipCipherStream_Read_m4630188F51081410A1CE2B37FD0F3AC1EAAC77F2,
	ZipCipherStream_Write_m6F40C1C12F562D2F43CE8A7A87952D053CC86191,
	ZipCipherStream_get_CanRead_mB58BCE6BEC7466E362A30AE577FDAED88E6E1F05,
	ZipCipherStream_get_CanSeek_m3EE862C3AD8EC4CEAC494892C1CDBE14C7635F96,
	ZipCipherStream_get_CanWrite_m99F172A52502A5CD99980AB4F74C832E80143603,
	ZipCipherStream_Flush_m3FC2D039280759A01826B1C01D92F30F5A7DF6E2,
	ZipCipherStream_get_Length_m567565D0F06DA527F9BBBACD99BF8F8BC9301C72,
	ZipCipherStream_get_Position_mA115C176883CEB3CA8311A0CC3CA0F04B7B84E9D,
	ZipCipherStream_set_Position_mBC174FB190D123161CAD299679F209FCC6CB2BBF,
	ZipCipherStream_Seek_mB73F2E811127324768784CA1D5E492C80141A70F,
	ZipCipherStream_SetLength_m4E03D99E76EB6C9AAD2736FDA0C45F5C3CA364CC,
	ZipEntry_get_AttributesIndicateDirectory_mFC9A596F6A62F1A66A837247100689D22434823D,
	ZipEntry_ResetDirEntry_mA0AA243AD75A4FC71D020BDEA3A37A93C04D1FB1,
	ZipEntry_ReadDirEntry_mC803809F96F9F59B4D6853EE019ACF6260B54130,
	ZipEntry_IsNotValidZipDirEntrySig_m879B2FDD1122D56549F7234FDBD7B1A0C6E0A29D,
	ZipEntry__ctor_m4B0D9F955EBAC6ABA29550BF878891358A51AA51,
	ZipEntry_get_LastModified_m492D436EE451489577644F70B65A6DEB64F5DF4A,
	ZipEntry_get_BufferSize_mF84EF1748B8352F8A562AA094E6EE339257F442F,
	ZipEntry_SetEntryTimes_mBC80BE3B794F8853AAAFF170514ABA28520BDF8D,
	ZipEntry_set_EmitTimesInWindowsFormatWhenSaving_m0D7189AB9B74FD9C2926F1DF4B68B50313557D63,
	ZipEntry_set_EmitTimesInUnixFormatWhenSaving_m1AC5F6779ACF4EA024006FA113BD837761474C97,
	ZipEntry_get_LocalFileName_m1AA6225E71223F4F71249AC5C4CBB874E0A03FFB,
	ZipEntry_get_FileName_mF864C6D4828CA38DE69ABF009AD151E0529F718D,
	ZipEntry_get_VersionNeeded_m537192D2F24384B72734A85885B3EA604CB04ECE,
	ZipEntry_get_Comment_mBC0C80D72F7F02065309C35B6C8450B0FE623B4E,
	ZipEntry_get_OutputUsedZip64_m391A1A87DE657C76DC034318795234B3178A9B2B,
	ZipEntry_get_CompressionMethod_m9103CA4DA4B7C29E491B2CFFFD8B8019DECD2A8A,
	ZipEntry_set_CompressionMethod_m91A2FE22B638804DA03560E6B499E0B70B60B11A,
	ZipEntry_get_CompressionLevel_mB46B7F1EB23FE0EB8FAC99EE94DB16BFF287F8B2,
	ZipEntry_set_CompressionLevel_m911503BDC9F8B6C66B0D29BEF3AAB19DF0206DED,
	ZipEntry_get_CompressedSize_mE1904DF19A834DC7DE7FFD8F6AE34860C21A2631,
	ZipEntry_get_UncompressedSize_mDF07EF7542F807FF694B82A9037EAB56FF7F1FFF,
	ZipEntry_get_CompressionRatio_mC08E8E8C9475A35D2E8AAC2966D0E1A45588FA81,
	ZipEntry_get_IsDirectory_mD095F7213A78A00F82A4C3147E3A44CB8FF96F05,
	ZipEntry_get_Encryption_m9F5C55393A212CF88F46B98863CE98A1CDE12BB4,
	ZipEntry_set_Encryption_mA432E3E028F788879017F78B28D5FC537E4C036C,
	ZipEntry_set_Password_m7E08A3DC1FEFA6C149440AB546C1DB4340D6DA5B,
	ZipEntry_get_ExtractExistingFile_m71B71C1DBBC32A399E3FB26EDC6DA11262839A81,
	ZipEntry_set_ExtractExistingFile_m6399CAAD7D6A73431CFAFB9C01C390849F810E64,
	ZipEntry_get_ZipErrorAction_m2804B08E54643DA5C34B0C63B49CC6375B9788AD,
	ZipEntry_set_ZipErrorAction_m7F80D92F3B2F28D440FC55AB88CAD7552C14C55D,
	ZipEntry_get_IncludedInMostRecentSave_m3A8DDAB7B8C4059050E5E118644FC7F5A2AF4998,
	ZipEntry_get_SetCompression_m53E48CA6B4277C0FF58586DA9A19C0319B14B9BC,
	ZipEntry_set_SetCompression_mAB90EF22F487AEC7E26325C6B3CA71ECDB96F368,
	ZipEntry_get_AlternateEncoding_m5A0CBE5ACED3D4B08F99F7E0E4C3F18603063574,
	ZipEntry_set_AlternateEncoding_mFD7FDF5DF2F9F02B75A69359EF7D19E7EF4E80F9,
	ZipEntry_get_AlternateEncodingUsage_m6A17179B91F451A97E9FC0EB42C2D39FEDBF590F,
	ZipEntry_set_AlternateEncodingUsage_m28B464A9E329FE90299C8B8BE862C93D0BFD6DC6,
	ZipEntry_NameInArchive_m083F2E6D4F9A430196F108C267A7BE5BA04B1327,
	ZipEntry_CreateForStream_mCBB4544AD70796680C146DEBA5F2685ED005C00A,
	ZipEntry_Create_mE2A5BA68E922BF6850D221FF6AE80DC362682CBF,
	ZipEntry_MarkAsDirectory_m023FF50C21CC9A80AADD74038DA4927039173BF5,
	ZipEntry_set_IsText_mF40B5FC07BD3D7E5365C51E4E9FB35ED94A0DBC6,
	ZipEntry_ToString_m1D5BB7398C978F630EBC20996BE67468106ABB19,
	ZipEntry_get_ArchiveStream_mFC7C43F8EB896D5AE5C9ACC387145BF6D4B565BD,
	ZipEntry_SetFdpLoh_m4818A6FC83DDA4B589D3F315CF214A80D2FD8A93,
	ZipEntry_GetKeyStrengthInBits_m7FEE948F3F05896EFCF86737F5D0294E5AB93166,
	ZipEntry_GetLengthOfCryptoHeaderBytes_m1267B98F8D67E15B701377FA9988137636D03774,
	ZipEntry_get_FileDataPosition_m619A0566DCDE69A6E7D2BA4B4B1ED797DE7FBF6F,
	ZipEntry_get_LengthOfHeader_mA9321B2AC1E70C199103687D64E7DF0BEA1861CA,
	ZipEntry_Extract_mEF265E0A8D3AA6028B89F77EE2BA785A5255C627,
	ZipEntry_Extract_m8251FCC30872C4A78CDF9ACEAFC99268391D6F96,
	ZipEntry_Extract_m2F376CD7D7F1DBC5BFE7AE53EF18E341CD32ADE1,
	ZipEntry_InternalOpenReader_mD959076F0EEE41920CE90343018BF20E3D3CD412,
	ZipEntry_OnExtractProgress_mC2F0481E7E28C48CCC1AD8A9422BD1B318F2D315,
	ZipEntry_OnBeforeExtract_m6AB24EBB0DCC836E336E738D9B03BD8615E83344,
	ZipEntry_OnAfterExtract_m33FE34C7FBE56F3ACB128488D093175600ADA776,
	ZipEntry_OnExtractExisting_mFF4D4F1267284A961721A6E5B1412EE11B53BFED,
	ZipEntry_ReallyDelete_m52E0CA04B580019CD9408CFD5BF11BF986D49294,
	ZipEntry_WriteStatus_m53934C557721CA5BF943DF88DA96A10D85C6F1D4,
	ZipEntry_InternalExtract_m4577204ADAD1F6AA1F00FEE78C1B1AC9B2ECE06C,
	ZipEntry_VerifyCrcAfterExtract_mA66FA7B962ECDFC81AAF8F6399EF51F67DD2B042,
	ZipEntry_CheckExtractExistingFile_mFE2B41B02FABE7A7C6F3C60971A0F2DC4DCD6C73,
	ZipEntry__CheckRead_m38A90D3B714A2B5D61A8014DEEDF5C677F1CCF26,
	ZipEntry_ExtractOne_m50295EC44E4CFDD666CA7BA5E379FC5178CEE266,
	ZipEntry_GetExtractDecompressor_m1E524EFE427C1EF2E0072DF87DC933E273471F21,
	ZipEntry_GetExtractDecryptor_m254A11D6A6CB2D66FF978D72F39652D1DD75C81A,
	ZipEntry__SetTimes_m01B415BA31D56F1D85802CB0042304C685D277ED,
	ZipEntry_get_UnsupportedAlgorithm_m978B1B04883E7453FB7110E1FFD316692F63B87C,
	ZipEntry_get_UnsupportedCompressionMethod_mBB1041C60DE8DA7AFD2541B10E48CF455EF1A42E,
	ZipEntry_ValidateEncryption_m334587E1BC96C603850EAB1252F564717FA20BF2,
	ZipEntry_ValidateCompression_mF6828EB22F5B51BB21C0117C9D74660F92275C85,
	ZipEntry_SetupCryptoForExtract_m1E4AD1ECBBB64272D24911B98FBE4DBA0B6EB096,
	ZipEntry_ValidateOutput_m35E8368C1681D6DDE9AC3CA71618A463F4CE5840,
	ZipEntry_ReadHeader_m5526CF5930E2C0714C477D106F20A8BE581A5CBF,
	ZipEntry_ReadWeakEncryptionHeader_mFBEB24A14C0E6DADAEE7E608C6710F8D3ACE58BC,
	ZipEntry_IsNotValidSig_m252AB903E61F7EC562A17176447283A477620AF7,
	ZipEntry_ReadEntry_m8253287E3CB97C368CEFA0C961101B91208DA6D7,
	ZipEntry_HandlePK00Prefix_m39B3957E6A68FB2994F5AF8AC9153A0987EA74EB,
	ZipEntry_HandleUnexpectedDataDescriptor_mDA8FF46E6530D9756F61FEF3ACD7974C1AE2C8B2,
	ZipEntry_FindExtraFieldSegment_mF7B9D9D1AE4E650378E5DF44502CB2579C2C5917,
	ZipEntry_ProcessExtraField_m3C73F6D001397600594E6B99917FBCFB26455C1D,
	ZipEntry_ProcessExtraFieldPkwareStrongEncryption_m62C3C9E44A031F779E4A47FF4E59C31FC617E528,
	ZipEntry_ProcessExtraFieldWinZipAes_mA75A7627245C3918548737D8DE6805302A80E560,
	ZipEntry_ProcessExtraFieldZip64_m18BED0DDE91C4D4228C109AE98298C0B1C46A91E,
	ZipEntry_ProcessExtraFieldInfoZipTimes_m4E6C2D3283FCD3B94CB20AF7ABDEB6F065DA0F06,
	ZipEntry_ProcessExtraFieldUnixTimes_m0F503E3CFFC6DFF638A735F00A82160B3D1DDCBF,
	ZipEntry_ProcessExtraFieldWindowsTimes_mC82846A976F09349F93144AEE27088DBB557707B,
	ZipEntry_WriteCentralDirectoryEntry_m28D978F34726D5D3F1203D388567889FCC528D66,
	ZipEntry_ConstructExtraField_m47CE516895694DE58AA3B6292DE241307A0FC72F,
	ZipEntry_NormalizeFileName_m79BD412794DDADBB3461F9C006AC50B9F800F1F2,
	ZipEntry_GetEncodedFileNameBytes_m890697761B0C4EC4F61BE63C53780E4A710A96A7,
	ZipEntry_WantReadAgain_m02A4EBA91B4F0D70FDB9A7FFE6EF6BB96D453770,
	ZipEntry_MaybeUnsetCompressionMethodForWriting_m243D98E14BCE459584D7EAA27A7F29F1AAAE0039,
	ZipEntry_WriteHeader_m72BC73EBA6F0541529A38B5ADB3D647305DA0641,
	ZipEntry_FigureCrc32_m329549EA0BD2FDDB1A623DD0E00ADD845B64BA96,
	ZipEntry_PrepSourceStream_m559CBDA0AB777E4B7392CDD68DF84B4879C2BAB6,
	ZipEntry_CopyMetaData_m1F69BF1C1E642E5668ED7349647AAB5DA9626481,
	ZipEntry_OnWriteBlock_mE9B5F4596A87DC8E7F8D8FD3DE7D97A3CEAC37D6,
	ZipEntry__WriteEntryData_m6AF2C4008879EC789171B544878F6603E563D8C8,
	ZipEntry_SetInputAndFigureFileLength_m1394875FCBE51E8629A14CE0F2E314F087C27E2D,
	ZipEntry_FinishOutputStream_mB63DE3F0840433073E6887D5512B877C64F2C8EE,
	ZipEntry_PostProcessOutput_m401371735AC7FAD33F5D36D60E2B50545A57F37E,
	ZipEntry_SetZip64Flags_m72F8E2FF0746785523F2F4B063D592187A75CE06,
	ZipEntry_PrepOutputStream_mEE3B14268304C8646C7259115569382EABBD2125,
	ZipEntry_MaybeApplyCompression_mA1C357D1D67B19ABD35A0E43007D88D9C544D831,
	ZipEntry_MaybeApplyEncryption_mB91522584465152E6FB45A5D4BDEEE1E5F2C676B,
	ZipEntry_OnZipErrorWhileSaving_m7CAEF7F8517DC2E22346C6AE368794E86A1ABCEF,
	ZipEntry_Write_m757F1528731A5928C31EE68AC19581D555D886FF,
	ZipEntry_StoreRelativeOffset_m7D262CFC3591DFBD516255516F511092EF6237CF,
	ZipEntry_NotifySaveComplete_m40A69C513BE2B90F277E99F8AC2C27FBE246AB42,
	ZipEntry_WriteSecurityMetadata_m412C9B0E4C709FD4C44E67D9532BC8BD2AD6CEDE,
	ZipEntry_CopyThroughOneEntry_mDD3A2D35EF165F915BD930240DF565A045D686EB,
	ZipEntry_CopyThroughWithRecompute_m5915D9E74E338EFBAF3BB48631ABCF4BCCCB0180,
	ZipEntry_CopyThroughWithNoChange_m6E7D6DBFD1E8C194726BDD334324FA4CD96BC00E,
	ZipEntry__cctor_m3CB3CC35A8EA5E4D565EBF71A9946FBCC61028B1,
	CopyHelper_AppendCopyToFileName_m32D7A2D4D460A4A1851011B62B02F0FB4D11CB18,
	CopyHelper__cctor_m8EAFCE3B04BC0284D151346A0394319A7BF35B33,
	ZipFile_AddEntry_m5C8DF150E6C4A4D34EA26B9B17B03CEB192C2F74,
	ZipFile__InternalAddEntry_m66E2FF10373B2668773C8FEEDEE457D3FF133054,
	ZipFile_RemoveEntryForUpdate_m462B4737D2FC9C64DA4EC2CCC9990A3FA34A12B4,
	ZipFile_AddEntry_m76C9BB5A8341218BF6FCAB95D2FEDE0B50593D5E,
	ZipFile_UpdateEntry_mE68A5DCFBA4D6D34E62D716E4D1F6E65C12CD413,
	ZipFile_InternalAddEntry_m374D1FBB03D4A3E33277DE9503601C49DFD470B2,
	ZipFile_get_FullScan_m56FC88EA212A59AAD4EA7A7D91638FA0D291A261,
	ZipFile_get_SortEntriesBeforeSaving_m32122C5AEADD8AE29BC1307FCE8593F7508ECC96,
	ZipFile_set_AddDirectoryWillTraverseReparsePoints_m1CA5EABC26AF5FE28B2F87747A673205250BDCC5,
	ZipFile_get_BufferSize_mD5BAAC3EF248B7FFEF04C99A40A1E78ECE23A8F5,
	ZipFile_get_CodecBufferSize_m7D3A2DC36BDAB3308C9A1BCA831EFDE6083B3F3D,
	ZipFile_get_FlattenFoldersOnExtract_m6D084AC18EA08F8E776E001F6268279E1E8410B1,
	ZipFile_get_Strategy_m8DAF51BCC2920965C8DCA54219E5C18C42F907F9,
	ZipFile_get_Name_m35A6AD543F5766356CB54FEBAB20AB74DE9106D8,
	ZipFile_get_CompressionLevel_mC806EE30F6A83C37BF8CA02B7E38E827C97B1FD8,
	ZipFile_set_CompressionLevel_m1AD5D1AA48FAF931ABDE2FE8E10E60DE5F6EAC2E,
	ZipFile_get_CompressionMethod_mBCC6031F9A1D522F814195E2C8D2D4C3FABFF7FC,
	ZipFile_get_Comment_mD5F70A277404A786069BEBAA81B9418A3F682844,
	ZipFile_set_Comment_m53DFE8807492E99FF17CFB25EE9D9D0450CEAF3A,
	ZipFile_get_Verbose_m67C5BB684540D4E34A2B46FC89BCB1D4C820160D,
	ZipFile_ContainsEntry_m4BE8AA6A5587314A95F2B4C8BC6F49A139FE4CFE,
	ZipFile_get_CaseSensitiveRetrieval_m1859960FF9C52C2226B4E8BC00E9833BD8E95D0C,
	ZipFile_get_UseZip64WhenSaving_m3D0791F610F7D41F8A1FBA1A67AD5E89ACF92058,
	ZipFile_set_UseZip64WhenSaving_m771CA27C243EE6446FDAC76B385EBF5AA9BF605B,
	ZipFile_get_AlternateEncoding_mAAB7764D2CC1EC03EDA0F9FA6D6369CDA36B6E09,
	ZipFile_set_AlternateEncoding_m79ABABDA2A98050A4F529A34E9D09B9D9A1198D2,
	ZipFile_get_AlternateEncodingUsage_m04EDE069296587D3651B258DD1C528E002FD186D,
	ZipFile_set_AlternateEncodingUsage_m726776935EA6DCA142B9B94DC7F6CB94921C43FF,
	ZipFile_get_DefaultEncoding_m39FD24A80083B54502DD970277E1FD3BA83BE88E,
	ZipFile_get_StatusMessageTextWriter_m3E38DE3A49BDA26FF671E18E2D5334F230D23B84,
	ZipFile_get_TempFileFolder_m88E95D34A159A6966477D73C065C29ACDAD35468,
	ZipFile_get_ExtractExistingFile_mA106092322B045D5AF9BA751FF67E2C27D68DB31,
	ZipFile_set_ExtractExistingFile_mB1C917B618CCC6ECC2F62D3C57C92D6FEC4D0A99,
	ZipFile_get_ZipErrorAction_mB87A88CD0116F76268D59DC36ED222971FC5D3A3,
	ZipFile_get_Encryption_m66CDE7A8F65BB5E442D33913D1B103473AE6FA15,
	ZipFile_get_SetCompression_m664DF931C08C010B35FB10D79C5FCBE2B7A21A80,
	ZipFile_get_MaxOutputSegmentSize_mB85F836219E4FD137C870B8968B0208E680B11F8,
	ZipFile_set_ParallelDeflateThreshold_m91D73ABD864893EBF1A3402DC84B0869CB259100,
	ZipFile_get_ParallelDeflateThreshold_mC112AE1F60762D205B873E29F0BA7FD5BC5B0BBE,
	ZipFile_get_ParallelDeflateMaxBufferPairs_mE68481FB480DD5119BDF5758CBF75A7EBB090B84,
	ZipFile_ToString_m34BB30432FC52C64D12C4827E1226D5C7CD55BEC,
	ZipFile_NotifyEntryChanged_m8B8E812D922DB2D8E1543B65ADB8660CB54F59B9,
	ZipFile_StreamForDiskNumber_m227D92EFB214FECD881D0A567EEE7CDACB91DA51,
	ZipFile_Reset_m5345493F9FFE7C0359CE2D6F8A3B7ABD03805AF2,
	ZipFile__ctor_m8C05FB020FF05D50C59AF6E63E4F03E977F1FB4A,
	ZipFile__ctor_m4029126C04BBB52462BDA2309D0C94FF9380D3DB,
	ZipFile__initEntriesDictionary_m4993A3198F8E878F999DBB6F0AE4CB19930E95E6,
	ZipFile__InitInstance_m3EA40BD97F2A17EE6A341AE5800A82E6FFD5FC52,
	ZipFile_get_Item_m1B630E7CA89B4706288F10839F167CB2FC80962C,
	ZipFile_get_EntryFileNames_mB28E74DC79FF849E8A99B72781F25C866A3C8D45,
	ZipFile_get_Entries_mAD5BF3E82B8C1D729E5B625583B4542B13A4A258,
	ZipFile_get_EntriesSorted_mF23C866CA97D53CFA246DE762D4B29C26B426AF0,
	ZipFile_get_Count_m89CF208B330281B9B97FC2533AFF9B5A85F18091,
	ZipFile_RemoveEntry_m52173831ECF996C7E45789EF28CC02BEA9067353,
	ZipFile_RemoveEntry_m712BFF66CECE8AFAAED507AFC4E8BFC63A6EE097,
	ZipFile_Dispose_m643DE5B626370EF273FF02724EAB808A41B33576,
	ZipFile_Dispose_m1CF3A8A63FACACAE9109897F89FD7CD25BF0B094,
	ZipFile_get_ReadStream_mD6D6B9C60C1F056AC167E92890EBE0BE28D61B3B,
	ZipFile_get_WriteStream_mF5DFE8750B50A9E04EC949C07825E0765C73F9A4,
	ZipFile_get_ArchiveNameForEvent_m1525603669F9D370F49D4962B948686686EF61BE,
	ZipFile_OnSaveBlock_m8FB1DB6753A88EE0E7720A7563A9C56A0278984A,
	ZipFile_OnSaveEntry_m415AC17B27CD4BA7954EBB94BBB2346764C1C3E7,
	ZipFile_OnSaveEvent_m78D8BC071F4FB894ED0EB050F2721393039BC213,
	ZipFile_OnSaveStarted_m1806BA368685710267A7C2B5370BA2EE05E49124,
	ZipFile_OnSaveCompleted_m5E2F51454ED46C00A12EBDA6AC1CDB16B911291B,
	ZipFile_OnReadStarted_m88758C77D9219D285B0D32E4E1E86A91F9F746E6,
	ZipFile_OnReadCompleted_m8C6EC409A34C457F3653850B2DDD252C0B7C3A40,
	ZipFile_OnReadBytes_mBA6149EB64232E9518FAF635AC27C682CC24718A,
	ZipFile_OnReadEntry_mD1736034A5B5E2557B4F6AEA32463C460412FA71,
	ZipFile_get_LengthOfReadStream_m9B68037D45329BEB1813A1D6AF353087C090D3FD,
	ZipFile_OnExtractEntry_m77384FD04EB04D20C3026051E92336ACEE0F46BC,
	ZipFile_OnExtractBlock_mBFFE29CCD4B7ECB7D82363CB83B3EAD059A2F53B,
	ZipFile_OnSingleEntryExtract_m6C883AE7B8E115F27839D5E59A36D16C22BFA3A8,
	ZipFile_OnExtractExisting_mC8090D76970A278A02B5170BDC1BBD9BD778BC5C,
	ZipFile_OnExtractAllCompleted_m002555A62FFCB150A9F4275B845BB4513D815777,
	ZipFile_OnExtractAllStarted_m32F90ADE0959A32815A99E66B1F889A54A208C19,
	ZipFile_AfterAddEntry_mE28AF504C2761ECFBAC5622AB2A29D05CCCF12A9,
	ZipFile_OnZipErrorSaving_mEB4CE51F16D77A794C7270569E029AEADA5EA825,
	ZipFile_ExtractAll_m4A8116DBB7E725C28680A3A369A57B71887BED9F,
	ZipFile__InternalExtractAll_m77901F2BF8642A1B8E75DE972018DE90238AECBE,
	ZipFile_Read_m1F3D9C9E25412191AE32CD36BCFBC33FCB27BD28,
	ZipFile_Read_mF0503CE972C02F7A6A68D05EFEF563B472E8D011,
	ZipFile_ReadIntoInstance_m3E332DA71272B6417EBCA65E51436318A67B1573,
	ZipFile_Zip64SeekToCentralDirectory_m41317754BF098F95A09E545AA672E359EA7BCBBF,
	ZipFile_ReadFirstFourBytes_m05843DBEFBD566CEE965B0DB834E057106D7148E,
	ZipFile_ReadCentralDirectory_m7804D0A479D6F8BBC8B5B1FD3AE8645BF2722375,
	ZipFile_ReadIntoInstance_Orig_m0EDEDE0CC1EF5BE8A719CFE797174398FC1CED2C,
	ZipFile_ReadCentralDirectoryFooter_m251B5ED3D04C84B6F4084D3AE5EB4C7658DEF795,
	ZipFile_ReadZipFileComment_m5C2D8D0FF724DB2C1EFA11796113D7FA300E549C,
	ZipFile_DeleteFileWithRetry_mF39D69F44BA7E6F8D5F4BBF642D5C5D169324E27,
	ZipFile_Save_mE1B9385A35CE3E8AB50A1A3259C163F567688731,
	ZipFile_NotifyEntriesSaveComplete_m6EB5EF93655176899630CB6B2FCE49AE6455A361,
	ZipFile_RemoveTempFile_m9EB75DD161FB7242348858B69B378D8D89E5292A,
	ZipFile_CleanupAfterSaveOperation_mEFBB4D1CA5F3AE347854EE7364CF193F47C87D10,
	ZipFile_Save_mE38B65B2D42796C38A3396B643F3ACE61C4B1EB2,
	ZipFile_GetEnumerator_m39988F80C45B430022BF74689FBC73143BBF4DEC,
	ZipFile_System_Collections_IEnumerable_GetEnumerator_m2ECFD2E9F3FED4418BEB16D1C2825C2CD99EB24D,
	ZipFile__cctor_m6375D953EA9EDFD8C84173363350C3EB906BB70D,
	ExtractorSettings__ctor_mD4A4DC0F074D52BBDAE423C7F2FC645DED21379C,
	U3CGetEnumeratorU3Ed__1_MoveNext_m0B5498D59FF60C9C9CE9C6BAB61736BAEFCECDDC,
	U3CGetEnumeratorU3Ed__1_System_Collections_Generic_IEnumeratorU3CIonic_Zip_ZipEntryU3E_get_Current_m0C6A9722F217ACE457C5D80697AE933D97223588,
	U3CGetEnumeratorU3Ed__1_System_Collections_IEnumerator_Reset_m5A599D1BC06E35C87010A62845E6E89D67E15EC1,
	U3CGetEnumeratorU3Ed__1_System_IDisposable_Dispose_m110CE69100293B836646549612BD25B7D67FA6DF,
	U3CGetEnumeratorU3Ed__1_System_Collections_IEnumerator_get_Current_mFB6092110F543DA051421346DDC478A216B80135,
	U3CGetEnumeratorU3Ed__1__ctor_mA9AC25368224C0A1EA44FA4CB772B406FD7FACC2,
	U3CGetEnumeratorU3Ed__1_U3CU3Em__Finally4_m648093EFEBC23909B975D728EF686E9995B402A8,
	ZipOutput_WriteCentralDirectoryStructure_mC72F15EE5BAC97568773B88E3CF6EB3681E37DAD,
	ZipOutput_GetEncoding_mB84366DA807215970BF399E8AD277F9A923AB51B,
	ZipOutput_GenCentralDirectoryFooter_m99F47FAF7B7F9317F4879EFAF2BEC8C7E8DFA7A9,
	ZipOutput_GenZip64EndOfCentralDirectory_mED9C1CCB2FAB1E950BC64B8288057D278C920365,
	ZipOutput_CountEntries_mAB2C43F3482FCA385CA2A1123106B07FE98EBD0A,
	ZipInputStream_get_CodecBufferSize_mFB52EF563E16449408107D06D1C7D8C30991876B,
	ZipInputStream_SetupStream_mABA5D5F4C54C80333E54F04477C4E49A4B4F91B6,
	ZipInputStream_get_ReadStream_m243DB11E65F261DD283ABAD2271D38B667590967,
	ZipInputStream_Read_m30113A6102D07F1BC5E7F3901E7AA2A6F15C3AB2,
	ZipInputStream_get_CanRead_mAEE964544E587ED755BAA13C5B327433A9FA629A,
	ZipInputStream_get_CanSeek_m9DD042221479A385A7D50514C375BB96CA7A92D9,
	ZipInputStream_get_CanWrite_m12665C7A78676A53C64C8A5970BAB337EF6FA0CA,
	ZipInputStream_get_Length_mFC566D263ACADB1DD0955C33F2097696C00108E2,
	ZipInputStream_get_Position_m7D57F06E8F6975CFE18AF1E21CA5F42EC9C88DBF,
	ZipInputStream_set_Position_m2BDF5800F0FD457A227CB0DAA7C5AB5BB5F691A1,
	ZipInputStream_Flush_m03E37C5318A618E5C35A72965A8299D7AAC1EBE6,
	ZipInputStream_Write_mAFD74BF2843480F9DBF3EE348DB73F80A9407606,
	ZipInputStream_Seek_m80861C5DEE88AEBED7820AECB6A3ABF5811463F9,
	ZipInputStream_SetLength_m9F418A7C7C42CF3399A4C140A0361F2DD24F8C94,
	ZipOutputStream_get_CodecBufferSize_mC467B796DD76833D00AD4A359464046473AB2A2E,
	ZipOutputStream_get_Strategy_m5E2EE33B9638110DDC7C751D925E7F491D488B76,
	ZipOutputStream_get_EnableZip64_m6A1838FAFBD8CBBA706F48E43867839CF049C450,
	ZipOutputStream_get_AlternateEncoding_m6DAA08CC1B904F3AB17D2441B53AD9A17FCB877D,
	ZipOutputStream_get_AlternateEncodingUsage_m6A2F602F01975B88F4908EF2293FFFA0372AD907,
	ZipOutputStream_get_DefaultEncoding_mF03E2C099E12AD02187B802AA41B89BD4491E75D,
	ZipOutputStream_get_ParallelDeflateThreshold_mDDA551B240D6B41DAB7F4B7BBCAC4DA3C83A0D52,
	ZipOutputStream_get_ParallelDeflateMaxBufferPairs_m69733555F5ACFEAB77659CDEBE187C3522E5E222,
	ZipOutputStream_get_OutputStream_mE2F565CA1C859B39623DEE4F9562E8E4DB9F8CF0,
	ZipOutputStream_Write_m5912944330053A5D5CF21FFE34B5BACE09BC9BFC,
	ZipOutputStream__InitiateCurrentEntry_mBF682F55D71B080CFB83D2FCAA94D1F2CF3B9314,
	ZipOutputStream_get_CanRead_m0EBD2C7D07784D87EBBD592CBBE2A85D1BD1C270,
	ZipOutputStream_get_CanSeek_m407B068D62FFE6E4F0095B07628105CD3FBC8052,
	ZipOutputStream_get_CanWrite_m132F4249556519271A33AD4E9A05652EBF0CE886,
	ZipOutputStream_get_Length_m9D0B489A3E1EA45F8E51FF0E288C5AB2D5E63E7C,
	ZipOutputStream_get_Position_mD71BC216EFA212E20816A4D884BE160B09CA9CCE,
	ZipOutputStream_set_Position_mC24632338E3A337B6ADA3EA616D657BBEF47F77F,
	ZipOutputStream_Flush_mEF22F8F1C599A16418A190F47689624C61A71773,
	ZipOutputStream_Read_m588E63A8F3A2C551958D5899D9AA0AD356EFDBAC,
	ZipOutputStream_Seek_m88A9BA7601CBD050C3EE7FCA8B50F749E92DD348,
	ZipOutputStream_SetLength_mAC780B284B8BF82206954695906969B571300462,
	ZipContainer__ctor_m29C10250A9BD529D65AAD20BE5EABE046B0AEBDA,
	ZipContainer_get_ZipFile_m40E15ECAF80FBEB5720A6FF557ED569A4FABF16A,
	ZipContainer_get_ZipOutputStream_mCD4B9A35F35EF36AEF03A8D3292948BD11B833A5,
	ZipContainer_get_Password_mCC3DC17E355DBCC8B27F12B37399D4B35C9F90B9,
	ZipContainer_get_Zip64_m6B929978F95B38CEBC8018A2000363027175D07E,
	ZipContainer_get_BufferSize_mF79DEFFD46F1DFC471B953433E6C5D94EE6289F0,
	ZipContainer_get_ParallelDeflater_mC9840E3BCF2559B99456ADF7B93A34E32C9E9114,
	ZipContainer_set_ParallelDeflater_m52406617BD48B694CAE12220BF3F25985C357AFF,
	ZipContainer_get_ParallelDeflateThreshold_mDC50668C2AC11CDB53F477CA0ED0086F38723A94,
	ZipContainer_get_ParallelDeflateMaxBufferPairs_m49B9819F99249207C689A1E5C947B8F5B22AACCA,
	ZipContainer_get_CodecBufferSize_m84F4AE6D8135043129350BD64DBE8F49760B8DA6,
	ZipContainer_get_Strategy_m1DCBF366F4CA22131207CA5F3B985A1180CD5D9D,
	ZipContainer_get_UseZip64WhenSaving_m5FA9CD96FDA984B6FB57E3465ABB5B4ED1700F45,
	ZipContainer_get_AlternateEncoding_mDDA135489EAEE3D3E0AF57AE8613EB7FC64B2FC6,
	ZipContainer_get_DefaultEncoding_m8384EADCD56E3870E694C7494D06578B51E078BB,
	ZipContainer_get_AlternateEncodingUsage_mA1C47C7A43CE7C616E90CFB4BEC4D2A4FF13476C,
	ZipContainer_get_ReadStream_m9E7D0C3B49247A0A2507A85AD774E4ACB31551E1,
	ZipSegmentedStream__ctor_mC5734EA0ECEB42173D28664EF02BDF2F390BC126,
	ZipSegmentedStream_ForReading_mD3A3F1C42D70F2F4EE2913F6CA5AE5C72319D4D3,
	ZipSegmentedStream_ForWriting_m6FB644C3AD6D24DBCC6174C8F596781CA168ACD7,
	ZipSegmentedStream_ForUpdate_m30A319B4F4D486DB33CBC34C179AFCD9231144A5,
	ZipSegmentedStream_get_ContiguousWrite_mEFF8E4AFC70727B90119530FFAC979495D8E2F42,
	ZipSegmentedStream_set_ContiguousWrite_m80534DA515842D1E5634A8D4DDC32F3526B536CA,
	ZipSegmentedStream_get_CurrentSegment_m3B7715B0022FD9EA6CF7F0BED060ACE4A675F14E,
	ZipSegmentedStream_set_CurrentSegment_mB25D54DADAC398D5A992B62B3F40ADB5CE68513A,
	ZipSegmentedStream_get_CurrentName_m27452D37C34B7DD659879AF595383D006CE1F1E2,
	ZipSegmentedStream_get_CurrentTempName_mABCA88BA46E4A3D5A31CA83ABF48F82560A5F9D5,
	ZipSegmentedStream__NameForSegment_m14145CFD1562C3977E7F0128B424D13F53C95429,
	ZipSegmentedStream_ComputeSegment_m6885F3B077AAE46E6BC7B0858DB7AEF84A89B54A,
	ZipSegmentedStream_ToString_m8824E743037A5B0AC077106DD13848E451B57006,
	ZipSegmentedStream__SetReadStream_mDA59AB5037C93B7EDEF166B64A3721C5928245B3,
	ZipSegmentedStream_Read_m32581082E352026A63DF6BC647C40EA817301B0B,
	ZipSegmentedStream__SetWriteStream_m2BD8C02F97394E59F36DDE97E034B7DA7B210EB4,
	ZipSegmentedStream_Write_m413A5DB6847BE81051303251FE3ECF08EB0972A2,
	ZipSegmentedStream_TruncateBackward_mF0A3D448EC9E17745A2478CCE5C919342DFD0236,
	ZipSegmentedStream_get_CanRead_m301EDA0A443547A1CADF0D51B52E30E5C9C88FDA,
	ZipSegmentedStream_get_CanSeek_mC1C6164A6E3B1C559A173B64D898008D0CB0F431,
	ZipSegmentedStream_get_CanWrite_m2923512C61F4ECB341F44F9F4D9C0EA5D8B8E629,
	ZipSegmentedStream_Flush_mB204CCF208000BECA4BD2FAEBFDAD558DCDF1E30,
	ZipSegmentedStream_get_Length_mEBB69E62DF0390BDBCB010A312145430011D4A80,
	ZipSegmentedStream_get_Position_m43BD3FB5F349B6C6BCBE01F9731D38CF208B7F97,
	ZipSegmentedStream_set_Position_mA0D0CD86FE7C7444F5926B44313BD0CF1EA1708E,
	ZipSegmentedStream_Seek_m900EBFFBDBE88A285FC99E708DBA3E61E1FB9DD8,
	ZipSegmentedStream_SetLength_m40262EA09BB8373F27A68C59272CC1D8607378DB,
	ZipSegmentedStream_Dispose_mCAB353F553FFB24B4EA7D8487AF02B150CC1DCB3,
	BitWriter__ctor_m63CFBDD75DDBD25EC642FBEC7FDFF78FE5C24676,
	BitWriter_get_RemainingBits_mE990E20067678E6BFAFFA3725C55A33FE0BF7EEC,
	BitWriter_get_NumRemainingBits_m72882230618C2494CEAC57EBBCE79CAD83B40F13,
	BitWriter_get_TotalBytesWrittenOut_mA8C36A034DF378DD397D425903E53892683F8990,
	BitWriter_Reset_m89AC034FBDAC09AE3EAC1CAFEBDE8C96258405BA,
	BitWriter_WriteBits_mE9A99C8336CD1B1983518E775385669BB933C2DF,
	BitWriter_WriteByte_m2F874181E743C267F1456F26AF39965E35CAF248,
	BitWriter_WriteInt_m4CE89EAE14DFC560A84BB702CFED559B65012B42,
	BitWriter_Flush_mD45AA96F3B25557F45F23D6F36387573401242D5,
	BitWriter_FinishAndPad_mC2327BC5B749624AD27947344D5114FADC85C7F9,
	BZip2Compressor__ctor_m02EA949E772FA6ABE212E1A2BBAE36E7AE7B81A1,
	BZip2Compressor_Reset_m9D9DF9464D496026459D09DF060AC79C8D5F32CD,
	BZip2Compressor_get_Crc32_m6A5C0081C6CE1A92C536004F1AD3B8D33DB3110B,
	BZip2Compressor_set_Crc32_mAC44DBB6D2381E38182BB24D4AEC8F922471F604,
	BZip2Compressor_Fill_mE2AB23B05823D64877BB7A1887D49334458E6BAE,
	BZip2Compressor_write0_m4A4D72C2D9E0F4613D7B3A6410BDB9CEB596845F,
	BZip2Compressor_AddRunToOutputBlock_mA73B4897CE9369C60A0817F1AE08C6EA420CD59A,
	BZip2Compressor_CompressAndWrite_m1FA3139B8F88831493B479C742E76B2CBB715886,
	BZip2Compressor_randomiseBlock_mB29BB166FF6C3C1550CD9580A32C25ACBBD8C15E,
	BZip2Compressor_mainSort_m8ECC932F1594397EBF9514199CAF1D4FAE10571B,
	BZip2Compressor_blockSort_m8738396E19B0205CF55CCC5F3680330712F230E5,
	BZip2Compressor_mainSimpleSort_mABF96757D4BD8024C3BA754463021F34C8E84C0B,
	BZip2Compressor_vswap_mF0E8F1BFCDFA81C7DCE878EF1A2A5CBC652BA9A6,
	BZip2Compressor_med3_mECD1D2AA2A7226606E702868EC51AD760C3D7461,
	BZip2Compressor_mainQSort3_m35C7FD1713C931424C9DF2173906DE3D96A7A969,
	BZip2Compressor_generateMTFValues_mF1E319881F382F621FABF213C6DA92F58E6EAB3B,
	BZip2Compressor_hbAssignCodes_m59E16FA69E6653F2D9F0A2F67E62F938B37C538B,
	BZip2Compressor_sendMTFValues_m028EF067A8FDDEF7361BA8DE22779ACC55B9B65D,
	BZip2Compressor_sendMTFValues0_mDB0E8428985EF61E9C97247E490ED6ADAC552D51,
	BZip2Compressor_hbMakeCodeLengths_mBF792140B8410D91B356F64BDA1511BC5EA7B458,
	BZip2Compressor_sendMTFValues1_m55D0E0C492C2D3AC29C6100117C80CE1467790E7,
	BZip2Compressor_sendMTFValues2_m93E6390C0005D7D9A1CF8C9A1F1B8A5FF5697DCE,
	BZip2Compressor_sendMTFValues3_m83FD3C5A2F359EBC1173E94CC08CCBFF293CFFEA,
	BZip2Compressor_sendMTFValues4_m630FD0217BD736A4306A74F27FF9C7115044B93C,
	BZip2Compressor_sendMTFValues5_m41BE7178B9C5E6AA375DFDA094401B728D92E2C8,
	BZip2Compressor_sendMTFValues6_m0D0AA4D2B5DC2D8B80E65829C1D60D2FFC39836E,
	BZip2Compressor_sendMTFValues7_m00CB975B0350D5391D4828607E8D7280DA8B961F,
	BZip2Compressor_moveToFrontCodeAndSend_m8CE1772ADBEA93A3D01C7A12800F8522F8E2D794,
	BZip2Compressor__cctor_m7409D6662398C8A6DBBCABFD9701ECD4AC55CDE0,
	CompressionState__ctor_mCB1623CFDB2449BE6AD4E1E349FA3443EACC35D6,
	BZip2InputStream__ctor_m960BFFDF1709936C69387F2CE195F904A9D16295,
	BZip2InputStream_Read_m4B5A314335719881E72712F8142C979396B41291,
	BZip2InputStream_MakeMaps_m08743EE6451C8E4D41AB20D7BB021D8253746C09,
	BZip2InputStream_ReadByte_m928A2C60985BEB81098851A1CD53A912BDC5CFC9,
	BZip2InputStream_get_CanRead_mE2E6D7BCA3B88A7BF8AAC90A95BBA2D4F7EAE548,
	BZip2InputStream_get_CanSeek_m2C72ABE3319FA63F4EA41831141F74A148CC3E70,
	BZip2InputStream_get_CanWrite_mE4418F7B94B8E9396C65F269E22A5A7E1AF4ADA3,
	BZip2InputStream_Flush_mE1FEE2E4B4C94BBACDA541A7703B6B6E2AF5D02A,
	BZip2InputStream_get_Length_m4C52257D69E92CD8A0FF274D99ECAF9915B86CFB,
	BZip2InputStream_get_Position_m66484EAF05A64277574156ED86169A606DB160BA,
	BZip2InputStream_set_Position_m5B2742F41FEFBD68768286BCCE4C8BA18C14ABAB,
	BZip2InputStream_Seek_mF3C8579B8E2EEDA1925CF706205063F86E8FF7EE,
	BZip2InputStream_SetLength_mB49DE9AAC35F91DC9758B3DA4B74368F97119A1C,
	BZip2InputStream_Write_mAE1D18E318616955B91D251775F9835FD47D5273,
	BZip2InputStream_Dispose_m70C3672FC397801DDBE844BC7E58C4AD151A5CDE,
	BZip2InputStream_init_m733F6F47E24E6CFFC0AE1C7FC39FB3BA043560D3,
	BZip2InputStream_CheckMagicChar_mBA29F7441EB9507DB2F784B0B0E006576BDC9D2B,
	BZip2InputStream_InitBlock_m12DF45C0D6464E96F5F5818248D42932F53D1509,
	BZip2InputStream_EndBlock_mE9B019E88DF2286E656CBDBAADB29B2A7C67A5A2,
	BZip2InputStream_complete_mD7A3806E4C552975FEE528324D97D3D491981277,
	BZip2InputStream_Close_mE1BF85ACF149D85197A1266805072938A40EFE48,
	BZip2InputStream_GetBits_mA876456FDC327E6610990B0F7AE3076DB4E4FDD4,
	BZip2InputStream_bsGetBit_m96011A71412F48D08EE0AA0E9F287F62332317C9,
	BZip2InputStream_bsGetUByte_m1DF7B32A4A7B87383A11972DADC6147E5C8904E3,
	BZip2InputStream_bsGetInt_mB9A50C3A090EC184CFD2E1F6F9CCCC41D2F03615,
	BZip2InputStream_hbCreateDecodeTables_m9C66E442DBEC805F22C30B40534D626BE53B24C3,
	BZip2InputStream_recvDecodingTables_m2F44567BEAB3B2AF4B9AF63CE4BAC8FEAE7C3DB4,
	BZip2InputStream_createHuffmanDecodingTables_mC7858C3C6FE3C2F51F66190E23667D353888BACB,
	BZip2InputStream_getAndMoveToFrontDecode_mADAC2520A5EA0656F747F57409A17C3838531124,
	BZip2InputStream_getAndMoveToFrontDecode0_m6F23B1945231A9632AB83A3CF10C0C316359EDF1,
	BZip2InputStream_SetupBlock_mE898DDFD7F41C7079DC60F4328333707418F8238,
	BZip2InputStream_SetupRandPartA_m99509EF9D2DCEFE1FC7079F2DBE1583E12976772,
	BZip2InputStream_SetupNoRandPartA_mF913A6950F5218DCFE33E4BA633B8F277B8A19B1,
	BZip2InputStream_SetupRandPartB_m90E0CAA173C920B68D5E008CB71BE1A21C075F2A,
	BZip2InputStream_SetupRandPartC_m9E0B695F62D3A86BEDB5A9489D875585DDB5A631,
	BZip2InputStream_SetupNoRandPartB_m58943FE8F5671BBBAF45E96D76098AAC5CF1B312,
	BZip2InputStream_SetupNoRandPartC_m5C2E44C6A48F2E8FD26EA71F1676543B1A9E19F7,
	DecompressionState__ctor_m18C1A285FBBE5F86742FE7DD8C5C4F91D3877914,
	DecompressionState_initTT_mCE35C3EAB11A7BDD797AF66E76E716A81822D91A,
	NULL,
	BZip2__cctor_mBB3F8069B24A99CB13EC4078D78AC08057D61FBB,
	BZip2OutputStream__ctor_m0BE5AA0484757CCEC16A7772C4B174E1232C6BA6,
	BZip2OutputStream__ctor_m63AE4F0ABF96E85810D40601EE49E2FB51F4AE30,
	BZip2OutputStream_Close_m5BA776801881BF87DA49CA90306F834DD4ACD8AF,
	BZip2OutputStream_Flush_m1612E02D74AC00C31757E7BDD5C144C63C56EBC0,
	BZip2OutputStream_EmitHeader_m1DE3B95D04B77A91D717E383EF2CC18556BE25B1,
	BZip2OutputStream_EmitTrailer_m7C6E9A7F9D2D648F6EB69FFC8E7598759203FE75,
	BZip2OutputStream_Finish_m3B32B8628B960470E2E13205E9258BA0697963EE,
	BZip2OutputStream_Write_m69A9CC3A956638BD7020EE679BCD14A93E9B1FD8,
	BZip2OutputStream_get_CanRead_mFD3895BED8B7C2F8AEF84BFF5597EB01A9A933B9,
	BZip2OutputStream_get_CanSeek_m07F87067A043FF4197675E64933438603A5A5474,
	BZip2OutputStream_get_CanWrite_mC11066D3B70CA57DBDDF5F10F6A8F4565C7477EF,
	BZip2OutputStream_get_Length_m7FA19E9C827AAD7E3E3173C769617820A4F75A4D,
	BZip2OutputStream_get_Position_mC8D689E873F49FA7590754A768F25F425E936033,
	BZip2OutputStream_set_Position_mE3DD27BC7F1276696A4968D044F3CFCCA24982F9,
	BZip2OutputStream_Seek_mBA1A267B5BDA4970C52DDA6AA7A9D986B7AD339D,
	BZip2OutputStream_SetLength_mE7B4879C2A890F5598849A42317E1FAF9B96C800,
	BZip2OutputStream_Read_m06FED714C84512E7E34329A74EDCEF809CB0FE3E,
	WorkItem_get_Compressor_m046F4CCB162F349FBEBD80C60A959C36F3B51CBC,
	WorkItem_set_Compressor_m621D715A0CAA78C46272DFB6DB2750DCDFAD5C30,
	WorkItem__ctor_mE01970ABA1DF70EEA04D6190F4631CBB7E5FE7AB,
	ParallelBZip2OutputStream__ctor_m4D272F339AA90F3038C97554FC1F65BB6A6BC2B8,
	ParallelBZip2OutputStream__ctor_m6B2CA1D2468FAFB177D4F85908271E794AA9460E,
	ParallelBZip2OutputStream_InitializePoolOfWorkItems_m5E49B6D3B89837A512B4F59EA511758F97F96B0E,
	ParallelBZip2OutputStream_get_MaxWorkers_m84F03253BBAF1857FCF24C96D6A068A8BECC9609,
	ParallelBZip2OutputStream_set_MaxWorkers_mA99061B20A342D5D7207E033DEB5612B686BF12B,
	ParallelBZip2OutputStream_Close_m6A0752BA1389DF390B077F13375B86920E8A1AFA,
	ParallelBZip2OutputStream_FlushOutput_m827F5DBC0380FEC2BAD2D7656198913C34DA0FE8,
	ParallelBZip2OutputStream_Flush_m65B3107DCA9BDDD19F4E68449C2FB97D596E596A,
	ParallelBZip2OutputStream_EmitHeader_m7534D339E5D4E834429D0633B8977F57FCC8AA07,
	ParallelBZip2OutputStream_EmitTrailer_mE7B8E278F3B8369F52742194542D8D30E8A63EFA,
	ParallelBZip2OutputStream_Write_mC018C4DD4CEE06D5D43D29A6175AE390EEE25477,
	ParallelBZip2OutputStream_EmitPendingBuffers_m353C7F4EF2E1822DFE99B207A105DFC5C077AC79,
	ParallelBZip2OutputStream_CompressOne_m8B35672163D97EAC6587123142D095C9E656ACCC,
	ParallelBZip2OutputStream_get_CanRead_m74080BAA5ED89DEA03BACEAB1ABB0B15F04E02F5,
	ParallelBZip2OutputStream_get_CanSeek_m1A963665DEFD7C39E2F7AE93E39FF7DA14704B98,
	ParallelBZip2OutputStream_get_CanWrite_m7557B78AC42B592370E47C2BC33E3D62D178EE09,
	ParallelBZip2OutputStream_get_Length_m4E81ADF75FD9AE4543D4C1EC96B8C40E45168631,
	ParallelBZip2OutputStream_get_Position_m6ACD1E658A6BA27721C8FC43CA0F953E7558E29E,
	ParallelBZip2OutputStream_set_Position_m7A4A0D74A410FC67932F42FD5C637D0C03E009CF,
	ParallelBZip2OutputStream_Seek_mB2D1552FCDB742449C560B6489B5F3211E9AAFFB,
	ParallelBZip2OutputStream_SetLength_m65E872BEB22C11D54ED9E901BE9D0ACCA95C95A0,
	ParallelBZip2OutputStream_Read_m638098749482D48700F859B6D46D3D90DDA50388,
	ParallelBZip2OutputStream__cctor_m7211795BEB5E16622AD18960471D307775E92B9F,
	Rand_Rnums_mEAB7E40B4850FAD5F4DB376EC10D6A4851AB2534,
	Rand__cctor_m315115DD4682AFFA5A5DCCEEBA269E4E364CD79E,
	DeflateManager__ctor_m673892FC3A1CBD9A29E22BD172E6A3692FAC15E7,
	DeflateManager__InitializeLazyMatch_m379A2C533AE8525D2A42DC770DBADCB0C594D34F,
	DeflateManager__InitializeTreeData_m2A45CA9A1F1BC4F6B9AED230EA244AAD4A7D26C4,
	DeflateManager__InitializeBlocks_mCAC5916D44A421E7EF0C2EDB28B39ECDAA662E5F,
	DeflateManager_pqdownheap_mB0C0AD8B852586766E8387BA14206891CFF92C6D,
	DeflateManager__IsSmaller_m3B82488927899FCD2D88365B45B41C9CE16F03AF,
	DeflateManager_scan_tree_m308FDA1D0515F89450B31218EA55C140A5A1A268,
	DeflateManager_build_bl_tree_m2F4844B7317C947DD017E8F51FD46D6814F38A49,
	DeflateManager_send_all_trees_mA1A3534DD25E2E8DB24DACA29C388C2961AEB637,
	DeflateManager_send_tree_mCAAC63E9C5AD0123CDE36C26366532DE354DF671,
	DeflateManager_put_bytes_mCF4CDD1CFE05B85A2EC5AC85A2D5CED672E65A31,
	DeflateManager_send_code_m65824D5B4571BCB54AD634B232B3AE571D836A53,
	DeflateManager_send_bits_mFE0FD7593E4F2FA302F28397B38C49E871145C39,
	DeflateManager__tr_align_m13E65833D07DFB16BB3EB984634A8A7E46CDF7E3,
	DeflateManager__tr_tally_m6A6E27AEFB338D384B61101C43250183A64A39A7,
	DeflateManager_send_compressed_block_m6939DB771E1E1D4E99972E7D771443CB1ED89085,
	DeflateManager_set_data_type_m20652FD813E4D17285CBA2B02B3FE31410134BC4,
	DeflateManager_bi_flush_m88D27CF5101646EB5B6AED63ACC49B421617B96C,
	DeflateManager_bi_windup_mB45A42D9FEFD7BD94726C605D8C4F5A1652FA263,
	DeflateManager_copy_block_mD225B994AA8BFC0041EF7F95568CE75C47684D71,
	DeflateManager_flush_block_only_mF828E18744E6601044F2BAB54537D69337111A40,
	DeflateManager_DeflateNone_m6D5C001FBAAC4A844BDDD1DB8535AA1C14AF620B,
	DeflateManager__tr_stored_block_mCE0E5C5ED44FED65F2D0AC296E3A7DFD3C4A5AB7,
	DeflateManager__tr_flush_block_m3B6D356E6FF874EA1EF5CE880FBAB96D2A49B237,
	DeflateManager__fillWindow_m93275F98D8823C7C41047B7C987A2C58BE7E71D0,
	DeflateManager_DeflateFast_mCB6BB716ABA82E871C3A3BBE050826B68BF227FA,
	DeflateManager_DeflateSlow_m62B70384CC6D843507EDF296C347D638CD972B81,
	DeflateManager_longest_match_m3C308D51E77F9ED7A88835CA76B34338FD21482A,
	DeflateManager_get_WantRfc1950HeaderBytes_m272EAEFE3BA2E1F77DC32034977C57BE27DEDFCF,
	DeflateManager_set_WantRfc1950HeaderBytes_mABBB4B9D8368738D4FF5922D1215907F1AAAB85F,
	DeflateManager_Initialize_m88BD2C811B3894FD301B6A5B809C5D4A82CE22BB,
	DeflateManager_Initialize_mADCBBFBB6D546DE532FBF769C0F1166F5966EDEC,
	DeflateManager_Reset_mB94032B5B8797C2376107C683C39A8E412C059B5,
	DeflateManager_SetDeflater_mB433E7050024976AE53A06D7F36E597D70E6C893,
	DeflateManager_Deflate_m1EB192C0188EF1F10925E173193F3F2A64711CFE,
	DeflateManager__cctor_mDDB46D27E997AB2407ADCF4E2951A5F980032534,
	CompressFunc__ctor_m4AA09C64C193D6F880A9E9D274E32E57121FBEAE,
	CompressFunc_Invoke_mFFD4FF3455F7139A4D2E8FE2783945530C50A8EC,
	Config__ctor_m8CC004E99CC83462780C4A8F4BD6343535FE8E20,
	Config_Lookup_mD4BC48A84B374131891BB93F4B00EAEAFD4808FD,
	Config__cctor_m192786F448884B2CD2445D0AD037A8CECD74CF61,
	DeflateStream__ctor_m526D853A68218A6BEB24BD85F05E935357919959,
	DeflateStream__ctor_mD0A2C65F467BDE8A2BDE997287A2DB9745422F2E,
	DeflateStream_set_BufferSize_m34A2182A2275B8C42D1612BDB72F066250A2889B,
	DeflateStream_set_Strategy_mBCF4C5B63CF6F14A6222CF4A56C2D8FBFAAFF2B1,
	DeflateStream_Dispose_mBA9F1D0B90214CC7AC4763A616DED39A2051C450,
	DeflateStream_get_CanRead_mD636DAD1BDC5C986C172B222A935E8838A4CCC7E,
	DeflateStream_get_CanSeek_m7B70CE6446B31A4CFCEF16A6B5D30062750776A8,
	DeflateStream_get_CanWrite_mD8E8DB6A601B51FD7212CDE605ADE2AD29527404,
	DeflateStream_Flush_mB07003845E043821D30C24733FCD10927E208C14,
	DeflateStream_get_Length_m1672C559C9CFBF3A3F1381F9AA80232F51F0CA65,
	DeflateStream_get_Position_m93D6C073E3273CC87FDF87EA8C3837ECFA225306,
	DeflateStream_set_Position_m7373C8D9F3C3D6BCAEBC5819E6CA0429A26BF2A7,
	DeflateStream_Read_mAC2FA09753A1F2DA73D6C6125315B67DF029EA7D,
	DeflateStream_Seek_m2E56224D609B67EF11F27866C502ED89A845D644,
	DeflateStream_SetLength_m1EC3B46D6C3C2BE8F3B95C7B8597BE0B9D18CAE0,
	DeflateStream_Write_m8F4B88D3DFE5FE3B8DF74C54FE0D1E2B68B0FE17,
	GZipStream_get_Comment_m7CD30C891BABC13DADA6FEEE7D981059476D0E32,
	GZipStream_set_Comment_m9474C9EDC6CF3149558AF67F49EE27BF8D8D9E27,
	GZipStream_get_FileName_m3E62EF49DC029D39C08FD8CB2F9E4F866EC7F7EF,
	GZipStream_set_FileName_m12C70BD5813D0300EC2BD4738ABC02E6A93410B3,
	GZipStream_get_CanRead_m6E965039A3D74CD1D27B354EB33548952F20AA98,
	GZipStream_get_CanSeek_m0F9A02066DDF200C2704E753B4AECC3A7C31B847,
	GZipStream_get_CanWrite_mE9AE609702DC0EFD7A79587711F94ACF5C17F798,
	GZipStream_Flush_mB063080933544FC4897E4A0B531AF83F481AEBA5,
	GZipStream_get_Length_m0497BF443DC8BB48A09884D278A2C72B4B294AD8,
	GZipStream_get_Position_m65C03842613D053AA4B85B3690FBF74D10F70894,
	GZipStream_set_Position_mF31070FC48ED0B0A455EBE0470A8C146931CAA3D,
	GZipStream_Read_mB53A305B4FDE06EE66BF99DC27D952E33E74928F,
	GZipStream_Seek_mD4E31CD4CF4EC5767B98D31D7F7DB2963B200A9B,
	GZipStream_SetLength_m19F98C9C154588E3D6D100BCD9B5BA063022FF7C,
	GZipStream_Write_m4BB9F116E2AB14242924C9243229F3A223E11B98,
	GZipStream_EmitHeader_mB6AC12AA7DA11B53251570D2DF4177848ACCC347,
	GZipStream__cctor_mA0AF0F21978757B76A302CC4083DFF43AF36C8B0,
	InflateBlocks__ctor_mBD83187E515C1662163E80CE84E600B4BBF1E1A9,
	InflateBlocks_Reset_mC62260B568FCC7B5C6E375E996074D24216F49DB,
	InflateBlocks_Process_mEC4507D32AE3CFF3A3C8F5423539E093245D1B19,
	InflateBlocks_Free_m7B9C1A78B3DB023A09527BC17672191F51BB9DC8,
	InflateBlocks_Flush_m82377F0E2FB5B7DB9346CD475443F4FDEF97E03E,
	InflateBlocks__cctor_m2C16853FAF2D4F4253B3B80A83D87CE3F2A91287,
	InternalInflateConstants__cctor_m4A8E1B064AFEF4BC891D3CC2198C2B105A78FD54,
	InflateCodes__ctor_m45BAF7B545F633FF622E70663867CF3F88BDCB77,
	InflateCodes_Init_m053AB0454E9975AA50F25A2FB0717429AD3E98EA,
	InflateCodes_Process_m4249FD5D2910A102F371910F0467779F7387933C,
	InflateCodes_InflateFast_mE5B0513DDEB93922CE88B74A87D1E1AB13964ECE,
	InflateManager_get_HandleRfc1950HeaderBytes_m7BEA6F6A7B1198443E61DD6571AFD8E590ADE2C7,
	InflateManager__ctor_m4449199BB4F2A4519FC54B43AE5CE853A6B5B758,
	InflateManager_Reset_mEC3AE288F09C96AEB6C089E65924B62F9D55856D,
	InflateManager_End_m208F730D247B703035CE2DEADDFEA8B499466B77,
	InflateManager_Initialize_m277BD686D0CDC51E687E558211D2B2AB049266B6,
	InflateManager_Inflate_mA1862D22D7D8FF6D4D69516F331D9C8D81CB850D,
	InflateManager__cctor_mE04E0A27D33EFBF0B84C7437DF7F861F9EE48DD8,
	InfTree_huft_build_m2468529E1E944A048AECF9A398B0FA00B9300B5B,
	InfTree_inflate_trees_bits_m5935E854D400B7C9D4775C3E4BB5E3E3F9F52E3D,
	InfTree_inflate_trees_dynamic_m635E3DE846E6C42287BCF4E6FEC97812720B594A,
	InfTree_inflate_trees_fixed_m061BDCEAA821B2ABC96E2E719180545662C1B49F,
	InfTree_initWorkArea_m92F4D89818B4BC8822FC0E8C280374B8837B5092,
	InfTree__ctor_mE10403441546396BCDD4C5BA558149D1793B7660,
	InfTree__cctor_m7FFB7AB8BF2FE19A163715BF7D18CAA206839A36,
	WorkItem__ctor_mE90C0B5F4D1B5267E4A2ABDF393F2F5AA7484AFA,
	ParallelDeflateOutputStream__ctor_m12A5E40C0EE7176A17CFED55B6BF864823D10E5E,
	ParallelDeflateOutputStream_get_Strategy_m6B656B8ED562A795E602FBE9318D562497A809E2,
	ParallelDeflateOutputStream_set_Strategy_m69949937485EF93C043D4100425063CD9B79B434,
	ParallelDeflateOutputStream_set_MaxBufferPairs_m5FC76A706C345D1663E12798F3E6A58434C85310,
	ParallelDeflateOutputStream_set_BufferSize_m93A54C256C068E0F3373E5F6A40F81349B58F20C,
	ParallelDeflateOutputStream__InitializePoolOfWorkItems_mD0DB6E3BA62AFEEBF1EB5535642D120F786335C0,
	ParallelDeflateOutputStream_Write_m7E845633ED8BA36F1812AAA4D66D53B92A4A1EF4,
	ParallelDeflateOutputStream__FlushFinish_m2F906333DC2C4141DB816FD57C07BA4B9E5E1822,
	ParallelDeflateOutputStream__Flush_mCC8D0791FB4B9025A9A83F1599B41544DDDF9DF9,
	ParallelDeflateOutputStream_Flush_mDFD512CCD5174225D4940B32B56A104C87F673CF,
	ParallelDeflateOutputStream_Close_m5C0B62B952804D7069545477BB19A9ACA1C0D31F,
	ParallelDeflateOutputStream_Dispose_m411A16D85461D71930E94DC098E027EF8CF5685E,
	ParallelDeflateOutputStream_Dispose_m6F6D3D8EF785A9D9031ADC26B371EBB18FC6BC7F,
	ParallelDeflateOutputStream_Reset_mBB61A43C4FD5349085B1D33208DEEC5E8D0BAC5D,
	ParallelDeflateOutputStream_EmitPendingBuffers_mCE92EAA554C53986C1C5271291F98DA90FB6ABAE,
	ParallelDeflateOutputStream__DeflateOne_mECB7A876BF3A253004F121471CF30EAC6675DF65,
	ParallelDeflateOutputStream_DeflateOneSegment_mEB1E8827E8852767FC842A213D6E631117CF5728,
	ParallelDeflateOutputStream_get_CanSeek_m423C8B56A1F1F4A4839A820DB8A45FC5BE76D8A6,
	ParallelDeflateOutputStream_get_CanRead_mCA32F79CCF594EF3EB58B7F2C696E729535EBD9A,
	ParallelDeflateOutputStream_get_CanWrite_mAD779F56A239D94344618D982D0D6F3069A6FA63,
	ParallelDeflateOutputStream_get_Length_m6117775A9864B01769CB8A672E68BD63EA800C6B,
	ParallelDeflateOutputStream_get_Position_mD69F8A38F0588E2A4D2A6699D7FC71055C74DDC8,
	ParallelDeflateOutputStream_set_Position_m04BCDB79F1953130820C34128FE40B3C83C4BED2,
	ParallelDeflateOutputStream_Read_m72977CD5DBB3CAA51771DB5BB638FCC381DE7366,
	ParallelDeflateOutputStream_Seek_m9E6E476D9974B398F04D36F46C817338179398E1,
	ParallelDeflateOutputStream_SetLength_mA984F3E4617685A2794C37EB1E0472E9AB1FAAD7,
	ParallelDeflateOutputStream__cctor_m5FAA66A8DAE4B0AE99BDE8DB5946AFD048E83A0B,
	Tree_DistanceCode_m06F87C001CF0FAF7ED49003FBEE47562E607B39F,
	Tree_gen_bitlen_mCC71BCD509A61D07F941EB86A9A075A889B60771,
	Tree_build_tree_mAEE538DA0D5EED419717CACF229B2D0E35060CDF,
	Tree_gen_codes_mDEC80E66B5FA7690A2A32357A9D19C3B8E35944D,
	Tree_bi_reverse_mA9C60E73353A2B344E0694C607D17682FA786FF9,
	Tree__ctor_m8E621E185B9BCE2BB6D047D590C12191A7CB958E,
	Tree__cctor_m20513C9268E561B565EED07A55622EAE33156032,
	ZlibException__ctor_m9FE554ECDEC43FD140C35A6F9C78A93A47AE3350,
	SharedUtils_URShift_m0482D2C4CDA787119DA7305843F3F0CA6F5997E5,
	InternalConstants__cctor_m6F7987484D109F716A8DA1D9B1BBB39C7B818B05,
	StaticTree__ctor_mAE9DE8E891ED7E618C9D5CB3F7975AC0ADACBE63,
	StaticTree__cctor_m09C0EC75C160555983A95C222379D122F38D46D6,
	Adler_Adler32_m947780F20CB573583D7638E892490EA9ADAD7375,
	Adler__cctor_m9B56D29B6DCB878488C01D8F0B61B699E1E1AB30,
	ZlibBaseStream__ctor_m473F51C96FFF5488FB504F4F17912A932CAB30DF,
	ZlibBaseStream_get__wantCompress_mC2244093FB3C970FF3866F695F07C4549ACD3E8D,
	ZlibBaseStream_get_z_m65B6F59B0C7BD6028E377FF0378C44E696665EE7,
	ZlibBaseStream_get_workingBuffer_mFD7482A91E26AD2DB3EFF93129FE67CDBECEBE0B,
	ZlibBaseStream_Write_m18B6467CBD0555A50EF7376C9983D2CC9EDDCCCB,
	ZlibBaseStream_finish_m5EFCDFBB8635255492C8769E0EF3BADA483856A4,
	ZlibBaseStream_end_m3FD7DE7CE07E34A574985CE1FD6C1CCA9B533434,
	ZlibBaseStream_Close_m2F14725EE6E24AF3BD89F6ADC757065F1E20BE8E,
	ZlibBaseStream_Flush_m62F96160EE8AC94CD1BC9A9FA4195CFF54782999,
	ZlibBaseStream_Seek_m9E64D7F8CB93A687B6243482B990BB9912F4C22F,
	ZlibBaseStream_SetLength_mC991E6EF1DF425D06BF93D55F0818984B6AE07EA,
	ZlibBaseStream_ReadZeroTerminatedString_m38106BA5D9FCAA697A2978CEF98B09D1A74CBD07,
	ZlibBaseStream__ReadAndValidateGzipHeader_mB9F06457369A9D52B00E2E40DDB55DBB7E60A8E3,
	ZlibBaseStream_Read_m493B5ADF22D628DCF2CBC711BABF759B0BA9CE36,
	ZlibBaseStream_get_CanRead_mA16C880B5C83CF7B4DD616C4EF05D10CF23364EE,
	ZlibBaseStream_get_CanSeek_mE860B962F6513FA5661FB447640697AB339DBCCD,
	ZlibBaseStream_get_CanWrite_m23ACD1627EB5171B3DC028D41B2265EBB5AE1F83,
	ZlibBaseStream_get_Length_m3282FE1F6934B5E3BC01FD27F870BDCD52981178,
	ZlibBaseStream_get_Position_mFC09E906DCEEE606216D8D4DA85ED8BEC1EA6CF5,
	ZlibBaseStream_set_Position_m240A06F95FA8443B0E744BF9881B0D8165D37A82,
	ZlibCodec__ctor_m0718287035AA71815837591F65FF7C951F5F4DB4,
	ZlibCodec_InitializeInflate_mB1FA0B26D37EEB00E29428A3996AD74D32E432F4,
	ZlibCodec_InitializeInflate_m0303067E504917DDE66930E1C301677F7EEDD758,
	ZlibCodec_Inflate_mB221058BC92D4A95CBB27322CB337A94CCD5CEA1,
	ZlibCodec_EndInflate_mA4A36AE96F6D466469F7122C5380BB19BE74646D,
	ZlibCodec_InitializeDeflate_m729D8104F6BD0D51CD6D00F1A9F2B08FD79F2A1A,
	ZlibCodec__InternalInitializeDeflate_m57D3371F48C6B3E608FA6F865C3E20EA64C4751B,
	ZlibCodec_Deflate_m46CCA2A0844A185891FF67BEF783130D614776C7,
	ZlibCodec_EndDeflate_m60C1C8B560560FC994F35F7BCDA41D9D07BDACEE,
	ZlibCodec_ResetDeflate_m3C5D1A0CDA778011C0EA720C7D7AE7E74F56BB90,
	ZlibCodec_flush_pending_m7280670338BAB991E9A6664E99DBE25D101BC486,
	ZlibCodec_read_buf_m5841F0EB4E6823028ADF7C126315C9CCD7D7ED8E,
	CRC32_get_TotalBytesRead_mCE5485999DE49DBB25751117A6633AEC01C1B76F,
	CRC32_get_Crc32Result_m3414F3DC7FA048EE9EE934E6302B7CD7CE4DD16F,
	CRC32_GetCrc32_m0C4F7501E77C727B7C533C31C0257370DCE6DC6F,
	CRC32_GetCrc32AndCopy_mEDD977C21D00296019953B1A482552068590654E,
	CRC32_ComputeCrc32_m120F6B0AD46EC92A2D1C579EC9D252AED427515F,
	CRC32__InternalComputeCrc32_m705391AF4E6DF3F3D0BF2878653794DFDCCCF2AE,
	CRC32_SlurpBlock_m6E04B167CAEBF451DD9888598C039A8784D20026,
	CRC32_UpdateCRC_mB0956C9175240EC27355097E030D4F26D39E80C4,
	CRC32_UpdateCRC_mDD142F29A46720BC9D7B260BFB89B4D87C1D6C75,
	CRC32_ReverseBits_m993847E8C60E50B8A615B72FAEA220FDB4CF83AC,
	CRC32_ReverseBits_mD9629CBB759884993C1DBDB412C6149DFBDFB8A3,
	CRC32_GenerateLookupTable_m28A5BD23480B63629FCFCCC328EDC3C159588E3E,
	CRC32_gf2_matrix_times_mA3E565E89504C6675621BD4C736FA59F28CA85D3,
	CRC32_gf2_matrix_square_m7CDE486A0712FB3FD207E4CD790C504F73F91D7C,
	CRC32_Combine_m24482D5EC824A642B6AC44D94118D948FD797C8C,
	CRC32__ctor_m08C46EBBE184F2D28A22B17418AA34195C039AAB,
	CRC32__ctor_m4B43E4FA3D15DD0B9AD5EA1B2DA3A44CAB998596,
	CRC32__ctor_m0DDD4836F8593CB29059C0036D9C2F0AB6E2D68E,
	CRC32_Reset_m625CD52712D35477B9C364EAB71F0A2E213E373A,
	CrcCalculatorStream__ctor_mC70A833A26464858289A61B575C30250B590DBAA,
	CrcCalculatorStream__ctor_m34C2935207C76CAF1D4EE3B9FFB7CE48BFF2D143,
	CrcCalculatorStream__ctor_m241DA2C21BB810DA26A6071A5A94EF9B1E41FB0A,
	CrcCalculatorStream__ctor_mC93C5CA32CF5B77FFAB9883DA5FBC9E8042E7FF0,
	CrcCalculatorStream_get_TotalBytesSlurped_m03D6F7B0DD5A8ADC19171DAE6AA150E6908B140A,
	CrcCalculatorStream_get_Crc_mD3ACB9E50C411928F1C39187F4FF9517B9F6D4F5,
	CrcCalculatorStream_Read_mD43A97825AA2F78E4E4E87A2F52258018A0458CB,
	CrcCalculatorStream_Write_m5710BDD2BD09D2CFA709A087B007D2C58170AF35,
	CrcCalculatorStream_get_CanRead_m13C8434CFA76E2F06CB7DC69BB5DADC4F1017F39,
	CrcCalculatorStream_get_CanSeek_mD042303467188CCDBD93F41014AE8260956E30D0,
	CrcCalculatorStream_get_CanWrite_mE5DD7610D2C0DCE98B67FA423B0B1CD35F691FA2,
	CrcCalculatorStream_Flush_mD2C630AC66394DB2A0D98B8B64C98E4C831DE029,
	CrcCalculatorStream_get_Length_m46CD5AFA6CC157CA551FD693611CFB60E2DD82B4,
	CrcCalculatorStream_get_Position_mA9DB434B0B622C74DEA5B5B3F3E2CB63CA7B08D7,
	CrcCalculatorStream_set_Position_m7BA832B15D1249618D4331AD02082402AD4C07B7,
	CrcCalculatorStream_Seek_m6D58DDDFBEDDD327EF9FC274E4C05A616DB0AAD9,
	CrcCalculatorStream_SetLength_mC1FC04AFFEA7559B27C92605812632512CDBA79B,
	CrcCalculatorStream_System_IDisposable_Dispose_m18FB18113D14694C7A539A64A844AE5F8B7952D3,
	CrcCalculatorStream_Close_mD2F75686BE984E6FCC7D3A944D70B9733F44D9D4,
	CrcCalculatorStream__cctor_m106295F1C274972A86693CC6C2DC857F5C5C83F2,
};
static const int32_t s_InvokerIndices[784] = 
{
	2570,
	2572,
	2570,
	3839,
	2570,
	2572,
	2570,
	1897,
	5150,
	2568,
	4234,
	4252,
	4967,
	4234,
	4252,
	4235,
	4235,
	2568,
	7136,
	6583,
	7686,
	6139,
	7686,
	2568,
	6583,
	536,
	2568,
	6139,
	7686,
	7686,
	281,
	2568,
	5150,
	6584,
	6584,
	6584,
	7139,
	7139,
	6139,
	5150,
	6584,
	5150,
	4252,
	2572,
	5150,
	4252,
	4252,
	4252,
	4252,
	2572,
	7624,
	7686,
	7686,
	7139,
	7686,
	7686,
	7139,
	7604,
	7604,
	7604,
	7064,
	7086,
	7528,
	7595,
	6764,
	8018,
	7119,
	5703,
	8046,
	4252,
	5021,
	5021,
	4235,
	1249,
	1512,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	5021,
	4235,
	2022,
	4235,
	2568,
	7136,
	6579,
	5040,
	5040,
	5020,
	5020,
	4252,
	5150,
	5040,
	5040,
	4252,
	1079,
	1531,
	1512,
	2568,
	1512,
	5150,
	1249,
	1512,
	1249,
	5040,
	1512,
	5150,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	2022,
	4235,
	5150,
	7686,
	7139,
	4967,
	2069,
	2069,
	4252,
	4181,
	1531,
	1249,
	1512,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	2022,
	4235,
	4967,
	5150,
	7139,
	7493,
	5150,
	4984,
	5020,
	1426,
	4181,
	4181,
	5040,
	5040,
	5019,
	5040,
	4887,
	5020,
	4234,
	5020,
	4234,
	5021,
	5021,
	4989,
	4967,
	5020,
	4234,
	4252,
	5020,
	4234,
	5020,
	4234,
	4967,
	5040,
	4252,
	5040,
	4252,
	5020,
	4234,
	7139,
	7139,
	6127,
	5150,
	4181,
	5040,
	5040,
	5150,
	7600,
	7600,
	5021,
	5020,
	4252,
	4252,
	2568,
	3839,
	2541,
	4252,
	4252,
	4252,
	7914,
	2572,
	1533,
	4234,
	1897,
	4234,
	3640,
	3839,
	3839,
	2558,
	5040,
	5040,
	5150,
	5150,
	4252,
	1182,
	6927,
	7064,
	7493,
	7129,
	7914,
	7914,
	6489,
	1895,
	1896,
	768,
	768,
	768,
	768,
	768,
	4252,
	3826,
	5040,
	5040,
	4967,
	4234,
	2568,
	5020,
	5150,
	4252,
	2541,
	4252,
	3789,
	575,
	4252,
	5150,
	300,
	2070,
	3839,
	4252,
	4252,
	5150,
	5150,
	4252,
	4252,
	4252,
	4252,
	8046,
	7686,
	8046,
	2071,
	3839,
	4252,
	2071,
	2071,
	2572,
	4967,
	4967,
	4181,
	5020,
	5020,
	4967,
	5020,
	5040,
	5020,
	4234,
	5020,
	5040,
	4252,
	4967,
	3146,
	4967,
	5020,
	4234,
	5040,
	4252,
	5020,
	4234,
	8018,
	5040,
	5040,
	5020,
	4234,
	5020,
	5020,
	5040,
	5020,
	4235,
	5021,
	5020,
	5040,
	5150,
	3849,
	4181,
	4252,
	5150,
	5150,
	2572,
	3839,
	5040,
	5040,
	5040,
	5020,
	4252,
	4252,
	5150,
	4181,
	5040,
	5040,
	5040,
	1181,
	1471,
	4234,
	5150,
	5150,
	5150,
	5150,
	4252,
	2177,
	5021,
	986,
	1181,
	1183,
	1693,
	4252,
	4252,
	4252,
	1693,
	2568,
	2558,
	7686,
	6143,
	7914,
	7914,
	7865,
	7914,
	7914,
	7914,
	7914,
	4252,
	5150,
	7914,
	5150,
	5150,
	4252,
	5040,
	5040,
	8046,
	5150,
	4967,
	5040,
	5150,
	5150,
	5040,
	4234,
	5150,
	5441,
	7139,
	5473,
	6104,
	7604,
	5020,
	5150,
	5040,
	1249,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	5150,
	1512,
	2022,
	4235,
	5020,
	5020,
	5020,
	5040,
	5020,
	8018,
	5021,
	5020,
	5040,
	1512,
	4181,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	5150,
	1249,
	2022,
	4235,
	4252,
	5040,
	5040,
	5040,
	5020,
	5020,
	5040,
	4252,
	5021,
	5020,
	5020,
	5020,
	5020,
	5040,
	5040,
	5020,
	5040,
	5150,
	6596,
	7136,
	7145,
	4967,
	4181,
	5137,
	4338,
	5040,
	5040,
	3849,
	3973,
	5040,
	5150,
	1249,
	4338,
	1512,
	2028,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	2022,
	4235,
	4181,
	4252,
	4967,
	5020,
	5020,
	5150,
	2453,
	4181,
	4338,
	5150,
	5150,
	2568,
	5150,
	5137,
	4338,
	1249,
	3586,
	3074,
	5150,
	5150,
	5150,
	5150,
	627,
	6274,
	6367,
	1052,
	5150,
	5844,
	5150,
	2372,
	5847,
	1876,
	2372,
	2372,
	5150,
	2372,
	2372,
	4234,
	5150,
	8046,
	4234,
	2558,
	1249,
	5150,
	5020,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	2022,
	4235,
	1512,
	4181,
	5150,
	2618,
	5150,
	5150,
	5150,
	5150,
	3624,
	4967,
	5136,
	5137,
	5410,
	5150,
	2372,
	5150,
	3624,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	4234,
	3836,
	0,
	8046,
	2558,
	1507,
	5150,
	5150,
	5150,
	5150,
	5150,
	1512,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	2022,
	4235,
	1249,
	5040,
	4252,
	2372,
	2558,
	1507,
	5150,
	5020,
	4234,
	5150,
	4181,
	5150,
	5150,
	5150,
	1512,
	2175,
	4252,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	2022,
	4235,
	1249,
	8046,
	7600,
	8046,
	5150,
	5150,
	5150,
	5150,
	2568,
	5908,
	2568,
	5020,
	1464,
	2568,
	1512,
	2388,
	2372,
	5150,
	1662,
	2572,
	5150,
	5150,
	5150,
	1461,
	4181,
	3624,
	1461,
	1461,
	5150,
	3624,
	3624,
	3624,
	4967,
	4181,
	771,
	389,
	5150,
	5150,
	3624,
	8046,
	2570,
	3624,
	511,
	7683,
	8046,
	1507,
	1051,
	4234,
	4234,
	4181,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	1249,
	2022,
	4235,
	1512,
	5040,
	4252,
	5040,
	4252,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	1249,
	2022,
	4235,
	1512,
	5020,
	8046,
	1531,
	5137,
	3624,
	5150,
	3624,
	8046,
	8046,
	5150,
	275,
	1896,
	87,
	4967,
	4181,
	5020,
	5020,
	1896,
	3624,
	8046,
	6,
	460,
	41,
	5704,
	4234,
	5150,
	8046,
	991,
	1051,
	5020,
	4234,
	4234,
	4234,
	5150,
	1512,
	5150,
	4181,
	5150,
	5150,
	5150,
	4181,
	4252,
	2175,
	4252,
	3146,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	1249,
	2022,
	4235,
	8046,
	7600,
	4252,
	4252,
	6779,
	7051,
	5150,
	8046,
	4252,
	7051,
	8046,
	562,
	8046,
	6203,
	8046,
	543,
	4967,
	5040,
	5040,
	1512,
	5150,
	5150,
	5150,
	5150,
	2022,
	4235,
	5040,
	5020,
	1249,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	5150,
	3586,
	1874,
	3624,
	5020,
	1874,
	3586,
	3624,
	5020,
	5150,
	5150,
	1249,
	5021,
	5020,
	3640,
	1897,
	1874,
	1952,
	1512,
	4181,
	2176,
	7869,
	7488,
	5150,
	2115,
	2572,
	2372,
	5150,
	4181,
	2334,
	5150,
	4252,
	2558,
	2569,
	976,
	5021,
	5020,
	1249,
	1512,
	4967,
	4967,
	4967,
	5150,
	5021,
	5021,
	4235,
	2022,
	4235,
	5150,
	5150,
	8046,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x0600020E, { 0, 2 } },
};
extern const uint32_t g_rgctx_TU5BU5DU5BU5D_t58A21C8A5F5F23F18FFDD7E8F6675CEA610C82C1;
extern const uint32_t g_rgctx_TU5BU5D_tCE00D461F82362B446EC3AB8EA4B0D5229225916;
static const Il2CppRGCTXDefinition s_rgctxValues[2] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5DU5BU5D_t58A21C8A5F5F23F18FFDD7E8F6675CEA610C82C1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tCE00D461F82362B446EC3AB8EA4B0D5229225916 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Ionic_Zip_Unity_CodeGenModule;
const Il2CppCodeGenModule g_Ionic_Zip_Unity_CodeGenModule = 
{
	"Ionic.Zip.Unity.dll",
	784,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	2,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
