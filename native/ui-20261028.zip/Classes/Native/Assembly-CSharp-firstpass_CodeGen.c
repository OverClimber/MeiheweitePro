﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void MeshExtrusion::ExtrudeMesh(UnityEngine.Mesh,UnityEngine.Mesh,UnityEngine.Matrix4x4[],System.Boolean)
extern void MeshExtrusion_ExtrudeMesh_m87433CED8E205FCE7A5647D594CC23979F30A115 (void);
// 0x00000002 System.Void MeshExtrusion::ExtrudeMesh(UnityEngine.Mesh,UnityEngine.Mesh,UnityEngine.Matrix4x4[],MeshExtrusion/Edge[],System.Boolean)
extern void MeshExtrusion_ExtrudeMesh_mF89AD0571E67F78A6264492E80C17E1748302005 (void);
// 0x00000003 MeshExtrusion/Edge[] MeshExtrusion::BuildManifoldEdges(UnityEngine.Mesh)
extern void MeshExtrusion_BuildManifoldEdges_m3655914CA59A1FC412956017511CBA80C0B30A95 (void);
// 0x00000004 MeshExtrusion/Edge[] MeshExtrusion::BuildEdges(System.Int32,System.Int32[])
extern void MeshExtrusion_BuildEdges_m0D0E827AA1F2E52DFF3F65472C1953D6187EF542 (void);
// 0x00000005 System.Void MeshExtrusion::.ctor()
extern void MeshExtrusion__ctor_m0829220D1D75EACB6E73E100E8A39A4C4C19D99D (void);
// 0x00000006 System.Void MeshExtrusion/Edge::.ctor()
extern void Edge__ctor_m528CF5C16394170E67D3C1AADDB767A46F620A6B (void);
// 0x00000007 UnityEngine.Vector3 SmoothRandom::GetVector3(System.Single)
extern void SmoothRandom_GetVector3_m15000652D189247BF6A3A4FB33251B6128E3F416 (void);
// 0x00000008 System.Single SmoothRandom::Get(System.Single)
extern void SmoothRandom_Get_m4AB58E36640AF24A1D7AB403D659E536B8EEE483 (void);
// 0x00000009 FractalNoise SmoothRandom::Get()
extern void SmoothRandom_Get_mEB0BB8E85E33326F19C843316011EC01C40B2C7A (void);
// 0x0000000A System.Void SmoothRandom::.ctor()
extern void SmoothRandom__ctor_mEF743C35596B66F0A2A0DD3744A68FF9323A0E65 (void);
// 0x0000000B System.Single Perlin::s_curve(System.Single)
extern void Perlin_s_curve_m556DF6067F50F3E59EFE8F0785AC002D76FF3D28 (void);
// 0x0000000C System.Single Perlin::lerp(System.Single,System.Single,System.Single)
extern void Perlin_lerp_mE1B6A29030803E432AD444722DA5A84F5D51E2E4 (void);
// 0x0000000D System.Void Perlin::setup(System.Single,System.Int32&,System.Int32&,System.Single&,System.Single&)
extern void Perlin_setup_m356F938F9EFC729EAF61849090E37DC427C433F9 (void);
// 0x0000000E System.Single Perlin::at2(System.Single,System.Single,System.Single,System.Single)
extern void Perlin_at2_mEF746B1C3BF4BACFA0B4D80BA2D77FAEB4FEBAC9 (void);
// 0x0000000F System.Single Perlin::at3(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void Perlin_at3_mB73855374FFFA3DA08FB71D57A451E7E613DC16D (void);
// 0x00000010 System.Single Perlin::Noise(System.Single)
extern void Perlin_Noise_m3EE22F6CABAEA87036904C24A3A35239FD59810C (void);
// 0x00000011 System.Single Perlin::Noise(System.Single,System.Single)
extern void Perlin_Noise_m6459430D3FCC023DEBABE54F78BB9541B69A3BE7 (void);
// 0x00000012 System.Single Perlin::Noise(System.Single,System.Single,System.Single)
extern void Perlin_Noise_mE78272BA1D89F0CB6823745DEB1000D6BC9339A2 (void);
// 0x00000013 System.Void Perlin::normalize2(System.Single&,System.Single&)
extern void Perlin_normalize2_m110D0ED15A8420645C0C4A989D62FF4482A7E052 (void);
// 0x00000014 System.Void Perlin::normalize3(System.Single&,System.Single&,System.Single&)
extern void Perlin_normalize3_m5AC971BD1747EB99F80F99382A99D43E304D1A8B (void);
// 0x00000015 System.Void Perlin::.ctor()
extern void Perlin__ctor_m3E6D13BD9F5BBBFB8700EEBD4BDFA80EE38D0508 (void);
// 0x00000016 System.Void FractalNoise::.ctor(System.Single,System.Single,System.Single)
extern void FractalNoise__ctor_mEC8CF46DA7530710D5A54C9AB405A2DD5CB567EC (void);
// 0x00000017 System.Void FractalNoise::.ctor(System.Single,System.Single,System.Single,Perlin)
extern void FractalNoise__ctor_m6404B47A8B3C8D0A0AFAB262AE09400845E62EA0 (void);
// 0x00000018 System.Single FractalNoise::HybridMultifractal(System.Single,System.Single,System.Single)
extern void FractalNoise_HybridMultifractal_m27739972BF39CDF4A7CA78A8A78834FBF506857E (void);
// 0x00000019 System.Single FractalNoise::RidgedMultifractal(System.Single,System.Single,System.Single,System.Single)
extern void FractalNoise_RidgedMultifractal_mA0BC0309D73044A6880C6107E49316034778CECC (void);
// 0x0000001A System.Single FractalNoise::BrownianMotion(System.Single,System.Single)
extern void FractalNoise_BrownianMotion_m979FE44AFDBEE881153C0A0C21FB05ADB71755AF (void);
// 0x0000001B DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleAudio::DOFade(UnityEngine.AudioSource,System.Single,System.Single)
extern void DOTweenModuleAudio_DOFade_m1D693C3CE476AABDF1973BE1CDB974276D71307A (void);
// 0x0000001C DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleAudio::DOPitch(UnityEngine.AudioSource,System.Single,System.Single)
extern void DOTweenModuleAudio_DOPitch_m21C03AF57AD7EEC7C1CF82CA7F660A58BD17D7CF (void);
// 0x0000001D DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleAudio::DOSetFloat(UnityEngine.Audio.AudioMixer,System.String,System.Single,System.Single)
extern void DOTweenModuleAudio_DOSetFloat_m95C5B73E2208425BB0D225DBBE705A62C34ADB8B (void);
// 0x0000001E System.Int32 DG.Tweening.DOTweenModuleAudio::DOComplete(UnityEngine.Audio.AudioMixer,System.Boolean)
extern void DOTweenModuleAudio_DOComplete_mB34A0C4B5156B4D5D7F88E1F1B3549F0ED35048C (void);
// 0x0000001F System.Int32 DG.Tweening.DOTweenModuleAudio::DOKill(UnityEngine.Audio.AudioMixer,System.Boolean)
extern void DOTweenModuleAudio_DOKill_mAF9948DBD5491192943527B5FD65561EB5E6DA23 (void);
// 0x00000020 System.Int32 DG.Tweening.DOTweenModuleAudio::DOFlip(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOFlip_mA5DAA9E654CBF4C302F7376463DC80EF9FE480B0 (void);
// 0x00000021 System.Int32 DG.Tweening.DOTweenModuleAudio::DOGoto(UnityEngine.Audio.AudioMixer,System.Single,System.Boolean)
extern void DOTweenModuleAudio_DOGoto_m0E560369CDA932ED0068A0CED7D733FE203E43E1 (void);
// 0x00000022 System.Int32 DG.Tweening.DOTweenModuleAudio::DOPause(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOPause_mDC395F8C1B08A113E79E42FAB5EE1EF453B1136D (void);
// 0x00000023 System.Int32 DG.Tweening.DOTweenModuleAudio::DOPlay(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOPlay_m86F982951B3B2786390449AFE30BAEFBDC7E92D7 (void);
// 0x00000024 System.Int32 DG.Tweening.DOTweenModuleAudio::DOPlayBackwards(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOPlayBackwards_mD371D3D6C3D85A6CE99B597BB0305D9E6EDD87F4 (void);
// 0x00000025 System.Int32 DG.Tweening.DOTweenModuleAudio::DOPlayForward(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOPlayForward_m561924708D16379FF482E79B5710AB2FB5B1E9FB (void);
// 0x00000026 System.Int32 DG.Tweening.DOTweenModuleAudio::DORestart(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DORestart_m0B4E5FF932DACDE8A3B1C85BE6B5A8FCB12AC0F0 (void);
// 0x00000027 System.Int32 DG.Tweening.DOTweenModuleAudio::DORewind(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DORewind_m20E78D2E878D7E35D859B4789DBDC2DF968B06E3 (void);
// 0x00000028 System.Int32 DG.Tweening.DOTweenModuleAudio::DOSmoothRewind(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOSmoothRewind_m775A16C85A17C3471062578BCC5A45683A67AC5A (void);
// 0x00000029 System.Int32 DG.Tweening.DOTweenModuleAudio::DOTogglePause(UnityEngine.Audio.AudioMixer)
extern void DOTweenModuleAudio_DOTogglePause_m23CC6F5387C5060B72E4000C5F4A61B944A5F971 (void);
// 0x0000002A System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m3791FA75A8CE2C48268B7EFD94EA4A3765266D67 (void);
// 0x0000002B System.Single DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass0_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__0_m8143CFDDC70BD69C48E4BBBDF5BD596D88C518F9 (void);
// 0x0000002C System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass0_0::<DOFade>b__1(System.Single)
extern void U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__1_m5E5FBB05013DE3D53572D7BA16CC7C54A0F2D0FC (void);
// 0x0000002D System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m7F6CF474218CDB04F1779336A4121CB4413DBA05 (void);
// 0x0000002E System.Single DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOPitchU3Eb__0_m0E574CBA7B1412BA78918BD8457649F22458B1FD (void);
// 0x0000002F System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1(System.Single)
extern void U3CU3Ec__DisplayClass1_0_U3CDOPitchU3Eb__1_m64853930D881A088A3DC9B899622925943A4BC13 (void);
// 0x00000030 System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m0137DE0DC632BA91C3E6EF826AF8E333F0293D90 (void);
// 0x00000031 System.Single DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CDOSetFloatU3Eb__0_m638EF4CAE8BAF409B36498CC75BE2EECB4E327C7 (void);
// 0x00000032 System.Void DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1(System.Single)
extern void U3CU3Ec__DisplayClass2_0_U3CDOSetFloatU3Eb__1_mD0BF393888DDC1CA4DB4E8035A4033B1FC5F3563 (void);
// 0x00000033 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics::DOMove(UnityEngine.Rigidbody,UnityEngine.Vector3,System.Single,System.Boolean)
extern void DOTweenModulePhysics_DOMove_m5B66A39F2C06E19EDFA4D9D79B8CEDD1B2C1AE9C (void);
// 0x00000034 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics::DOMoveX(UnityEngine.Rigidbody,System.Single,System.Single,System.Boolean)
extern void DOTweenModulePhysics_DOMoveX_mAE96C9DA1E0C5EC23A773965A91B86C987BAEAAB (void);
// 0x00000035 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics::DOMoveY(UnityEngine.Rigidbody,System.Single,System.Single,System.Boolean)
extern void DOTweenModulePhysics_DOMoveY_mE4DCBAC03F31FBF07EDFB15A55E2822256EAE03A (void);
// 0x00000036 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics::DOMoveZ(UnityEngine.Rigidbody,System.Single,System.Single,System.Boolean)
extern void DOTweenModulePhysics_DOMoveZ_m5915FC138CB7BBFFCEF34456590EF4670B1893CE (void);
// 0x00000037 DG.Tweening.Core.TweenerCore`3<UnityEngine.Quaternion,UnityEngine.Vector3,DG.Tweening.Plugins.Options.QuaternionOptions> DG.Tweening.DOTweenModulePhysics::DORotate(UnityEngine.Rigidbody,UnityEngine.Vector3,System.Single,DG.Tweening.RotateMode)
extern void DOTweenModulePhysics_DORotate_m65EA16E432A1B477A5A696EF95257FE812C948D6 (void);
// 0x00000038 DG.Tweening.Core.TweenerCore`3<UnityEngine.Quaternion,UnityEngine.Vector3,DG.Tweening.Plugins.Options.QuaternionOptions> DG.Tweening.DOTweenModulePhysics::DOLookAt(UnityEngine.Rigidbody,UnityEngine.Vector3,System.Single,DG.Tweening.AxisConstraint,System.Nullable`1<UnityEngine.Vector3>)
extern void DOTweenModulePhysics_DOLookAt_m86BB568C280583D5140AF00ACDB6102191ECD98D (void);
// 0x00000039 DG.Tweening.Sequence DG.Tweening.DOTweenModulePhysics::DOJump(UnityEngine.Rigidbody,UnityEngine.Vector3,System.Single,System.Int32,System.Single,System.Boolean)
extern void DOTweenModulePhysics_DOJump_m66B1A29F77189B9981097A35A69E00974F0ACA65 (void);
// 0x0000003A DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics::DOPath(UnityEngine.Rigidbody,UnityEngine.Vector3[],System.Single,DG.Tweening.PathType,DG.Tweening.PathMode,System.Int32,System.Nullable`1<UnityEngine.Color>)
extern void DOTweenModulePhysics_DOPath_m1443BEE665EB5D1A4EF2C356BE311406251657D4 (void);
// 0x0000003B DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics::DOLocalPath(UnityEngine.Rigidbody,UnityEngine.Vector3[],System.Single,DG.Tweening.PathType,DG.Tweening.PathMode,System.Int32,System.Nullable`1<UnityEngine.Color>)
extern void DOTweenModulePhysics_DOLocalPath_m16C97084468DB6E53825EEED8132F80E127EF0FA (void);
// 0x0000003C DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics::DOPath(UnityEngine.Rigidbody,DG.Tweening.Plugins.Core.PathCore.Path,System.Single,DG.Tweening.PathMode)
extern void DOTweenModulePhysics_DOPath_mF43CCB4AF2A13F42ED05CE2E666422CA4065F328 (void);
// 0x0000003D DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics::DOLocalPath(UnityEngine.Rigidbody,DG.Tweening.Plugins.Core.PathCore.Path,System.Single,DG.Tweening.PathMode)
extern void DOTweenModulePhysics_DOLocalPath_mCB4C763749BBB71E0B4ECB3EA7C9C43B9EAA45FF (void);
// 0x0000003E System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m0BEB792A0FE19EAA31D6B34FD5B01D116B6982E8 (void);
// 0x0000003F UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0::<DOMove>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CDOMoveU3Eb__0_m6E0B04D7869F5FF54EA1C743AC07762BE15C450F (void);
// 0x00000040 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m82174D8C8C82955F6E9E1D59B330645364022DD0 (void);
// 0x00000041 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass1_0::<DOMoveX>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOMoveXU3Eb__0_m44B6924634D19688FB006D483138E93595291D10 (void);
// 0x00000042 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m95E3ADCB89ABFACB7D1E91DA4A1CDF392DC794E6 (void);
// 0x00000043 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::<DOMoveY>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CDOMoveYU3Eb__0_m6BFE21962DA4F6AD341BB59633EDCE28B6E45B67 (void);
// 0x00000044 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m5EFD6FE639198BF1AD1E9FA475731D194EFE073B (void);
// 0x00000045 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass3_0::<DOMoveZ>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CDOMoveZU3Eb__0_mB670881A3259C5E5997D07DA4A1DDD3EDE75063B (void);
// 0x00000046 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_m0C905B754B9A6187494F408107EE861B650A5DF7 (void);
// 0x00000047 UnityEngine.Quaternion DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass4_0::<DORotate>b__0()
extern void U3CU3Ec__DisplayClass4_0_U3CDORotateU3Eb__0_m1F121B516FF4A3B19D60370CAF7215037FC55AFE (void);
// 0x00000048 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m5454D12FFC74B0B715588F08E4DA72D94E47D69A (void);
// 0x00000049 UnityEngine.Quaternion DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0::<DOLookAt>b__0()
extern void U3CU3Ec__DisplayClass5_0_U3CDOLookAtU3Eb__0_m23D8CC0E9DB5CE2D88199B4DDE0CAD4AD1B2BC5E (void);
// 0x0000004A System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m0D378F1E0358380DA1CD247F90674C29D9954E0E (void);
// 0x0000004B UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::<DOJump>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__0_m41ECCE19967CB8FF9557E9EFC068AB9199CF160D (void);
// 0x0000004C System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::<DOJump>b__1()
extern void U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__1_mF4A2E742B3B0550F2D22177E36FB64F1298BE508 (void);
// 0x0000004D UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::<DOJump>b__2()
extern void U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__2_m9DB85188D8D2D2AB9C1656C58A65639CFB20CCAA (void);
// 0x0000004E UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::<DOJump>b__3()
extern void U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__3_m20C802577C48BC4FEEC502F10698D6E33014CF3D (void);
// 0x0000004F System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass6_0::<DOJump>b__4()
extern void U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__4_m8F3D5C990949F26E7B0CCCC3E56815037389E63C (void);
// 0x00000050 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_mC0EAAE8F4A19AAD8FD1BE8F1E1F982463877988F (void);
// 0x00000051 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass7_0::<DOPath>b__0()
extern void U3CU3Ec__DisplayClass7_0_U3CDOPathU3Eb__0_m7C61A8F92F87D76AE9C46EBFDE4A761BD36EEC9D (void);
// 0x00000052 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_mA253330E57ECE63BD9DA2F36F950A44B8D19F75D (void);
// 0x00000053 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass8_0::<DOLocalPath>b__0()
extern void U3CU3Ec__DisplayClass8_0_U3CDOLocalPathU3Eb__0_m5C5018BD3AB3DEFE56DB1B58F78D8E8B4AE5AC20 (void);
// 0x00000054 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass8_0::<DOLocalPath>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass8_0_U3CDOLocalPathU3Eb__1_m209F28992EB1879A4349497D0672A7C2749EC393 (void);
// 0x00000055 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_mE8C66DFD146B85189C06E2392A7CEDA18580DFF1 (void);
// 0x00000056 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass9_0::<DOPath>b__0()
extern void U3CU3Ec__DisplayClass9_0_U3CDOPathU3Eb__0_m780F14A754BC9CD461B328E1D201CCBA31236A3E (void);
// 0x00000057 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_m03E61F264547D93763B90C045BE06D44AAA239DF (void);
// 0x00000058 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass10_0::<DOLocalPath>b__0()
extern void U3CU3Ec__DisplayClass10_0_U3CDOLocalPathU3Eb__0_m7055847965DE725A80D146EAEB0434DF0D185D01 (void);
// 0x00000059 System.Void DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass10_0::<DOLocalPath>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass10_0_U3CDOLocalPathU3Eb__1_m3744C63CE1A944BF7209BD755A38A3EF757E32C7 (void);
// 0x0000005A DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics2D::DOMove(UnityEngine.Rigidbody2D,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModulePhysics2D_DOMove_m6A74D57E65B6F8E119164B18F17D3ED7BB8B6B44 (void);
// 0x0000005B DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics2D::DOMoveX(UnityEngine.Rigidbody2D,System.Single,System.Single,System.Boolean)
extern void DOTweenModulePhysics2D_DOMoveX_m7F9730EFF5DE54338332D74B2364243C211EB7F4 (void);
// 0x0000005C DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModulePhysics2D::DOMoveY(UnityEngine.Rigidbody2D,System.Single,System.Single,System.Boolean)
extern void DOTweenModulePhysics2D_DOMoveY_mA3B4A7F4B174180E22FA9F9CC8852B001460E990 (void);
// 0x0000005D DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModulePhysics2D::DORotate(UnityEngine.Rigidbody2D,System.Single,System.Single)
extern void DOTweenModulePhysics2D_DORotate_m914F5F01CD6972EE0FCBA60FBC4AB340E647DC5E (void);
// 0x0000005E DG.Tweening.Sequence DG.Tweening.DOTweenModulePhysics2D::DOJump(UnityEngine.Rigidbody2D,UnityEngine.Vector2,System.Single,System.Int32,System.Single,System.Boolean)
extern void DOTweenModulePhysics2D_DOJump_m994418231434C0151D7ADEE79A02174D6F4E5B2B (void);
// 0x0000005F DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics2D::DOPath(UnityEngine.Rigidbody2D,UnityEngine.Vector2[],System.Single,DG.Tweening.PathType,DG.Tweening.PathMode,System.Int32,System.Nullable`1<UnityEngine.Color>)
extern void DOTweenModulePhysics2D_DOPath_m0CF606B5F7970A8D1FBC5816ED775CA1736C9D1C (void);
// 0x00000060 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModulePhysics2D::DOLocalPath(UnityEngine.Rigidbody2D,UnityEngine.Vector2[],System.Single,DG.Tweening.PathType,DG.Tweening.PathMode,System.Int32,System.Nullable`1<UnityEngine.Color>)
extern void DOTweenModulePhysics2D_DOLocalPath_mEC1BAA9AEDBCE7F667D52E04746C6E29C7AFAA5B (void);
// 0x00000061 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m6E60A649269716DA67C91FEA9DB5E4838B171FFB (void);
// 0x00000062 UnityEngine.Vector2 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass0_0::<DOMove>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CDOMoveU3Eb__0_m3B437B7A49D2CB3F8665A68251D2037D4D2DFAFB (void);
// 0x00000063 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mAA755EB23D9336AA9EC71EBD7D962163A5D701BB (void);
// 0x00000064 UnityEngine.Vector2 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass1_0::<DOMoveX>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOMoveXU3Eb__0_mDCC3F81EA6919A6758DF902C951C7BE90FD9ED21 (void);
// 0x00000065 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m287F996454332CC75504F22382E84F764A6703E5 (void);
// 0x00000066 UnityEngine.Vector2 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass2_0::<DOMoveY>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CDOMoveYU3Eb__0_m26EFA27B3283A4CDEA74C1C10C2298172D6F3DA7 (void);
// 0x00000067 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m4AB88AEBE4C86B65F1E152630DCC77C868D114EF (void);
// 0x00000068 System.Single DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass3_0::<DORotate>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CDORotateU3Eb__0_mA761FE1B426A6D4F495CF6236077759B83404880 (void);
// 0x00000069 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_mB04F62E995B27D6A6428EC7912C8E28383226888 (void);
// 0x0000006A UnityEngine.Vector2 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__0()
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__0_mC384861F18478CA4920D44A4FF1DBAC168091984 (void);
// 0x0000006B System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__1_m4BE94E6CA4A7343449BF1C380C49969ACEAC3258 (void);
// 0x0000006C System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__2()
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__2_mB0AC03FA3A2D44B6659E6FD460970C0AED148A48 (void);
// 0x0000006D UnityEngine.Vector2 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__3()
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__3_m50157E12B08569073B9B7C226EA7E0FF7AF83BE3 (void);
// 0x0000006E System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__4(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__4_mAB03323C38080C1800DA5545B062D5ADAA39CB73 (void);
// 0x0000006F System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass4_0::<DOJump>b__5()
extern void U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__5_mA4ECC8E0DC621BEC5EA7C6F8B770CCF97FAFFDFB (void);
// 0x00000070 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m7785F019FCF0C76EB1A4663C908429D4552F8864 (void);
// 0x00000071 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass5_0::<DOPath>b__0()
extern void U3CU3Ec__DisplayClass5_0_U3CDOPathU3Eb__0_mC091AB67A43DA9A1DB9DD889184670E586A7F96F (void);
// 0x00000072 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass5_0::<DOPath>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass5_0_U3CDOPathU3Eb__1_m2D47B6559DAF1FA18DC18EE9DD442D9A949533C1 (void);
// 0x00000073 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m08366EEB1AB56732D845835BBA4105463E4F109D (void);
// 0x00000074 UnityEngine.Vector3 DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass6_0::<DOLocalPath>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CDOLocalPathU3Eb__0_m3D8AA6655141216299BC1F1259C20544EEA146C4 (void);
// 0x00000075 System.Void DG.Tweening.DOTweenModulePhysics2D/<>c__DisplayClass6_0::<DOLocalPath>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass6_0_U3CDOLocalPathU3Eb__1_mC71B4D60BA6713F56A7626ECA1C0AC87C640EF16 (void);
// 0x00000076 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleSprite::DOColor(UnityEngine.SpriteRenderer,UnityEngine.Color,System.Single)
extern void DOTweenModuleSprite_DOColor_m6E59DCD8638072DF9AA02645F45A4367CE903FF3 (void);
// 0x00000077 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleSprite::DOFade(UnityEngine.SpriteRenderer,System.Single,System.Single)
extern void DOTweenModuleSprite_DOFade_m6AE51AD4E4655B3A03EE59353450C611725E6D1A (void);
// 0x00000078 DG.Tweening.Sequence DG.Tweening.DOTweenModuleSprite::DOGradientColor(UnityEngine.SpriteRenderer,UnityEngine.Gradient,System.Single)
extern void DOTweenModuleSprite_DOGradientColor_mBDB37BF5C3939448FCEFEB812414F303D7C99C72 (void);
// 0x00000079 DG.Tweening.Tweener DG.Tweening.DOTweenModuleSprite::DOBlendableColor(UnityEngine.SpriteRenderer,UnityEngine.Color,System.Single)
extern void DOTweenModuleSprite_DOBlendableColor_m5570320359C3164713C74486272EC313724DD6F1 (void);
// 0x0000007A System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m270031771548A13843FD1B9701D5D178797EB9AD (void);
// 0x0000007B UnityEngine.Color DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass0_0::<DOColor>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CDOColorU3Eb__0_mA10A642C6F3D0B140227D1D6B5B972CA9624F6B7 (void);
// 0x0000007C System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass0_0::<DOColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass0_0_U3CDOColorU3Eb__1_m31412CE4EE9499BB433AC04B055AB41BD5047A74 (void);
// 0x0000007D System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mDF7123DA26647D6C19E3D8D2131EDB0AFE40446A (void);
// 0x0000007E UnityEngine.Color DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass1_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOFadeU3Eb__0_m34F6B168CAE3EBDE25B3A62A680E3F5387957414 (void);
// 0x0000007F System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass1_0::<DOFade>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass1_0_U3CDOFadeU3Eb__1_m769F0265E8D0A6320E185169D06F8ED38FF6191E (void);
// 0x00000080 System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m6B0AC5DDB17C25A1A2C8F55A84AC2C5986EF8240 (void);
// 0x00000081 UnityEngine.Color DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass3_0::<DOBlendableColor>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CDOBlendableColorU3Eb__0_mD1F5CC03348BACDD68A45FC8BC8D379841EF09D6 (void);
// 0x00000082 System.Void DG.Tweening.DOTweenModuleSprite/<>c__DisplayClass3_0::<DOBlendableColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass3_0_U3CDOBlendableColorU3Eb__1_mF6CA7D8E1F46B4CAC9DC17BE940693728B469EE2 (void);
// 0x00000083 DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleUI::DOFade(UnityEngine.CanvasGroup,System.Single,System.Single)
extern void DOTweenModuleUI_DOFade_mA073F33862AA7BEF33842B8200D0E79E046D114E (void);
// 0x00000084 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOColor(UnityEngine.UI.Graphic,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOColor_m961875592E62912276F701C48C3C3C3DDB4E7341 (void);
// 0x00000085 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOFade(UnityEngine.UI.Graphic,System.Single,System.Single)
extern void DOTweenModuleUI_DOFade_mE2E3C2482CD1D3B81C2F4B0EA4E95CF2CC10CC21 (void);
// 0x00000086 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOColor(UnityEngine.UI.Image,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOColor_m385F3DCBA53A421BC288521879635D67E8155783 (void);
// 0x00000087 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOFade(UnityEngine.UI.Image,System.Single,System.Single)
extern void DOTweenModuleUI_DOFade_mC1C042C14FF418F2BE7B8A6B3B73A2F8D3719EED (void);
// 0x00000088 DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleUI::DOFillAmount(UnityEngine.UI.Image,System.Single,System.Single)
extern void DOTweenModuleUI_DOFillAmount_mF99B81AA5E4A001FD8DEB2C7F6056271802D153D (void);
// 0x00000089 DG.Tweening.Sequence DG.Tweening.DOTweenModuleUI::DOGradientColor(UnityEngine.UI.Image,UnityEngine.Gradient,System.Single)
extern void DOTweenModuleUI_DOGradientColor_mB08E7CC98E98E7A0A8A04DC84CDE434B038CF03E (void);
// 0x0000008A DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOFlexibleSize(UnityEngine.UI.LayoutElement,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOFlexibleSize_m2476B21F9C3D8213723B01A0FA93553D8E45F3B7 (void);
// 0x0000008B DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOMinSize(UnityEngine.UI.LayoutElement,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOMinSize_m2D92E524BAEA78CDA2815597D779B2835EF8CC03 (void);
// 0x0000008C DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOPreferredSize(UnityEngine.UI.LayoutElement,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOPreferredSize_m59E62BDF15A51E4529FC3D920EBC77178DFEDFD8 (void);
// 0x0000008D DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOColor(UnityEngine.UI.Outline,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOColor_mAF1146331160A3A8C7FFA916BFA8B71A8531FCF2 (void);
// 0x0000008E DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOFade(UnityEngine.UI.Outline,System.Single,System.Single)
extern void DOTweenModuleUI_DOFade_mFDEF44F0F048DD606FEF46F539D4F47AF40EF817 (void);
// 0x0000008F DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOScale(UnityEngine.UI.Outline,UnityEngine.Vector2,System.Single)
extern void DOTweenModuleUI_DOScale_mEBEA04E6C90874A4903841D8D2720867B2CA292F (void);
// 0x00000090 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPos(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPos_m5B60876E10960019C209F1C215F921E6F994831A (void);
// 0x00000091 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPosX(UnityEngine.RectTransform,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPosX_m483100309684443A215A8279D4E54B2769DAF3E8 (void);
// 0x00000092 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPosY(UnityEngine.RectTransform,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPosY_mBCFDB7E014D45E6B56588C598C23D4EB111D1395 (void);
// 0x00000093 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPos3D(UnityEngine.RectTransform,UnityEngine.Vector3,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPos3D_mBFA28183F6CBCCD444AF47AA85A0272E8D1CAA48 (void);
// 0x00000094 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPos3DX(UnityEngine.RectTransform,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPos3DX_m6AE58A54659B9562734FB13539AE84FA69C34980 (void);
// 0x00000095 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPos3DY(UnityEngine.RectTransform,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPos3DY_mC051E07149C6D443662E3682338A26D0ADC6591C (void);
// 0x00000096 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,UnityEngine.Vector3,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorPos3DZ(UnityEngine.RectTransform,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorPos3DZ_m334F6667A6103C39B84749DC1EBE6557CCBE91D3 (void);
// 0x00000097 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorMax(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorMax_mA7BFD0284B3A23C3BF4DE76F542F60EAE1CC5368 (void);
// 0x00000098 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOAnchorMin(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOAnchorMin_m7EC8E45746F25D2679DE1267FBD5DEB4CC619057 (void);
// 0x00000099 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOPivot(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single)
extern void DOTweenModuleUI_DOPivot_m3F8012446C42571C9F1549771422917AEC9EEDF8 (void);
// 0x0000009A DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOPivotX(UnityEngine.RectTransform,System.Single,System.Single)
extern void DOTweenModuleUI_DOPivotX_mFD1858E2B5933F093EB84E3D87A69783B04CA7F4 (void);
// 0x0000009B DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOPivotY(UnityEngine.RectTransform,System.Single,System.Single)
extern void DOTweenModuleUI_DOPivotY_m7CA2B8D7162770DC0700106C9ADB97F9A4BD877B (void);
// 0x0000009C DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUI::DOSizeDelta(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOSizeDelta_mC2236310385A8326B78FE900A33586006C8B4474 (void);
// 0x0000009D DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOPunchAnchorPos(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Int32,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOPunchAnchorPos_mCE5DF2A8B462E813FBB84C4DBC5697848D1C2B45 (void);
// 0x0000009E DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOShakeAnchorPos(UnityEngine.RectTransform,System.Single,System.Single,System.Int32,System.Single,System.Boolean,System.Boolean)
extern void DOTweenModuleUI_DOShakeAnchorPos_m5AB3C24FE1C10F8B0ED53ED04FF08E3ED682044B (void);
// 0x0000009F DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOShakeAnchorPos(UnityEngine.RectTransform,System.Single,UnityEngine.Vector2,System.Int32,System.Single,System.Boolean,System.Boolean)
extern void DOTweenModuleUI_DOShakeAnchorPos_m81D0D12B80B4FCA0F14A62E118EC8BCD515BBB35 (void);
// 0x000000A0 DG.Tweening.Sequence DG.Tweening.DOTweenModuleUI::DOJumpAnchorPos(UnityEngine.RectTransform,UnityEngine.Vector2,System.Single,System.Int32,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOJumpAnchorPos_m5629EA273819E9C2EE98068F8793202EC96765F3 (void);
// 0x000000A1 DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DONormalizedPos(UnityEngine.UI.ScrollRect,UnityEngine.Vector2,System.Single,System.Boolean)
extern void DOTweenModuleUI_DONormalizedPos_mABC0EB2280EEC8C8A990E76E16D7BB5DA48A1706 (void);
// 0x000000A2 DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOHorizontalNormalizedPos(UnityEngine.UI.ScrollRect,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOHorizontalNormalizedPos_m41E8A271B7FE392B43523F6B123DCBF26CB0BA74 (void);
// 0x000000A3 DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOVerticalNormalizedPos(UnityEngine.UI.ScrollRect,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOVerticalNormalizedPos_mC141061A07ACD836F365221BA33198FF316BFBA3 (void);
// 0x000000A4 DG.Tweening.Core.TweenerCore`3<System.Single,System.Single,DG.Tweening.Plugins.Options.FloatOptions> DG.Tweening.DOTweenModuleUI::DOValue(UnityEngine.UI.Slider,System.Single,System.Single,System.Boolean)
extern void DOTweenModuleUI_DOValue_m38DB0CB09A73E2DDC33B3EEE49D74944FBA82A38 (void);
// 0x000000A5 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOColor(UnityEngine.UI.Text,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOColor_mAF96B607A774C0B0D912E56C3C11A87E4F093440 (void);
// 0x000000A6 DG.Tweening.Core.TweenerCore`3<System.Int32,System.Int32,DG.Tweening.Plugins.Options.NoOptions> DG.Tweening.DOTweenModuleUI::DOCounter(UnityEngine.UI.Text,System.Int32,System.Int32,System.Single,System.Boolean,System.Globalization.CultureInfo)
extern void DOTweenModuleUI_DOCounter_m85EC79863973B9D9DF9D67E7B5DD835C86BF1438 (void);
// 0x000000A7 DG.Tweening.Core.TweenerCore`3<UnityEngine.Color,UnityEngine.Color,DG.Tweening.Plugins.Options.ColorOptions> DG.Tweening.DOTweenModuleUI::DOFade(UnityEngine.UI.Text,System.Single,System.Single)
extern void DOTweenModuleUI_DOFade_m5AD3262DBFA4B713B61D3F2203B2930562A3B54D (void);
// 0x000000A8 DG.Tweening.Core.TweenerCore`3<System.String,System.String,DG.Tweening.Plugins.Options.StringOptions> DG.Tweening.DOTweenModuleUI::DOText(UnityEngine.UI.Text,System.String,System.Single,System.Boolean,DG.Tweening.ScrambleMode,System.String)
extern void DOTweenModuleUI_DOText_mDE24022401FC6820F90F1BE517FF46F73AE9BC15 (void);
// 0x000000A9 DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOBlendableColor(UnityEngine.UI.Graphic,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOBlendableColor_m69717A08080A14BE5A01F1E8886EBF829CEF7227 (void);
// 0x000000AA DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOBlendableColor(UnityEngine.UI.Image,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOBlendableColor_m9D9F47100CD74C031BBA7ABF9A16E45AC29D2E8F (void);
// 0x000000AB DG.Tweening.Tweener DG.Tweening.DOTweenModuleUI::DOBlendableColor(UnityEngine.UI.Text,UnityEngine.Color,System.Single)
extern void DOTweenModuleUI_DOBlendableColor_m7569CFBAB6EFA6049EECFDBC96898880565C368A (void);
// 0x000000AC UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/Utils::SwitchToRectTransform(UnityEngine.RectTransform,UnityEngine.RectTransform)
extern void Utils_SwitchToRectTransform_m6A264948787CBEE108E0D97B235AE921BFBB6152 (void);
// 0x000000AD System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m7CDF4DE59B75149775AFE16A0C4AB5482BC4C442 (void);
// 0x000000AE System.Single DG.Tweening.DOTweenModuleUI/<>c__DisplayClass0_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__0_m43479452AB6CABC809F8BB075F80A6B391A8AA4B (void);
// 0x000000AF System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass0_0::<DOFade>b__1(System.Single)
extern void U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__1_mB9CCB118057D74D8F6C152B0FA27DE980521FD9A (void);
// 0x000000B0 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m6513901DE6123169BD8642D3EDF9341AD2C78AB9 (void);
// 0x000000B1 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass1_0::<DOColor>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOColorU3Eb__0_m7A0F2549C2C54325EC64A09C154142F9212E4119 (void);
// 0x000000B2 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass1_0::<DOColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass1_0_U3CDOColorU3Eb__1_mFE2DE0E537DD7B1255D9B75969C15549646E6C94 (void);
// 0x000000B3 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_mAC2FAC72E368A0770D2C88F39065B0CD1B860FDC (void);
// 0x000000B4 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass2_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CDOFadeU3Eb__0_m83DABFF83F53843B3210E3663AA658A393F72C21 (void);
// 0x000000B5 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass2_0::<DOFade>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass2_0_U3CDOFadeU3Eb__1_mEBA98F9D99539591FC60AFBE48FD7336309CFE1D (void);
// 0x000000B6 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m6F636F1E7727A97A11CD562DA6C62E44D0CE8D37 (void);
// 0x000000B7 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass3_0::<DOColor>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CDOColorU3Eb__0_m4568743D7735E8597149620347E7C6C1F8F8F573 (void);
// 0x000000B8 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass3_0::<DOColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass3_0_U3CDOColorU3Eb__1_m931C95B84B1BCD2FB3A2D8038972C9570DAB288D (void);
// 0x000000B9 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_m9953E31874A19DF4ACB95C87FCE12660693A6AD5 (void);
// 0x000000BA UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass4_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass4_0_U3CDOFadeU3Eb__0_m45ED3C46917C2BF3FA1E62E5E5FA07933322FC8B (void);
// 0x000000BB System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass4_0::<DOFade>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass4_0_U3CDOFadeU3Eb__1_m1FCDD6D867999371C3AA240FAC66D48DD045C3DC (void);
// 0x000000BC System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m8826744854B3DF452491AF2C9F78CF8CD21E5ADF (void);
// 0x000000BD System.Single DG.Tweening.DOTweenModuleUI/<>c__DisplayClass5_0::<DOFillAmount>b__0()
extern void U3CU3Ec__DisplayClass5_0_U3CDOFillAmountU3Eb__0_mA61D89DB8E1FCE175F34BFC13C1173C788BC70FF (void);
// 0x000000BE System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass5_0::<DOFillAmount>b__1(System.Single)
extern void U3CU3Ec__DisplayClass5_0_U3CDOFillAmountU3Eb__1_mD611009CE94D3EBF2517D0EA25B6858E54C6FBAE (void);
// 0x000000BF System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_mC3A13E5D8A90789E6C1F6A26DFC8C8ED6B5B42DF (void);
// 0x000000C0 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass7_0::<DOFlexibleSize>b__0()
extern void U3CU3Ec__DisplayClass7_0_U3CDOFlexibleSizeU3Eb__0_m3785D78D950D02D749F4640AA0C67FB2CA01DB48 (void);
// 0x000000C1 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass7_0::<DOFlexibleSize>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass7_0_U3CDOFlexibleSizeU3Eb__1_m1E713C41B3EC5ED27907BEFDB2CDCB2D9649D3F0 (void);
// 0x000000C2 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_m12549EFF091117C02D5BD5BBAF860766EFFBD335 (void);
// 0x000000C3 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass8_0::<DOMinSize>b__0()
extern void U3CU3Ec__DisplayClass8_0_U3CDOMinSizeU3Eb__0_mCB197686B19FEE2A3789796C320289EDEBCA59DD (void);
// 0x000000C4 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass8_0::<DOMinSize>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass8_0_U3CDOMinSizeU3Eb__1_m8B8E20DB6700A9E435B4EC30F00578E23B81F319 (void);
// 0x000000C5 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_m638C89DD65FC918306CF707CF4B3EA9CFACAF02E (void);
// 0x000000C6 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass9_0::<DOPreferredSize>b__0()
extern void U3CU3Ec__DisplayClass9_0_U3CDOPreferredSizeU3Eb__0_m1AB892211B71DB2D4E8F21F9BA126944DF9D500C (void);
// 0x000000C7 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass9_0::<DOPreferredSize>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass9_0_U3CDOPreferredSizeU3Eb__1_mBA091FF947DA978F76C73673E1472EB9BEABDCC8 (void);
// 0x000000C8 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_m985D8AA039C4BC8FC17F125005481B94749837C7 (void);
// 0x000000C9 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass10_0::<DOColor>b__0()
extern void U3CU3Ec__DisplayClass10_0_U3CDOColorU3Eb__0_mA4364DFDB200823F9D4FF95D114157C2A424D9DC (void);
// 0x000000CA System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass10_0::<DOColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass10_0_U3CDOColorU3Eb__1_mD28650B7F8BE4B8C96C0AB9DF5BB4B53C443CE41 (void);
// 0x000000CB System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass11_0::.ctor()
extern void U3CU3Ec__DisplayClass11_0__ctor_m69309DF61BEF60177017EDBE3811AA7119806287 (void);
// 0x000000CC UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass11_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass11_0_U3CDOFadeU3Eb__0_mDCACD4D30AEE9D07134544798AB5B9C5D979BE93 (void);
// 0x000000CD System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass11_0::<DOFade>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass11_0_U3CDOFadeU3Eb__1_m73D2BA809B8464E6E216465A623D609E96823BD9 (void);
// 0x000000CE System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass12_0::.ctor()
extern void U3CU3Ec__DisplayClass12_0__ctor_m64C4DEEF82977228537228CAAAF48792AE080622 (void);
// 0x000000CF UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass12_0::<DOScale>b__0()
extern void U3CU3Ec__DisplayClass12_0_U3CDOScaleU3Eb__0_m5C34A94B2CF727A19CE3D6D99933B680E7847F2A (void);
// 0x000000D0 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass12_0::<DOScale>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass12_0_U3CDOScaleU3Eb__1_m79C4D6FE81FC8292C6B825B55A2F711DE92D835C (void);
// 0x000000D1 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass13_0::.ctor()
extern void U3CU3Ec__DisplayClass13_0__ctor_mBD97A0B94BB8F658AA2895C371742B0E74198455 (void);
// 0x000000D2 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass13_0::<DOAnchorPos>b__0()
extern void U3CU3Ec__DisplayClass13_0_U3CDOAnchorPosU3Eb__0_m45698E882FAA3963ED0653B5927E9B5F99C8B4E4 (void);
// 0x000000D3 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass13_0::<DOAnchorPos>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass13_0_U3CDOAnchorPosU3Eb__1_m5DD4C4D9473EA1DD1B2021D9131B4F6D8124BD57 (void);
// 0x000000D4 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass14_0::.ctor()
extern void U3CU3Ec__DisplayClass14_0__ctor_mF03BAB1D5A00A73CAA680F13E3BE0B226712B8C3 (void);
// 0x000000D5 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass14_0::<DOAnchorPosX>b__0()
extern void U3CU3Ec__DisplayClass14_0_U3CDOAnchorPosXU3Eb__0_m77F354FDCA32A28B5E166D92E7AD31A13AAC60FA (void);
// 0x000000D6 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass14_0::<DOAnchorPosX>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass14_0_U3CDOAnchorPosXU3Eb__1_m017F7F1E8BC9250F6CF7A0B75ED09A7ED669BA34 (void);
// 0x000000D7 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass15_0::.ctor()
extern void U3CU3Ec__DisplayClass15_0__ctor_m48FC24F32D0415BE4512FB1D5C17CFF39D8149DC (void);
// 0x000000D8 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass15_0::<DOAnchorPosY>b__0()
extern void U3CU3Ec__DisplayClass15_0_U3CDOAnchorPosYU3Eb__0_m3B38EF80DFF9D4EF696F2F08DCC156C16FE55E8D (void);
// 0x000000D9 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass15_0::<DOAnchorPosY>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass15_0_U3CDOAnchorPosYU3Eb__1_mEB016F250A040B81AEEF7C5D3A98D0B05E3B231F (void);
// 0x000000DA System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass16_0::.ctor()
extern void U3CU3Ec__DisplayClass16_0__ctor_m6A7514F7CF8978AD8D2179728B06E74F14F4485E (void);
// 0x000000DB UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass16_0::<DOAnchorPos3D>b__0()
extern void U3CU3Ec__DisplayClass16_0_U3CDOAnchorPos3DU3Eb__0_m2E02A40A5465C662FCB26908E7F13C7DD3A4BBC2 (void);
// 0x000000DC System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass16_0::<DOAnchorPos3D>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass16_0_U3CDOAnchorPos3DU3Eb__1_mEC7A7D9EDE2E44E5EAF9ACBA9A993FC950F4EEE2 (void);
// 0x000000DD System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass17_0::.ctor()
extern void U3CU3Ec__DisplayClass17_0__ctor_m54FF0D8E95B7DE95B74B8886D64EA0F803C66D9A (void);
// 0x000000DE UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass17_0::<DOAnchorPos3DX>b__0()
extern void U3CU3Ec__DisplayClass17_0_U3CDOAnchorPos3DXU3Eb__0_mC5FAD099F119CE2ACDEAD414435B244F21CDB4E7 (void);
// 0x000000DF System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass17_0::<DOAnchorPos3DX>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass17_0_U3CDOAnchorPos3DXU3Eb__1_mA7F32AA90629508030AAD74E0725D4B5DF28B76D (void);
// 0x000000E0 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass18_0::.ctor()
extern void U3CU3Ec__DisplayClass18_0__ctor_mE054C2ABDC10BD5D710C5AF29506CA2841AA72E2 (void);
// 0x000000E1 UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass18_0::<DOAnchorPos3DY>b__0()
extern void U3CU3Ec__DisplayClass18_0_U3CDOAnchorPos3DYU3Eb__0_m30DD1FDFC6B5104DB734F01FB77F60BAB3C67578 (void);
// 0x000000E2 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass18_0::<DOAnchorPos3DY>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass18_0_U3CDOAnchorPos3DYU3Eb__1_m46549819EBCBEB1EE8404F9888866CD75997825D (void);
// 0x000000E3 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass19_0::.ctor()
extern void U3CU3Ec__DisplayClass19_0__ctor_m74B141AA06FF97B9170A5CD56D2E4422B6511AE3 (void);
// 0x000000E4 UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass19_0::<DOAnchorPos3DZ>b__0()
extern void U3CU3Ec__DisplayClass19_0_U3CDOAnchorPos3DZU3Eb__0_m81FCF7B95ACC17C67BE6C8D68B570D959D88EADC (void);
// 0x000000E5 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass19_0::<DOAnchorPos3DZ>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass19_0_U3CDOAnchorPos3DZU3Eb__1_m27CE65B98533504D302D8580C61D7D3F09A48D27 (void);
// 0x000000E6 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass20_0::.ctor()
extern void U3CU3Ec__DisplayClass20_0__ctor_mA78DA0FD1C871D24DEB547744F4DE38ABEACD0B4 (void);
// 0x000000E7 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass20_0::<DOAnchorMax>b__0()
extern void U3CU3Ec__DisplayClass20_0_U3CDOAnchorMaxU3Eb__0_mD50D23ECA6FBD3AE03536697B9ED7332E4FDD2CD (void);
// 0x000000E8 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass20_0::<DOAnchorMax>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass20_0_U3CDOAnchorMaxU3Eb__1_mFEA7E952BB247F3CC01585B3C896AE53BB7B6540 (void);
// 0x000000E9 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass21_0::.ctor()
extern void U3CU3Ec__DisplayClass21_0__ctor_mCAB7F9CC3BBBA542AF258E0D021EC7AEFE5C2AF1 (void);
// 0x000000EA UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass21_0::<DOAnchorMin>b__0()
extern void U3CU3Ec__DisplayClass21_0_U3CDOAnchorMinU3Eb__0_m33BBB55D66991F54EE55E79B0AE622F40FFCD764 (void);
// 0x000000EB System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass21_0::<DOAnchorMin>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass21_0_U3CDOAnchorMinU3Eb__1_m9D2C994ECFF4FB4237C178E213B731C1BD197F0A (void);
// 0x000000EC System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass22_0::.ctor()
extern void U3CU3Ec__DisplayClass22_0__ctor_mE10D2BDE628966FE49512531B20C51F6C2787089 (void);
// 0x000000ED UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass22_0::<DOPivot>b__0()
extern void U3CU3Ec__DisplayClass22_0_U3CDOPivotU3Eb__0_m5FE19E82DBA2702E7A7ADF66BB937773CACBEC6D (void);
// 0x000000EE System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass22_0::<DOPivot>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass22_0_U3CDOPivotU3Eb__1_mE3E48A091761963476D9CB2F1004A83281EE2643 (void);
// 0x000000EF System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass23_0::.ctor()
extern void U3CU3Ec__DisplayClass23_0__ctor_m983854683F9F5CE4B7F0BD9033AB45DDA296F9E7 (void);
// 0x000000F0 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass23_0::<DOPivotX>b__0()
extern void U3CU3Ec__DisplayClass23_0_U3CDOPivotXU3Eb__0_mEBA64E950B901D99C27662F211C5357066A46C1B (void);
// 0x000000F1 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass23_0::<DOPivotX>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass23_0_U3CDOPivotXU3Eb__1_m2BECC738B1793D1B2B8F075191056F44AE61DD6D (void);
// 0x000000F2 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0::.ctor()
extern void U3CU3Ec__DisplayClass24_0__ctor_m41C1CA93D499089E6C5CD68BEB55BD64ADBFE43F (void);
// 0x000000F3 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0::<DOPivotY>b__0()
extern void U3CU3Ec__DisplayClass24_0_U3CDOPivotYU3Eb__0_mB9A0E99B23333028B4BA97E332DA19268ADFEBBB (void);
// 0x000000F4 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0::<DOPivotY>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass24_0_U3CDOPivotYU3Eb__1_mC0B65C0BEC4968B86083A8E493E782A486638E3F (void);
// 0x000000F5 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass25_0::.ctor()
extern void U3CU3Ec__DisplayClass25_0__ctor_mDF25A8BF6CB8B1A343590B334D354F5EAC765572 (void);
// 0x000000F6 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass25_0::<DOSizeDelta>b__0()
extern void U3CU3Ec__DisplayClass25_0_U3CDOSizeDeltaU3Eb__0_m9465A762A443D9DAA50004FF4EC3E7A5710D24F3 (void);
// 0x000000F7 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass25_0::<DOSizeDelta>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass25_0_U3CDOSizeDeltaU3Eb__1_mE4D6E5ADF19E5741ADB793A0E043CAE94C18772B (void);
// 0x000000F8 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass26_0::.ctor()
extern void U3CU3Ec__DisplayClass26_0__ctor_m7F4C69BB9BF2084453CFD95533563FC7C6AF5941 (void);
// 0x000000F9 UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass26_0::<DOPunchAnchorPos>b__0()
extern void U3CU3Ec__DisplayClass26_0_U3CDOPunchAnchorPosU3Eb__0_m8A97B30EF54DCC1B5253F2CE036DA7BEF521F9E2 (void);
// 0x000000FA System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass26_0::<DOPunchAnchorPos>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass26_0_U3CDOPunchAnchorPosU3Eb__1_mA354D1798B36E08566BC12DEDD0A878C47D19C46 (void);
// 0x000000FB System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass27_0::.ctor()
extern void U3CU3Ec__DisplayClass27_0__ctor_m8180394F95E4CEDEA6E4B91A408E7CBC7F36A8D5 (void);
// 0x000000FC UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass27_0::<DOShakeAnchorPos>b__0()
extern void U3CU3Ec__DisplayClass27_0_U3CDOShakeAnchorPosU3Eb__0_m28D2453CAB4630D898B61CF1679C5C4955EC5761 (void);
// 0x000000FD System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass27_0::<DOShakeAnchorPos>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass27_0_U3CDOShakeAnchorPosU3Eb__1_m08D936A746E8737C9E37B326E975EDCB90427B5F (void);
// 0x000000FE System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass28_0::.ctor()
extern void U3CU3Ec__DisplayClass28_0__ctor_m4179B6F77D9F8B2D07F78D25FC745F542063F335 (void);
// 0x000000FF UnityEngine.Vector3 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass28_0::<DOShakeAnchorPos>b__0()
extern void U3CU3Ec__DisplayClass28_0_U3CDOShakeAnchorPosU3Eb__0_mE987488CB26087991EB5B2AF5E1BB03633A9C5E9 (void);
// 0x00000100 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass28_0::<DOShakeAnchorPos>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass28_0_U3CDOShakeAnchorPosU3Eb__1_m223F195EA08AAF2F03AE46C9DE4761B0BC7FB7EC (void);
// 0x00000101 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::.ctor()
extern void U3CU3Ec__DisplayClass29_0__ctor_mCA183B392317E1ABAF1B8CA84C02784D75678A78 (void);
// 0x00000102 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__0()
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__0_m82918F5D73CE67BC9AD9979A3F81C717AA95A5EF (void);
// 0x00000103 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__1_mACBA5402D427457E33770E20ABBF153EE8EA73B2 (void);
// 0x00000104 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__2()
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__2_m6BAF800D607189779E65F18B54EA2A29AC45D84B (void);
// 0x00000105 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__3()
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__3_mA6D64EC026FB4AA6873394DBB91E728E6F6EFF3D (void);
// 0x00000106 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__4(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__4_mD71EC1A09CD5404D79A2FA0B068A00F3D2E7D12F (void);
// 0x00000107 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0::<DOJumpAnchorPos>b__5()
extern void U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__5_m31B52507CE1503653EED1573137622C1202BA9D9 (void);
// 0x00000108 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass30_0::.ctor()
extern void U3CU3Ec__DisplayClass30_0__ctor_m5F4F51BC32159EE37265F7032DE223AC3AB6A1C0 (void);
// 0x00000109 UnityEngine.Vector2 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass30_0::<DONormalizedPos>b__0()
extern void U3CU3Ec__DisplayClass30_0_U3CDONormalizedPosU3Eb__0_m80C5E010B8B0C14A9F1358140D6DB2AE6C5374A9 (void);
// 0x0000010A System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass30_0::<DONormalizedPos>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass30_0_U3CDONormalizedPosU3Eb__1_m8185551DA74F9CE20DAD3392E7DDE2490EB1D301 (void);
// 0x0000010B System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass31_0::.ctor()
extern void U3CU3Ec__DisplayClass31_0__ctor_m417F41C2607E2F3A10C14B9556514FC2BBA1B035 (void);
// 0x0000010C System.Single DG.Tweening.DOTweenModuleUI/<>c__DisplayClass31_0::<DOHorizontalNormalizedPos>b__0()
extern void U3CU3Ec__DisplayClass31_0_U3CDOHorizontalNormalizedPosU3Eb__0_m77E495AE88490935170B5479753B0D251A5D3CA4 (void);
// 0x0000010D System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass31_0::<DOHorizontalNormalizedPos>b__1(System.Single)
extern void U3CU3Ec__DisplayClass31_0_U3CDOHorizontalNormalizedPosU3Eb__1_mF7393D7DDB277D5BFB5CE86BEB93E25B0558B7BD (void);
// 0x0000010E System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass32_0::.ctor()
extern void U3CU3Ec__DisplayClass32_0__ctor_mA218955A26898E155307DDE47E12B7E53255AB3E (void);
// 0x0000010F System.Single DG.Tweening.DOTweenModuleUI/<>c__DisplayClass32_0::<DOVerticalNormalizedPos>b__0()
extern void U3CU3Ec__DisplayClass32_0_U3CDOVerticalNormalizedPosU3Eb__0_m38805643288D85CEE1588577A69586E047726867 (void);
// 0x00000110 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass32_0::<DOVerticalNormalizedPos>b__1(System.Single)
extern void U3CU3Ec__DisplayClass32_0_U3CDOVerticalNormalizedPosU3Eb__1_mD395D9118A7944AE3F2ACF8AADCF71B0611F80BB (void);
// 0x00000111 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass33_0::.ctor()
extern void U3CU3Ec__DisplayClass33_0__ctor_mFDBB24E2EB71DAB7C3811F51BCF45EE7733321D3 (void);
// 0x00000112 System.Single DG.Tweening.DOTweenModuleUI/<>c__DisplayClass33_0::<DOValue>b__0()
extern void U3CU3Ec__DisplayClass33_0_U3CDOValueU3Eb__0_m8E6B52F72A726C09781FAAE48C1097CE6C2D8188 (void);
// 0x00000113 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass33_0::<DOValue>b__1(System.Single)
extern void U3CU3Ec__DisplayClass33_0_U3CDOValueU3Eb__1_m02996BC134ED2E96E505224009462007F093F825 (void);
// 0x00000114 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass34_0::.ctor()
extern void U3CU3Ec__DisplayClass34_0__ctor_m6903649B5BDBAA53F5C179B09D1C77AABC913561 (void);
// 0x00000115 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass34_0::<DOColor>b__0()
extern void U3CU3Ec__DisplayClass34_0_U3CDOColorU3Eb__0_mBA716E6626BB3051125B19AC02EC825AA305B9A6 (void);
// 0x00000116 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass34_0::<DOColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass34_0_U3CDOColorU3Eb__1_m534299537BAA83C8B80BDB7C0622F05B8501D4C6 (void);
// 0x00000117 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass35_0::.ctor()
extern void U3CU3Ec__DisplayClass35_0__ctor_m6F52791A710AA19C73082E0EED5D298E31EDF1EF (void);
// 0x00000118 System.Int32 DG.Tweening.DOTweenModuleUI/<>c__DisplayClass35_0::<DOCounter>b__0()
extern void U3CU3Ec__DisplayClass35_0_U3CDOCounterU3Eb__0_mD4515C9E2BA21A91E51DCA562DB8BD859BB73D4B (void);
// 0x00000119 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass35_0::<DOCounter>b__1(System.Int32)
extern void U3CU3Ec__DisplayClass35_0_U3CDOCounterU3Eb__1_m91616BD436B4FAB5C826763E445C8A59C11AF221 (void);
// 0x0000011A System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass36_0::.ctor()
extern void U3CU3Ec__DisplayClass36_0__ctor_m7C683C9CF75033301DA090C8B583860556AF7F29 (void);
// 0x0000011B UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass36_0::<DOFade>b__0()
extern void U3CU3Ec__DisplayClass36_0_U3CDOFadeU3Eb__0_m72BB7D6C818418B6497D3356DA77BA4A5B325E47 (void);
// 0x0000011C System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass36_0::<DOFade>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass36_0_U3CDOFadeU3Eb__1_m4083DFAFABE118FAC072D3EE81663ACA96DD8F10 (void);
// 0x0000011D System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass37_0::.ctor()
extern void U3CU3Ec__DisplayClass37_0__ctor_m30C619C273CA88E1630ADE30076D3BAB756E8037 (void);
// 0x0000011E System.String DG.Tweening.DOTweenModuleUI/<>c__DisplayClass37_0::<DOText>b__0()
extern void U3CU3Ec__DisplayClass37_0_U3CDOTextU3Eb__0_m02FF7D2EC040673A6A8DAF254FA06CCB5E19150D (void);
// 0x0000011F System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass37_0::<DOText>b__1(System.String)
extern void U3CU3Ec__DisplayClass37_0_U3CDOTextU3Eb__1_m2838FBD1C16B38207C0B4528D6E805E6308E1E6B (void);
// 0x00000120 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass38_0::.ctor()
extern void U3CU3Ec__DisplayClass38_0__ctor_m82948A429B319CC7B45105656F6DD0ADBB2136CC (void);
// 0x00000121 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass38_0::<DOBlendableColor>b__0()
extern void U3CU3Ec__DisplayClass38_0_U3CDOBlendableColorU3Eb__0_mE68FE0C254E1D0E7E8D659FF3E4A3AA5F7738351 (void);
// 0x00000122 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass38_0::<DOBlendableColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass38_0_U3CDOBlendableColorU3Eb__1_mA5048FA5B74BD7E9906C80159B99ACB2AFED6634 (void);
// 0x00000123 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass39_0::.ctor()
extern void U3CU3Ec__DisplayClass39_0__ctor_mBAA4D644FB605A60D0C3BEB67229723BB3874E6D (void);
// 0x00000124 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass39_0::<DOBlendableColor>b__0()
extern void U3CU3Ec__DisplayClass39_0_U3CDOBlendableColorU3Eb__0_m897EF1C1C8D7A638D7271A6E3BD8640F834CA567 (void);
// 0x00000125 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass39_0::<DOBlendableColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass39_0_U3CDOBlendableColorU3Eb__1_m059D299137E18F4172FB89D42BBC0DBE0408311C (void);
// 0x00000126 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass40_0::.ctor()
extern void U3CU3Ec__DisplayClass40_0__ctor_m6C547429D9E437CED8C4BDCB96EE8BE2D7182763 (void);
// 0x00000127 UnityEngine.Color DG.Tweening.DOTweenModuleUI/<>c__DisplayClass40_0::<DOBlendableColor>b__0()
extern void U3CU3Ec__DisplayClass40_0_U3CDOBlendableColorU3Eb__0_m031A8418D686ADB8B4AD6572C18FCBAD1E42B0F6 (void);
// 0x00000128 System.Void DG.Tweening.DOTweenModuleUI/<>c__DisplayClass40_0::<DOBlendableColor>b__1(UnityEngine.Color)
extern void U3CU3Ec__DisplayClass40_0_U3CDOBlendableColorU3Eb__1_m74D298854E55DD21E0191F65A0A67376028748EC (void);
// 0x00000129 DG.Tweening.Sequence DG.Tweening.DOTweenModuleUnityVersion::DOGradientColor(UnityEngine.Material,UnityEngine.Gradient,System.Single)
extern void DOTweenModuleUnityVersion_DOGradientColor_m5989D5E5CCAA8B96FEC40CE899DDD9BC255F4126 (void);
// 0x0000012A DG.Tweening.Sequence DG.Tweening.DOTweenModuleUnityVersion::DOGradientColor(UnityEngine.Material,UnityEngine.Gradient,System.String,System.Single)
extern void DOTweenModuleUnityVersion_DOGradientColor_m16A5065B7DA6EA92AC15D1E186EE14617F64896B (void);
// 0x0000012B UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForCompletion(DG.Tweening.Tween,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForCompletion_m080081BC7D031CAE8CB22FC166C6E19FAA91295C (void);
// 0x0000012C UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForRewind(DG.Tweening.Tween,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForRewind_m7EB6AB643D5F309EE41F15305ADB1324E16853A7 (void);
// 0x0000012D UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForKill(DG.Tweening.Tween,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForKill_m9592B2D81F0C76C9F8003645BDB0C4C3BA4E6A3B (void);
// 0x0000012E UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForElapsedLoops(DG.Tweening.Tween,System.Int32,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForElapsedLoops_m08D7DB6E86076A4D3224DE7F651529C03B0C9B93 (void);
// 0x0000012F UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForPosition(DG.Tweening.Tween,System.Single,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForPosition_m918A05EB65877997F48B218DE2B9B95A4E198A0E (void);
// 0x00000130 UnityEngine.CustomYieldInstruction DG.Tweening.DOTweenModuleUnityVersion::WaitForStart(DG.Tweening.Tween,System.Boolean)
extern void DOTweenModuleUnityVersion_WaitForStart_m3E6DF08DBF844D468C3DD2A14AB96AAF3717BA53 (void);
// 0x00000131 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUnityVersion::DOOffset(UnityEngine.Material,UnityEngine.Vector2,System.Int32,System.Single)
extern void DOTweenModuleUnityVersion_DOOffset_mB985D0A38167056313BD49AA97A9A2F12B6C1CA2 (void);
// 0x00000132 DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector2,UnityEngine.Vector2,DG.Tweening.Plugins.Options.VectorOptions> DG.Tweening.DOTweenModuleUnityVersion::DOTiling(UnityEngine.Material,UnityEngine.Vector2,System.Int32,System.Single)
extern void DOTweenModuleUnityVersion_DOTiling_m354938745AA34ED1539D3CBF54C94A5E5753B903 (void);
// 0x00000133 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForCompletion(DG.Tweening.Tween)
extern void DOTweenModuleUnityVersion_AsyncWaitForCompletion_m47D1F5AACF019F8C3233238D5B73EBD325685681 (void);
// 0x00000134 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForRewind(DG.Tweening.Tween)
extern void DOTweenModuleUnityVersion_AsyncWaitForRewind_m4B4AD3964B5CBB9F56BB1050E8EF7C0AF414060E (void);
// 0x00000135 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForKill(DG.Tweening.Tween)
extern void DOTweenModuleUnityVersion_AsyncWaitForKill_m4CE6BA6CDF93365F4D14CE2909C7F7FF6B332928 (void);
// 0x00000136 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForElapsedLoops(DG.Tweening.Tween,System.Int32)
extern void DOTweenModuleUnityVersion_AsyncWaitForElapsedLoops_m08434CDEC811346692A3795B1736C8499E391277 (void);
// 0x00000137 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForPosition(DG.Tweening.Tween,System.Single)
extern void DOTweenModuleUnityVersion_AsyncWaitForPosition_mA1767089E7840940CEB85BEAF15FBC02CE56D487 (void);
// 0x00000138 System.Threading.Tasks.Task DG.Tweening.DOTweenModuleUnityVersion::AsyncWaitForStart(DG.Tweening.Tween)
extern void DOTweenModuleUnityVersion_AsyncWaitForStart_m3BAC94C50C109B2795BAA10D582617B3F2F95126 (void);
// 0x00000139 System.Void DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_mF5EC87634B90C628AE370887DCF280218F814B4C (void);
// 0x0000013A UnityEngine.Vector2 DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass8_0::<DOOffset>b__0()
extern void U3CU3Ec__DisplayClass8_0_U3CDOOffsetU3Eb__0_m0247C66637BE1BC486E9B83E29D9A8C539F0C4C7 (void);
// 0x0000013B System.Void DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass8_0::<DOOffset>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass8_0_U3CDOOffsetU3Eb__1_m3FB8CA36F894BB6D62D812DF2F13F0714F48945A (void);
// 0x0000013C System.Void DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_m1E2466F9751381E5A3C76E5E2970972957741B9E (void);
// 0x0000013D UnityEngine.Vector2 DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass9_0::<DOTiling>b__0()
extern void U3CU3Ec__DisplayClass9_0_U3CDOTilingU3Eb__0_m049884D699FDEDD9B8CE44EC9104A8055F7E4DD8 (void);
// 0x0000013E System.Void DG.Tweening.DOTweenModuleUnityVersion/<>c__DisplayClass9_0::<DOTiling>b__1(UnityEngine.Vector2)
extern void U3CU3Ec__DisplayClass9_0_U3CDOTilingU3Eb__1_m5C1495C9398445575DA1139EF2967F0C6535992D (void);
// 0x0000013F System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10::MoveNext()
extern void U3CAsyncWaitForCompletionU3Ed__10_MoveNext_m7AE96D202005CC27A2EBEB47057FADA081D6DCDA (void);
// 0x00000140 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForCompletion>d__10::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForCompletionU3Ed__10_SetStateMachine_m6240E5A12BCFEF8EA8588C4C18B3BB48BBA71FBB (void);
// 0x00000141 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11::MoveNext()
extern void U3CAsyncWaitForRewindU3Ed__11_MoveNext_m5E01823C6DBEFF1763AD6606972918D90935D340 (void);
// 0x00000142 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForRewind>d__11::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForRewindU3Ed__11_SetStateMachine_m3F25AF370573B0A32A25D5D01483AF62C16AD5C3 (void);
// 0x00000143 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12::MoveNext()
extern void U3CAsyncWaitForKillU3Ed__12_MoveNext_mC10BB60238B855C88268AEE7DA0D7E8CF59AC885 (void);
// 0x00000144 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForKill>d__12::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForKillU3Ed__12_SetStateMachine_m7BC3B905F4C08F129E4E6DFD12DDA73E5756DD0B (void);
// 0x00000145 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13::MoveNext()
extern void U3CAsyncWaitForElapsedLoopsU3Ed__13_MoveNext_mF44348C1C974B48E1B0F6FE03AD1F713A4A6F8A2 (void);
// 0x00000146 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForElapsedLoops>d__13::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForElapsedLoopsU3Ed__13_SetStateMachine_m4D5053D74FA671E83FA48E11A3EE5C6534F995AB (void);
// 0x00000147 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14::MoveNext()
extern void U3CAsyncWaitForPositionU3Ed__14_MoveNext_mB726C581B4A8055414678A86C800C4A0525E5121 (void);
// 0x00000148 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForPosition>d__14::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForPositionU3Ed__14_SetStateMachine_m060A3B894F6700B46D57FD2443F396C7C9CC7111 (void);
// 0x00000149 System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15::MoveNext()
extern void U3CAsyncWaitForStartU3Ed__15_MoveNext_mDBD2BBC1B727D4C915B0E2AB910330411086BC12 (void);
// 0x0000014A System.Void DG.Tweening.DOTweenModuleUnityVersion/<AsyncWaitForStart>d__15::SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine)
extern void U3CAsyncWaitForStartU3Ed__15_SetStateMachine_m3B0B96BE14F355F5A0AF74DD42C7774158140A41 (void);
// 0x0000014B System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForCompletion::get_keepWaiting()
extern void WaitForCompletion_get_keepWaiting_mD2C729ECA6B6F6BE57B718492953D588237F743D (void);
// 0x0000014C System.Void DG.Tweening.DOTweenCYInstruction/WaitForCompletion::.ctor(DG.Tweening.Tween)
extern void WaitForCompletion__ctor_mE85B7CC8B7FE6A2AE84DB8210249A61018118C4D (void);
// 0x0000014D System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForRewind::get_keepWaiting()
extern void WaitForRewind_get_keepWaiting_mF46CA00D1A5FDF140C0C027C4109C7373245A16C (void);
// 0x0000014E System.Void DG.Tweening.DOTweenCYInstruction/WaitForRewind::.ctor(DG.Tweening.Tween)
extern void WaitForRewind__ctor_mD79A34DBDAC1B30FBEBD36A8D749EC81935520B2 (void);
// 0x0000014F System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForKill::get_keepWaiting()
extern void WaitForKill_get_keepWaiting_m4C085E03853426F4D4F5C312334101AE9BA75E3F (void);
// 0x00000150 System.Void DG.Tweening.DOTweenCYInstruction/WaitForKill::.ctor(DG.Tweening.Tween)
extern void WaitForKill__ctor_m75C2D3D54DBBBB35DE297B947C08C982CABF1BAF (void);
// 0x00000151 System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForElapsedLoops::get_keepWaiting()
extern void WaitForElapsedLoops_get_keepWaiting_mC2A906DBE9A06B7697041B76EC7C6AF58F928D6C (void);
// 0x00000152 System.Void DG.Tweening.DOTweenCYInstruction/WaitForElapsedLoops::.ctor(DG.Tweening.Tween,System.Int32)
extern void WaitForElapsedLoops__ctor_mA0E7D5A115AB56AD618E24B320476B81B9CAEC7A (void);
// 0x00000153 System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForPosition::get_keepWaiting()
extern void WaitForPosition_get_keepWaiting_mA71AB7B7C269AB062BB6AF9CDF42E0F54EA6549F (void);
// 0x00000154 System.Void DG.Tweening.DOTweenCYInstruction/WaitForPosition::.ctor(DG.Tweening.Tween,System.Single)
extern void WaitForPosition__ctor_mB6CCFCE59F142931CF19AC3BA4FE5CAFF1CBA4AD (void);
// 0x00000155 System.Boolean DG.Tweening.DOTweenCYInstruction/WaitForStart::get_keepWaiting()
extern void WaitForStart_get_keepWaiting_mA0B7858981A2CEDE516D5F2C5133629C6D537E0B (void);
// 0x00000156 System.Void DG.Tweening.DOTweenCYInstruction/WaitForStart::.ctor(DG.Tweening.Tween)
extern void WaitForStart__ctor_m3AEC2F6E37815ED0D94C2FA5F3B784456C6E49D1 (void);
// 0x00000157 System.Void DG.Tweening.DOTweenModuleUtils::Init()
extern void DOTweenModuleUtils_Init_m8FD2F0DFE3D768ECE332A27B64ED208ED53568D5 (void);
// 0x00000158 System.Void DG.Tweening.DOTweenModuleUtils::Preserver()
extern void DOTweenModuleUtils_Preserver_m6DD0C54BCF6FBA75AA80562BFBEDF89F7A224189 (void);
// 0x00000159 System.Void DG.Tweening.DOTweenModuleUtils/Physics::SetOrientationOnPath(DG.Tweening.Plugins.Options.PathOptions,DG.Tweening.Tween,UnityEngine.Quaternion,UnityEngine.Transform)
extern void Physics_SetOrientationOnPath_mC2C4E6FA124458E00765F647C3E824CC31A4696D (void);
// 0x0000015A System.Boolean DG.Tweening.DOTweenModuleUtils/Physics::HasRigidbody2D(UnityEngine.Component)
extern void Physics_HasRigidbody2D_m80204646E4EEA6187F16FE74B1608D54DC0EFA00 (void);
// 0x0000015B System.Boolean DG.Tweening.DOTweenModuleUtils/Physics::HasRigidbody(UnityEngine.Component)
extern void Physics_HasRigidbody_m81595D61A93C148222BD16F87F82F465286457B8 (void);
// 0x0000015C DG.Tweening.Core.TweenerCore`3<UnityEngine.Vector3,DG.Tweening.Plugins.Core.PathCore.Path,DG.Tweening.Plugins.Options.PathOptions> DG.Tweening.DOTweenModuleUtils/Physics::CreateDOTweenPathTween(UnityEngine.MonoBehaviour,System.Boolean,System.Boolean,DG.Tweening.Plugins.Core.PathCore.Path,System.Single,DG.Tweening.PathMode)
extern void Physics_CreateDOTweenPathTween_m9AA6DE226F6876ACF693B7254E3DB5773E7651E0 (void);
// 0x0000015D System.Void DG.Tweening.DOTweenAnimation::add_OnReset(System.Action`1<DG.Tweening.DOTweenAnimation>)
extern void DOTweenAnimation_add_OnReset_mA8F5741736259C46628FC55869998F518051D4C1 (void);
// 0x0000015E System.Void DG.Tweening.DOTweenAnimation::remove_OnReset(System.Action`1<DG.Tweening.DOTweenAnimation>)
extern void DOTweenAnimation_remove_OnReset_mAE32F1B7F1B2497982F03D1E04FC2D60B0FB58FC (void);
// 0x0000015F System.Void DG.Tweening.DOTweenAnimation::Dispatch_OnReset(DG.Tweening.DOTweenAnimation)
extern void DOTweenAnimation_Dispatch_OnReset_m502D1D6A50C88AB144971DE59485CE3E3439085C (void);
// 0x00000160 System.Void DG.Tweening.DOTweenAnimation::Awake()
extern void DOTweenAnimation_Awake_m5A2F45736E953494BAD492FF36EED788F8AD4656 (void);
// 0x00000161 System.Void DG.Tweening.DOTweenAnimation::Start()
extern void DOTweenAnimation_Start_mEE5D784A65EE9DCD56E55542181CF33F6B1A4BED (void);
// 0x00000162 System.Void DG.Tweening.DOTweenAnimation::Reset()
extern void DOTweenAnimation_Reset_mE401C717944D3566EFF81FA6147D22F5599E2287 (void);
// 0x00000163 System.Void DG.Tweening.DOTweenAnimation::OnDestroy()
extern void DOTweenAnimation_OnDestroy_mD2017B5DEEC60E62BACD32FCDC61B9225F7A45DC (void);
// 0x00000164 System.Void DG.Tweening.DOTweenAnimation::CreateTween()
extern void DOTweenAnimation_CreateTween_mE197759CB9087F9F55ED0112FA19472D4810ADF2 (void);
// 0x00000165 System.Void DG.Tweening.DOTweenAnimation::DOPlay()
extern void DOTweenAnimation_DOPlay_m404032EAB118EBBFBF65F3A975E04B3A59C407AC (void);
// 0x00000166 System.Void DG.Tweening.DOTweenAnimation::DOPlayBackwards()
extern void DOTweenAnimation_DOPlayBackwards_m28B62919A803EE87FDF72C013294176078553A83 (void);
// 0x00000167 System.Void DG.Tweening.DOTweenAnimation::DOPlayForward()
extern void DOTweenAnimation_DOPlayForward_mA152942BA1264751895AC1FB8D8716F4A8066964 (void);
// 0x00000168 System.Void DG.Tweening.DOTweenAnimation::DOPause()
extern void DOTweenAnimation_DOPause_m0373908CB11AD693FE23DD7735532D6CD116EFA5 (void);
// 0x00000169 System.Void DG.Tweening.DOTweenAnimation::DOTogglePause()
extern void DOTweenAnimation_DOTogglePause_m5348CFC134E384E4D64EAE6ADC8CF2DAC95C4869 (void);
// 0x0000016A System.Void DG.Tweening.DOTweenAnimation::DORewind()
extern void DOTweenAnimation_DORewind_m59758817F07694487F36D556DD3C075346B03989 (void);
// 0x0000016B System.Void DG.Tweening.DOTweenAnimation::DORestart()
extern void DOTweenAnimation_DORestart_m4AB0A91DF102E0D643DADE7D915CB147AE57D44B (void);
// 0x0000016C System.Void DG.Tweening.DOTweenAnimation::DORestart(System.Boolean)
extern void DOTweenAnimation_DORestart_mCAB0990689AB762A9B8A9BDE208BA1E8D138520C (void);
// 0x0000016D System.Void DG.Tweening.DOTweenAnimation::DOComplete()
extern void DOTweenAnimation_DOComplete_m26F8261306361C2B5E795B73CADE12A8894710BF (void);
// 0x0000016E System.Void DG.Tweening.DOTweenAnimation::DOKill()
extern void DOTweenAnimation_DOKill_mE596789184B6317AAEB7C7C11E31014BF43D40C7 (void);
// 0x0000016F System.Void DG.Tweening.DOTweenAnimation::DOPlayById(System.String)
extern void DOTweenAnimation_DOPlayById_m12D97C7EF5521A499512B6F730DC850E96CB9575 (void);
// 0x00000170 System.Void DG.Tweening.DOTweenAnimation::DOPlayAllById(System.String)
extern void DOTweenAnimation_DOPlayAllById_m78E04FBAA4F91F516CD6EF97D4F33D633087DF4F (void);
// 0x00000171 System.Void DG.Tweening.DOTweenAnimation::DOPauseAllById(System.String)
extern void DOTweenAnimation_DOPauseAllById_m521B9C4119FA1F6AC6F8E28952AA89EB9BC43BAD (void);
// 0x00000172 System.Void DG.Tweening.DOTweenAnimation::DOPlayBackwardsById(System.String)
extern void DOTweenAnimation_DOPlayBackwardsById_m092989EC8744A4F4383D1F664A9F32BAF78C50AF (void);
// 0x00000173 System.Void DG.Tweening.DOTweenAnimation::DOPlayBackwardsAllById(System.String)
extern void DOTweenAnimation_DOPlayBackwardsAllById_m7C27AFED81EEA8B8629A7D276E377760CEECE79E (void);
// 0x00000174 System.Void DG.Tweening.DOTweenAnimation::DOPlayForwardById(System.String)
extern void DOTweenAnimation_DOPlayForwardById_m76C5756941FBE7DE791B9753FD3F0851D0AC9529 (void);
// 0x00000175 System.Void DG.Tweening.DOTweenAnimation::DOPlayForwardAllById(System.String)
extern void DOTweenAnimation_DOPlayForwardAllById_m655297832660471E1C91A695B9B9AD8E29069A80 (void);
// 0x00000176 System.Void DG.Tweening.DOTweenAnimation::DOPlayNext()
extern void DOTweenAnimation_DOPlayNext_m73E38E99F8700E05203AF52600AAC0F59147B30D (void);
// 0x00000177 System.Void DG.Tweening.DOTweenAnimation::DORewindAndPlayNext()
extern void DOTweenAnimation_DORewindAndPlayNext_m462F1FE5A33CED8A07535F5777CD7F1AA90C4E48 (void);
// 0x00000178 System.Void DG.Tweening.DOTweenAnimation::DORewindAllById(System.String)
extern void DOTweenAnimation_DORewindAllById_m1F3F3C40A945A9F27ABB32090961D4518BA01C2C (void);
// 0x00000179 System.Void DG.Tweening.DOTweenAnimation::DORestartById(System.String)
extern void DOTweenAnimation_DORestartById_m1F30DC4E8D4DB44FFE3ACEF871443ACA26EBDC75 (void);
// 0x0000017A System.Void DG.Tweening.DOTweenAnimation::DORestartAllById(System.String)
extern void DOTweenAnimation_DORestartAllById_m64AA94F735F90651E0FC436DCC83B19ACA942D2E (void);
// 0x0000017B System.Collections.Generic.List`1<DG.Tweening.Tween> DG.Tweening.DOTweenAnimation::GetTweens()
extern void DOTweenAnimation_GetTweens_m72B45D0B5DC11B3FE7F0ADAF345ABE4A31D90833 (void);
// 0x0000017C DG.Tweening.DOTweenAnimation/TargetType DG.Tweening.DOTweenAnimation::TypeToDOTargetType(System.Type)
extern void DOTweenAnimation_TypeToDOTargetType_m15E19090315002396417BA530BCB3450914B519F (void);
// 0x0000017D DG.Tweening.Tween DG.Tweening.DOTweenAnimation::CreateEditorPreview()
extern void DOTweenAnimation_CreateEditorPreview_mC9FC6CE29107384E390C42E9AABDC713259C8593 (void);
// 0x0000017E UnityEngine.GameObject DG.Tweening.DOTweenAnimation::GetTweenGO()
extern void DOTweenAnimation_GetTweenGO_mDF43174309BC150372D175C32F9819011D787F38 (void);
// 0x0000017F System.Void DG.Tweening.DOTweenAnimation::ReEvaluateRelativeTween()
extern void DOTweenAnimation_ReEvaluateRelativeTween_m23AF3B509234313AE3E2A9657E2CC5997AD323C7 (void);
// 0x00000180 System.Void DG.Tweening.DOTweenAnimation::.ctor()
extern void DOTweenAnimation__ctor_mA3F7CBFE6A98CAEF4059B593C245E8B6D2F1CFF0 (void);
// 0x00000181 System.Void DG.Tweening.DOTweenAnimation::<CreateTween>b__47_0()
extern void DOTweenAnimation_U3CCreateTweenU3Eb__47_0_m4A2111E4BF4F1513A25F4D01ED658ED99B84E148 (void);
// 0x00000182 System.Boolean DG.Tweening.DOTweenAnimationExtensions::IsSameOrSubclassOf(UnityEngine.Component)
// 0x00000183 System.Void DG.Tweening.DOTweenProShortcuts::.cctor()
extern void DOTweenProShortcuts__cctor_mB5D4F77E7578688BA434DE03F61A80F240CC85AB (void);
// 0x00000184 DG.Tweening.Tweener DG.Tweening.DOTweenProShortcuts::DOSpiral(UnityEngine.Transform,System.Single,System.Nullable`1<UnityEngine.Vector3>,DG.Tweening.SpiralMode,System.Single,System.Single,System.Single,System.Boolean)
extern void DOTweenProShortcuts_DOSpiral_mBB6B961D53DD13CE5727CEA20BC179F5F1FE282D (void);
// 0x00000185 DG.Tweening.Tweener DG.Tweening.DOTweenProShortcuts::DOSpiral(UnityEngine.Rigidbody,System.Single,System.Nullable`1<UnityEngine.Vector3>,DG.Tweening.SpiralMode,System.Single,System.Single,System.Single,System.Boolean)
extern void DOTweenProShortcuts_DOSpiral_mD1B212D21905AC2EE0D4BA1F24604DAA44D65B1E (void);
// 0x00000186 System.Void DG.Tweening.DOTweenProShortcuts/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mADA95A56850C09B62E886A9438E5959ACFE782A4 (void);
// 0x00000187 UnityEngine.Vector3 DG.Tweening.DOTweenProShortcuts/<>c__DisplayClass1_0::<DOSpiral>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CDOSpiralU3Eb__0_m712CB5D59B45F2FF3023A9C8772B55099EC4436C (void);
// 0x00000188 System.Void DG.Tweening.DOTweenProShortcuts/<>c__DisplayClass1_0::<DOSpiral>b__1(UnityEngine.Vector3)
extern void U3CU3Ec__DisplayClass1_0_U3CDOSpiralU3Eb__1_m0F83BC8B95F0E610CC06BD323AF0EA3A7F1EF405 (void);
// 0x00000189 System.Void DG.Tweening.DOTweenProShortcuts/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_mD18FFCA0D468681B299C2F09E602FF6619E4F74D (void);
// 0x0000018A UnityEngine.Vector3 DG.Tweening.DOTweenProShortcuts/<>c__DisplayClass2_0::<DOSpiral>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CDOSpiralU3Eb__0_m7179D74055A097F51CA14CBAE2FE92B941A4A543 (void);
// 0x0000018B System.Void SevenZip.CRC::.cctor()
extern void CRC__cctor_mB40D92FF619984657395B910C96AB205B95D9150 (void);
// 0x0000018C System.Void SevenZip.CRC::Init()
extern void CRC_Init_m16709DA73B42F924063FF919572CDD418A11ADC5 (void);
// 0x0000018D System.Void SevenZip.CRC::UpdateByte(System.Byte)
extern void CRC_UpdateByte_m4A4769F5943800546A3CF3EE3A6AE57F87FF115F (void);
// 0x0000018E System.Void SevenZip.CRC::Update(System.Byte[],System.UInt32,System.UInt32)
extern void CRC_Update_m7AAF2C449ABBAA9EAFE6326E145963054E2EF757 (void);
// 0x0000018F System.UInt32 SevenZip.CRC::GetDigest()
extern void CRC_GetDigest_mBEC96B14FF952BF124F11DD6DFC1A0409E0B337C (void);
// 0x00000190 System.UInt32 SevenZip.CRC::CalculateDigest(System.Byte[],System.UInt32,System.UInt32)
extern void CRC_CalculateDigest_m4CBBB31AF681644C0321A83D5867C6B319913CA9 (void);
// 0x00000191 System.Boolean SevenZip.CRC::VerifyDigest(System.UInt32,System.Byte[],System.UInt32,System.UInt32)
extern void CRC_VerifyDigest_m80F70FF7F7F6A3BF93F9687D666834E515C92B8D (void);
// 0x00000192 System.Void SevenZip.CRC::.ctor()
extern void CRC__ctor_mC6EEE59734EB9FA7EBB21C22BBE19C9441361628 (void);
// 0x00000193 System.Boolean SevenZip.CDoubleStream::get_CanRead()
extern void CDoubleStream_get_CanRead_m5060C0A5137418FADD52708FE60664E805B74187 (void);
// 0x00000194 System.Boolean SevenZip.CDoubleStream::get_CanWrite()
extern void CDoubleStream_get_CanWrite_m1FD7CA1571FE179F1990EE80F22898EB290EC509 (void);
// 0x00000195 System.Boolean SevenZip.CDoubleStream::get_CanSeek()
extern void CDoubleStream_get_CanSeek_mDF4A3993B642D0FB469D8C8C2F699D42B9E02D82 (void);
// 0x00000196 System.Int64 SevenZip.CDoubleStream::get_Length()
extern void CDoubleStream_get_Length_mC40EE4C46EBDCF453F6041EC4C1BC6DC8FC6F8D4 (void);
// 0x00000197 System.Int64 SevenZip.CDoubleStream::get_Position()
extern void CDoubleStream_get_Position_mF1FB86CE3358F663EC7E2B8E8FDE03D6FE8B32B9 (void);
// 0x00000198 System.Void SevenZip.CDoubleStream::set_Position(System.Int64)
extern void CDoubleStream_set_Position_mEE3FF43AA23F0FD9F57E3BE5EB64F99F9A551D20 (void);
// 0x00000199 System.Void SevenZip.CDoubleStream::Flush()
extern void CDoubleStream_Flush_mFD80243F66FAAD4AC2272388E12E3E221B64A86E (void);
// 0x0000019A System.Int32 SevenZip.CDoubleStream::Read(System.Byte[],System.Int32,System.Int32)
extern void CDoubleStream_Read_m0F19805CEB5EB26C4AC05987FFC85DCB8834804E (void);
// 0x0000019B System.Void SevenZip.CDoubleStream::Write(System.Byte[],System.Int32,System.Int32)
extern void CDoubleStream_Write_m93DBD5D7046D4E05D3CF41B235D4825615CA7333 (void);
// 0x0000019C System.Int64 SevenZip.CDoubleStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void CDoubleStream_Seek_mC23979073BF1052080F8E6599945AC99FBF2EA4A (void);
// 0x0000019D System.Void SevenZip.CDoubleStream::SetLength(System.Int64)
extern void CDoubleStream_SetLength_m225F929A580C6FF241C1A78A65EF0371DEEF57A5 (void);
// 0x0000019E System.Void SevenZip.CDoubleStream::.ctor()
extern void CDoubleStream__ctor_mAE4EDB07912E3D48C27F32830E828E7CC65A0458 (void);
// 0x0000019F System.Void SevenZip.LzmaAlone::PrintHelp()
extern void LzmaAlone_PrintHelp_mA3F5C0E2DC5FF43F3EBBCA9420187691FE73E51E (void);
// 0x000001A0 System.Boolean SevenZip.LzmaAlone::GetNumber(System.String,System.Int32&)
extern void LzmaAlone_GetNumber_m09941593E9EE8F6F7AEDE2E720DD148485E1F06F (void);
// 0x000001A1 System.Int32 SevenZip.LzmaAlone::IncorrectCommand()
extern void LzmaAlone_IncorrectCommand_mF2F94D2AF7D1BEE667922EC7CDFE1CE80175438B (void);
// 0x000001A2 System.Int32 SevenZip.LzmaAlone::Main2(System.String[])
extern void LzmaAlone_Main2_m38DA78FCD8AE038575ADAF1D124ABF69ABDDACA9 (void);
// 0x000001A3 System.Int32 SevenZip.LzmaAlone::Main(System.String[])
extern void LzmaAlone_Main_m9FD9075DE12A802AFCB20C884FA1C5692863904E (void);
// 0x000001A4 System.Void SevenZip.LzmaAlone::.ctor()
extern void LzmaAlone__ctor_m010E7E66099013E6C24CC590B0AAE79F704B6192 (void);
// 0x000001A5 System.UInt32 SevenZip.LzmaBench::GetLogSize(System.UInt32)
extern void LzmaBench_GetLogSize_m41C6144E9100BDAEFFCEEF67808D73E7907E60C4 (void);
// 0x000001A6 System.UInt64 SevenZip.LzmaBench::MyMultDiv64(System.UInt64,System.UInt64)
extern void LzmaBench_MyMultDiv64_m6BCBAA24BF6045E56FD4431C6D9C904735678D8C (void);
// 0x000001A7 System.UInt64 SevenZip.LzmaBench::GetCompressRating(System.UInt32,System.UInt64,System.UInt64)
extern void LzmaBench_GetCompressRating_mBDDC0AE40A05070280F64021488824BD17092AD0 (void);
// 0x000001A8 System.UInt64 SevenZip.LzmaBench::GetDecompressRating(System.UInt64,System.UInt64,System.UInt64)
extern void LzmaBench_GetDecompressRating_mF753EB237ADEFEBB582E59D8AB1C6FE94FC172A6 (void);
// 0x000001A9 System.UInt64 SevenZip.LzmaBench::GetTotalRating(System.UInt32,System.UInt64,System.UInt64,System.UInt64,System.UInt64,System.UInt64)
extern void LzmaBench_GetTotalRating_m3A5CD12B68B6634D390835A08E58A95A795BD1DA (void);
// 0x000001AA System.Void SevenZip.LzmaBench::PrintValue(System.UInt64)
extern void LzmaBench_PrintValue_mD389B8BFCFE82174F06382E69272C4E823CEB1B0 (void);
// 0x000001AB System.Void SevenZip.LzmaBench::PrintRating(System.UInt64)
extern void LzmaBench_PrintRating_mA7C5217ACA86ED9D1344988B4D5B39FAE560BEEC (void);
// 0x000001AC System.Void SevenZip.LzmaBench::PrintResults(System.UInt32,System.UInt64,System.UInt64,System.Boolean,System.UInt64)
extern void LzmaBench_PrintResults_mE52F0145CBEFDE45A9D37E3CC61566E233A3667A (void);
// 0x000001AD System.Int32 SevenZip.LzmaBench::LzmaBenchmark(System.Int32,System.UInt32)
extern void LzmaBench_LzmaBenchmark_m41F84D49FED9B9CA4F1FEE962877746E58A0AD53 (void);
// 0x000001AE System.Void SevenZip.LzmaBench::.ctor()
extern void LzmaBench__ctor_m11D0914DE62F36A6480BEAA72844B75DAAC70A1A (void);
// 0x000001AF System.Void SevenZip.LzmaBench/CRandomGenerator::.ctor()
extern void CRandomGenerator__ctor_m27F05B1231B661743CFBA88B1677660B0656BAE6 (void);
// 0x000001B0 System.Void SevenZip.LzmaBench/CRandomGenerator::Init()
extern void CRandomGenerator_Init_m1217E671E019AC326DE2CB74EBB73603DFB0072E (void);
// 0x000001B1 System.UInt32 SevenZip.LzmaBench/CRandomGenerator::GetRnd()
extern void CRandomGenerator_GetRnd_m42F1495721B1E4989BFBF64D8881B321B4C3B0EB (void);
// 0x000001B2 System.Void SevenZip.LzmaBench/CBitRandomGenerator::Init()
extern void CBitRandomGenerator_Init_m543F8B977D9AE09FA691D262D1BEB551D8C88888 (void);
// 0x000001B3 System.UInt32 SevenZip.LzmaBench/CBitRandomGenerator::GetRnd(System.Int32)
extern void CBitRandomGenerator_GetRnd_m6C33DD654498C35B561286634E2967556F72D004 (void);
// 0x000001B4 System.Void SevenZip.LzmaBench/CBitRandomGenerator::.ctor()
extern void CBitRandomGenerator__ctor_m9BEBE00097278D19E966564D8D4C07B9BA9BE4FA (void);
// 0x000001B5 System.Void SevenZip.LzmaBench/CBenchRandomGenerator::.ctor()
extern void CBenchRandomGenerator__ctor_m4B67684D0C3BC36B785F6AFF53D53CDD6D546CB9 (void);
// 0x000001B6 System.Void SevenZip.LzmaBench/CBenchRandomGenerator::Set(System.UInt32)
extern void CBenchRandomGenerator_Set_m37C8D4AC6D9B7384884BA0A3EA8524335818008F (void);
// 0x000001B7 System.UInt32 SevenZip.LzmaBench/CBenchRandomGenerator::GetRndBit()
extern void CBenchRandomGenerator_GetRndBit_m1F82A566BE7BA876A2877DC75CDE0F0CA21D46DF (void);
// 0x000001B8 System.UInt32 SevenZip.LzmaBench/CBenchRandomGenerator::GetLogRandBits(System.Int32)
extern void CBenchRandomGenerator_GetLogRandBits_m869214B4FE84873CB6B66B8C15A159D1A110F5E0 (void);
// 0x000001B9 System.UInt32 SevenZip.LzmaBench/CBenchRandomGenerator::GetOffset()
extern void CBenchRandomGenerator_GetOffset_mA9ACB83F9616CCF998C045DC6F24FB9B6006718B (void);
// 0x000001BA System.UInt32 SevenZip.LzmaBench/CBenchRandomGenerator::GetLen1()
extern void CBenchRandomGenerator_GetLen1_m6323ADE59175D885D5C09A102F72C8003FA72FF9 (void);
// 0x000001BB System.UInt32 SevenZip.LzmaBench/CBenchRandomGenerator::GetLen2()
extern void CBenchRandomGenerator_GetLen2_m1C80C3DC8D918A8140E5CB33D78A627BDD7A246B (void);
// 0x000001BC System.Void SevenZip.LzmaBench/CBenchRandomGenerator::Generate()
extern void CBenchRandomGenerator_Generate_m46B741A1CA94E3D8EDB290B690C87FB26401F6D6 (void);
// 0x000001BD System.Void SevenZip.LzmaBench/CrcOutStream::Init()
extern void CrcOutStream_Init_mD15615423C1D13B3F5ACBC82C839E851BFE925F8 (void);
// 0x000001BE System.UInt32 SevenZip.LzmaBench/CrcOutStream::GetDigest()
extern void CrcOutStream_GetDigest_m60767F1AD77C6F12CC63B3100D3BACC43CBAE061 (void);
// 0x000001BF System.Boolean SevenZip.LzmaBench/CrcOutStream::get_CanRead()
extern void CrcOutStream_get_CanRead_m5A40358D70D0C1FC20B9D3F1A036D92D56EFE1FB (void);
// 0x000001C0 System.Boolean SevenZip.LzmaBench/CrcOutStream::get_CanSeek()
extern void CrcOutStream_get_CanSeek_m4BE994A24D1342184583BB0439F0D5283635C583 (void);
// 0x000001C1 System.Boolean SevenZip.LzmaBench/CrcOutStream::get_CanWrite()
extern void CrcOutStream_get_CanWrite_m2E58BE6E86FD21BBCDAA8DB1A1F4783220006B99 (void);
// 0x000001C2 System.Int64 SevenZip.LzmaBench/CrcOutStream::get_Length()
extern void CrcOutStream_get_Length_m964E5BE20E83E1164C6636BA1FEEEA52B17FE136 (void);
// 0x000001C3 System.Int64 SevenZip.LzmaBench/CrcOutStream::get_Position()
extern void CrcOutStream_get_Position_m9B3167B49067ED558B71B4EED194BBD755CFCDD5 (void);
// 0x000001C4 System.Void SevenZip.LzmaBench/CrcOutStream::set_Position(System.Int64)
extern void CrcOutStream_set_Position_mB65A0B8EE2E2C28E82AA984E2ADB21C14C49C53D (void);
// 0x000001C5 System.Void SevenZip.LzmaBench/CrcOutStream::Flush()
extern void CrcOutStream_Flush_m4599297795EB3E89392E158844B6294E7E9617D9 (void);
// 0x000001C6 System.Int64 SevenZip.LzmaBench/CrcOutStream::Seek(System.Int64,System.IO.SeekOrigin)
extern void CrcOutStream_Seek_m3286B99050882FB43C436EE0F76B3FA0B4542A28 (void);
// 0x000001C7 System.Void SevenZip.LzmaBench/CrcOutStream::SetLength(System.Int64)
extern void CrcOutStream_SetLength_mDF25A1F86A5BF2D57C07248ED936B2B33F0AECAB (void);
// 0x000001C8 System.Int32 SevenZip.LzmaBench/CrcOutStream::Read(System.Byte[],System.Int32,System.Int32)
extern void CrcOutStream_Read_m6B3A35C40C0C88B598267FB0FE010EE8A5EE067B (void);
// 0x000001C9 System.Void SevenZip.LzmaBench/CrcOutStream::WriteByte(System.Byte)
extern void CrcOutStream_WriteByte_mEA065EE83708FB9B08A3D7434BC7512463DD06B2 (void);
// 0x000001CA System.Void SevenZip.LzmaBench/CrcOutStream::Write(System.Byte[],System.Int32,System.Int32)
extern void CrcOutStream_Write_m8E45C0161EDE3A3375A81E2A0157D101E16B64BD (void);
// 0x000001CB System.Void SevenZip.LzmaBench/CrcOutStream::.ctor()
extern void CrcOutStream__ctor_mBD399FB1EC42265D2D067EBFD9242E53947477CD (void);
// 0x000001CC System.Void SevenZip.LzmaBench/CProgressInfo::Init()
extern void CProgressInfo_Init_mE6CC26EBC5518F9868B56AFF19D22B79B434105D (void);
// 0x000001CD System.Void SevenZip.LzmaBench/CProgressInfo::SetProgress(System.Int64,System.Int64)
extern void CProgressInfo_SetProgress_m9D4D537D20993B80AFB77B6F52EE5412D5097B4E (void);
// 0x000001CE System.Void SevenZip.LzmaBench/CProgressInfo::.ctor()
extern void CProgressInfo__ctor_m8642C06719EA299630B87FF25AC5F771BB73D4DE (void);
// 0x000001CF System.Void SevenZip.DataErrorException::.ctor()
extern void DataErrorException__ctor_mFAE964EE99BB4427542E8AFA3A96AB934B2038E2 (void);
// 0x000001D0 System.Void SevenZip.InvalidParamException::.ctor()
extern void InvalidParamException__ctor_mA3AE5908C4D2FF5BC359058D9C77EB2F319E81C1 (void);
// 0x000001D1 System.Void SevenZip.ICodeProgress::SetProgress(System.Int64,System.Int64)
// 0x000001D2 System.Void SevenZip.ICoder::Code(System.IO.Stream,System.IO.Stream,System.Int64,System.Int64,SevenZip.ICodeProgress)
// 0x000001D3 System.Void SevenZip.ISetCoderProperties::SetCoderProperties(SevenZip.CoderPropID[],System.Object[])
// 0x000001D4 System.Void SevenZip.IWriteCoderProperties::WriteCoderProperties(System.IO.Stream)
// 0x000001D5 System.Void SevenZip.ISetDecoderProperties::SetDecoderProperties(System.Byte[])
// 0x000001D6 System.Void SevenZip.Compression.RangeCoder.Encoder::SetStream(System.IO.Stream)
extern void Encoder_SetStream_m87913AA6C2C86932066B673C09CA188940BACC82 (void);
// 0x000001D7 System.Void SevenZip.Compression.RangeCoder.Encoder::ReleaseStream()
extern void Encoder_ReleaseStream_m2AA2E64882CE0E83389D6B830FF97B6DD144BE0C (void);
// 0x000001D8 System.Void SevenZip.Compression.RangeCoder.Encoder::Init()
extern void Encoder_Init_m13EF3D6427847BA6B0F84645F1E01CFBD18D1821 (void);
// 0x000001D9 System.Void SevenZip.Compression.RangeCoder.Encoder::FlushData()
extern void Encoder_FlushData_m7ED14A883D2164F0EE30A06E347C6980354741FB (void);
// 0x000001DA System.Void SevenZip.Compression.RangeCoder.Encoder::FlushStream()
extern void Encoder_FlushStream_m861690A1C22E9EED6CC42BFF8BE78198352C55E4 (void);
// 0x000001DB System.Void SevenZip.Compression.RangeCoder.Encoder::CloseStream()
extern void Encoder_CloseStream_mD1DF717FD8C2B82EC56F06B10BAAE16F5ACA913A (void);
// 0x000001DC System.Void SevenZip.Compression.RangeCoder.Encoder::Encode(System.UInt32,System.UInt32,System.UInt32)
extern void Encoder_Encode_m398A62450844859DFD301BA94B9554BE40E95873 (void);
// 0x000001DD System.Void SevenZip.Compression.RangeCoder.Encoder::ShiftLow()
extern void Encoder_ShiftLow_mF506A156F6A06E32A3BC8F1F91944FBA04DDB822 (void);
// 0x000001DE System.Void SevenZip.Compression.RangeCoder.Encoder::EncodeDirectBits(System.UInt32,System.Int32)
extern void Encoder_EncodeDirectBits_m0EC8F378A332BB941335FAB80C7AA7680CDC5FD1 (void);
// 0x000001DF System.Void SevenZip.Compression.RangeCoder.Encoder::EncodeBit(System.UInt32,System.Int32,System.UInt32)
extern void Encoder_EncodeBit_m75FC926A2B1D8FF0D7BE6C63429993325FAF38A0 (void);
// 0x000001E0 System.Int64 SevenZip.Compression.RangeCoder.Encoder::GetProcessedSizeAdd()
extern void Encoder_GetProcessedSizeAdd_mD4DA7E3B928C2EBC97DE6FD925FE3AD2A1FAA96E (void);
// 0x000001E1 System.Void SevenZip.Compression.RangeCoder.Encoder::.ctor()
extern void Encoder__ctor_m20D804BD52871197013B2523C009BEC6812BF2AF (void);
// 0x000001E2 System.Void SevenZip.Compression.RangeCoder.Decoder::Init(System.IO.Stream)
extern void Decoder_Init_m221FEEB1072ED329F543756BDDED53F1987DFC4D (void);
// 0x000001E3 System.Void SevenZip.Compression.RangeCoder.Decoder::ReleaseStream()
extern void Decoder_ReleaseStream_m52B3EDA96370FB3E74FF6FE84E8AAD85C0EC60DD (void);
// 0x000001E4 System.Void SevenZip.Compression.RangeCoder.Decoder::CloseStream()
extern void Decoder_CloseStream_m652DF60156E652B320D89FE5DF83F985D5FFF2A4 (void);
// 0x000001E5 System.Void SevenZip.Compression.RangeCoder.Decoder::Normalize()
extern void Decoder_Normalize_mD1F2BBEF3111433799CB9D6C7F560F8248D30EF8 (void);
// 0x000001E6 System.Void SevenZip.Compression.RangeCoder.Decoder::Normalize2()
extern void Decoder_Normalize2_mFC680B204DFFC5ACF23C1EFBC25DEE9EDB6BDD4E (void);
// 0x000001E7 System.UInt32 SevenZip.Compression.RangeCoder.Decoder::GetThreshold(System.UInt32)
extern void Decoder_GetThreshold_m08EF976172F0B95C707FD35FAC47527BEEC051AD (void);
// 0x000001E8 System.Void SevenZip.Compression.RangeCoder.Decoder::Decode(System.UInt32,System.UInt32,System.UInt32)
extern void Decoder_Decode_m43FF146DEA654F8066A5772C3447C212F2882FA2 (void);
// 0x000001E9 System.UInt32 SevenZip.Compression.RangeCoder.Decoder::DecodeDirectBits(System.Int32)
extern void Decoder_DecodeDirectBits_m91B29A5AC9C84F7870311751DA37F542EA6294B9 (void);
// 0x000001EA System.UInt32 SevenZip.Compression.RangeCoder.Decoder::DecodeBit(System.UInt32,System.Int32)
extern void Decoder_DecodeBit_m4DDBA59EAF5D7948A233DE94D0BEF41802BF03E6 (void);
// 0x000001EB System.Void SevenZip.Compression.RangeCoder.Decoder::.ctor()
extern void Decoder__ctor_mD47AE642523D2D79FC438883442ADD65B4374833 (void);
// 0x000001EC System.Void SevenZip.Compression.RangeCoder.BitEncoder::Init()
extern void BitEncoder_Init_m68426CA151D731E44F85CC306F3E1B9836E5458F (void);
// 0x000001ED System.Void SevenZip.Compression.RangeCoder.BitEncoder::UpdateModel(System.UInt32)
extern void BitEncoder_UpdateModel_m51B34A64E13E85FA2B3184935A8E3F5BAE221737 (void);
// 0x000001EE System.Void SevenZip.Compression.RangeCoder.BitEncoder::Encode(SevenZip.Compression.RangeCoder.Encoder,System.UInt32)
extern void BitEncoder_Encode_mCD58F1E637387163CEAC3D7208F47513D859E22A (void);
// 0x000001EF System.Void SevenZip.Compression.RangeCoder.BitEncoder::.cctor()
extern void BitEncoder__cctor_m00874CCD332C7D1F3047D0840667A42259CC0EDD (void);
// 0x000001F0 System.UInt32 SevenZip.Compression.RangeCoder.BitEncoder::GetPrice(System.UInt32)
extern void BitEncoder_GetPrice_m40EB541A9EF40C99EC13BF1077D202DA91A58A90 (void);
// 0x000001F1 System.UInt32 SevenZip.Compression.RangeCoder.BitEncoder::GetPrice0()
extern void BitEncoder_GetPrice0_m02FA7E2289C8EF43EFDAF814804ABE45A0D43541 (void);
// 0x000001F2 System.UInt32 SevenZip.Compression.RangeCoder.BitEncoder::GetPrice1()
extern void BitEncoder_GetPrice1_mD6A5B31A0488E4CA5EE5F6DDB6DB77C5552AF3E9 (void);
// 0x000001F3 System.Void SevenZip.Compression.RangeCoder.BitDecoder::UpdateModel(System.Int32,System.UInt32)
extern void BitDecoder_UpdateModel_m5CF8F08A017DBC16703DBEA50660E3E8E6C88A7B (void);
// 0x000001F4 System.Void SevenZip.Compression.RangeCoder.BitDecoder::Init()
extern void BitDecoder_Init_m7EA9C8B1CDA48D2F5E2F3929DDB7916D6EA6F4AA (void);
// 0x000001F5 System.UInt32 SevenZip.Compression.RangeCoder.BitDecoder::Decode(SevenZip.Compression.RangeCoder.Decoder)
extern void BitDecoder_Decode_mBCEA763F5D3E5F60E81B2ABE5DCB9B290A8EBAE5 (void);
// 0x000001F6 System.Void SevenZip.Compression.RangeCoder.BitTreeEncoder::.ctor(System.Int32)
extern void BitTreeEncoder__ctor_m5F0DA5C9AC03B1FE073C3B90A90C2F465A306CAB (void);
// 0x000001F7 System.Void SevenZip.Compression.RangeCoder.BitTreeEncoder::Init()
extern void BitTreeEncoder_Init_m0A0B663FF70A3CBFC3C8D68B3863C0FC77C74605 (void);
// 0x000001F8 System.Void SevenZip.Compression.RangeCoder.BitTreeEncoder::Encode(SevenZip.Compression.RangeCoder.Encoder,System.UInt32)
extern void BitTreeEncoder_Encode_mCDDBB85FB3EA58ECFCDD475FFEB02C417A31A116 (void);
// 0x000001F9 System.Void SevenZip.Compression.RangeCoder.BitTreeEncoder::ReverseEncode(SevenZip.Compression.RangeCoder.Encoder,System.UInt32)
extern void BitTreeEncoder_ReverseEncode_m4FC699263B0397DFCAD5BE718A81D2C1FF9C1FFE (void);
// 0x000001FA System.UInt32 SevenZip.Compression.RangeCoder.BitTreeEncoder::GetPrice(System.UInt32)
extern void BitTreeEncoder_GetPrice_m7F02D425B2E6F5D5B32EDD966A7311EEEDA39E46 (void);
// 0x000001FB System.UInt32 SevenZip.Compression.RangeCoder.BitTreeEncoder::ReverseGetPrice(System.UInt32)
extern void BitTreeEncoder_ReverseGetPrice_m15BE0BEBC99B1F31865AFA37848A3DCF1427E59C (void);
// 0x000001FC System.UInt32 SevenZip.Compression.RangeCoder.BitTreeEncoder::ReverseGetPrice(SevenZip.Compression.RangeCoder.BitEncoder[],System.UInt32,System.Int32,System.UInt32)
extern void BitTreeEncoder_ReverseGetPrice_mD4EF00A5B3FC7A03DE33B6286F3B42CBCBF6A22D (void);
// 0x000001FD System.Void SevenZip.Compression.RangeCoder.BitTreeEncoder::ReverseEncode(SevenZip.Compression.RangeCoder.BitEncoder[],System.UInt32,SevenZip.Compression.RangeCoder.Encoder,System.Int32,System.UInt32)
extern void BitTreeEncoder_ReverseEncode_m0F6FB151A1FA471BD91631E132C0A9B90AF6EFAF (void);
// 0x000001FE System.Void SevenZip.Compression.RangeCoder.BitTreeDecoder::.ctor(System.Int32)
extern void BitTreeDecoder__ctor_mAACC7C1607730AF43769ED463FB1F9929A9532CF (void);
// 0x000001FF System.Void SevenZip.Compression.RangeCoder.BitTreeDecoder::Init()
extern void BitTreeDecoder_Init_m777D61C2C472606D0A64286FE0DB66DE6AB45856 (void);
// 0x00000200 System.UInt32 SevenZip.Compression.RangeCoder.BitTreeDecoder::Decode(SevenZip.Compression.RangeCoder.Decoder)
extern void BitTreeDecoder_Decode_m86B18873A6849B019532F906DC4507A75B937810 (void);
// 0x00000201 System.UInt32 SevenZip.Compression.RangeCoder.BitTreeDecoder::ReverseDecode(SevenZip.Compression.RangeCoder.Decoder)
extern void BitTreeDecoder_ReverseDecode_mD907A6D635552C372B458A987213A6D2AE7D31F7 (void);
// 0x00000202 System.UInt32 SevenZip.Compression.RangeCoder.BitTreeDecoder::ReverseDecode(SevenZip.Compression.RangeCoder.BitDecoder[],System.UInt32,SevenZip.Compression.RangeCoder.Decoder,System.Int32)
extern void BitTreeDecoder_ReverseDecode_mC031E5F166F2F9DA57359370F95057393292EA64 (void);
// 0x00000203 System.UInt32 SevenZip.Compression.LZMA.Base::GetLenToPosState(System.UInt32)
extern void Base_GetLenToPosState_m67939A0C9306049FC9AAEA2E973B7A4DACBAA637 (void);
// 0x00000204 System.Void SevenZip.Compression.LZMA.Base::.ctor()
extern void Base__ctor_mF4E7C9566FEDEFED86FD118AF8BAA26488F48E61 (void);
// 0x00000205 System.Void SevenZip.Compression.LZMA.Base/State::Init()
extern void State_Init_m2C7DFCBA2E97DBA2C4F0DDA7FF5C7BF0D28346BF (void);
// 0x00000206 System.Void SevenZip.Compression.LZMA.Base/State::UpdateChar()
extern void State_UpdateChar_m6440A75D3A569E66B39A9B2794ECABB71D6AB517 (void);
// 0x00000207 System.Void SevenZip.Compression.LZMA.Base/State::UpdateMatch()
extern void State_UpdateMatch_m24D8D8072CC69D6C52FE4405AAD1B7B35D46F3BC (void);
// 0x00000208 System.Void SevenZip.Compression.LZMA.Base/State::UpdateRep()
extern void State_UpdateRep_m975104264E0D9A3AC8484C17614E4807F3E51219 (void);
// 0x00000209 System.Void SevenZip.Compression.LZMA.Base/State::UpdateShortRep()
extern void State_UpdateShortRep_m615DAF95E40EBB8DFB08C19BD5EA73F18B4F3547 (void);
// 0x0000020A System.Boolean SevenZip.Compression.LZMA.Base/State::IsCharState()
extern void State_IsCharState_mD09239444CBEBD37FDBF95A5699B4F30DCF79611 (void);
// 0x0000020B System.Void SevenZip.Compression.LZMA.Decoder::.ctor()
extern void Decoder__ctor_mDDDDEB045F01F09EAD0D32614A93446BFAFF0F65 (void);
// 0x0000020C System.Void SevenZip.Compression.LZMA.Decoder::SetDictionarySize(System.UInt32)
extern void Decoder_SetDictionarySize_mE840C63A009B5CC2E341874797F0B67F4F3EE997 (void);
// 0x0000020D System.Void SevenZip.Compression.LZMA.Decoder::SetLiteralProperties(System.Int32,System.Int32)
extern void Decoder_SetLiteralProperties_m0B0E9EC6D6E93FEB88837436B03074F9F56A3602 (void);
// 0x0000020E System.Void SevenZip.Compression.LZMA.Decoder::SetPosBitsProperties(System.Int32)
extern void Decoder_SetPosBitsProperties_mADA9B8DD5721101822809B23B58E7C28C63A0573 (void);
// 0x0000020F System.Void SevenZip.Compression.LZMA.Decoder::Init(System.IO.Stream,System.IO.Stream)
extern void Decoder_Init_m4180E0DF2C7ADD2E7D33DE0622C4A3D82E0D0A34 (void);
// 0x00000210 System.Void SevenZip.Compression.LZMA.Decoder::Code(System.IO.Stream,System.IO.Stream,System.Int64,System.Int64,SevenZip.ICodeProgress)
extern void Decoder_Code_m3113243939972AD7004EC97C6EDE302AFB7319DF (void);
// 0x00000211 System.Void SevenZip.Compression.LZMA.Decoder::SetDecoderProperties(System.Byte[])
extern void Decoder_SetDecoderProperties_m5A19504FC6AAA414092173B3F0E24CAC5C555C90 (void);
// 0x00000212 System.Boolean SevenZip.Compression.LZMA.Decoder::Train(System.IO.Stream)
extern void Decoder_Train_mBF54EDD27F7BD7911AC11B6DE145A25B4D37506D (void);
// 0x00000213 System.Void SevenZip.Compression.LZMA.Decoder/LenDecoder::Create(System.UInt32)
extern void LenDecoder_Create_mCD3DC4DA25337601A87364AD4F3DEAEAE187E105 (void);
// 0x00000214 System.Void SevenZip.Compression.LZMA.Decoder/LenDecoder::Init()
extern void LenDecoder_Init_m0DA88D04AD1D3EA2F973B0D227D6E230E125E9B5 (void);
// 0x00000215 System.UInt32 SevenZip.Compression.LZMA.Decoder/LenDecoder::Decode(SevenZip.Compression.RangeCoder.Decoder,System.UInt32)
extern void LenDecoder_Decode_m3959505C181AEEA8500F7245A4CFA35602246AB0 (void);
// 0x00000216 System.Void SevenZip.Compression.LZMA.Decoder/LenDecoder::.ctor()
extern void LenDecoder__ctor_mFFE500BFCE0698FACBC360D307203F551C5DE20F (void);
// 0x00000217 System.Void SevenZip.Compression.LZMA.Decoder/LiteralDecoder::Create(System.Int32,System.Int32)
extern void LiteralDecoder_Create_mAA7D107BCB9D26B7F92B7962EE03F9C00C0DA251 (void);
// 0x00000218 System.Void SevenZip.Compression.LZMA.Decoder/LiteralDecoder::Init()
extern void LiteralDecoder_Init_m452663AE2B5B01AA9D227E011DF7F7B3B6B0F1FD (void);
// 0x00000219 System.UInt32 SevenZip.Compression.LZMA.Decoder/LiteralDecoder::GetState(System.UInt32,System.Byte)
extern void LiteralDecoder_GetState_m5F4212B08F492B9620C00872DA185A3E190F7749 (void);
// 0x0000021A System.Byte SevenZip.Compression.LZMA.Decoder/LiteralDecoder::DecodeNormal(SevenZip.Compression.RangeCoder.Decoder,System.UInt32,System.Byte)
extern void LiteralDecoder_DecodeNormal_m89B1EF9C679565CB7F6DB4ACD7550DFCA906A9CE (void);
// 0x0000021B System.Byte SevenZip.Compression.LZMA.Decoder/LiteralDecoder::DecodeWithMatchByte(SevenZip.Compression.RangeCoder.Decoder,System.UInt32,System.Byte,System.Byte)
extern void LiteralDecoder_DecodeWithMatchByte_mF3AA32C6B79BBA2DDE5D004A673239E6614A426B (void);
// 0x0000021C System.Void SevenZip.Compression.LZMA.Decoder/LiteralDecoder::.ctor()
extern void LiteralDecoder__ctor_m4E7D227A3D749FA5D3CB84AF81CC2E05B4051137 (void);
// 0x0000021D System.Void SevenZip.Compression.LZMA.Decoder/LiteralDecoder/Decoder2::Create()
extern void Decoder2_Create_m434789D58C48A4C42D1BBAF67312DB317DFAC198 (void);
// 0x0000021E System.Void SevenZip.Compression.LZMA.Decoder/LiteralDecoder/Decoder2::Init()
extern void Decoder2_Init_m1317F802E071CF00C530D02199453A93F109B15A (void);
// 0x0000021F System.Byte SevenZip.Compression.LZMA.Decoder/LiteralDecoder/Decoder2::DecodeNormal(SevenZip.Compression.RangeCoder.Decoder)
extern void Decoder2_DecodeNormal_m20A55707B43292AD6AE85106A0E2E8151C38CB22 (void);
// 0x00000220 System.Byte SevenZip.Compression.LZMA.Decoder/LiteralDecoder/Decoder2::DecodeWithMatchByte(SevenZip.Compression.RangeCoder.Decoder,System.Byte)
extern void Decoder2_DecodeWithMatchByte_m3E243459999F5EC8F0212E810BC668ED2067B27A (void);
// 0x00000221 System.Void SevenZip.Compression.LZMA.Encoder::.cctor()
extern void Encoder__cctor_m904379D9FBD92EAFFF12D89897CD055A53A42328 (void);
// 0x00000222 System.UInt32 SevenZip.Compression.LZMA.Encoder::GetPosSlot(System.UInt32)
extern void Encoder_GetPosSlot_m3053180D2945043563DD3B9393B911A1869A77DD (void);
// 0x00000223 System.UInt32 SevenZip.Compression.LZMA.Encoder::GetPosSlot2(System.UInt32)
extern void Encoder_GetPosSlot2_mC15EEF960E842F2E7217063572158B78CA1D9BBD (void);
// 0x00000224 System.Void SevenZip.Compression.LZMA.Encoder::BaseInit()
extern void Encoder_BaseInit_m8A6C90546ABE82A188C4CF3FE23071AAF84595BE (void);
// 0x00000225 System.Void SevenZip.Compression.LZMA.Encoder::Create()
extern void Encoder_Create_m40ADF517795C813437B29009BBF729956A077213 (void);
// 0x00000226 System.Void SevenZip.Compression.LZMA.Encoder::.ctor()
extern void Encoder__ctor_m80F5A4953728599944772AC2299B9F850D5E10C1 (void);
// 0x00000227 System.Void SevenZip.Compression.LZMA.Encoder::SetWriteEndMarkerMode(System.Boolean)
extern void Encoder_SetWriteEndMarkerMode_mDBCCF1276B46DA5EA3D2ED0AF56CE1819F73B669 (void);
// 0x00000228 System.Void SevenZip.Compression.LZMA.Encoder::Init()
extern void Encoder_Init_mA2B40AE20643BE05950A4F95E750BA432A4CF75F (void);
// 0x00000229 System.Void SevenZip.Compression.LZMA.Encoder::ReadMatchDistances(System.UInt32&,System.UInt32&)
extern void Encoder_ReadMatchDistances_m50B63384861CDF22505DB5644678CACCD87494E2 (void);
// 0x0000022A System.Void SevenZip.Compression.LZMA.Encoder::MovePos(System.UInt32)
extern void Encoder_MovePos_mB1DEF79455AD173D6AC5C2AA6188119D8133A1DC (void);
// 0x0000022B System.UInt32 SevenZip.Compression.LZMA.Encoder::GetRepLen1Price(SevenZip.Compression.LZMA.Base/State,System.UInt32)
extern void Encoder_GetRepLen1Price_m5E0FA43C565AC943921D5E8B644CA89936781AE9 (void);
// 0x0000022C System.UInt32 SevenZip.Compression.LZMA.Encoder::GetPureRepPrice(System.UInt32,SevenZip.Compression.LZMA.Base/State,System.UInt32)
extern void Encoder_GetPureRepPrice_mDCFECC0A28D28968BFAD79E34541FAF6B2A1E952 (void);
// 0x0000022D System.UInt32 SevenZip.Compression.LZMA.Encoder::GetRepPrice(System.UInt32,System.UInt32,SevenZip.Compression.LZMA.Base/State,System.UInt32)
extern void Encoder_GetRepPrice_mC87B302D13B41CE7C66F0B895E1A221174E2E6A7 (void);
// 0x0000022E System.UInt32 SevenZip.Compression.LZMA.Encoder::GetPosLenPrice(System.UInt32,System.UInt32,System.UInt32)
extern void Encoder_GetPosLenPrice_mD289C27BD1D43A529ECBADAAFD2C08E3DD3BB499 (void);
// 0x0000022F System.UInt32 SevenZip.Compression.LZMA.Encoder::Backward(System.UInt32&,System.UInt32)
extern void Encoder_Backward_mBCB4B7DE5F14A2EC438698526D49B9477F3E19A3 (void);
// 0x00000230 System.UInt32 SevenZip.Compression.LZMA.Encoder::GetOptimum(System.UInt32,System.UInt32&)
extern void Encoder_GetOptimum_mB72B5EE5AC0A852261985A45F6F010DE33233959 (void);
// 0x00000231 System.Boolean SevenZip.Compression.LZMA.Encoder::ChangePair(System.UInt32,System.UInt32)
extern void Encoder_ChangePair_m647A1017359F4C36CF39091B88B132019E58DE3E (void);
// 0x00000232 System.Void SevenZip.Compression.LZMA.Encoder::WriteEndMarker(System.UInt32)
extern void Encoder_WriteEndMarker_m30C1E4F47496A79103A1AC799A6FEB397B10AD50 (void);
// 0x00000233 System.Void SevenZip.Compression.LZMA.Encoder::Flush(System.UInt32)
extern void Encoder_Flush_mE1A3BDFB6556135386DF58ACC29E24908811D965 (void);
// 0x00000234 System.Void SevenZip.Compression.LZMA.Encoder::CodeOneBlock(System.Int64&,System.Int64&,System.Boolean&)
extern void Encoder_CodeOneBlock_m6E0AEABD9669941A79897D8B899E9D5E0EF65ADA (void);
// 0x00000235 System.Void SevenZip.Compression.LZMA.Encoder::ReleaseMFStream()
extern void Encoder_ReleaseMFStream_m1E317AAE9EED580BA684312CBD36EB4504C0CFAF (void);
// 0x00000236 System.Void SevenZip.Compression.LZMA.Encoder::SetOutStream(System.IO.Stream)
extern void Encoder_SetOutStream_m958BED8327D46F2DE7919CC3CA44F9373FF4FB1C (void);
// 0x00000237 System.Void SevenZip.Compression.LZMA.Encoder::ReleaseOutStream()
extern void Encoder_ReleaseOutStream_m328889869428B51DB63AC4AC5B941F9BD16B03B1 (void);
// 0x00000238 System.Void SevenZip.Compression.LZMA.Encoder::ReleaseStreams()
extern void Encoder_ReleaseStreams_m54FF38FC875C285AC8A7B429B48E0B4B37CBE870 (void);
// 0x00000239 System.Void SevenZip.Compression.LZMA.Encoder::SetStreams(System.IO.Stream,System.IO.Stream,System.Int64,System.Int64)
extern void Encoder_SetStreams_mC61C032BF93ECA1549FA694BF29F462DA42F8942 (void);
// 0x0000023A System.Void SevenZip.Compression.LZMA.Encoder::Code(System.IO.Stream,System.IO.Stream,System.Int64,System.Int64,SevenZip.ICodeProgress)
extern void Encoder_Code_m09F80B2FC86FB59D645742C5E8D3B1BF07AD2871 (void);
// 0x0000023B System.Void SevenZip.Compression.LZMA.Encoder::WriteCoderProperties(System.IO.Stream)
extern void Encoder_WriteCoderProperties_m5FA4E6313A85A0D0D641867C74F92FFC4FDA6C70 (void);
// 0x0000023C System.Void SevenZip.Compression.LZMA.Encoder::FillDistancesPrices()
extern void Encoder_FillDistancesPrices_m4D81890FF833DDCEE6BEAA2B7ACC2A32D478F013 (void);
// 0x0000023D System.Void SevenZip.Compression.LZMA.Encoder::FillAlignPrices()
extern void Encoder_FillAlignPrices_m0C9540F3259AA2B9BA5619093734313FE79867CF (void);
// 0x0000023E System.Int32 SevenZip.Compression.LZMA.Encoder::FindMatchFinder(System.String)
extern void Encoder_FindMatchFinder_m8D2DF28FE35A05CAF59814B3B5C8F6B731322F9E (void);
// 0x0000023F System.Void SevenZip.Compression.LZMA.Encoder::SetCoderProperties(SevenZip.CoderPropID[],System.Object[])
extern void Encoder_SetCoderProperties_m60402854437C219C22653A8C48E23D0376AB6DE7 (void);
// 0x00000240 System.Void SevenZip.Compression.LZMA.Encoder::SetTrainSize(System.UInt32)
extern void Encoder_SetTrainSize_m289E652AA20786AE5F6E52C19A0F26B9BEBB4B21 (void);
// 0x00000241 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder::Create(System.Int32,System.Int32)
extern void LiteralEncoder_Create_m844B7CC4D876A2DE8347CB58DFF1E79C6595E65F (void);
// 0x00000242 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder::Init()
extern void LiteralEncoder_Init_m1D2A98DA484A417A47C47C7099F4C0185B87DD63 (void);
// 0x00000243 SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2 SevenZip.Compression.LZMA.Encoder/LiteralEncoder::GetSubCoder(System.UInt32,System.Byte)
extern void LiteralEncoder_GetSubCoder_mFD16D22EA8FF3B1DEE2D248ED150C74CBB0F1C98 (void);
// 0x00000244 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder::.ctor()
extern void LiteralEncoder__ctor_m4AB69E9FC19D83054FC50B7025A2B25F953649C9 (void);
// 0x00000245 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2::Create()
extern void Encoder2_Create_m2EFD56B68C6C8D9E48DE0F454F2378B867D7D705 (void);
// 0x00000246 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2::Init()
extern void Encoder2_Init_m7BF50A1BE4C1A16A8A59F50FA08EB42BC21870C9 (void);
// 0x00000247 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2::Encode(SevenZip.Compression.RangeCoder.Encoder,System.Byte)
extern void Encoder2_Encode_m6A0160C1B25BD97EA8D4141CF3AA2B009B18B040 (void);
// 0x00000248 System.Void SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2::EncodeMatched(SevenZip.Compression.RangeCoder.Encoder,System.Byte,System.Byte)
extern void Encoder2_EncodeMatched_m40CC1C9FAA87F4A0DE7B9EAE5670B4E594557DC6 (void);
// 0x00000249 System.UInt32 SevenZip.Compression.LZMA.Encoder/LiteralEncoder/Encoder2::GetPrice(System.Boolean,System.Byte,System.Byte)
extern void Encoder2_GetPrice_m5F4E123994682AD7B7745D7DAB30C44FFFA3E4F9 (void);
// 0x0000024A System.Void SevenZip.Compression.LZMA.Encoder/LenEncoder::.ctor()
extern void LenEncoder__ctor_mFA498C3CF87F00FFE58AF22747840AB89693E7BC (void);
// 0x0000024B System.Void SevenZip.Compression.LZMA.Encoder/LenEncoder::Init(System.UInt32)
extern void LenEncoder_Init_mCB20EB7AE2DC2D602F671F980E347CF90E7AF4B4 (void);
// 0x0000024C System.Void SevenZip.Compression.LZMA.Encoder/LenEncoder::Encode(SevenZip.Compression.RangeCoder.Encoder,System.UInt32,System.UInt32)
extern void LenEncoder_Encode_m5C5A66E2AE0E2CEC12AC66C1EAAFB20E8D7305A1 (void);
// 0x0000024D System.Void SevenZip.Compression.LZMA.Encoder/LenEncoder::SetPrices(System.UInt32,System.UInt32,System.UInt32[],System.UInt32)
extern void LenEncoder_SetPrices_m5E4FFDC23F07D67E39DD8C0A5CF9C7D13A7122AD (void);
// 0x0000024E System.Void SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::SetTableSize(System.UInt32)
extern void LenPriceTableEncoder_SetTableSize_m3782A45635CBB4364C23B3BA319D2C26BB35EC66 (void);
// 0x0000024F System.UInt32 SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::GetPrice(System.UInt32,System.UInt32)
extern void LenPriceTableEncoder_GetPrice_m34433F8B9A40D45BD6425AD53FEC96EC37592A8A (void);
// 0x00000250 System.Void SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::UpdateTable(System.UInt32)
extern void LenPriceTableEncoder_UpdateTable_m7A4C60ACC6FB0510269DA9DBBEE779B9223377F6 (void);
// 0x00000251 System.Void SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::UpdateTables(System.UInt32)
extern void LenPriceTableEncoder_UpdateTables_m94C54EE5ADAB9F428658A252B0ACF8BDAA0C3FEA (void);
// 0x00000252 System.Void SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::Encode(SevenZip.Compression.RangeCoder.Encoder,System.UInt32,System.UInt32)
extern void LenPriceTableEncoder_Encode_m5D5C62DBBC98FEFF347B81EDFCE4DA706E56A4B5 (void);
// 0x00000253 System.Void SevenZip.Compression.LZMA.Encoder/LenPriceTableEncoder::.ctor()
extern void LenPriceTableEncoder__ctor_m20CFDAA4325B19C1F4ACBC9B38D54BC8B8F7277A (void);
// 0x00000254 System.Void SevenZip.Compression.LZMA.Encoder/Optimal::MakeAsChar()
extern void Optimal_MakeAsChar_m9ABE4B0B07625B22791F04C27E7A0CB2136194FB (void);
// 0x00000255 System.Void SevenZip.Compression.LZMA.Encoder/Optimal::MakeAsShortRep()
extern void Optimal_MakeAsShortRep_mF3E03AF06E3CEA77FA71BDC4C59B22F1FF75F261 (void);
// 0x00000256 System.Boolean SevenZip.Compression.LZMA.Encoder/Optimal::IsShortRep()
extern void Optimal_IsShortRep_mB7D67F2732B810C0E5CDBEFBA1BEC689EDCC328D (void);
// 0x00000257 System.Void SevenZip.Compression.LZMA.Encoder/Optimal::.ctor()
extern void Optimal__ctor_m3FB6ABBDD35AFBDC0E329250861F2F9393C62732 (void);
// 0x00000258 System.Void SevenZip.Compression.LZ.IInWindowStream::SetStream(System.IO.Stream)
// 0x00000259 System.Void SevenZip.Compression.LZ.IInWindowStream::Init()
// 0x0000025A System.Void SevenZip.Compression.LZ.IInWindowStream::ReleaseStream()
// 0x0000025B System.Byte SevenZip.Compression.LZ.IInWindowStream::GetIndexByte(System.Int32)
// 0x0000025C System.UInt32 SevenZip.Compression.LZ.IInWindowStream::GetMatchLen(System.Int32,System.UInt32,System.UInt32)
// 0x0000025D System.UInt32 SevenZip.Compression.LZ.IInWindowStream::GetNumAvailableBytes()
// 0x0000025E System.Void SevenZip.Compression.LZ.IMatchFinder::Create(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
// 0x0000025F System.UInt32 SevenZip.Compression.LZ.IMatchFinder::GetMatches(System.UInt32[])
// 0x00000260 System.Void SevenZip.Compression.LZ.IMatchFinder::Skip(System.UInt32)
// 0x00000261 System.Void SevenZip.Compression.LZ.BinTree::SetType(System.Int32)
extern void BinTree_SetType_mF7048130CC2F17776229F63CCAD6F57ADF365F04 (void);
// 0x00000262 System.Void SevenZip.Compression.LZ.BinTree::SetStream(System.IO.Stream)
extern void BinTree_SetStream_mCD63057CD4EDA36D1A82D56D83B844487B90A518 (void);
// 0x00000263 System.Void SevenZip.Compression.LZ.BinTree::ReleaseStream()
extern void BinTree_ReleaseStream_mB27FDCDAB66C744190688AF450D130B774186D65 (void);
// 0x00000264 System.Void SevenZip.Compression.LZ.BinTree::Init()
extern void BinTree_Init_mA907B8CAA1CA55C4271A5CE52C6B9215445770EA (void);
// 0x00000265 System.Void SevenZip.Compression.LZ.BinTree::MovePos()
extern void BinTree_MovePos_m8E9E7DB8F7227CD54E15CA289F1E3B3174D13DD2 (void);
// 0x00000266 System.Byte SevenZip.Compression.LZ.BinTree::GetIndexByte(System.Int32)
extern void BinTree_GetIndexByte_m8A695321CE0D96D2524DD050109DFE48F1286D28 (void);
// 0x00000267 System.UInt32 SevenZip.Compression.LZ.BinTree::GetMatchLen(System.Int32,System.UInt32,System.UInt32)
extern void BinTree_GetMatchLen_m74E4C6B3390A1A8D83FF72C8E6C70EA739E374C4 (void);
// 0x00000268 System.UInt32 SevenZip.Compression.LZ.BinTree::GetNumAvailableBytes()
extern void BinTree_GetNumAvailableBytes_m4119C3A869C7B2264BF5D5F6CB3FF945C118ECF5 (void);
// 0x00000269 System.Void SevenZip.Compression.LZ.BinTree::Create(System.UInt32,System.UInt32,System.UInt32,System.UInt32)
extern void BinTree_Create_m82B68043BD459A38FBBFC40A2D1350FBBD1487E5 (void);
// 0x0000026A System.UInt32 SevenZip.Compression.LZ.BinTree::GetMatches(System.UInt32[])
extern void BinTree_GetMatches_m8A3F09A5472E784DF429241398ACF83928DC8253 (void);
// 0x0000026B System.Void SevenZip.Compression.LZ.BinTree::Skip(System.UInt32)
extern void BinTree_Skip_m5835FFC65918A658118B82289B1DBEB54039F767 (void);
// 0x0000026C System.Void SevenZip.Compression.LZ.BinTree::NormalizeLinks(System.UInt32[],System.UInt32,System.UInt32)
extern void BinTree_NormalizeLinks_mEC655AEE21AE0EC66FD0D329D56143935D8158CD (void);
// 0x0000026D System.Void SevenZip.Compression.LZ.BinTree::Normalize()
extern void BinTree_Normalize_m2DC38A434D1E156140F6658BB10A8A60EEBBB87C (void);
// 0x0000026E System.Void SevenZip.Compression.LZ.BinTree::SetCutValue(System.UInt32)
extern void BinTree_SetCutValue_m0C646F5C232E8EE83733DF42E13A27E229E82EB9 (void);
// 0x0000026F System.Void SevenZip.Compression.LZ.BinTree::.ctor()
extern void BinTree__ctor_m6E9B35C783832E205CAC6D0E85254FCEF098793D (void);
// 0x00000270 System.Void SevenZip.Compression.LZ.InWindow::MoveBlock()
extern void InWindow_MoveBlock_m06FD6CA0E8DC9136AEDA4A08258D67417464354C (void);
// 0x00000271 System.Void SevenZip.Compression.LZ.InWindow::ReadBlock()
extern void InWindow_ReadBlock_m2EFC773855F92AA1AC2307EF8C8825CA7F489917 (void);
// 0x00000272 System.Void SevenZip.Compression.LZ.InWindow::Free()
extern void InWindow_Free_m6A3E286EDB95287BF35068BEFABBE3B6AFE898EB (void);
// 0x00000273 System.Void SevenZip.Compression.LZ.InWindow::Create(System.UInt32,System.UInt32,System.UInt32)
extern void InWindow_Create_m4582B01803966271E73CC0C4A3F0A9095AF1C1D8 (void);
// 0x00000274 System.Void SevenZip.Compression.LZ.InWindow::SetStream(System.IO.Stream)
extern void InWindow_SetStream_m3FD3756AB33D319D87A0520126223F964DDBBD9D (void);
// 0x00000275 System.Void SevenZip.Compression.LZ.InWindow::ReleaseStream()
extern void InWindow_ReleaseStream_mBCBE6CF63BE912AEE4E34F6C9C989F0A2CD5C41A (void);
// 0x00000276 System.Void SevenZip.Compression.LZ.InWindow::Init()
extern void InWindow_Init_m31606786F9FE7AC0197630B1C0B316A5223B0E20 (void);
// 0x00000277 System.Void SevenZip.Compression.LZ.InWindow::MovePos()
extern void InWindow_MovePos_m4A4E5ACDEF823FE8E2E8798DEFCD91DB3F276934 (void);
// 0x00000278 System.Byte SevenZip.Compression.LZ.InWindow::GetIndexByte(System.Int32)
extern void InWindow_GetIndexByte_mD8D377EFB6DF5076A0A0656AA20061C73395098A (void);
// 0x00000279 System.UInt32 SevenZip.Compression.LZ.InWindow::GetMatchLen(System.Int32,System.UInt32,System.UInt32)
extern void InWindow_GetMatchLen_m1D091B1309886259F3B31BF8421AC614081EE250 (void);
// 0x0000027A System.UInt32 SevenZip.Compression.LZ.InWindow::GetNumAvailableBytes()
extern void InWindow_GetNumAvailableBytes_m47E431B2DA3B04F0051C3DF5978521131AF1D33A (void);
// 0x0000027B System.Void SevenZip.Compression.LZ.InWindow::ReduceOffsets(System.Int32)
extern void InWindow_ReduceOffsets_m561D4491BA9E730EF6FD0C9A48E3C79420A7253E (void);
// 0x0000027C System.Void SevenZip.Compression.LZ.InWindow::.ctor()
extern void InWindow__ctor_mA032BE6BADEFAD6E7D3E125317029E52BABED488 (void);
// 0x0000027D System.Void SevenZip.Compression.LZ.OutWindow::Create(System.UInt32)
extern void OutWindow_Create_m297D76E8B4421BC651C24E0FA75AAD41431DF0EE (void);
// 0x0000027E System.Void SevenZip.Compression.LZ.OutWindow::Init(System.IO.Stream,System.Boolean)
extern void OutWindow_Init_m42DCD6EE7C17E813DA8F8E92CD49EEE1FEF4CCCD (void);
// 0x0000027F System.Boolean SevenZip.Compression.LZ.OutWindow::Train(System.IO.Stream)
extern void OutWindow_Train_m998C5DC98908C1265D29734BBF96F15A35FE8249 (void);
// 0x00000280 System.Void SevenZip.Compression.LZ.OutWindow::ReleaseStream()
extern void OutWindow_ReleaseStream_m4AEE4EEA2F074830F4BF5B81587B18E089E12655 (void);
// 0x00000281 System.Void SevenZip.Compression.LZ.OutWindow::Flush()
extern void OutWindow_Flush_m1C7B5B20BCEC59A088DDB252B522422DB7BD68AB (void);
// 0x00000282 System.Void SevenZip.Compression.LZ.OutWindow::CopyBlock(System.UInt32,System.UInt32)
extern void OutWindow_CopyBlock_m2E07B5AF59C4892D7C73C2CCAF738098E62D0D9D (void);
// 0x00000283 System.Void SevenZip.Compression.LZ.OutWindow::PutByte(System.Byte)
extern void OutWindow_PutByte_m1992D1AA6471D3D21A1C738E0501B6288D923627 (void);
// 0x00000284 System.Byte SevenZip.Compression.LZ.OutWindow::GetByte(System.UInt32)
extern void OutWindow_GetByte_mF3CFE942C5427EE578B5D7233E3B9D6CCE596B06 (void);
// 0x00000285 System.Void SevenZip.Compression.LZ.OutWindow::.ctor()
extern void OutWindow__ctor_m07E707DF1D5B7012DCE5080C201125600AE25146 (void);
// 0x00000286 System.Void SevenZip.Buffer.InBuffer::.ctor(System.UInt32)
extern void InBuffer__ctor_m1519854005664D99A38320EAC4193D2FFE4B5E35 (void);
// 0x00000287 System.Void SevenZip.Buffer.InBuffer::Init(System.IO.Stream)
extern void InBuffer_Init_mB7A99222B8786DF353FC2BCC1149FB7E489637D5 (void);
// 0x00000288 System.Boolean SevenZip.Buffer.InBuffer::ReadBlock()
extern void InBuffer_ReadBlock_m5EA871C9102AA90461C31291B821BF0556DE1700 (void);
// 0x00000289 System.Void SevenZip.Buffer.InBuffer::ReleaseStream()
extern void InBuffer_ReleaseStream_m5349B2EEE46E43A9E39E03120B8564BFE8091663 (void);
// 0x0000028A System.Boolean SevenZip.Buffer.InBuffer::ReadByte(System.Byte)
extern void InBuffer_ReadByte_mA84D801E7CD1CFFA14C97BB854EF680E3F511438 (void);
// 0x0000028B System.Byte SevenZip.Buffer.InBuffer::ReadByte()
extern void InBuffer_ReadByte_m0E7F1B67484CA2175FD9D3E593544679D61B86DB (void);
// 0x0000028C System.UInt64 SevenZip.Buffer.InBuffer::GetProcessedSize()
extern void InBuffer_GetProcessedSize_mC77A0BC4E80664004CA287A25C477ACA14B408CE (void);
// 0x0000028D System.Void SevenZip.Buffer.OutBuffer::.ctor(System.UInt32)
extern void OutBuffer__ctor_mC219CDFE2418F8F0989ADFD4703CC0E491FAA80F (void);
// 0x0000028E System.Void SevenZip.Buffer.OutBuffer::SetStream(System.IO.Stream)
extern void OutBuffer_SetStream_mCD5C2CD28A3117A959364818880D808506F1CF8F (void);
// 0x0000028F System.Void SevenZip.Buffer.OutBuffer::FlushStream()
extern void OutBuffer_FlushStream_mA74FC9E653629F2F6828CF2CE8D77B45652129D5 (void);
// 0x00000290 System.Void SevenZip.Buffer.OutBuffer::CloseStream()
extern void OutBuffer_CloseStream_m7B0E84847EF253A20F49EDD470FFD93E8E258471 (void);
// 0x00000291 System.Void SevenZip.Buffer.OutBuffer::ReleaseStream()
extern void OutBuffer_ReleaseStream_m97AEE4C40E4642FF4C9752F5F0A34345508E8971 (void);
// 0x00000292 System.Void SevenZip.Buffer.OutBuffer::Init()
extern void OutBuffer_Init_m2F94DE0DD7A61836D96CB70BF455E24F79C1023B (void);
// 0x00000293 System.Void SevenZip.Buffer.OutBuffer::WriteByte(System.Byte)
extern void OutBuffer_WriteByte_m61AD60E103BB5092DA2B41D1F17AE5F856B2F9F4 (void);
// 0x00000294 System.Void SevenZip.Buffer.OutBuffer::FlushData()
extern void OutBuffer_FlushData_m872430FB7F724D504C377F48BD5FA6A3785B13C5 (void);
// 0x00000295 System.UInt64 SevenZip.Buffer.OutBuffer::GetProcessedSize()
extern void OutBuffer_GetProcessedSize_mFB8261D78ECFAEB0D72D0DEC9CF7CFA5A2B12550 (void);
// 0x00000296 System.Void SevenZip.CommandLineParser.SwitchForm::.ctor(System.String,SevenZip.CommandLineParser.SwitchType,System.Boolean,System.Int32,System.Int32,System.String)
extern void SwitchForm__ctor_m3511B91754817A339912089D3F1554DC7C0DDC55 (void);
// 0x00000297 System.Void SevenZip.CommandLineParser.SwitchForm::.ctor(System.String,SevenZip.CommandLineParser.SwitchType,System.Boolean,System.Int32)
extern void SwitchForm__ctor_mD6BD25C5620B3589E7B3A23354DFCC2C3FD6DE2F (void);
// 0x00000298 System.Void SevenZip.CommandLineParser.SwitchForm::.ctor(System.String,SevenZip.CommandLineParser.SwitchType,System.Boolean)
extern void SwitchForm__ctor_m6710ADCDAF1EAE7E477C698E8C01432704DA7E5A (void);
// 0x00000299 System.Void SevenZip.CommandLineParser.SwitchResult::.ctor()
extern void SwitchResult__ctor_m0AFED1002B17157D5B1A01029271BFF97B658F45 (void);
// 0x0000029A System.Void SevenZip.CommandLineParser.Parser::.ctor(System.Int32)
extern void Parser__ctor_m4115EA2710211958519E7E6251249ADFBAB2DDAF (void);
// 0x0000029B System.Boolean SevenZip.CommandLineParser.Parser::ParseString(System.String,SevenZip.CommandLineParser.SwitchForm[])
extern void Parser_ParseString_m41BADFED49F04FD70F96C4C7B273D3E732631C7A (void);
// 0x0000029C System.Void SevenZip.CommandLineParser.Parser::ParseStrings(SevenZip.CommandLineParser.SwitchForm[],System.String[])
extern void Parser_ParseStrings_mE066889B309C8C59D359CA08BB561560874EDE95 (void);
// 0x0000029D SevenZip.CommandLineParser.SwitchResult SevenZip.CommandLineParser.Parser::get_Item(System.Int32)
extern void Parser_get_Item_m6E0C83B2C60167230C59CA4C6CB2F30F7973972D (void);
// 0x0000029E System.Int32 SevenZip.CommandLineParser.Parser::ParseCommand(SevenZip.CommandLineParser.CommandForm[],System.String,System.String&)
extern void Parser_ParseCommand_m763C1F67499ABEE651D2130E03D972F810996BA2 (void);
// 0x0000029F System.Boolean SevenZip.CommandLineParser.Parser::ParseSubCharsCommand(System.Int32,SevenZip.CommandLineParser.CommandSubCharsSet[],System.String,System.Collections.ArrayList)
extern void Parser_ParseSubCharsCommand_mC6ED1B8784F3F4C1090A5412E9B2E4906460BCFE (void);
// 0x000002A0 System.Boolean SevenZip.CommandLineParser.Parser::IsItSwitchChar(System.Char)
extern void Parser_IsItSwitchChar_mBAA397855C963D11B309395FEEBDD3BF57C34722 (void);
// 0x000002A1 System.Void SevenZip.CommandLineParser.CommandForm::.ctor(System.String,System.Boolean)
extern void CommandForm__ctor_m1DA3E356F916F3B483DB4B41E0ECDFDCACF01933 (void);
// 0x000002A2 System.Void SevenZip.CommandLineParser.CommandSubCharsSet::.ctor()
extern void CommandSubCharsSet__ctor_m4BC3AF6B894ECEF54D58E88051A6C59C911E0723 (void);
static Il2CppMethodPointer s_methodPointers[674] = 
{
	MeshExtrusion_ExtrudeMesh_m87433CED8E205FCE7A5647D594CC23979F30A115,
	MeshExtrusion_ExtrudeMesh_mF89AD0571E67F78A6264492E80C17E1748302005,
	MeshExtrusion_BuildManifoldEdges_m3655914CA59A1FC412956017511CBA80C0B30A95,
	MeshExtrusion_BuildEdges_m0D0E827AA1F2E52DFF3F65472C1953D6187EF542,
	MeshExtrusion__ctor_m0829220D1D75EACB6E73E100E8A39A4C4C19D99D,
	Edge__ctor_m528CF5C16394170E67D3C1AADDB767A46F620A6B,
	SmoothRandom_GetVector3_m15000652D189247BF6A3A4FB33251B6128E3F416,
	SmoothRandom_Get_m4AB58E36640AF24A1D7AB403D659E536B8EEE483,
	SmoothRandom_Get_mEB0BB8E85E33326F19C843316011EC01C40B2C7A,
	SmoothRandom__ctor_mEF743C35596B66F0A2A0DD3744A68FF9323A0E65,
	Perlin_s_curve_m556DF6067F50F3E59EFE8F0785AC002D76FF3D28,
	Perlin_lerp_mE1B6A29030803E432AD444722DA5A84F5D51E2E4,
	Perlin_setup_m356F938F9EFC729EAF61849090E37DC427C433F9,
	Perlin_at2_mEF746B1C3BF4BACFA0B4D80BA2D77FAEB4FEBAC9,
	Perlin_at3_mB73855374FFFA3DA08FB71D57A451E7E613DC16D,
	Perlin_Noise_m3EE22F6CABAEA87036904C24A3A35239FD59810C,
	Perlin_Noise_m6459430D3FCC023DEBABE54F78BB9541B69A3BE7,
	Perlin_Noise_mE78272BA1D89F0CB6823745DEB1000D6BC9339A2,
	Perlin_normalize2_m110D0ED15A8420645C0C4A989D62FF4482A7E052,
	Perlin_normalize3_m5AC971BD1747EB99F80F99382A99D43E304D1A8B,
	Perlin__ctor_m3E6D13BD9F5BBBFB8700EEBD4BDFA80EE38D0508,
	FractalNoise__ctor_mEC8CF46DA7530710D5A54C9AB405A2DD5CB567EC,
	FractalNoise__ctor_m6404B47A8B3C8D0A0AFAB262AE09400845E62EA0,
	FractalNoise_HybridMultifractal_m27739972BF39CDF4A7CA78A8A78834FBF506857E,
	FractalNoise_RidgedMultifractal_mA0BC0309D73044A6880C6107E49316034778CECC,
	FractalNoise_BrownianMotion_m979FE44AFDBEE881153C0A0C21FB05ADB71755AF,
	DOTweenModuleAudio_DOFade_m1D693C3CE476AABDF1973BE1CDB974276D71307A,
	DOTweenModuleAudio_DOPitch_m21C03AF57AD7EEC7C1CF82CA7F660A58BD17D7CF,
	DOTweenModuleAudio_DOSetFloat_m95C5B73E2208425BB0D225DBBE705A62C34ADB8B,
	DOTweenModuleAudio_DOComplete_mB34A0C4B5156B4D5D7F88E1F1B3549F0ED35048C,
	DOTweenModuleAudio_DOKill_mAF9948DBD5491192943527B5FD65561EB5E6DA23,
	DOTweenModuleAudio_DOFlip_mA5DAA9E654CBF4C302F7376463DC80EF9FE480B0,
	DOTweenModuleAudio_DOGoto_m0E560369CDA932ED0068A0CED7D733FE203E43E1,
	DOTweenModuleAudio_DOPause_mDC395F8C1B08A113E79E42FAB5EE1EF453B1136D,
	DOTweenModuleAudio_DOPlay_m86F982951B3B2786390449AFE30BAEFBDC7E92D7,
	DOTweenModuleAudio_DOPlayBackwards_mD371D3D6C3D85A6CE99B597BB0305D9E6EDD87F4,
	DOTweenModuleAudio_DOPlayForward_m561924708D16379FF482E79B5710AB2FB5B1E9FB,
	DOTweenModuleAudio_DORestart_m0B4E5FF932DACDE8A3B1C85BE6B5A8FCB12AC0F0,
	DOTweenModuleAudio_DORewind_m20E78D2E878D7E35D859B4789DBDC2DF968B06E3,
	DOTweenModuleAudio_DOSmoothRewind_m775A16C85A17C3471062578BCC5A45683A67AC5A,
	DOTweenModuleAudio_DOTogglePause_m23CC6F5387C5060B72E4000C5F4A61B944A5F971,
	U3CU3Ec__DisplayClass0_0__ctor_m3791FA75A8CE2C48268B7EFD94EA4A3765266D67,
	U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__0_m8143CFDDC70BD69C48E4BBBDF5BD596D88C518F9,
	U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__1_m5E5FBB05013DE3D53572D7BA16CC7C54A0F2D0FC,
	U3CU3Ec__DisplayClass1_0__ctor_m7F6CF474218CDB04F1779336A4121CB4413DBA05,
	U3CU3Ec__DisplayClass1_0_U3CDOPitchU3Eb__0_m0E574CBA7B1412BA78918BD8457649F22458B1FD,
	U3CU3Ec__DisplayClass1_0_U3CDOPitchU3Eb__1_m64853930D881A088A3DC9B899622925943A4BC13,
	U3CU3Ec__DisplayClass2_0__ctor_m0137DE0DC632BA91C3E6EF826AF8E333F0293D90,
	U3CU3Ec__DisplayClass2_0_U3CDOSetFloatU3Eb__0_m638EF4CAE8BAF409B36498CC75BE2EECB4E327C7,
	U3CU3Ec__DisplayClass2_0_U3CDOSetFloatU3Eb__1_mD0BF393888DDC1CA4DB4E8035A4033B1FC5F3563,
	DOTweenModulePhysics_DOMove_m5B66A39F2C06E19EDFA4D9D79B8CEDD1B2C1AE9C,
	DOTweenModulePhysics_DOMoveX_mAE96C9DA1E0C5EC23A773965A91B86C987BAEAAB,
	DOTweenModulePhysics_DOMoveY_mE4DCBAC03F31FBF07EDFB15A55E2822256EAE03A,
	DOTweenModulePhysics_DOMoveZ_m5915FC138CB7BBFFCEF34456590EF4670B1893CE,
	DOTweenModulePhysics_DORotate_m65EA16E432A1B477A5A696EF95257FE812C948D6,
	DOTweenModulePhysics_DOLookAt_m86BB568C280583D5140AF00ACDB6102191ECD98D,
	DOTweenModulePhysics_DOJump_m66B1A29F77189B9981097A35A69E00974F0ACA65,
	DOTweenModulePhysics_DOPath_m1443BEE665EB5D1A4EF2C356BE311406251657D4,
	DOTweenModulePhysics_DOLocalPath_m16C97084468DB6E53825EEED8132F80E127EF0FA,
	DOTweenModulePhysics_DOPath_mF43CCB4AF2A13F42ED05CE2E666422CA4065F328,
	DOTweenModulePhysics_DOLocalPath_mCB4C763749BBB71E0B4ECB3EA7C9C43B9EAA45FF,
	U3CU3Ec__DisplayClass0_0__ctor_m0BEB792A0FE19EAA31D6B34FD5B01D116B6982E8,
	U3CU3Ec__DisplayClass0_0_U3CDOMoveU3Eb__0_m6E0B04D7869F5FF54EA1C743AC07762BE15C450F,
	U3CU3Ec__DisplayClass1_0__ctor_m82174D8C8C82955F6E9E1D59B330645364022DD0,
	U3CU3Ec__DisplayClass1_0_U3CDOMoveXU3Eb__0_m44B6924634D19688FB006D483138E93595291D10,
	U3CU3Ec__DisplayClass2_0__ctor_m95E3ADCB89ABFACB7D1E91DA4A1CDF392DC794E6,
	U3CU3Ec__DisplayClass2_0_U3CDOMoveYU3Eb__0_m6BFE21962DA4F6AD341BB59633EDCE28B6E45B67,
	U3CU3Ec__DisplayClass3_0__ctor_m5EFD6FE639198BF1AD1E9FA475731D194EFE073B,
	U3CU3Ec__DisplayClass3_0_U3CDOMoveZU3Eb__0_mB670881A3259C5E5997D07DA4A1DDD3EDE75063B,
	U3CU3Ec__DisplayClass4_0__ctor_m0C905B754B9A6187494F408107EE861B650A5DF7,
	U3CU3Ec__DisplayClass4_0_U3CDORotateU3Eb__0_m1F121B516FF4A3B19D60370CAF7215037FC55AFE,
	U3CU3Ec__DisplayClass5_0__ctor_m5454D12FFC74B0B715588F08E4DA72D94E47D69A,
	U3CU3Ec__DisplayClass5_0_U3CDOLookAtU3Eb__0_m23D8CC0E9DB5CE2D88199B4DDE0CAD4AD1B2BC5E,
	U3CU3Ec__DisplayClass6_0__ctor_m0D378F1E0358380DA1CD247F90674C29D9954E0E,
	U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__0_m41ECCE19967CB8FF9557E9EFC068AB9199CF160D,
	U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__1_mF4A2E742B3B0550F2D22177E36FB64F1298BE508,
	U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__2_m9DB85188D8D2D2AB9C1656C58A65639CFB20CCAA,
	U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__3_m20C802577C48BC4FEEC502F10698D6E33014CF3D,
	U3CU3Ec__DisplayClass6_0_U3CDOJumpU3Eb__4_m8F3D5C990949F26E7B0CCCC3E56815037389E63C,
	U3CU3Ec__DisplayClass7_0__ctor_mC0EAAE8F4A19AAD8FD1BE8F1E1F982463877988F,
	U3CU3Ec__DisplayClass7_0_U3CDOPathU3Eb__0_m7C61A8F92F87D76AE9C46EBFDE4A761BD36EEC9D,
	U3CU3Ec__DisplayClass8_0__ctor_mA253330E57ECE63BD9DA2F36F950A44B8D19F75D,
	U3CU3Ec__DisplayClass8_0_U3CDOLocalPathU3Eb__0_m5C5018BD3AB3DEFE56DB1B58F78D8E8B4AE5AC20,
	U3CU3Ec__DisplayClass8_0_U3CDOLocalPathU3Eb__1_m209F28992EB1879A4349497D0672A7C2749EC393,
	U3CU3Ec__DisplayClass9_0__ctor_mE8C66DFD146B85189C06E2392A7CEDA18580DFF1,
	U3CU3Ec__DisplayClass9_0_U3CDOPathU3Eb__0_m780F14A754BC9CD461B328E1D201CCBA31236A3E,
	U3CU3Ec__DisplayClass10_0__ctor_m03E61F264547D93763B90C045BE06D44AAA239DF,
	U3CU3Ec__DisplayClass10_0_U3CDOLocalPathU3Eb__0_m7055847965DE725A80D146EAEB0434DF0D185D01,
	U3CU3Ec__DisplayClass10_0_U3CDOLocalPathU3Eb__1_m3744C63CE1A944BF7209BD755A38A3EF757E32C7,
	DOTweenModulePhysics2D_DOMove_m6A74D57E65B6F8E119164B18F17D3ED7BB8B6B44,
	DOTweenModulePhysics2D_DOMoveX_m7F9730EFF5DE54338332D74B2364243C211EB7F4,
	DOTweenModulePhysics2D_DOMoveY_mA3B4A7F4B174180E22FA9F9CC8852B001460E990,
	DOTweenModulePhysics2D_DORotate_m914F5F01CD6972EE0FCBA60FBC4AB340E647DC5E,
	DOTweenModulePhysics2D_DOJump_m994418231434C0151D7ADEE79A02174D6F4E5B2B,
	DOTweenModulePhysics2D_DOPath_m0CF606B5F7970A8D1FBC5816ED775CA1736C9D1C,
	DOTweenModulePhysics2D_DOLocalPath_mEC1BAA9AEDBCE7F667D52E04746C6E29C7AFAA5B,
	U3CU3Ec__DisplayClass0_0__ctor_m6E60A649269716DA67C91FEA9DB5E4838B171FFB,
	U3CU3Ec__DisplayClass0_0_U3CDOMoveU3Eb__0_m3B437B7A49D2CB3F8665A68251D2037D4D2DFAFB,
	U3CU3Ec__DisplayClass1_0__ctor_mAA755EB23D9336AA9EC71EBD7D962163A5D701BB,
	U3CU3Ec__DisplayClass1_0_U3CDOMoveXU3Eb__0_mDCC3F81EA6919A6758DF902C951C7BE90FD9ED21,
	U3CU3Ec__DisplayClass2_0__ctor_m287F996454332CC75504F22382E84F764A6703E5,
	U3CU3Ec__DisplayClass2_0_U3CDOMoveYU3Eb__0_m26EFA27B3283A4CDEA74C1C10C2298172D6F3DA7,
	U3CU3Ec__DisplayClass3_0__ctor_m4AB88AEBE4C86B65F1E152630DCC77C868D114EF,
	U3CU3Ec__DisplayClass3_0_U3CDORotateU3Eb__0_mA761FE1B426A6D4F495CF6236077759B83404880,
	U3CU3Ec__DisplayClass4_0__ctor_mB04F62E995B27D6A6428EC7912C8E28383226888,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__0_mC384861F18478CA4920D44A4FF1DBAC168091984,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__1_m4BE94E6CA4A7343449BF1C380C49969ACEAC3258,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__2_mB0AC03FA3A2D44B6659E6FD460970C0AED148A48,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__3_m50157E12B08569073B9B7C226EA7E0FF7AF83BE3,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__4_mAB03323C38080C1800DA5545B062D5ADAA39CB73,
	U3CU3Ec__DisplayClass4_0_U3CDOJumpU3Eb__5_mA4ECC8E0DC621BEC5EA7C6F8B770CCF97FAFFDFB,
	U3CU3Ec__DisplayClass5_0__ctor_m7785F019FCF0C76EB1A4663C908429D4552F8864,
	U3CU3Ec__DisplayClass5_0_U3CDOPathU3Eb__0_mC091AB67A43DA9A1DB9DD889184670E586A7F96F,
	U3CU3Ec__DisplayClass5_0_U3CDOPathU3Eb__1_m2D47B6559DAF1FA18DC18EE9DD442D9A949533C1,
	U3CU3Ec__DisplayClass6_0__ctor_m08366EEB1AB56732D845835BBA4105463E4F109D,
	U3CU3Ec__DisplayClass6_0_U3CDOLocalPathU3Eb__0_m3D8AA6655141216299BC1F1259C20544EEA146C4,
	U3CU3Ec__DisplayClass6_0_U3CDOLocalPathU3Eb__1_mC71B4D60BA6713F56A7626ECA1C0AC87C640EF16,
	DOTweenModuleSprite_DOColor_m6E59DCD8638072DF9AA02645F45A4367CE903FF3,
	DOTweenModuleSprite_DOFade_m6AE51AD4E4655B3A03EE59353450C611725E6D1A,
	DOTweenModuleSprite_DOGradientColor_mBDB37BF5C3939448FCEFEB812414F303D7C99C72,
	DOTweenModuleSprite_DOBlendableColor_m5570320359C3164713C74486272EC313724DD6F1,
	U3CU3Ec__DisplayClass0_0__ctor_m270031771548A13843FD1B9701D5D178797EB9AD,
	U3CU3Ec__DisplayClass0_0_U3CDOColorU3Eb__0_mA10A642C6F3D0B140227D1D6B5B972CA9624F6B7,
	U3CU3Ec__DisplayClass0_0_U3CDOColorU3Eb__1_m31412CE4EE9499BB433AC04B055AB41BD5047A74,
	U3CU3Ec__DisplayClass1_0__ctor_mDF7123DA26647D6C19E3D8D2131EDB0AFE40446A,
	U3CU3Ec__DisplayClass1_0_U3CDOFadeU3Eb__0_m34F6B168CAE3EBDE25B3A62A680E3F5387957414,
	U3CU3Ec__DisplayClass1_0_U3CDOFadeU3Eb__1_m769F0265E8D0A6320E185169D06F8ED38FF6191E,
	U3CU3Ec__DisplayClass3_0__ctor_m6B0AC5DDB17C25A1A2C8F55A84AC2C5986EF8240,
	U3CU3Ec__DisplayClass3_0_U3CDOBlendableColorU3Eb__0_mD1F5CC03348BACDD68A45FC8BC8D379841EF09D6,
	U3CU3Ec__DisplayClass3_0_U3CDOBlendableColorU3Eb__1_mF6CA7D8E1F46B4CAC9DC17BE940693728B469EE2,
	DOTweenModuleUI_DOFade_mA073F33862AA7BEF33842B8200D0E79E046D114E,
	DOTweenModuleUI_DOColor_m961875592E62912276F701C48C3C3C3DDB4E7341,
	DOTweenModuleUI_DOFade_mE2E3C2482CD1D3B81C2F4B0EA4E95CF2CC10CC21,
	DOTweenModuleUI_DOColor_m385F3DCBA53A421BC288521879635D67E8155783,
	DOTweenModuleUI_DOFade_mC1C042C14FF418F2BE7B8A6B3B73A2F8D3719EED,
	DOTweenModuleUI_DOFillAmount_mF99B81AA5E4A001FD8DEB2C7F6056271802D153D,
	DOTweenModuleUI_DOGradientColor_mB08E7CC98E98E7A0A8A04DC84CDE434B038CF03E,
	DOTweenModuleUI_DOFlexibleSize_m2476B21F9C3D8213723B01A0FA93553D8E45F3B7,
	DOTweenModuleUI_DOMinSize_m2D92E524BAEA78CDA2815597D779B2835EF8CC03,
	DOTweenModuleUI_DOPreferredSize_m59E62BDF15A51E4529FC3D920EBC77178DFEDFD8,
	DOTweenModuleUI_DOColor_mAF1146331160A3A8C7FFA916BFA8B71A8531FCF2,
	DOTweenModuleUI_DOFade_mFDEF44F0F048DD606FEF46F539D4F47AF40EF817,
	DOTweenModuleUI_DOScale_mEBEA04E6C90874A4903841D8D2720867B2CA292F,
	DOTweenModuleUI_DOAnchorPos_m5B60876E10960019C209F1C215F921E6F994831A,
	DOTweenModuleUI_DOAnchorPosX_m483100309684443A215A8279D4E54B2769DAF3E8,
	DOTweenModuleUI_DOAnchorPosY_mBCFDB7E014D45E6B56588C598C23D4EB111D1395,
	DOTweenModuleUI_DOAnchorPos3D_mBFA28183F6CBCCD444AF47AA85A0272E8D1CAA48,
	DOTweenModuleUI_DOAnchorPos3DX_m6AE58A54659B9562734FB13539AE84FA69C34980,
	DOTweenModuleUI_DOAnchorPos3DY_mC051E07149C6D443662E3682338A26D0ADC6591C,
	DOTweenModuleUI_DOAnchorPos3DZ_m334F6667A6103C39B84749DC1EBE6557CCBE91D3,
	DOTweenModuleUI_DOAnchorMax_mA7BFD0284B3A23C3BF4DE76F542F60EAE1CC5368,
	DOTweenModuleUI_DOAnchorMin_m7EC8E45746F25D2679DE1267FBD5DEB4CC619057,
	DOTweenModuleUI_DOPivot_m3F8012446C42571C9F1549771422917AEC9EEDF8,
	DOTweenModuleUI_DOPivotX_mFD1858E2B5933F093EB84E3D87A69783B04CA7F4,
	DOTweenModuleUI_DOPivotY_m7CA2B8D7162770DC0700106C9ADB97F9A4BD877B,
	DOTweenModuleUI_DOSizeDelta_mC2236310385A8326B78FE900A33586006C8B4474,
	DOTweenModuleUI_DOPunchAnchorPos_mCE5DF2A8B462E813FBB84C4DBC5697848D1C2B45,
	DOTweenModuleUI_DOShakeAnchorPos_m5AB3C24FE1C10F8B0ED53ED04FF08E3ED682044B,
	DOTweenModuleUI_DOShakeAnchorPos_m81D0D12B80B4FCA0F14A62E118EC8BCD515BBB35,
	DOTweenModuleUI_DOJumpAnchorPos_m5629EA273819E9C2EE98068F8793202EC96765F3,
	DOTweenModuleUI_DONormalizedPos_mABC0EB2280EEC8C8A990E76E16D7BB5DA48A1706,
	DOTweenModuleUI_DOHorizontalNormalizedPos_m41E8A271B7FE392B43523F6B123DCBF26CB0BA74,
	DOTweenModuleUI_DOVerticalNormalizedPos_mC141061A07ACD836F365221BA33198FF316BFBA3,
	DOTweenModuleUI_DOValue_m38DB0CB09A73E2DDC33B3EEE49D74944FBA82A38,
	DOTweenModuleUI_DOColor_mAF96B607A774C0B0D912E56C3C11A87E4F093440,
	DOTweenModuleUI_DOCounter_m85EC79863973B9D9DF9D67E7B5DD835C86BF1438,
	DOTweenModuleUI_DOFade_m5AD3262DBFA4B713B61D3F2203B2930562A3B54D,
	DOTweenModuleUI_DOText_mDE24022401FC6820F90F1BE517FF46F73AE9BC15,
	DOTweenModuleUI_DOBlendableColor_m69717A08080A14BE5A01F1E8886EBF829CEF7227,
	DOTweenModuleUI_DOBlendableColor_m9D9F47100CD74C031BBA7ABF9A16E45AC29D2E8F,
	DOTweenModuleUI_DOBlendableColor_m7569CFBAB6EFA6049EECFDBC96898880565C368A,
	Utils_SwitchToRectTransform_m6A264948787CBEE108E0D97B235AE921BFBB6152,
	U3CU3Ec__DisplayClass0_0__ctor_m7CDF4DE59B75149775AFE16A0C4AB5482BC4C442,
	U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__0_m43479452AB6CABC809F8BB075F80A6B391A8AA4B,
	U3CU3Ec__DisplayClass0_0_U3CDOFadeU3Eb__1_mB9CCB118057D74D8F6C152B0FA27DE980521FD9A,
	U3CU3Ec__DisplayClass1_0__ctor_m6513901DE6123169BD8642D3EDF9341AD2C78AB9,
	U3CU3Ec__DisplayClass1_0_U3CDOColorU3Eb__0_m7A0F2549C2C54325EC64A09C154142F9212E4119,
	U3CU3Ec__DisplayClass1_0_U3CDOColorU3Eb__1_mFE2DE0E537DD7B1255D9B75969C15549646E6C94,
	U3CU3Ec__DisplayClass2_0__ctor_mAC2FAC72E368A0770D2C88F39065B0CD1B860FDC,
	U3CU3Ec__DisplayClass2_0_U3CDOFadeU3Eb__0_m83DABFF83F53843B3210E3663AA658A393F72C21,
	U3CU3Ec__DisplayClass2_0_U3CDOFadeU3Eb__1_mEBA98F9D99539591FC60AFBE48FD7336309CFE1D,
	U3CU3Ec__DisplayClass3_0__ctor_m6F636F1E7727A97A11CD562DA6C62E44D0CE8D37,
	U3CU3Ec__DisplayClass3_0_U3CDOColorU3Eb__0_m4568743D7735E8597149620347E7C6C1F8F8F573,
	U3CU3Ec__DisplayClass3_0_U3CDOColorU3Eb__1_m931C95B84B1BCD2FB3A2D8038972C9570DAB288D,
	U3CU3Ec__DisplayClass4_0__ctor_m9953E31874A19DF4ACB95C87FCE12660693A6AD5,
	U3CU3Ec__DisplayClass4_0_U3CDOFadeU3Eb__0_m45ED3C46917C2BF3FA1E62E5E5FA07933322FC8B,
	U3CU3Ec__DisplayClass4_0_U3CDOFadeU3Eb__1_m1FCDD6D867999371C3AA240FAC66D48DD045C3DC,
	U3CU3Ec__DisplayClass5_0__ctor_m8826744854B3DF452491AF2C9F78CF8CD21E5ADF,
	U3CU3Ec__DisplayClass5_0_U3CDOFillAmountU3Eb__0_mA61D89DB8E1FCE175F34BFC13C1173C788BC70FF,
	U3CU3Ec__DisplayClass5_0_U3CDOFillAmountU3Eb__1_mD611009CE94D3EBF2517D0EA25B6858E54C6FBAE,
	U3CU3Ec__DisplayClass7_0__ctor_mC3A13E5D8A90789E6C1F6A26DFC8C8ED6B5B42DF,
	U3CU3Ec__DisplayClass7_0_U3CDOFlexibleSizeU3Eb__0_m3785D78D950D02D749F4640AA0C67FB2CA01DB48,
	U3CU3Ec__DisplayClass7_0_U3CDOFlexibleSizeU3Eb__1_m1E713C41B3EC5ED27907BEFDB2CDCB2D9649D3F0,
	U3CU3Ec__DisplayClass8_0__ctor_m12549EFF091117C02D5BD5BBAF860766EFFBD335,
	U3CU3Ec__DisplayClass8_0_U3CDOMinSizeU3Eb__0_mCB197686B19FEE2A3789796C320289EDEBCA59DD,
	U3CU3Ec__DisplayClass8_0_U3CDOMinSizeU3Eb__1_m8B8E20DB6700A9E435B4EC30F00578E23B81F319,
	U3CU3Ec__DisplayClass9_0__ctor_m638C89DD65FC918306CF707CF4B3EA9CFACAF02E,
	U3CU3Ec__DisplayClass9_0_U3CDOPreferredSizeU3Eb__0_m1AB892211B71DB2D4E8F21F9BA126944DF9D500C,
	U3CU3Ec__DisplayClass9_0_U3CDOPreferredSizeU3Eb__1_mBA091FF947DA978F76C73673E1472EB9BEABDCC8,
	U3CU3Ec__DisplayClass10_0__ctor_m985D8AA039C4BC8FC17F125005481B94749837C7,
	U3CU3Ec__DisplayClass10_0_U3CDOColorU3Eb__0_mA4364DFDB200823F9D4FF95D114157C2A424D9DC,
	U3CU3Ec__DisplayClass10_0_U3CDOColorU3Eb__1_mD28650B7F8BE4B8C96C0AB9DF5BB4B53C443CE41,
	U3CU3Ec__DisplayClass11_0__ctor_m69309DF61BEF60177017EDBE3811AA7119806287,
	U3CU3Ec__DisplayClass11_0_U3CDOFadeU3Eb__0_mDCACD4D30AEE9D07134544798AB5B9C5D979BE93,
	U3CU3Ec__DisplayClass11_0_U3CDOFadeU3Eb__1_m73D2BA809B8464E6E216465A623D609E96823BD9,
	U3CU3Ec__DisplayClass12_0__ctor_m64C4DEEF82977228537228CAAAF48792AE080622,
	U3CU3Ec__DisplayClass12_0_U3CDOScaleU3Eb__0_m5C34A94B2CF727A19CE3D6D99933B680E7847F2A,
	U3CU3Ec__DisplayClass12_0_U3CDOScaleU3Eb__1_m79C4D6FE81FC8292C6B825B55A2F711DE92D835C,
	U3CU3Ec__DisplayClass13_0__ctor_mBD97A0B94BB8F658AA2895C371742B0E74198455,
	U3CU3Ec__DisplayClass13_0_U3CDOAnchorPosU3Eb__0_m45698E882FAA3963ED0653B5927E9B5F99C8B4E4,
	U3CU3Ec__DisplayClass13_0_U3CDOAnchorPosU3Eb__1_m5DD4C4D9473EA1DD1B2021D9131B4F6D8124BD57,
	U3CU3Ec__DisplayClass14_0__ctor_mF03BAB1D5A00A73CAA680F13E3BE0B226712B8C3,
	U3CU3Ec__DisplayClass14_0_U3CDOAnchorPosXU3Eb__0_m77F354FDCA32A28B5E166D92E7AD31A13AAC60FA,
	U3CU3Ec__DisplayClass14_0_U3CDOAnchorPosXU3Eb__1_m017F7F1E8BC9250F6CF7A0B75ED09A7ED669BA34,
	U3CU3Ec__DisplayClass15_0__ctor_m48FC24F32D0415BE4512FB1D5C17CFF39D8149DC,
	U3CU3Ec__DisplayClass15_0_U3CDOAnchorPosYU3Eb__0_m3B38EF80DFF9D4EF696F2F08DCC156C16FE55E8D,
	U3CU3Ec__DisplayClass15_0_U3CDOAnchorPosYU3Eb__1_mEB016F250A040B81AEEF7C5D3A98D0B05E3B231F,
	U3CU3Ec__DisplayClass16_0__ctor_m6A7514F7CF8978AD8D2179728B06E74F14F4485E,
	U3CU3Ec__DisplayClass16_0_U3CDOAnchorPos3DU3Eb__0_m2E02A40A5465C662FCB26908E7F13C7DD3A4BBC2,
	U3CU3Ec__DisplayClass16_0_U3CDOAnchorPos3DU3Eb__1_mEC7A7D9EDE2E44E5EAF9ACBA9A993FC950F4EEE2,
	U3CU3Ec__DisplayClass17_0__ctor_m54FF0D8E95B7DE95B74B8886D64EA0F803C66D9A,
	U3CU3Ec__DisplayClass17_0_U3CDOAnchorPos3DXU3Eb__0_mC5FAD099F119CE2ACDEAD414435B244F21CDB4E7,
	U3CU3Ec__DisplayClass17_0_U3CDOAnchorPos3DXU3Eb__1_mA7F32AA90629508030AAD74E0725D4B5DF28B76D,
	U3CU3Ec__DisplayClass18_0__ctor_mE054C2ABDC10BD5D710C5AF29506CA2841AA72E2,
	U3CU3Ec__DisplayClass18_0_U3CDOAnchorPos3DYU3Eb__0_m30DD1FDFC6B5104DB734F01FB77F60BAB3C67578,
	U3CU3Ec__DisplayClass18_0_U3CDOAnchorPos3DYU3Eb__1_m46549819EBCBEB1EE8404F9888866CD75997825D,
	U3CU3Ec__DisplayClass19_0__ctor_m74B141AA06FF97B9170A5CD56D2E4422B6511AE3,
	U3CU3Ec__DisplayClass19_0_U3CDOAnchorPos3DZU3Eb__0_m81FCF7B95ACC17C67BE6C8D68B570D959D88EADC,
	U3CU3Ec__DisplayClass19_0_U3CDOAnchorPos3DZU3Eb__1_m27CE65B98533504D302D8580C61D7D3F09A48D27,
	U3CU3Ec__DisplayClass20_0__ctor_mA78DA0FD1C871D24DEB547744F4DE38ABEACD0B4,
	U3CU3Ec__DisplayClass20_0_U3CDOAnchorMaxU3Eb__0_mD50D23ECA6FBD3AE03536697B9ED7332E4FDD2CD,
	U3CU3Ec__DisplayClass20_0_U3CDOAnchorMaxU3Eb__1_mFEA7E952BB247F3CC01585B3C896AE53BB7B6540,
	U3CU3Ec__DisplayClass21_0__ctor_mCAB7F9CC3BBBA542AF258E0D021EC7AEFE5C2AF1,
	U3CU3Ec__DisplayClass21_0_U3CDOAnchorMinU3Eb__0_m33BBB55D66991F54EE55E79B0AE622F40FFCD764,
	U3CU3Ec__DisplayClass21_0_U3CDOAnchorMinU3Eb__1_m9D2C994ECFF4FB4237C178E213B731C1BD197F0A,
	U3CU3Ec__DisplayClass22_0__ctor_mE10D2BDE628966FE49512531B20C51F6C2787089,
	U3CU3Ec__DisplayClass22_0_U3CDOPivotU3Eb__0_m5FE19E82DBA2702E7A7ADF66BB937773CACBEC6D,
	U3CU3Ec__DisplayClass22_0_U3CDOPivotU3Eb__1_mE3E48A091761963476D9CB2F1004A83281EE2643,
	U3CU3Ec__DisplayClass23_0__ctor_m983854683F9F5CE4B7F0BD9033AB45DDA296F9E7,
	U3CU3Ec__DisplayClass23_0_U3CDOPivotXU3Eb__0_mEBA64E950B901D99C27662F211C5357066A46C1B,
	U3CU3Ec__DisplayClass23_0_U3CDOPivotXU3Eb__1_m2BECC738B1793D1B2B8F075191056F44AE61DD6D,
	U3CU3Ec__DisplayClass24_0__ctor_m41C1CA93D499089E6C5CD68BEB55BD64ADBFE43F,
	U3CU3Ec__DisplayClass24_0_U3CDOPivotYU3Eb__0_mB9A0E99B23333028B4BA97E332DA19268ADFEBBB,
	U3CU3Ec__DisplayClass24_0_U3CDOPivotYU3Eb__1_mC0B65C0BEC4968B86083A8E493E782A486638E3F,
	U3CU3Ec__DisplayClass25_0__ctor_mDF25A8BF6CB8B1A343590B334D354F5EAC765572,
	U3CU3Ec__DisplayClass25_0_U3CDOSizeDeltaU3Eb__0_m9465A762A443D9DAA50004FF4EC3E7A5710D24F3,
	U3CU3Ec__DisplayClass25_0_U3CDOSizeDeltaU3Eb__1_mE4D6E5ADF19E5741ADB793A0E043CAE94C18772B,
	U3CU3Ec__DisplayClass26_0__ctor_m7F4C69BB9BF2084453CFD95533563FC7C6AF5941,
	U3CU3Ec__DisplayClass26_0_U3CDOPunchAnchorPosU3Eb__0_m8A97B30EF54DCC1B5253F2CE036DA7BEF521F9E2,
	U3CU3Ec__DisplayClass26_0_U3CDOPunchAnchorPosU3Eb__1_mA354D1798B36E08566BC12DEDD0A878C47D19C46,
	U3CU3Ec__DisplayClass27_0__ctor_m8180394F95E4CEDEA6E4B91A408E7CBC7F36A8D5,
	U3CU3Ec__DisplayClass27_0_U3CDOShakeAnchorPosU3Eb__0_m28D2453CAB4630D898B61CF1679C5C4955EC5761,
	U3CU3Ec__DisplayClass27_0_U3CDOShakeAnchorPosU3Eb__1_m08D936A746E8737C9E37B326E975EDCB90427B5F,
	U3CU3Ec__DisplayClass28_0__ctor_m4179B6F77D9F8B2D07F78D25FC745F542063F335,
	U3CU3Ec__DisplayClass28_0_U3CDOShakeAnchorPosU3Eb__0_mE987488CB26087991EB5B2AF5E1BB03633A9C5E9,
	U3CU3Ec__DisplayClass28_0_U3CDOShakeAnchorPosU3Eb__1_m223F195EA08AAF2F03AE46C9DE4761B0BC7FB7EC,
	U3CU3Ec__DisplayClass29_0__ctor_mCA183B392317E1ABAF1B8CA84C02784D75678A78,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__0_m82918F5D73CE67BC9AD9979A3F81C717AA95A5EF,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__1_mACBA5402D427457E33770E20ABBF153EE8EA73B2,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__2_m6BAF800D607189779E65F18B54EA2A29AC45D84B,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__3_mA6D64EC026FB4AA6873394DBB91E728E6F6EFF3D,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__4_mD71EC1A09CD5404D79A2FA0B068A00F3D2E7D12F,
	U3CU3Ec__DisplayClass29_0_U3CDOJumpAnchorPosU3Eb__5_m31B52507CE1503653EED1573137622C1202BA9D9,
	U3CU3Ec__DisplayClass30_0__ctor_m5F4F51BC32159EE37265F7032DE223AC3AB6A1C0,
	U3CU3Ec__DisplayClass30_0_U3CDONormalizedPosU3Eb__0_m80C5E010B8B0C14A9F1358140D6DB2AE6C5374A9,
	U3CU3Ec__DisplayClass30_0_U3CDONormalizedPosU3Eb__1_m8185551DA74F9CE20DAD3392E7DDE2490EB1D301,
	U3CU3Ec__DisplayClass31_0__ctor_m417F41C2607E2F3A10C14B9556514FC2BBA1B035,
	U3CU3Ec__DisplayClass31_0_U3CDOHorizontalNormalizedPosU3Eb__0_m77E495AE88490935170B5479753B0D251A5D3CA4,
	U3CU3Ec__DisplayClass31_0_U3CDOHorizontalNormalizedPosU3Eb__1_mF7393D7DDB277D5BFB5CE86BEB93E25B0558B7BD,
	U3CU3Ec__DisplayClass32_0__ctor_mA218955A26898E155307DDE47E12B7E53255AB3E,
	U3CU3Ec__DisplayClass32_0_U3CDOVerticalNormalizedPosU3Eb__0_m38805643288D85CEE1588577A69586E047726867,
	U3CU3Ec__DisplayClass32_0_U3CDOVerticalNormalizedPosU3Eb__1_mD395D9118A7944AE3F2ACF8AADCF71B0611F80BB,
	U3CU3Ec__DisplayClass33_0__ctor_mFDBB24E2EB71DAB7C3811F51BCF45EE7733321D3,
	U3CU3Ec__DisplayClass33_0_U3CDOValueU3Eb__0_m8E6B52F72A726C09781FAAE48C1097CE6C2D8188,
	U3CU3Ec__DisplayClass33_0_U3CDOValueU3Eb__1_m02996BC134ED2E96E505224009462007F093F825,
	U3CU3Ec__DisplayClass34_0__ctor_m6903649B5BDBAA53F5C179B09D1C77AABC913561,
	U3CU3Ec__DisplayClass34_0_U3CDOColorU3Eb__0_mBA716E6626BB3051125B19AC02EC825AA305B9A6,
	U3CU3Ec__DisplayClass34_0_U3CDOColorU3Eb__1_m534299537BAA83C8B80BDB7C0622F05B8501D4C6,
	U3CU3Ec__DisplayClass35_0__ctor_m6F52791A710AA19C73082E0EED5D298E31EDF1EF,
	U3CU3Ec__DisplayClass35_0_U3CDOCounterU3Eb__0_mD4515C9E2BA21A91E51DCA562DB8BD859BB73D4B,
	U3CU3Ec__DisplayClass35_0_U3CDOCounterU3Eb__1_m91616BD436B4FAB5C826763E445C8A59C11AF221,
	U3CU3Ec__DisplayClass36_0__ctor_m7C683C9CF75033301DA090C8B583860556AF7F29,
	U3CU3Ec__DisplayClass36_0_U3CDOFadeU3Eb__0_m72BB7D6C818418B6497D3356DA77BA4A5B325E47,
	U3CU3Ec__DisplayClass36_0_U3CDOFadeU3Eb__1_m4083DFAFABE118FAC072D3EE81663ACA96DD8F10,
	U3CU3Ec__DisplayClass37_0__ctor_m30C619C273CA88E1630ADE30076D3BAB756E8037,
	U3CU3Ec__DisplayClass37_0_U3CDOTextU3Eb__0_m02FF7D2EC040673A6A8DAF254FA06CCB5E19150D,
	U3CU3Ec__DisplayClass37_0_U3CDOTextU3Eb__1_m2838FBD1C16B38207C0B4528D6E805E6308E1E6B,
	U3CU3Ec__DisplayClass38_0__ctor_m82948A429B319CC7B45105656F6DD0ADBB2136CC,
	U3CU3Ec__DisplayClass38_0_U3CDOBlendableColorU3Eb__0_mE68FE0C254E1D0E7E8D659FF3E4A3AA5F7738351,
	U3CU3Ec__DisplayClass38_0_U3CDOBlendableColorU3Eb__1_mA5048FA5B74BD7E9906C80159B99ACB2AFED6634,
	U3CU3Ec__DisplayClass39_0__ctor_mBAA4D644FB605A60D0C3BEB67229723BB3874E6D,
	U3CU3Ec__DisplayClass39_0_U3CDOBlendableColorU3Eb__0_m897EF1C1C8D7A638D7271A6E3BD8640F834CA567,
	U3CU3Ec__DisplayClass39_0_U3CDOBlendableColorU3Eb__1_m059D299137E18F4172FB89D42BBC0DBE0408311C,
	U3CU3Ec__DisplayClass40_0__ctor_m6C547429D9E437CED8C4BDCB96EE8BE2D7182763,
	U3CU3Ec__DisplayClass40_0_U3CDOBlendableColorU3Eb__0_m031A8418D686ADB8B4AD6572C18FCBAD1E42B0F6,
	U3CU3Ec__DisplayClass40_0_U3CDOBlendableColorU3Eb__1_m74D298854E55DD21E0191F65A0A67376028748EC,
	DOTweenModuleUnityVersion_DOGradientColor_m5989D5E5CCAA8B96FEC40CE899DDD9BC255F4126,
	DOTweenModuleUnityVersion_DOGradientColor_m16A5065B7DA6EA92AC15D1E186EE14617F64896B,
	DOTweenModuleUnityVersion_WaitForCompletion_m080081BC7D031CAE8CB22FC166C6E19FAA91295C,
	DOTweenModuleUnityVersion_WaitForRewind_m7EB6AB643D5F309EE41F15305ADB1324E16853A7,
	DOTweenModuleUnityVersion_WaitForKill_m9592B2D81F0C76C9F8003645BDB0C4C3BA4E6A3B,
	DOTweenModuleUnityVersion_WaitForElapsedLoops_m08D7DB6E86076A4D3224DE7F651529C03B0C9B93,
	DOTweenModuleUnityVersion_WaitForPosition_m918A05EB65877997F48B218DE2B9B95A4E198A0E,
	DOTweenModuleUnityVersion_WaitForStart_m3E6DF08DBF844D468C3DD2A14AB96AAF3717BA53,
	DOTweenModuleUnityVersion_DOOffset_mB985D0A38167056313BD49AA97A9A2F12B6C1CA2,
	DOTweenModuleUnityVersion_DOTiling_m354938745AA34ED1539D3CBF54C94A5E5753B903,
	DOTweenModuleUnityVersion_AsyncWaitForCompletion_m47D1F5AACF019F8C3233238D5B73EBD325685681,
	DOTweenModuleUnityVersion_AsyncWaitForRewind_m4B4AD3964B5CBB9F56BB1050E8EF7C0AF414060E,
	DOTweenModuleUnityVersion_AsyncWaitForKill_m4CE6BA6CDF93365F4D14CE2909C7F7FF6B332928,
	DOTweenModuleUnityVersion_AsyncWaitForElapsedLoops_m08434CDEC811346692A3795B1736C8499E391277,
	DOTweenModuleUnityVersion_AsyncWaitForPosition_mA1767089E7840940CEB85BEAF15FBC02CE56D487,
	DOTweenModuleUnityVersion_AsyncWaitForStart_m3BAC94C50C109B2795BAA10D582617B3F2F95126,
	U3CU3Ec__DisplayClass8_0__ctor_mF5EC87634B90C628AE370887DCF280218F814B4C,
	U3CU3Ec__DisplayClass8_0_U3CDOOffsetU3Eb__0_m0247C66637BE1BC486E9B83E29D9A8C539F0C4C7,
	U3CU3Ec__DisplayClass8_0_U3CDOOffsetU3Eb__1_m3FB8CA36F894BB6D62D812DF2F13F0714F48945A,
	U3CU3Ec__DisplayClass9_0__ctor_m1E2466F9751381E5A3C76E5E2970972957741B9E,
	U3CU3Ec__DisplayClass9_0_U3CDOTilingU3Eb__0_m049884D699FDEDD9B8CE44EC9104A8055F7E4DD8,
	U3CU3Ec__DisplayClass9_0_U3CDOTilingU3Eb__1_m5C1495C9398445575DA1139EF2967F0C6535992D,
	U3CAsyncWaitForCompletionU3Ed__10_MoveNext_m7AE96D202005CC27A2EBEB47057FADA081D6DCDA,
	U3CAsyncWaitForCompletionU3Ed__10_SetStateMachine_m6240E5A12BCFEF8EA8588C4C18B3BB48BBA71FBB,
	U3CAsyncWaitForRewindU3Ed__11_MoveNext_m5E01823C6DBEFF1763AD6606972918D90935D340,
	U3CAsyncWaitForRewindU3Ed__11_SetStateMachine_m3F25AF370573B0A32A25D5D01483AF62C16AD5C3,
	U3CAsyncWaitForKillU3Ed__12_MoveNext_mC10BB60238B855C88268AEE7DA0D7E8CF59AC885,
	U3CAsyncWaitForKillU3Ed__12_SetStateMachine_m7BC3B905F4C08F129E4E6DFD12DDA73E5756DD0B,
	U3CAsyncWaitForElapsedLoopsU3Ed__13_MoveNext_mF44348C1C974B48E1B0F6FE03AD1F713A4A6F8A2,
	U3CAsyncWaitForElapsedLoopsU3Ed__13_SetStateMachine_m4D5053D74FA671E83FA48E11A3EE5C6534F995AB,
	U3CAsyncWaitForPositionU3Ed__14_MoveNext_mB726C581B4A8055414678A86C800C4A0525E5121,
	U3CAsyncWaitForPositionU3Ed__14_SetStateMachine_m060A3B894F6700B46D57FD2443F396C7C9CC7111,
	U3CAsyncWaitForStartU3Ed__15_MoveNext_mDBD2BBC1B727D4C915B0E2AB910330411086BC12,
	U3CAsyncWaitForStartU3Ed__15_SetStateMachine_m3B0B96BE14F355F5A0AF74DD42C7774158140A41,
	WaitForCompletion_get_keepWaiting_mD2C729ECA6B6F6BE57B718492953D588237F743D,
	WaitForCompletion__ctor_mE85B7CC8B7FE6A2AE84DB8210249A61018118C4D,
	WaitForRewind_get_keepWaiting_mF46CA00D1A5FDF140C0C027C4109C7373245A16C,
	WaitForRewind__ctor_mD79A34DBDAC1B30FBEBD36A8D749EC81935520B2,
	WaitForKill_get_keepWaiting_m4C085E03853426F4D4F5C312334101AE9BA75E3F,
	WaitForKill__ctor_m75C2D3D54DBBBB35DE297B947C08C982CABF1BAF,
	WaitForElapsedLoops_get_keepWaiting_mC2A906DBE9A06B7697041B76EC7C6AF58F928D6C,
	WaitForElapsedLoops__ctor_mA0E7D5A115AB56AD618E24B320476B81B9CAEC7A,
	WaitForPosition_get_keepWaiting_mA71AB7B7C269AB062BB6AF9CDF42E0F54EA6549F,
	WaitForPosition__ctor_mB6CCFCE59F142931CF19AC3BA4FE5CAFF1CBA4AD,
	WaitForStart_get_keepWaiting_mA0B7858981A2CEDE516D5F2C5133629C6D537E0B,
	WaitForStart__ctor_m3AEC2F6E37815ED0D94C2FA5F3B784456C6E49D1,
	DOTweenModuleUtils_Init_m8FD2F0DFE3D768ECE332A27B64ED208ED53568D5,
	DOTweenModuleUtils_Preserver_m6DD0C54BCF6FBA75AA80562BFBEDF89F7A224189,
	Physics_SetOrientationOnPath_mC2C4E6FA124458E00765F647C3E824CC31A4696D,
	Physics_HasRigidbody2D_m80204646E4EEA6187F16FE74B1608D54DC0EFA00,
	Physics_HasRigidbody_m81595D61A93C148222BD16F87F82F465286457B8,
	Physics_CreateDOTweenPathTween_m9AA6DE226F6876ACF693B7254E3DB5773E7651E0,
	DOTweenAnimation_add_OnReset_mA8F5741736259C46628FC55869998F518051D4C1,
	DOTweenAnimation_remove_OnReset_mAE32F1B7F1B2497982F03D1E04FC2D60B0FB58FC,
	DOTweenAnimation_Dispatch_OnReset_m502D1D6A50C88AB144971DE59485CE3E3439085C,
	DOTweenAnimation_Awake_m5A2F45736E953494BAD492FF36EED788F8AD4656,
	DOTweenAnimation_Start_mEE5D784A65EE9DCD56E55542181CF33F6B1A4BED,
	DOTweenAnimation_Reset_mE401C717944D3566EFF81FA6147D22F5599E2287,
	DOTweenAnimation_OnDestroy_mD2017B5DEEC60E62BACD32FCDC61B9225F7A45DC,
	DOTweenAnimation_CreateTween_mE197759CB9087F9F55ED0112FA19472D4810ADF2,
	DOTweenAnimation_DOPlay_m404032EAB118EBBFBF65F3A975E04B3A59C407AC,
	DOTweenAnimation_DOPlayBackwards_m28B62919A803EE87FDF72C013294176078553A83,
	DOTweenAnimation_DOPlayForward_mA152942BA1264751895AC1FB8D8716F4A8066964,
	DOTweenAnimation_DOPause_m0373908CB11AD693FE23DD7735532D6CD116EFA5,
	DOTweenAnimation_DOTogglePause_m5348CFC134E384E4D64EAE6ADC8CF2DAC95C4869,
	DOTweenAnimation_DORewind_m59758817F07694487F36D556DD3C075346B03989,
	DOTweenAnimation_DORestart_m4AB0A91DF102E0D643DADE7D915CB147AE57D44B,
	DOTweenAnimation_DORestart_mCAB0990689AB762A9B8A9BDE208BA1E8D138520C,
	DOTweenAnimation_DOComplete_m26F8261306361C2B5E795B73CADE12A8894710BF,
	DOTweenAnimation_DOKill_mE596789184B6317AAEB7C7C11E31014BF43D40C7,
	DOTweenAnimation_DOPlayById_m12D97C7EF5521A499512B6F730DC850E96CB9575,
	DOTweenAnimation_DOPlayAllById_m78E04FBAA4F91F516CD6EF97D4F33D633087DF4F,
	DOTweenAnimation_DOPauseAllById_m521B9C4119FA1F6AC6F8E28952AA89EB9BC43BAD,
	DOTweenAnimation_DOPlayBackwardsById_m092989EC8744A4F4383D1F664A9F32BAF78C50AF,
	DOTweenAnimation_DOPlayBackwardsAllById_m7C27AFED81EEA8B8629A7D276E377760CEECE79E,
	DOTweenAnimation_DOPlayForwardById_m76C5756941FBE7DE791B9753FD3F0851D0AC9529,
	DOTweenAnimation_DOPlayForwardAllById_m655297832660471E1C91A695B9B9AD8E29069A80,
	DOTweenAnimation_DOPlayNext_m73E38E99F8700E05203AF52600AAC0F59147B30D,
	DOTweenAnimation_DORewindAndPlayNext_m462F1FE5A33CED8A07535F5777CD7F1AA90C4E48,
	DOTweenAnimation_DORewindAllById_m1F3F3C40A945A9F27ABB32090961D4518BA01C2C,
	DOTweenAnimation_DORestartById_m1F30DC4E8D4DB44FFE3ACEF871443ACA26EBDC75,
	DOTweenAnimation_DORestartAllById_m64AA94F735F90651E0FC436DCC83B19ACA942D2E,
	DOTweenAnimation_GetTweens_m72B45D0B5DC11B3FE7F0ADAF345ABE4A31D90833,
	DOTweenAnimation_TypeToDOTargetType_m15E19090315002396417BA530BCB3450914B519F,
	DOTweenAnimation_CreateEditorPreview_mC9FC6CE29107384E390C42E9AABDC713259C8593,
	DOTweenAnimation_GetTweenGO_mDF43174309BC150372D175C32F9819011D787F38,
	DOTweenAnimation_ReEvaluateRelativeTween_m23AF3B509234313AE3E2A9657E2CC5997AD323C7,
	DOTweenAnimation__ctor_mA3F7CBFE6A98CAEF4059B593C245E8B6D2F1CFF0,
	DOTweenAnimation_U3CCreateTweenU3Eb__47_0_m4A2111E4BF4F1513A25F4D01ED658ED99B84E148,
	NULL,
	DOTweenProShortcuts__cctor_mB5D4F77E7578688BA434DE03F61A80F240CC85AB,
	DOTweenProShortcuts_DOSpiral_mBB6B961D53DD13CE5727CEA20BC179F5F1FE282D,
	DOTweenProShortcuts_DOSpiral_mD1B212D21905AC2EE0D4BA1F24604DAA44D65B1E,
	U3CU3Ec__DisplayClass1_0__ctor_mADA95A56850C09B62E886A9438E5959ACFE782A4,
	U3CU3Ec__DisplayClass1_0_U3CDOSpiralU3Eb__0_m712CB5D59B45F2FF3023A9C8772B55099EC4436C,
	U3CU3Ec__DisplayClass1_0_U3CDOSpiralU3Eb__1_m0F83BC8B95F0E610CC06BD323AF0EA3A7F1EF405,
	U3CU3Ec__DisplayClass2_0__ctor_mD18FFCA0D468681B299C2F09E602FF6619E4F74D,
	U3CU3Ec__DisplayClass2_0_U3CDOSpiralU3Eb__0_m7179D74055A097F51CA14CBAE2FE92B941A4A543,
	CRC__cctor_mB40D92FF619984657395B910C96AB205B95D9150,
	CRC_Init_m16709DA73B42F924063FF919572CDD418A11ADC5,
	CRC_UpdateByte_m4A4769F5943800546A3CF3EE3A6AE57F87FF115F,
	CRC_Update_m7AAF2C449ABBAA9EAFE6326E145963054E2EF757,
	CRC_GetDigest_mBEC96B14FF952BF124F11DD6DFC1A0409E0B337C,
	CRC_CalculateDigest_m4CBBB31AF681644C0321A83D5867C6B319913CA9,
	CRC_VerifyDigest_m80F70FF7F7F6A3BF93F9687D666834E515C92B8D,
	CRC__ctor_mC6EEE59734EB9FA7EBB21C22BBE19C9441361628,
	CDoubleStream_get_CanRead_m5060C0A5137418FADD52708FE60664E805B74187,
	CDoubleStream_get_CanWrite_m1FD7CA1571FE179F1990EE80F22898EB290EC509,
	CDoubleStream_get_CanSeek_mDF4A3993B642D0FB469D8C8C2F699D42B9E02D82,
	CDoubleStream_get_Length_mC40EE4C46EBDCF453F6041EC4C1BC6DC8FC6F8D4,
	CDoubleStream_get_Position_mF1FB86CE3358F663EC7E2B8E8FDE03D6FE8B32B9,
	CDoubleStream_set_Position_mEE3FF43AA23F0FD9F57E3BE5EB64F99F9A551D20,
	CDoubleStream_Flush_mFD80243F66FAAD4AC2272388E12E3E221B64A86E,
	CDoubleStream_Read_m0F19805CEB5EB26C4AC05987FFC85DCB8834804E,
	CDoubleStream_Write_m93DBD5D7046D4E05D3CF41B235D4825615CA7333,
	CDoubleStream_Seek_mC23979073BF1052080F8E6599945AC99FBF2EA4A,
	CDoubleStream_SetLength_m225F929A580C6FF241C1A78A65EF0371DEEF57A5,
	CDoubleStream__ctor_mAE4EDB07912E3D48C27F32830E828E7CC65A0458,
	LzmaAlone_PrintHelp_mA3F5C0E2DC5FF43F3EBBCA9420187691FE73E51E,
	LzmaAlone_GetNumber_m09941593E9EE8F6F7AEDE2E720DD148485E1F06F,
	LzmaAlone_IncorrectCommand_mF2F94D2AF7D1BEE667922EC7CDFE1CE80175438B,
	LzmaAlone_Main2_m38DA78FCD8AE038575ADAF1D124ABF69ABDDACA9,
	LzmaAlone_Main_m9FD9075DE12A802AFCB20C884FA1C5692863904E,
	LzmaAlone__ctor_m010E7E66099013E6C24CC590B0AAE79F704B6192,
	LzmaBench_GetLogSize_m41C6144E9100BDAEFFCEEF67808D73E7907E60C4,
	LzmaBench_MyMultDiv64_m6BCBAA24BF6045E56FD4431C6D9C904735678D8C,
	LzmaBench_GetCompressRating_mBDDC0AE40A05070280F64021488824BD17092AD0,
	LzmaBench_GetDecompressRating_mF753EB237ADEFEBB582E59D8AB1C6FE94FC172A6,
	LzmaBench_GetTotalRating_m3A5CD12B68B6634D390835A08E58A95A795BD1DA,
	LzmaBench_PrintValue_mD389B8BFCFE82174F06382E69272C4E823CEB1B0,
	LzmaBench_PrintRating_mA7C5217ACA86ED9D1344988B4D5B39FAE560BEEC,
	LzmaBench_PrintResults_mE52F0145CBEFDE45A9D37E3CC61566E233A3667A,
	LzmaBench_LzmaBenchmark_m41F84D49FED9B9CA4F1FEE962877746E58A0AD53,
	LzmaBench__ctor_m11D0914DE62F36A6480BEAA72844B75DAAC70A1A,
	CRandomGenerator__ctor_m27F05B1231B661743CFBA88B1677660B0656BAE6,
	CRandomGenerator_Init_m1217E671E019AC326DE2CB74EBB73603DFB0072E,
	CRandomGenerator_GetRnd_m42F1495721B1E4989BFBF64D8881B321B4C3B0EB,
	CBitRandomGenerator_Init_m543F8B977D9AE09FA691D262D1BEB551D8C88888,
	CBitRandomGenerator_GetRnd_m6C33DD654498C35B561286634E2967556F72D004,
	CBitRandomGenerator__ctor_m9BEBE00097278D19E966564D8D4C07B9BA9BE4FA,
	CBenchRandomGenerator__ctor_m4B67684D0C3BC36B785F6AFF53D53CDD6D546CB9,
	CBenchRandomGenerator_Set_m37C8D4AC6D9B7384884BA0A3EA8524335818008F,
	CBenchRandomGenerator_GetRndBit_m1F82A566BE7BA876A2877DC75CDE0F0CA21D46DF,
	CBenchRandomGenerator_GetLogRandBits_m869214B4FE84873CB6B66B8C15A159D1A110F5E0,
	CBenchRandomGenerator_GetOffset_mA9ACB83F9616CCF998C045DC6F24FB9B6006718B,
	CBenchRandomGenerator_GetLen1_m6323ADE59175D885D5C09A102F72C8003FA72FF9,
	CBenchRandomGenerator_GetLen2_m1C80C3DC8D918A8140E5CB33D78A627BDD7A246B,
	CBenchRandomGenerator_Generate_m46B741A1CA94E3D8EDB290B690C87FB26401F6D6,
	CrcOutStream_Init_mD15615423C1D13B3F5ACBC82C839E851BFE925F8,
	CrcOutStream_GetDigest_m60767F1AD77C6F12CC63B3100D3BACC43CBAE061,
	CrcOutStream_get_CanRead_m5A40358D70D0C1FC20B9D3F1A036D92D56EFE1FB,
	CrcOutStream_get_CanSeek_m4BE994A24D1342184583BB0439F0D5283635C583,
	CrcOutStream_get_CanWrite_m2E58BE6E86FD21BBCDAA8DB1A1F4783220006B99,
	CrcOutStream_get_Length_m964E5BE20E83E1164C6636BA1FEEEA52B17FE136,
	CrcOutStream_get_Position_m9B3167B49067ED558B71B4EED194BBD755CFCDD5,
	CrcOutStream_set_Position_mB65A0B8EE2E2C28E82AA984E2ADB21C14C49C53D,
	CrcOutStream_Flush_m4599297795EB3E89392E158844B6294E7E9617D9,
	CrcOutStream_Seek_m3286B99050882FB43C436EE0F76B3FA0B4542A28,
	CrcOutStream_SetLength_mDF25A1F86A5BF2D57C07248ED936B2B33F0AECAB,
	CrcOutStream_Read_m6B3A35C40C0C88B598267FB0FE010EE8A5EE067B,
	CrcOutStream_WriteByte_mEA065EE83708FB9B08A3D7434BC7512463DD06B2,
	CrcOutStream_Write_m8E45C0161EDE3A3375A81E2A0157D101E16B64BD,
	CrcOutStream__ctor_mBD399FB1EC42265D2D067EBFD9242E53947477CD,
	CProgressInfo_Init_mE6CC26EBC5518F9868B56AFF19D22B79B434105D,
	CProgressInfo_SetProgress_m9D4D537D20993B80AFB77B6F52EE5412D5097B4E,
	CProgressInfo__ctor_m8642C06719EA299630B87FF25AC5F771BB73D4DE,
	DataErrorException__ctor_mFAE964EE99BB4427542E8AFA3A96AB934B2038E2,
	InvalidParamException__ctor_mA3AE5908C4D2FF5BC359058D9C77EB2F319E81C1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Encoder_SetStream_m87913AA6C2C86932066B673C09CA188940BACC82,
	Encoder_ReleaseStream_m2AA2E64882CE0E83389D6B830FF97B6DD144BE0C,
	Encoder_Init_m13EF3D6427847BA6B0F84645F1E01CFBD18D1821,
	Encoder_FlushData_m7ED14A883D2164F0EE30A06E347C6980354741FB,
	Encoder_FlushStream_m861690A1C22E9EED6CC42BFF8BE78198352C55E4,
	Encoder_CloseStream_mD1DF717FD8C2B82EC56F06B10BAAE16F5ACA913A,
	Encoder_Encode_m398A62450844859DFD301BA94B9554BE40E95873,
	Encoder_ShiftLow_mF506A156F6A06E32A3BC8F1F91944FBA04DDB822,
	Encoder_EncodeDirectBits_m0EC8F378A332BB941335FAB80C7AA7680CDC5FD1,
	Encoder_EncodeBit_m75FC926A2B1D8FF0D7BE6C63429993325FAF38A0,
	Encoder_GetProcessedSizeAdd_mD4DA7E3B928C2EBC97DE6FD925FE3AD2A1FAA96E,
	Encoder__ctor_m20D804BD52871197013B2523C009BEC6812BF2AF,
	Decoder_Init_m221FEEB1072ED329F543756BDDED53F1987DFC4D,
	Decoder_ReleaseStream_m52B3EDA96370FB3E74FF6FE84E8AAD85C0EC60DD,
	Decoder_CloseStream_m652DF60156E652B320D89FE5DF83F985D5FFF2A4,
	Decoder_Normalize_mD1F2BBEF3111433799CB9D6C7F560F8248D30EF8,
	Decoder_Normalize2_mFC680B204DFFC5ACF23C1EFBC25DEE9EDB6BDD4E,
	Decoder_GetThreshold_m08EF976172F0B95C707FD35FAC47527BEEC051AD,
	Decoder_Decode_m43FF146DEA654F8066A5772C3447C212F2882FA2,
	Decoder_DecodeDirectBits_m91B29A5AC9C84F7870311751DA37F542EA6294B9,
	Decoder_DecodeBit_m4DDBA59EAF5D7948A233DE94D0BEF41802BF03E6,
	Decoder__ctor_mD47AE642523D2D79FC438883442ADD65B4374833,
	BitEncoder_Init_m68426CA151D731E44F85CC306F3E1B9836E5458F,
	BitEncoder_UpdateModel_m51B34A64E13E85FA2B3184935A8E3F5BAE221737,
	BitEncoder_Encode_mCD58F1E637387163CEAC3D7208F47513D859E22A,
	BitEncoder__cctor_m00874CCD332C7D1F3047D0840667A42259CC0EDD,
	BitEncoder_GetPrice_m40EB541A9EF40C99EC13BF1077D202DA91A58A90,
	BitEncoder_GetPrice0_m02FA7E2289C8EF43EFDAF814804ABE45A0D43541,
	BitEncoder_GetPrice1_mD6A5B31A0488E4CA5EE5F6DDB6DB77C5552AF3E9,
	BitDecoder_UpdateModel_m5CF8F08A017DBC16703DBEA50660E3E8E6C88A7B,
	BitDecoder_Init_m7EA9C8B1CDA48D2F5E2F3929DDB7916D6EA6F4AA,
	BitDecoder_Decode_mBCEA763F5D3E5F60E81B2ABE5DCB9B290A8EBAE5,
	BitTreeEncoder__ctor_m5F0DA5C9AC03B1FE073C3B90A90C2F465A306CAB,
	BitTreeEncoder_Init_m0A0B663FF70A3CBFC3C8D68B3863C0FC77C74605,
	BitTreeEncoder_Encode_mCDDBB85FB3EA58ECFCDD475FFEB02C417A31A116,
	BitTreeEncoder_ReverseEncode_m4FC699263B0397DFCAD5BE718A81D2C1FF9C1FFE,
	BitTreeEncoder_GetPrice_m7F02D425B2E6F5D5B32EDD966A7311EEEDA39E46,
	BitTreeEncoder_ReverseGetPrice_m15BE0BEBC99B1F31865AFA37848A3DCF1427E59C,
	BitTreeEncoder_ReverseGetPrice_mD4EF00A5B3FC7A03DE33B6286F3B42CBCBF6A22D,
	BitTreeEncoder_ReverseEncode_m0F6FB151A1FA471BD91631E132C0A9B90AF6EFAF,
	BitTreeDecoder__ctor_mAACC7C1607730AF43769ED463FB1F9929A9532CF,
	BitTreeDecoder_Init_m777D61C2C472606D0A64286FE0DB66DE6AB45856,
	BitTreeDecoder_Decode_m86B18873A6849B019532F906DC4507A75B937810,
	BitTreeDecoder_ReverseDecode_mD907A6D635552C372B458A987213A6D2AE7D31F7,
	BitTreeDecoder_ReverseDecode_mC031E5F166F2F9DA57359370F95057393292EA64,
	Base_GetLenToPosState_m67939A0C9306049FC9AAEA2E973B7A4DACBAA637,
	Base__ctor_mF4E7C9566FEDEFED86FD118AF8BAA26488F48E61,
	State_Init_m2C7DFCBA2E97DBA2C4F0DDA7FF5C7BF0D28346BF,
	State_UpdateChar_m6440A75D3A569E66B39A9B2794ECABB71D6AB517,
	State_UpdateMatch_m24D8D8072CC69D6C52FE4405AAD1B7B35D46F3BC,
	State_UpdateRep_m975104264E0D9A3AC8484C17614E4807F3E51219,
	State_UpdateShortRep_m615DAF95E40EBB8DFB08C19BD5EA73F18B4F3547,
	State_IsCharState_mD09239444CBEBD37FDBF95A5699B4F30DCF79611,
	Decoder__ctor_mDDDDEB045F01F09EAD0D32614A93446BFAFF0F65,
	Decoder_SetDictionarySize_mE840C63A009B5CC2E341874797F0B67F4F3EE997,
	Decoder_SetLiteralProperties_m0B0E9EC6D6E93FEB88837436B03074F9F56A3602,
	Decoder_SetPosBitsProperties_mADA9B8DD5721101822809B23B58E7C28C63A0573,
	Decoder_Init_m4180E0DF2C7ADD2E7D33DE0622C4A3D82E0D0A34,
	Decoder_Code_m3113243939972AD7004EC97C6EDE302AFB7319DF,
	Decoder_SetDecoderProperties_m5A19504FC6AAA414092173B3F0E24CAC5C555C90,
	Decoder_Train_mBF54EDD27F7BD7911AC11B6DE145A25B4D37506D,
	LenDecoder_Create_mCD3DC4DA25337601A87364AD4F3DEAEAE187E105,
	LenDecoder_Init_m0DA88D04AD1D3EA2F973B0D227D6E230E125E9B5,
	LenDecoder_Decode_m3959505C181AEEA8500F7245A4CFA35602246AB0,
	LenDecoder__ctor_mFFE500BFCE0698FACBC360D307203F551C5DE20F,
	LiteralDecoder_Create_mAA7D107BCB9D26B7F92B7962EE03F9C00C0DA251,
	LiteralDecoder_Init_m452663AE2B5B01AA9D227E011DF7F7B3B6B0F1FD,
	LiteralDecoder_GetState_m5F4212B08F492B9620C00872DA185A3E190F7749,
	LiteralDecoder_DecodeNormal_m89B1EF9C679565CB7F6DB4ACD7550DFCA906A9CE,
	LiteralDecoder_DecodeWithMatchByte_mF3AA32C6B79BBA2DDE5D004A673239E6614A426B,
	LiteralDecoder__ctor_m4E7D227A3D749FA5D3CB84AF81CC2E05B4051137,
	Decoder2_Create_m434789D58C48A4C42D1BBAF67312DB317DFAC198,
	Decoder2_Init_m1317F802E071CF00C530D02199453A93F109B15A,
	Decoder2_DecodeNormal_m20A55707B43292AD6AE85106A0E2E8151C38CB22,
	Decoder2_DecodeWithMatchByte_m3E243459999F5EC8F0212E810BC668ED2067B27A,
	Encoder__cctor_m904379D9FBD92EAFFF12D89897CD055A53A42328,
	Encoder_GetPosSlot_m3053180D2945043563DD3B9393B911A1869A77DD,
	Encoder_GetPosSlot2_mC15EEF960E842F2E7217063572158B78CA1D9BBD,
	Encoder_BaseInit_m8A6C90546ABE82A188C4CF3FE23071AAF84595BE,
	Encoder_Create_m40ADF517795C813437B29009BBF729956A077213,
	Encoder__ctor_m80F5A4953728599944772AC2299B9F850D5E10C1,
	Encoder_SetWriteEndMarkerMode_mDBCCF1276B46DA5EA3D2ED0AF56CE1819F73B669,
	Encoder_Init_mA2B40AE20643BE05950A4F95E750BA432A4CF75F,
	Encoder_ReadMatchDistances_m50B63384861CDF22505DB5644678CACCD87494E2,
	Encoder_MovePos_mB1DEF79455AD173D6AC5C2AA6188119D8133A1DC,
	Encoder_GetRepLen1Price_m5E0FA43C565AC943921D5E8B644CA89936781AE9,
	Encoder_GetPureRepPrice_mDCFECC0A28D28968BFAD79E34541FAF6B2A1E952,
	Encoder_GetRepPrice_mC87B302D13B41CE7C66F0B895E1A221174E2E6A7,
	Encoder_GetPosLenPrice_mD289C27BD1D43A529ECBADAAFD2C08E3DD3BB499,
	Encoder_Backward_mBCB4B7DE5F14A2EC438698526D49B9477F3E19A3,
	Encoder_GetOptimum_mB72B5EE5AC0A852261985A45F6F010DE33233959,
	Encoder_ChangePair_m647A1017359F4C36CF39091B88B132019E58DE3E,
	Encoder_WriteEndMarker_m30C1E4F47496A79103A1AC799A6FEB397B10AD50,
	Encoder_Flush_mE1A3BDFB6556135386DF58ACC29E24908811D965,
	Encoder_CodeOneBlock_m6E0AEABD9669941A79897D8B899E9D5E0EF65ADA,
	Encoder_ReleaseMFStream_m1E317AAE9EED580BA684312CBD36EB4504C0CFAF,
	Encoder_SetOutStream_m958BED8327D46F2DE7919CC3CA44F9373FF4FB1C,
	Encoder_ReleaseOutStream_m328889869428B51DB63AC4AC5B941F9BD16B03B1,
	Encoder_ReleaseStreams_m54FF38FC875C285AC8A7B429B48E0B4B37CBE870,
	Encoder_SetStreams_mC61C032BF93ECA1549FA694BF29F462DA42F8942,
	Encoder_Code_m09F80B2FC86FB59D645742C5E8D3B1BF07AD2871,
	Encoder_WriteCoderProperties_m5FA4E6313A85A0D0D641867C74F92FFC4FDA6C70,
	Encoder_FillDistancesPrices_m4D81890FF833DDCEE6BEAA2B7ACC2A32D478F013,
	Encoder_FillAlignPrices_m0C9540F3259AA2B9BA5619093734313FE79867CF,
	Encoder_FindMatchFinder_m8D2DF28FE35A05CAF59814B3B5C8F6B731322F9E,
	Encoder_SetCoderProperties_m60402854437C219C22653A8C48E23D0376AB6DE7,
	Encoder_SetTrainSize_m289E652AA20786AE5F6E52C19A0F26B9BEBB4B21,
	LiteralEncoder_Create_m844B7CC4D876A2DE8347CB58DFF1E79C6595E65F,
	LiteralEncoder_Init_m1D2A98DA484A417A47C47C7099F4C0185B87DD63,
	LiteralEncoder_GetSubCoder_mFD16D22EA8FF3B1DEE2D248ED150C74CBB0F1C98,
	LiteralEncoder__ctor_m4AB69E9FC19D83054FC50B7025A2B25F953649C9,
	Encoder2_Create_m2EFD56B68C6C8D9E48DE0F454F2378B867D7D705,
	Encoder2_Init_m7BF50A1BE4C1A16A8A59F50FA08EB42BC21870C9,
	Encoder2_Encode_m6A0160C1B25BD97EA8D4141CF3AA2B009B18B040,
	Encoder2_EncodeMatched_m40CC1C9FAA87F4A0DE7B9EAE5670B4E594557DC6,
	Encoder2_GetPrice_m5F4E123994682AD7B7745D7DAB30C44FFFA3E4F9,
	LenEncoder__ctor_mFA498C3CF87F00FFE58AF22747840AB89693E7BC,
	LenEncoder_Init_mCB20EB7AE2DC2D602F671F980E347CF90E7AF4B4,
	LenEncoder_Encode_m5C5A66E2AE0E2CEC12AC66C1EAAFB20E8D7305A1,
	LenEncoder_SetPrices_m5E4FFDC23F07D67E39DD8C0A5CF9C7D13A7122AD,
	LenPriceTableEncoder_SetTableSize_m3782A45635CBB4364C23B3BA319D2C26BB35EC66,
	LenPriceTableEncoder_GetPrice_m34433F8B9A40D45BD6425AD53FEC96EC37592A8A,
	LenPriceTableEncoder_UpdateTable_m7A4C60ACC6FB0510269DA9DBBEE779B9223377F6,
	LenPriceTableEncoder_UpdateTables_m94C54EE5ADAB9F428658A252B0ACF8BDAA0C3FEA,
	LenPriceTableEncoder_Encode_m5D5C62DBBC98FEFF347B81EDFCE4DA706E56A4B5,
	LenPriceTableEncoder__ctor_m20CFDAA4325B19C1F4ACBC9B38D54BC8B8F7277A,
	Optimal_MakeAsChar_m9ABE4B0B07625B22791F04C27E7A0CB2136194FB,
	Optimal_MakeAsShortRep_mF3E03AF06E3CEA77FA71BDC4C59B22F1FF75F261,
	Optimal_IsShortRep_mB7D67F2732B810C0E5CDBEFBA1BEC689EDCC328D,
	Optimal__ctor_m3FB6ABBDD35AFBDC0E329250861F2F9393C62732,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BinTree_SetType_mF7048130CC2F17776229F63CCAD6F57ADF365F04,
	BinTree_SetStream_mCD63057CD4EDA36D1A82D56D83B844487B90A518,
	BinTree_ReleaseStream_mB27FDCDAB66C744190688AF450D130B774186D65,
	BinTree_Init_mA907B8CAA1CA55C4271A5CE52C6B9215445770EA,
	BinTree_MovePos_m8E9E7DB8F7227CD54E15CA289F1E3B3174D13DD2,
	BinTree_GetIndexByte_m8A695321CE0D96D2524DD050109DFE48F1286D28,
	BinTree_GetMatchLen_m74E4C6B3390A1A8D83FF72C8E6C70EA739E374C4,
	BinTree_GetNumAvailableBytes_m4119C3A869C7B2264BF5D5F6CB3FF945C118ECF5,
	BinTree_Create_m82B68043BD459A38FBBFC40A2D1350FBBD1487E5,
	BinTree_GetMatches_m8A3F09A5472E784DF429241398ACF83928DC8253,
	BinTree_Skip_m5835FFC65918A658118B82289B1DBEB54039F767,
	BinTree_NormalizeLinks_mEC655AEE21AE0EC66FD0D329D56143935D8158CD,
	BinTree_Normalize_m2DC38A434D1E156140F6658BB10A8A60EEBBB87C,
	BinTree_SetCutValue_m0C646F5C232E8EE83733DF42E13A27E229E82EB9,
	BinTree__ctor_m6E9B35C783832E205CAC6D0E85254FCEF098793D,
	InWindow_MoveBlock_m06FD6CA0E8DC9136AEDA4A08258D67417464354C,
	InWindow_ReadBlock_m2EFC773855F92AA1AC2307EF8C8825CA7F489917,
	InWindow_Free_m6A3E286EDB95287BF35068BEFABBE3B6AFE898EB,
	InWindow_Create_m4582B01803966271E73CC0C4A3F0A9095AF1C1D8,
	InWindow_SetStream_m3FD3756AB33D319D87A0520126223F964DDBBD9D,
	InWindow_ReleaseStream_mBCBE6CF63BE912AEE4E34F6C9C989F0A2CD5C41A,
	InWindow_Init_m31606786F9FE7AC0197630B1C0B316A5223B0E20,
	InWindow_MovePos_m4A4E5ACDEF823FE8E2E8798DEFCD91DB3F276934,
	InWindow_GetIndexByte_mD8D377EFB6DF5076A0A0656AA20061C73395098A,
	InWindow_GetMatchLen_m1D091B1309886259F3B31BF8421AC614081EE250,
	InWindow_GetNumAvailableBytes_m47E431B2DA3B04F0051C3DF5978521131AF1D33A,
	InWindow_ReduceOffsets_m561D4491BA9E730EF6FD0C9A48E3C79420A7253E,
	InWindow__ctor_mA032BE6BADEFAD6E7D3E125317029E52BABED488,
	OutWindow_Create_m297D76E8B4421BC651C24E0FA75AAD41431DF0EE,
	OutWindow_Init_m42DCD6EE7C17E813DA8F8E92CD49EEE1FEF4CCCD,
	OutWindow_Train_m998C5DC98908C1265D29734BBF96F15A35FE8249,
	OutWindow_ReleaseStream_m4AEE4EEA2F074830F4BF5B81587B18E089E12655,
	OutWindow_Flush_m1C7B5B20BCEC59A088DDB252B522422DB7BD68AB,
	OutWindow_CopyBlock_m2E07B5AF59C4892D7C73C2CCAF738098E62D0D9D,
	OutWindow_PutByte_m1992D1AA6471D3D21A1C738E0501B6288D923627,
	OutWindow_GetByte_mF3CFE942C5427EE578B5D7233E3B9D6CCE596B06,
	OutWindow__ctor_m07E707DF1D5B7012DCE5080C201125600AE25146,
	InBuffer__ctor_m1519854005664D99A38320EAC4193D2FFE4B5E35,
	InBuffer_Init_mB7A99222B8786DF353FC2BCC1149FB7E489637D5,
	InBuffer_ReadBlock_m5EA871C9102AA90461C31291B821BF0556DE1700,
	InBuffer_ReleaseStream_m5349B2EEE46E43A9E39E03120B8564BFE8091663,
	InBuffer_ReadByte_mA84D801E7CD1CFFA14C97BB854EF680E3F511438,
	InBuffer_ReadByte_m0E7F1B67484CA2175FD9D3E593544679D61B86DB,
	InBuffer_GetProcessedSize_mC77A0BC4E80664004CA287A25C477ACA14B408CE,
	OutBuffer__ctor_mC219CDFE2418F8F0989ADFD4703CC0E491FAA80F,
	OutBuffer_SetStream_mCD5C2CD28A3117A959364818880D808506F1CF8F,
	OutBuffer_FlushStream_mA74FC9E653629F2F6828CF2CE8D77B45652129D5,
	OutBuffer_CloseStream_m7B0E84847EF253A20F49EDD470FFD93E8E258471,
	OutBuffer_ReleaseStream_m97AEE4C40E4642FF4C9752F5F0A34345508E8971,
	OutBuffer_Init_m2F94DE0DD7A61836D96CB70BF455E24F79C1023B,
	OutBuffer_WriteByte_m61AD60E103BB5092DA2B41D1F17AE5F856B2F9F4,
	OutBuffer_FlushData_m872430FB7F724D504C377F48BD5FA6A3785B13C5,
	OutBuffer_GetProcessedSize_mFB8261D78ECFAEB0D72D0DEC9CF7CFA5A2B12550,
	SwitchForm__ctor_m3511B91754817A339912089D3F1554DC7C0DDC55,
	SwitchForm__ctor_mD6BD25C5620B3589E7B3A23354DFCC2C3FD6DE2F,
	SwitchForm__ctor_m6710ADCDAF1EAE7E477C698E8C01432704DA7E5A,
	SwitchResult__ctor_m0AFED1002B17157D5B1A01029271BFF97B658F45,
	Parser__ctor_m4115EA2710211958519E7E6251249ADFBAB2DDAF,
	Parser_ParseString_m41BADFED49F04FD70F96C4C7B273D3E732631C7A,
	Parser_ParseStrings_mE066889B309C8C59D359CA08BB561560874EDE95,
	Parser_get_Item_m6E0C83B2C60167230C59CA4C6CB2F30F7973972D,
	Parser_ParseCommand_m763C1F67499ABEE651D2130E03D972F810996BA2,
	Parser_ParseSubCharsCommand_mC6ED1B8784F3F4C1090A5412E9B2E4906460BCFE,
	Parser_IsItSwitchChar_mBAA397855C963D11B309395FEEBDD3BF57C34722,
	CommandForm__ctor_m1DA3E356F916F3B483DB4B41E0ECDFDCACF01933,
	CommandSubCharsSet__ctor_m4BC3AF6B894ECEF54D58E88051A6C59C911E0723,
};
extern void U3CAsyncWaitForCompletionU3Ed__10_MoveNext_m7AE96D202005CC27A2EBEB47057FADA081D6DCDA_AdjustorThunk (void);
extern void U3CAsyncWaitForCompletionU3Ed__10_SetStateMachine_m6240E5A12BCFEF8EA8588C4C18B3BB48BBA71FBB_AdjustorThunk (void);
extern void U3CAsyncWaitForRewindU3Ed__11_MoveNext_m5E01823C6DBEFF1763AD6606972918D90935D340_AdjustorThunk (void);
extern void U3CAsyncWaitForRewindU3Ed__11_SetStateMachine_m3F25AF370573B0A32A25D5D01483AF62C16AD5C3_AdjustorThunk (void);
extern void U3CAsyncWaitForKillU3Ed__12_MoveNext_mC10BB60238B855C88268AEE7DA0D7E8CF59AC885_AdjustorThunk (void);
extern void U3CAsyncWaitForKillU3Ed__12_SetStateMachine_m7BC3B905F4C08F129E4E6DFD12DDA73E5756DD0B_AdjustorThunk (void);
extern void U3CAsyncWaitForElapsedLoopsU3Ed__13_MoveNext_mF44348C1C974B48E1B0F6FE03AD1F713A4A6F8A2_AdjustorThunk (void);
extern void U3CAsyncWaitForElapsedLoopsU3Ed__13_SetStateMachine_m4D5053D74FA671E83FA48E11A3EE5C6534F995AB_AdjustorThunk (void);
extern void U3CAsyncWaitForPositionU3Ed__14_MoveNext_mB726C581B4A8055414678A86C800C4A0525E5121_AdjustorThunk (void);
extern void U3CAsyncWaitForPositionU3Ed__14_SetStateMachine_m060A3B894F6700B46D57FD2443F396C7C9CC7111_AdjustorThunk (void);
extern void U3CAsyncWaitForStartU3Ed__15_MoveNext_mDBD2BBC1B727D4C915B0E2AB910330411086BC12_AdjustorThunk (void);
extern void U3CAsyncWaitForStartU3Ed__15_SetStateMachine_m3B0B96BE14F355F5A0AF74DD42C7774158140A41_AdjustorThunk (void);
extern void BitEncoder_Init_m68426CA151D731E44F85CC306F3E1B9836E5458F_AdjustorThunk (void);
extern void BitEncoder_UpdateModel_m51B34A64E13E85FA2B3184935A8E3F5BAE221737_AdjustorThunk (void);
extern void BitEncoder_Encode_mCD58F1E637387163CEAC3D7208F47513D859E22A_AdjustorThunk (void);
extern void BitEncoder_GetPrice_m40EB541A9EF40C99EC13BF1077D202DA91A58A90_AdjustorThunk (void);
extern void BitEncoder_GetPrice0_m02FA7E2289C8EF43EFDAF814804ABE45A0D43541_AdjustorThunk (void);
extern void BitEncoder_GetPrice1_mD6A5B31A0488E4CA5EE5F6DDB6DB77C5552AF3E9_AdjustorThunk (void);
extern void BitDecoder_UpdateModel_m5CF8F08A017DBC16703DBEA50660E3E8E6C88A7B_AdjustorThunk (void);
extern void BitDecoder_Init_m7EA9C8B1CDA48D2F5E2F3929DDB7916D6EA6F4AA_AdjustorThunk (void);
extern void BitDecoder_Decode_mBCEA763F5D3E5F60E81B2ABE5DCB9B290A8EBAE5_AdjustorThunk (void);
extern void BitTreeEncoder__ctor_m5F0DA5C9AC03B1FE073C3B90A90C2F465A306CAB_AdjustorThunk (void);
extern void BitTreeEncoder_Init_m0A0B663FF70A3CBFC3C8D68B3863C0FC77C74605_AdjustorThunk (void);
extern void BitTreeEncoder_Encode_mCDDBB85FB3EA58ECFCDD475FFEB02C417A31A116_AdjustorThunk (void);
extern void BitTreeEncoder_ReverseEncode_m4FC699263B0397DFCAD5BE718A81D2C1FF9C1FFE_AdjustorThunk (void);
extern void BitTreeEncoder_GetPrice_m7F02D425B2E6F5D5B32EDD966A7311EEEDA39E46_AdjustorThunk (void);
extern void BitTreeEncoder_ReverseGetPrice_m15BE0BEBC99B1F31865AFA37848A3DCF1427E59C_AdjustorThunk (void);
extern void BitTreeDecoder__ctor_mAACC7C1607730AF43769ED463FB1F9929A9532CF_AdjustorThunk (void);
extern void BitTreeDecoder_Init_m777D61C2C472606D0A64286FE0DB66DE6AB45856_AdjustorThunk (void);
extern void BitTreeDecoder_Decode_m86B18873A6849B019532F906DC4507A75B937810_AdjustorThunk (void);
extern void BitTreeDecoder_ReverseDecode_mD907A6D635552C372B458A987213A6D2AE7D31F7_AdjustorThunk (void);
extern void State_Init_m2C7DFCBA2E97DBA2C4F0DDA7FF5C7BF0D28346BF_AdjustorThunk (void);
extern void State_UpdateChar_m6440A75D3A569E66B39A9B2794ECABB71D6AB517_AdjustorThunk (void);
extern void State_UpdateMatch_m24D8D8072CC69D6C52FE4405AAD1B7B35D46F3BC_AdjustorThunk (void);
extern void State_UpdateRep_m975104264E0D9A3AC8484C17614E4807F3E51219_AdjustorThunk (void);
extern void State_UpdateShortRep_m615DAF95E40EBB8DFB08C19BD5EA73F18B4F3547_AdjustorThunk (void);
extern void State_IsCharState_mD09239444CBEBD37FDBF95A5699B4F30DCF79611_AdjustorThunk (void);
extern void Decoder2_Create_m434789D58C48A4C42D1BBAF67312DB317DFAC198_AdjustorThunk (void);
extern void Decoder2_Init_m1317F802E071CF00C530D02199453A93F109B15A_AdjustorThunk (void);
extern void Decoder2_DecodeNormal_m20A55707B43292AD6AE85106A0E2E8151C38CB22_AdjustorThunk (void);
extern void Decoder2_DecodeWithMatchByte_m3E243459999F5EC8F0212E810BC668ED2067B27A_AdjustorThunk (void);
extern void Encoder2_Create_m2EFD56B68C6C8D9E48DE0F454F2378B867D7D705_AdjustorThunk (void);
extern void Encoder2_Init_m7BF50A1BE4C1A16A8A59F50FA08EB42BC21870C9_AdjustorThunk (void);
extern void Encoder2_Encode_m6A0160C1B25BD97EA8D4141CF3AA2B009B18B040_AdjustorThunk (void);
extern void Encoder2_EncodeMatched_m40CC1C9FAA87F4A0DE7B9EAE5670B4E594557DC6_AdjustorThunk (void);
extern void Encoder2_GetPrice_m5F4E123994682AD7B7745D7DAB30C44FFFA3E4F9_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[46] = 
{
	{ 0x0600013F, U3CAsyncWaitForCompletionU3Ed__10_MoveNext_m7AE96D202005CC27A2EBEB47057FADA081D6DCDA_AdjustorThunk },
	{ 0x06000140, U3CAsyncWaitForCompletionU3Ed__10_SetStateMachine_m6240E5A12BCFEF8EA8588C4C18B3BB48BBA71FBB_AdjustorThunk },
	{ 0x06000141, U3CAsyncWaitForRewindU3Ed__11_MoveNext_m5E01823C6DBEFF1763AD6606972918D90935D340_AdjustorThunk },
	{ 0x06000142, U3CAsyncWaitForRewindU3Ed__11_SetStateMachine_m3F25AF370573B0A32A25D5D01483AF62C16AD5C3_AdjustorThunk },
	{ 0x06000143, U3CAsyncWaitForKillU3Ed__12_MoveNext_mC10BB60238B855C88268AEE7DA0D7E8CF59AC885_AdjustorThunk },
	{ 0x06000144, U3CAsyncWaitForKillU3Ed__12_SetStateMachine_m7BC3B905F4C08F129E4E6DFD12DDA73E5756DD0B_AdjustorThunk },
	{ 0x06000145, U3CAsyncWaitForElapsedLoopsU3Ed__13_MoveNext_mF44348C1C974B48E1B0F6FE03AD1F713A4A6F8A2_AdjustorThunk },
	{ 0x06000146, U3CAsyncWaitForElapsedLoopsU3Ed__13_SetStateMachine_m4D5053D74FA671E83FA48E11A3EE5C6534F995AB_AdjustorThunk },
	{ 0x06000147, U3CAsyncWaitForPositionU3Ed__14_MoveNext_mB726C581B4A8055414678A86C800C4A0525E5121_AdjustorThunk },
	{ 0x06000148, U3CAsyncWaitForPositionU3Ed__14_SetStateMachine_m060A3B894F6700B46D57FD2443F396C7C9CC7111_AdjustorThunk },
	{ 0x06000149, U3CAsyncWaitForStartU3Ed__15_MoveNext_mDBD2BBC1B727D4C915B0E2AB910330411086BC12_AdjustorThunk },
	{ 0x0600014A, U3CAsyncWaitForStartU3Ed__15_SetStateMachine_m3B0B96BE14F355F5A0AF74DD42C7774158140A41_AdjustorThunk },
	{ 0x060001EC, BitEncoder_Init_m68426CA151D731E44F85CC306F3E1B9836E5458F_AdjustorThunk },
	{ 0x060001ED, BitEncoder_UpdateModel_m51B34A64E13E85FA2B3184935A8E3F5BAE221737_AdjustorThunk },
	{ 0x060001EE, BitEncoder_Encode_mCD58F1E637387163CEAC3D7208F47513D859E22A_AdjustorThunk },
	{ 0x060001F0, BitEncoder_GetPrice_m40EB541A9EF40C99EC13BF1077D202DA91A58A90_AdjustorThunk },
	{ 0x060001F1, BitEncoder_GetPrice0_m02FA7E2289C8EF43EFDAF814804ABE45A0D43541_AdjustorThunk },
	{ 0x060001F2, BitEncoder_GetPrice1_mD6A5B31A0488E4CA5EE5F6DDB6DB77C5552AF3E9_AdjustorThunk },
	{ 0x060001F3, BitDecoder_UpdateModel_m5CF8F08A017DBC16703DBEA50660E3E8E6C88A7B_AdjustorThunk },
	{ 0x060001F4, BitDecoder_Init_m7EA9C8B1CDA48D2F5E2F3929DDB7916D6EA6F4AA_AdjustorThunk },
	{ 0x060001F5, BitDecoder_Decode_mBCEA763F5D3E5F60E81B2ABE5DCB9B290A8EBAE5_AdjustorThunk },
	{ 0x060001F6, BitTreeEncoder__ctor_m5F0DA5C9AC03B1FE073C3B90A90C2F465A306CAB_AdjustorThunk },
	{ 0x060001F7, BitTreeEncoder_Init_m0A0B663FF70A3CBFC3C8D68B3863C0FC77C74605_AdjustorThunk },
	{ 0x060001F8, BitTreeEncoder_Encode_mCDDBB85FB3EA58ECFCDD475FFEB02C417A31A116_AdjustorThunk },
	{ 0x060001F9, BitTreeEncoder_ReverseEncode_m4FC699263B0397DFCAD5BE718A81D2C1FF9C1FFE_AdjustorThunk },
	{ 0x060001FA, BitTreeEncoder_GetPrice_m7F02D425B2E6F5D5B32EDD966A7311EEEDA39E46_AdjustorThunk },
	{ 0x060001FB, BitTreeEncoder_ReverseGetPrice_m15BE0BEBC99B1F31865AFA37848A3DCF1427E59C_AdjustorThunk },
	{ 0x060001FE, BitTreeDecoder__ctor_mAACC7C1607730AF43769ED463FB1F9929A9532CF_AdjustorThunk },
	{ 0x060001FF, BitTreeDecoder_Init_m777D61C2C472606D0A64286FE0DB66DE6AB45856_AdjustorThunk },
	{ 0x06000200, BitTreeDecoder_Decode_m86B18873A6849B019532F906DC4507A75B937810_AdjustorThunk },
	{ 0x06000201, BitTreeDecoder_ReverseDecode_mD907A6D635552C372B458A987213A6D2AE7D31F7_AdjustorThunk },
	{ 0x06000205, State_Init_m2C7DFCBA2E97DBA2C4F0DDA7FF5C7BF0D28346BF_AdjustorThunk },
	{ 0x06000206, State_UpdateChar_m6440A75D3A569E66B39A9B2794ECABB71D6AB517_AdjustorThunk },
	{ 0x06000207, State_UpdateMatch_m24D8D8072CC69D6C52FE4405AAD1B7B35D46F3BC_AdjustorThunk },
	{ 0x06000208, State_UpdateRep_m975104264E0D9A3AC8484C17614E4807F3E51219_AdjustorThunk },
	{ 0x06000209, State_UpdateShortRep_m615DAF95E40EBB8DFB08C19BD5EA73F18B4F3547_AdjustorThunk },
	{ 0x0600020A, State_IsCharState_mD09239444CBEBD37FDBF95A5699B4F30DCF79611_AdjustorThunk },
	{ 0x0600021D, Decoder2_Create_m434789D58C48A4C42D1BBAF67312DB317DFAC198_AdjustorThunk },
	{ 0x0600021E, Decoder2_Init_m1317F802E071CF00C530D02199453A93F109B15A_AdjustorThunk },
	{ 0x0600021F, Decoder2_DecodeNormal_m20A55707B43292AD6AE85106A0E2E8151C38CB22_AdjustorThunk },
	{ 0x06000220, Decoder2_DecodeWithMatchByte_m3E243459999F5EC8F0212E810BC668ED2067B27A_AdjustorThunk },
	{ 0x06000245, Encoder2_Create_m2EFD56B68C6C8D9E48DE0F454F2378B867D7D705_AdjustorThunk },
	{ 0x06000246, Encoder2_Init_m7BF50A1BE4C1A16A8A59F50FA08EB42BC21870C9_AdjustorThunk },
	{ 0x06000247, Encoder2_Encode_m6A0160C1B25BD97EA8D4141CF3AA2B009B18B040_AdjustorThunk },
	{ 0x06000248, Encoder2_EncodeMatched_m40CC1C9FAA87F4A0DE7B9EAE5670B4E594557DC6_AdjustorThunk },
	{ 0x06000249, Encoder2_GetPrice_m5F4E123994682AD7B7745D7DAB30C44FFFA3E4F9_AdjustorThunk },
};
static const int32_t s_InvokerIndices[674] = 
{
	6292,
	5849,
	7686,
	7120,
	5150,
	5150,
	7896,
	7744,
	8018,
	5150,
	3899,
	1349,
	588,
	939,
	259,
	3899,
	2104,
	1349,
	2163,
	1396,
	5150,
	1554,
	1106,
	1349,
	939,
	2104,
	6594,
	6594,
	6148,
	7062,
	7062,
	7604,
	6498,
	7604,
	7604,
	7604,
	7604,
	7604,
	7604,
	7604,
	7604,
	5150,
	5081,
	4289,
	5150,
	5081,
	4289,
	5150,
	5081,
	4289,
	6166,
	6156,
	6156,
	6156,
	6167,
	5759,
	5493,
	5385,
	5385,
	6147,
	6147,
	5150,
	5142,
	5150,
	5142,
	5150,
	5142,
	5150,
	5142,
	5150,
	5051,
	5150,
	5051,
	5150,
	5142,
	5150,
	5142,
	5142,
	5150,
	5150,
	5142,
	5150,
	5142,
	4343,
	5150,
	5142,
	5150,
	5142,
	4343,
	6164,
	6156,
	6156,
	6594,
	5492,
	5385,
	5385,
	5150,
	5140,
	5150,
	5140,
	5150,
	5140,
	5150,
	5081,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	6573,
	6594,
	6586,
	6573,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	6594,
	6573,
	6594,
	6573,
	6594,
	6594,
	6586,
	6164,
	6164,
	6164,
	6573,
	6594,
	6600,
	6164,
	6156,
	6156,
	6166,
	6156,
	6156,
	6156,
	6164,
	6164,
	6600,
	6594,
	6594,
	6164,
	5492,
	5389,
	5390,
	5492,
	6164,
	6156,
	6156,
	6156,
	6573,
	5478,
	6594,
	5488,
	6573,
	6573,
	6573,
	7273,
	5150,
	5081,
	4289,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	5081,
	4289,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	5150,
	5142,
	4343,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	5150,
	5140,
	4341,
	5150,
	5081,
	4289,
	5150,
	5081,
	4289,
	5150,
	5081,
	4289,
	5150,
	4970,
	4185,
	5150,
	5020,
	4234,
	5150,
	4970,
	4185,
	5150,
	5040,
	4252,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	5150,
	4970,
	4185,
	6586,
	6144,
	7129,
	7129,
	7129,
	6576,
	6589,
	7129,
	6163,
	6163,
	7686,
	7686,
	7686,
	7136,
	7141,
	7686,
	5150,
	5140,
	4341,
	5150,
	5140,
	4341,
	5150,
	4252,
	5150,
	4252,
	5150,
	4252,
	5150,
	4252,
	5150,
	4252,
	5150,
	4252,
	4967,
	4252,
	4967,
	4252,
	4967,
	4252,
	4967,
	2568,
	4967,
	2576,
	4967,
	4252,
	8046,
	8046,
	6310,
	7497,
	7497,
	5477,
	7914,
	7914,
	7914,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	4181,
	5150,
	5150,
	4252,
	4252,
	4252,
	4252,
	4252,
	4252,
	4252,
	5150,
	5150,
	4252,
	4252,
	4252,
	5040,
	7604,
	5040,
	5040,
	5150,
	5150,
	5150,
	0,
	8046,
	5320,
	5320,
	5150,
	5142,
	4343,
	5150,
	5142,
	8046,
	5150,
	4181,
	1545,
	5137,
	6659,
	5934,
	5150,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	5150,
	1249,
	1512,
	2022,
	4235,
	5150,
	8046,
	6922,
	8010,
	7604,
	7604,
	5150,
	7869,
	7268,
	6664,
	6666,
	5506,
	7923,
	7923,
	5863,
	7054,
	5150,
	5150,
	5150,
	5137,
	5150,
	3973,
	5150,
	5150,
	4338,
	5137,
	3973,
	5137,
	5137,
	5137,
	5150,
	5150,
	5137,
	4967,
	4967,
	4967,
	5021,
	5021,
	4235,
	5150,
	2022,
	4235,
	1249,
	4181,
	1512,
	5150,
	5150,
	2541,
	5150,
	5150,
	5150,
	0,
	0,
	0,
	0,
	0,
	4252,
	5150,
	5150,
	5150,
	5150,
	5150,
	1562,
	5150,
	2623,
	1558,
	5021,
	5150,
	4252,
	5150,
	5150,
	5150,
	5150,
	3976,
	1562,
	3973,
	2119,
	5150,
	5150,
	4338,
	2582,
	8046,
	3976,
	5137,
	5137,
	2453,
	5150,
	3975,
	4234,
	5150,
	2582,
	2582,
	3976,
	3976,
	6201,
	5858,
	4234,
	5150,
	3975,
	3975,
	6202,
	7869,
	5150,
	5150,
	5150,
	5150,
	5150,
	5150,
	4967,
	5150,
	4338,
	2372,
	4234,
	2572,
	566,
	4252,
	3146,
	4338,
	5150,
	2115,
	5150,
	2372,
	5150,
	2118,
	1191,
	637,
	5150,
	5150,
	5150,
	3146,
	1688,
	8046,
	7869,
	7869,
	5150,
	5150,
	5150,
	4181,
	5150,
	2163,
	4338,
	2121,
	1367,
	944,
	1366,
	2113,
	2117,
	1750,
	4338,
	4338,
	1396,
	5150,
	4252,
	5150,
	5150,
	1080,
	566,
	4252,
	5150,
	5150,
	7604,
	2572,
	4338,
	2372,
	5150,
	2652,
	5150,
	5150,
	5150,
	2558,
	1495,
	1364,
	5150,
	4338,
	1545,
	1111,
	4338,
	2120,
	4338,
	4338,
	1545,
	5150,
	5150,
	5150,
	4967,
	5150,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4234,
	4252,
	5150,
	5150,
	5150,
	3125,
	1365,
	5137,
	1113,
	3975,
	4338,
	1545,
	5150,
	4338,
	5150,
	5150,
	5150,
	5150,
	1562,
	4252,
	5150,
	5150,
	5150,
	3125,
	1365,
	5137,
	4234,
	5150,
	4338,
	2558,
	3146,
	5150,
	5150,
	2625,
	4181,
	3247,
	5150,
	4338,
	4252,
	4967,
	5150,
	3074,
	4967,
	5138,
	4338,
	4252,
	5150,
	5150,
	5150,
	5150,
	4181,
	5150,
	5138,
	286,
	1048,
	1507,
	5150,
	4234,
	1693,
	2572,
	3836,
	6492,
	5896,
	7506,
	2558,
	5150,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000182, { 0, 1 } },
};
extern const uint32_t g_rgctx_T_t42AC2852DB88E4DFD0661A153111F0C12666BC45;
static const Il2CppRGCTXDefinition s_rgctxValues[1] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t42AC2852DB88E4DFD0661A153111F0C12666BC45 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharpU2Dfirstpass_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpU2Dfirstpass_CodeGenModule = 
{
	"Assembly-CSharp-firstpass.dll",
	674,
	s_methodPointers,
	46,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	1,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
